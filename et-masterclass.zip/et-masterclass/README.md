# ET Masterclass: What Nobody Teaches You About Being a Data Scientist

Two independent 60-minute sessions for junior data scientists.

| | Session 1 · The ML Traps Nobody Warns You About | Session 2 · When a Good Model Fails in the Real World |
|---|---|---|
| Deck (22 / 23 slides, script in speaker notes) | `decks/Session1_ML_Traps.pptx` | `decks/Session2_Good_Model_Fails.pptx` |
| Word-for-word script | `scripts/s1_script.md` (.docx) | `scripts/s2_script.md` (.docx) |
| Notebook | `notebooks/s1_bike_demand.ipynb` | `notebooks/s2_taxi_duration.ipynb` |
| Exported numbers | `outputs/s1/*.csv` | `outputs/s2/*.csv` |

Also: `scripts/quick_reference.md` (one-page five rules + mental model) and `scripts/slide_plan.md` (timings, source of truth).

## Editing loop
- **Words you say:** edit `scripts/sN_script.md`, keeping the `## [NN] Title` headers and the italic timing line, then rebuild. The notes are regenerated from the script.
- **Slide content:** edit `decks/s1.js` / `decks/s2.js`. All numbers are read from `outputs/`, never typed in.
- **Rebuild:** `cd decks && NODE_PATH=../node_modules node s1.js && NODE_PATH=../node_modules node s2.js`
- **Re-run analysis:** `cd notebooks && ../.venv/bin/jupyter nbconvert --to notebook --execute --inplace s1_bike_demand.ipynb` (likewise for s2). The `.py` files are the jupytext source.

Charts are inserted with python-pptx (`decks/add_charts.py`), because Keynote drops pptxgenjs charts. They stay native and editable in PowerPoint, Keynote and Google Slides.

## Data
- UCI Bike Sharing Dataset (id 275), CC BY 4.0, in `data/raw/bike/`
- NYC TLC Yellow Taxi Jan–Mar 2024 parquet + taxi zone lookup, downloaded 2026-10-27, in `data/raw/`
