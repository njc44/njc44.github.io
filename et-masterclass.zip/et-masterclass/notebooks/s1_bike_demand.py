# ---
# jupyter:
#   jupytext:
#     formats: py:percent,ipynb
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Session 1 — The ML Traps Nobody Warns You About
# ## Companion notebook: hourly bike demand (UCI Bike Sharing, Capital Bikeshare, Washington D.C., 2011–2012)
#
# **00 · Provenance**
# - Source: UCI Machine Learning Repository, *Bike Sharing Dataset* (id 275), Fanaee-T & Gama (2013).
#   https://archive.ics.uci.edu/dataset/275/bike+sharing+dataset — licence CC BY 4.0.
# - File used: `hour.csv` (17,379 hourly records, 2011-01-01 → 2012-12-31).
# - Weather fields in the file are *observed* weather for that hour (freemeteo.com), not forecasts.
# - `cnt = casual + registered` — the two sub-counts are part of the outcome.
#
# Every number used on the Session 1 slides is written to `outputs/s1/*.csv` by this notebook.

# %%
import json, platform
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import sklearn
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error

ROOT = Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()
RAW = ROOT / "data/raw/bike/hour.csv"
OUT = ROOT / "outputs/s1"
OUT.mkdir(parents=True, exist_ok=True)
SEED = 42

env = {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__,
       "sklearn": sklearn.__version__, "seed": SEED}
print(env)

# %% [markdown]
# **01 · Load and audit**

# %%
raw = pd.read_csv(RAW, parse_dates=["dteday"])
raw["ts"] = raw["dteday"] + pd.to_timedelta(raw["hr"], unit="h")
full_grid = pd.date_range(raw["ts"].min(), raw["ts"].max(), freq="h")
audit = {
    "rows": len(raw),
    "first_hour": str(raw["ts"].min()),
    "last_hour": str(raw["ts"].max()),
    "hours_in_calendar": len(full_grid),
    "missing_hours": len(full_grid) - len(raw),
    "duplicates": int(raw["ts"].duplicated().sum()),
    "null_cells": int(raw.isna().sum().sum()),
    "cnt_equals_casual_plus_registered": bool((raw["cnt"] == raw["casual"] + raw["registered"]).all()),
    "mean_cnt_2011": round(raw.loc[raw.yr == 0, "cnt"].mean(), 1),
    "mean_cnt_2012": round(raw.loc[raw.yr == 1, "cnt"].mean(), 1),
}
print(json.dumps(audit, indent=2))

# %% [markdown]
# Missing hours are *absent rows*, mostly hours with zero rentals or system outages. So "previous row" is **not**
# "previous hour". We reindex onto a complete hourly grid before building any lag features.

# %%
df = raw.set_index("ts").reindex(full_grid)
df.index.name = "ts"
df["was_missing"] = df["cnt"].isna()
# Calendar fields are knowable for any hour, so rebuild them for the filled rows.
df["hr"] = df.index.hour
df["weekday"] = df.index.dayofweek          # 0 = Monday
df["mnth"] = df.index.month
df["yr"] = df.index.year - 2011
df["dteday"] = df.index.normalize()
hol = raw.groupby("dteday")["holiday"].max()
df["holiday"] = df["dteday"].map(hol).fillna(0).astype(int)
df["workingday"] = ((df["weekday"] < 5) & (df["holiday"] == 0)).astype(int)
df["season"] = df["dteday"].map(raw.groupby("dteday")["season"].first()).ffill().astype(int)
for c in ["weathersit", "temp", "atemp", "hum", "windspeed"]:
    df[c] = df[c].ffill()
df["cnt"] = df["cnt"].fillna(0)               # a missing hour = no recorded rentals
for c in ["casual", "registered"]:
    df[c] = df[c].fillna(0)

# %% [markdown]
# **02 · Define the task (the prediction-time contract)**
#
# | | |
# |---|---|
# | Decision supported | How many bikes to rebalance / staff to schedule for the coming hour (system level) |
# | Target | `cnt` = total *rentals* started in hour *t* (a proxy — not unmet demand) |
# | Prediction made | at the **start** of hour *t*, i.e. with information up to the end of hour *t−1* |
# | Allowed | calendar of hour *t* (hour, weekday, month, holiday, working day); rentals up to *t−1*; weather observed up to *t−1* (stand-in for a forecast) |
# | Not allowed | `casual`, `registered` of hour *t* (they sum to the target); weather *observed during* hour *t* |

# %%
df["lag_1h"] = df["cnt"].shift(1)
df["lag_24h"] = df["cnt"].shift(24)
df["lag_168h"] = df["cnt"].shift(168)
df["roll_mean_24h"] = df["cnt"].shift(1).rolling(24).mean()
for c in ["weathersit", "temp", "hum", "windspeed"]:
    df[f"{c}_prev_hr"] = df[c].shift(1)

data = df.dropna(subset=["lag_168h", "roll_mean_24h"]).copy()
data = data[~data["was_missing"]]  # evaluate only on hours that are real records

CAL = ["hr", "weekday", "mnth", "holiday", "workingday", "season"]
REALISED_WX = ["weathersit", "temp", "atemp", "hum", "windspeed"]   # observed during target hour
FEATURE_SETS = {
    "A · Everything in the file (incl. casual + registered)": CAL + ["yr"] + REALISED_WX + ["casual", "registered"],
    "B · Calendar + same-hour observed weather": CAL + ["yr"] + REALISED_WX,
    "C · Prediction-time honest: calendar + past demand + last hour's weather":
        CAL + ["lag_1h", "lag_24h", "lag_168h", "roll_mean_24h",
               "weathersit_prev_hr", "temp_prev_hr", "hum_prev_hr", "windspeed_prev_hr"],
}

# %% [markdown]
# **04 · Split.** Chronological: train on everything before 2012-09-01, test on 2012-09-01 → 2012-12-31 (the
# last four months, which the model never sees). Random split as a contrast: 75 / 25 shuffled over the *same rows*.

# %%
SPLIT = pd.Timestamp("2012-09-01")
train_c, test_c = data[data.index < SPLIT], data[data.index >= SPLIT]
train_r, test_r = train_test_split(data, test_size=len(test_c) / len(data), random_state=SEED)

split_info = pd.DataFrame([
    {"split": "Chronological", "train_from": str(train_c.index.min().date()), "train_to": str(train_c.index.max().date()),
     "test_from": str(test_c.index.min().date()), "test_to": str(test_c.index.max().date()),
     "n_train": len(train_c), "n_test": len(test_c)},
    {"split": "Random (shuffled)", "train_from": "mixed", "train_to": "mixed", "test_from": "mixed", "test_to": "mixed",
     "n_train": len(train_r), "n_test": len(test_r)},
])
split_info.to_csv(OUT / "split_info.csv", index=False)
split_info

# %% [markdown]
# **05 · Baselines** (all fitted on the training rows only)

# %%
def metrics(y, p):
    return {"MAE": mean_absolute_error(y, p), "RMSE": float(np.sqrt(mean_squared_error(y, p)))}

def baseline_preds(train, test):
    hw = train.groupby(["weekday", "hr"])["cnt"].mean()
    return {
        "Baseline · training mean": np.full(len(test), train["cnt"].mean()),
        "Baseline · same hour last week": test["lag_168h"].values,
        "Baseline · avg for this weekday × hour": hw.reindex(pd.MultiIndex.from_arrays([test.weekday, test.hr])).values,
    }

def fit_model(train, cols):
    m = HistGradientBoostingRegressor(max_iter=400, learning_rate=0.05, random_state=SEED)
    m.fit(train[cols], train["cnt"])
    return m

# %% [markdown]
# **06 · Models — every candidate scored on the same test rows**

# %%
rows, preds_chrono = [], {}
for split_name, (tr, te) in {"Chronological": (train_c, test_c), "Random": (train_r, test_r)}.items():
    for name, p in baseline_preds(tr, te).items():
        rows.append({"split": split_name, "candidate": name, **metrics(te["cnt"], p)})
        if split_name == "Chronological": preds_chrono[name] = p
    for name, cols in FEATURE_SETS.items():
        p = fit_model(tr, cols).predict(te[cols])
        rows.append({"split": split_name, "candidate": "Model " + name, **metrics(te["cnt"], p)})
        if split_name == "Chronological": preds_chrono["Model " + name] = p

results = pd.DataFrame(rows)
results["MAE"] = results["MAE"].round(1); results["RMSE"] = results["RMSE"].round(1)
results.to_csv(OUT / "results_all.csv", index=False)
print("Mean rentals per hour in chronological test period:", round(test_c["cnt"].mean(), 1))
results.pivot(index="candidate", columns="split", values="MAE")

# %% [markdown]
# **Random vs chronological for the honest model and for model B** — what question does each answer?

# %%
contrast = results[results.candidate.str.startswith(("Model B", "Model C", "Baseline · training mean"))] \
    .pivot(index="candidate", columns="split", values="MAE")
contrast.to_csv(OUT / "split_contrast_mae.csv")
contrast

# %% [markdown]
# Why does the *training mean* baseline differ so much between splits? Because demand grew between 2011 and 2012:

# %%
monthly = df["cnt"].resample("MS").mean().round(1).rename("mean_rentals_per_hour").to_frame()
monthly["period"] = np.where(monthly.index < SPLIT, "train", "test")
monthly.to_csv(OUT / "monthly_mean.csv")
print("Train mean:", round(train_c.cnt.mean(), 1), "| Test mean:", round(test_c.cnt.mean(), 1))

# %% [markdown]
# **07 · Error analysis** (honest model C vs best baseline, chronological test set)

# %%
best_base = "Baseline · avg for this weekday × hour"
mC = [k for k in preds_chrono if k.startswith("Model C")][0]
ea = test_c[["cnt", "hr", "workingday", "weathersit", "dteday"]].copy()
ea["pred_C"] = preds_chrono[mC]
ea["pred_base"] = preds_chrono[best_base]
ea["abs_err_C"] = (ea["cnt"] - ea["pred_C"]).abs()
ea["abs_err_base"] = (ea["cnt"] - ea["pred_base"]).abs()

by_hour = ea.groupby("hr")[["cnt", "abs_err_C", "abs_err_base"]].mean().round(1)
by_hour.to_csv(OUT / "error_by_hour.csv")

q = ea["cnt"].quantile([0.5, 0.9]).values
ea["demand_band"] = pd.cut(ea["cnt"], [-1, q[0], q[1], 1e9],
                           labels=[f"Low (≤{int(q[0])})", f"Mid ({int(q[0])}–{int(q[1])})", f"Peak (>{int(q[1])})"])
by_band = ea.groupby("demand_band", observed=True).agg(
    hours=("cnt", "size"), mean_rentals=("cnt", "mean"), MAE_model=("abs_err_C", "mean"),
    MAE_baseline=("abs_err_base", "mean")).round(1)
by_band["MAE_as_pct_of_demand"] = (100 * by_band.MAE_model / by_band.mean_rentals).round(1)
by_band.to_csv(OUT / "error_by_demand_band.csv")

by_day = ea.assign(daytype=np.where(ea.workingday == 1, "Working day", "Weekend / holiday")) \
    .groupby("daytype")[["cnt", "abs_err_C", "abs_err_base"]].mean().round(1)
by_day.to_csv(OUT / "error_by_daytype.csv")

wx_names = {1: "Clear / cloudy", 2: "Mist", 3: "Light rain / snow", 4: "Heavy rain / storm"}
by_wx = ea.assign(weather=ea.weathersit.map(wx_names)).groupby("weather").agg(
    hours=("cnt", "size"), MAE_model=("abs_err_C", "mean")).round(1)
by_wx.to_csv(OUT / "error_by_weather.csv")

worst_days = ea.groupby("dteday").agg(actual=("cnt", "sum"), predicted=("pred_C", "sum"),
                                      daily_abs_err=("abs_err_C", "sum")).sort_values("daily_abs_err", ascending=False).head(5).round(0)
worst_days.to_csv(OUT / "worst_days.csv")
print(by_band, by_day, by_wx, worst_days, sep="\n\n")

# %% [markdown]
# Share of all absolute error that comes from the peak band — the hours where rebalancing matters most.

# %%
share = ea.groupby("demand_band", observed=True)["abs_err_C"].sum() / ea["abs_err_C"].sum()
share_hours = ea["demand_band"].value_counts(normalize=True)
err_share = pd.DataFrame({"share_of_hours_pct": (100 * share_hours).round(1), "share_of_abs_error_pct": (100 * share).round(1)})
err_share.to_csv(OUT / "error_share_by_band.csv")
err_share

# %% [markdown]
# **Hourly profile for the opening chart** (whole dataset, mean rentals by hour, working day vs not)

# %%
profile = df.assign(daytype=np.where(df.workingday == 1, "Working day", "Weekend / holiday")) \
    .pivot_table(index="hr", columns="daytype", values="cnt", aggfunc="mean").round(1)
profile.to_csv(OUT / "hourly_profile.csv")

# %% [markdown]
# **09 · Figures** (also rebuilt natively in the deck from the CSVs)

# %%
fig, ax = plt.subplots(1, 2, figsize=(13, 4))
profile.plot(ax=ax[0], title="Mean rentals by hour of day"); ax[0].set_ylabel("rentals / hour")
by_hour[["abs_err_C", "abs_err_base"]].plot(ax=ax[1], title="Chronological test: MAE by hour"); ax[1].set_ylabel("MAE (rentals)")
fig.tight_layout(); fig.savefig(OUT / "fig_overview.png", dpi=150)

# %% [markdown]
# **10 · Conclusions** — see printed summary; the interpretation is written in the speaker notes.

# %%
summary = {"env": env, "audit": audit, "split_date": str(SPLIT.date()),
           "test_mean_cnt": round(test_c.cnt.mean(), 1), "train_mean_cnt": round(train_c.cnt.mean(), 1)}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
