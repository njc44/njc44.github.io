# ---
# jupyter:
#   jupytext:
#     formats: py:percent,ipynb
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Session 2 — When a Good Model Fails in the Real World
# ## Companion notebook: NYC yellow-taxi trip duration, predicted at pickup
#
# **00 · Provenance**
# - Source: NYC Taxi & Limousine Commission (TLC) Trip Record Data — Yellow Taxi, Jan, Feb, Mar 2024 (parquet).
#   https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page · files `yellow_tripdata_2024-0{1,2,3}.parquet`
#   from `d37ci6vzurychx.cloudfront.net/trip-data/`; zone lookup `taxi_zone_lookup.csv`. Downloaded 2026-10-27.
# - Data dictionary: https://www.nyc.gov/assets/tlc/downloads/pdf/data_dictionary_trip_records_yellow.pdf
# - Terms: NYC Open Data terms of use. Records are submitted by technology providers; TLC does not guarantee accuracy.
# - Key dictionary facts used here: `trip_distance` = "elapsed trip distance in miles reported by the taximeter" (post-trip);
#   `fare_amount` = "time-and-distance fare calculated by the meter" (post-trip); `PULocationID` / `DOLocationID` = TLC taxi zones.
#
# Every number on the Session 2 slides is written to `outputs/s2/*.csv` by this notebook.

# %%
import json, platform
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import TargetEncoder

ROOT = Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()
RAW = ROOT / "data/raw"
OUT = ROOT / "outputs/s2"
OUT.mkdir(parents=True, exist_ok=True)
SEED = 42
SAMPLE_PER_MONTH = 200_000
env = {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__,
       "sklearn": sklearn.__version__, "seed": SEED, "sample_per_month": SAMPLE_PER_MONTH}
print(env)

# %% [markdown]
# **01 · Load and audit** — only the columns we need.

# %%
COLS = ["tpep_pickup_datetime", "tpep_dropoff_datetime", "PULocationID", "DOLocationID",
        "trip_distance", "fare_amount", "passenger_count", "RatecodeID"]
frames = []
for m in ["01", "02", "03"]:
    d = pd.read_parquet(RAW / f"yellow_2024-{m}.parquet", columns=COLS)
    d["file_month"] = int(m)
    frames.append(d)
raw = pd.concat(frames, ignore_index=True)
zones = pd.read_csv(RAW / "taxi_zone_lookup.csv")
print(len(raw), "rows loaded")
raw.isna().mean().round(4)

# %% [markdown]
# **02 · The prediction-time contract**
#
# | | |
# |---|---|
# | Prediction made | at **pickup** |
# | Target | minutes between `tpep_pickup_datetime` and `tpep_dropoff_datetime` |
# | Scenario S — street hail | known at pickup: time, pickup zone. Destination *not* known. |
# | Scenario D — booked trip | known at pickup: time, pickup zone **and** the destination zone the rider entered |
# | Never an input | drop-off time (it *is* the label), `trip_distance` (taximeter, post-trip), `fare_amount` (meter, post-trip), tips, totals |

# %% [markdown]
# **03 · Cleaning — log every filter**

# %%
d = raw.copy()
d["duration_min"] = (d.tpep_dropoff_datetime - d.tpep_pickup_datetime).dt.total_seconds() / 60
log = [("Loaded (Jan–Mar 2024 files)", len(d))]
def step(mask, label):
    global d
    d = d[mask]
    log.append((label, len(d)))

step(d.tpep_pickup_datetime.notna() & d.tpep_dropoff_datetime.notna(), "Both timestamps present")
step((d.tpep_pickup_datetime.dt.year == 2024) & (d.tpep_pickup_datetime.dt.month == d.file_month),
     "Pickup inside the file's month (drops 2002/2008-dated rows)")
step(d.duration_min > 0, "Duration > 0")
step(d.duration_min >= 1, "Duration ≥ 1 minute")
step(d.duration_min <= 180, "Duration ≤ 180 minutes")
step(~d.PULocationID.isin([264, 265]) & ~d.DOLocationID.isin([264, 265]), "Known pickup & drop-off zone")
step(d.trip_distance > 0, "Metered distance > 0 (malformed / cancelled)")
speed = d.trip_distance / (d.duration_min / 60)
step(speed <= 80, "Average speed ≤ 80 mph")

clean_log = pd.DataFrame(log, columns=["step", "rows_remaining"])
clean_log["rows_removed"] = (-clean_log.rows_remaining.diff()).fillna(0).astype(int)
clean_log["pct_of_loaded_remaining"] = (100 * clean_log.rows_remaining / clean_log.rows_remaining.iloc[0]).round(2)
clean_log.to_csv(OUT / "cleaning_log.csv", index=False)
clean_log

# %% [markdown]
# Daylight saving started 2024-03-10 at 02:00 (clocks jumped to 03:00). Timestamps are local and naive, so a trip that
# spans the jump looks one hour longer than it was. How many are there?

# %%
dst = pd.Timestamp("2024-03-10 02:00")
dst_trips = int(((d.tpep_pickup_datetime < dst) & (d.tpep_dropoff_datetime >= pd.Timestamp("2024-03-10 03:00"))).sum())
print("Trips spanning the DST jump:", dst_trips)

# %% [markdown]
# **Sample** a fixed number of cleaned trips per month (fixed seed) so the notebook runs in minutes.

# %%
d = d.groupby("file_month", group_keys=False).sample(n=SAMPLE_PER_MONTH, random_state=SEED)
d = d.sort_values("tpep_pickup_datetime").reset_index(drop=True)

# %% [markdown]
# **Features available at pickup**

# %%
zb = zones.set_index("LocationID")["Borough"]
zn = zones.set_index("LocationID")["Zone"]
AIRPORTS = {1, 132, 138}  # EWR, JFK, LaGuardia
t = d.tpep_pickup_datetime
d["hour"] = t.dt.hour
d["dow"] = t.dt.dayofweek
d["minute_of_day"] = t.dt.hour * 60 + t.dt.minute
d["is_weekend"] = (d.dow >= 5).astype(int)
d["pu_borough"] = d.PULocationID.map(zb).astype("category").cat.codes
d["do_borough"] = d.DOLocationID.map(zb).astype("category").cat.codes
d["pu_airport"] = d.PULocationID.isin(AIRPORTS).astype(int)
d["do_airport"] = d.DOLocationID.isin(AIRPORTS).astype(int)
d["same_zone"] = (d.PULocationID == d.DOLocationID).astype(int)
d["pair"] = d.PULocationID * 1000 + d.DOLocationID   # route identifier (zone → zone)

TIME = ["hour", "dow", "minute_of_day", "is_weekend"]
FEATURES = {
    "S · Street hail (time + pickup zone)": {"te": ["PULocationID"], "num": TIME + ["pu_borough", "pu_airport"]},
    "D · Booked trip (+ destination zone)": {"te": ["PULocationID", "DOLocationID", "pair"],
                                             "num": TIME + ["pu_borough", "pu_airport", "do_borough", "do_airport", "same_zone"]},
    "L · Leaky (+ metered distance & fare)": {"te": ["PULocationID", "DOLocationID", "pair"],
                                              "num": TIME + ["pu_borough", "pu_airport", "do_borough", "do_airport", "same_zone",
                                                             "trip_distance", "fare_amount"]},
}
audit_rows = [
    ("Pickup timestamp → hour, weekday, minute", "At pickup", "Used"),
    ("Pickup zone", "At pickup", "Used"),
    ("Destination zone", "Only if rider enters it (booking)", "Scenario D only"),
    ("Passenger count", "Entered by driver; unreliable", "Not used"),
    ("Drop-off timestamp", "After trip — it defines the label", "Never"),
    ("trip_distance (taximeter)", "After trip", "Never (leaky demo only)"),
    ("fare_amount (meter)", "After trip", "Never (leaky demo only)"),
    ("Tip, tolls, total_amount, payment type", "After trip", "Never"),
]
pd.DataFrame(audit_rows, columns=["field", "when_known", "use"]).to_csv(OUT / "feature_audit.csv", index=False)

# %% [markdown]
# **04 · Split.** Chronological: train on Jan + Feb, test on March (unseen future month).
# Random contrast: the *same* 600k rows shuffled, test size equal to March's.

# %%
train_c = d[d.file_month <= 2]; test_c = d[d.file_month == 3]
train_r, test_r = train_test_split(d, test_size=len(test_c) / len(d), random_state=SEED)
pd.DataFrame([
    {"split": "Chronological", "train": "2024-01-01 → 2024-02-29", "test": "2024-03-01 → 2024-03-31",
     "n_train": len(train_c), "n_test": len(test_c)},
    {"split": "Random", "train": "shuffled Jan–Mar", "test": "shuffled Jan–Mar", "n_train": len(train_r), "n_test": len(test_r)},
]).to_csv(OUT / "split_info.csv", index=False)
print("Median duration train/test:", train_c.duration_min.median(), test_c.duration_min.median())

# %% [markdown]
# **05–06 · Baselines and model** — all fitted on training rows only; preprocessing lives inside the pipeline.

# %%
def metrics(y, p):
    e = np.abs(y - p)
    return {"MAE": mean_absolute_error(y, p), "RMSE": float(np.sqrt(mean_squared_error(y, p))),
            "P90_abs_err": float(np.quantile(e, 0.9))}

def baselines(tr, te):
    med = tr.duration_min.median()
    hd = tr.groupby(["dow", "hour"]).duration_min.median()
    p_hd = hd.reindex(pd.MultiIndex.from_arrays([te.dow, te.hour])).fillna(med).values
    pr = tr.groupby("pair").duration_min.agg(["median", "size"])
    pr = pr[pr["size"] >= 5]["median"]
    p_pair = te.pair.map(pr).values
    p_pair = np.where(np.isnan(p_pair), p_hd, p_pair)
    return {"Baseline · overall median": np.full(len(te), med),
            "Baseline · median for weekday × hour": p_hd,
            "Baseline · median for this route (zone → zone)": p_pair}

def make_model(spec):
    pre = ColumnTransformer([("te", TargetEncoder(target_type="continuous", random_state=SEED), spec["te"]),
                             ("num", "passthrough", spec["num"])])
    return make_pipeline(pre, HistGradientBoostingRegressor(max_iter=300, learning_rate=0.08, random_state=SEED))

rows, keep = [], {}
for split_name, (tr, te) in {"Chronological": (train_c, test_c), "Random": (train_r, test_r)}.items():
    for name, p in baselines(tr, te).items():
        rows.append({"split": split_name, "candidate": name, **metrics(te.duration_min.values, p)})
        keep[(split_name, name)] = p
    for name, spec in FEATURES.items():
        cols = spec["te"] + spec["num"]
        m = make_model(spec).fit(tr[cols], tr.duration_min)
        p = m.predict(te[cols])
        rows.append({"split": split_name, "candidate": "Model " + name, **metrics(te.duration_min.values, p)})
        keep[(split_name, "Model " + name)] = p
results = pd.DataFrame(rows).round(2)
results.to_csv(OUT / "results_all.csv", index=False)
print("Test mean / median duration (Mar):", round(test_c.duration_min.mean(), 2), round(test_c.duration_min.median(), 2))
results

# %% [markdown]
# **Preprocessing leak demo.** Same Scenario-D model, but the route (pair) median is computed on *all* rows —
# including March — before splitting. Nothing about the model changes; only *when* the encoding was learned.

# %%
spec = FEATURES["D · Booked trip (+ destination zone)"]
leaky_pair = d.groupby("pair").duration_min.median()
def with_pair_stat(df_):
    out = df_.copy(); out["pair_median_all"] = out.pair.map(leaky_pair); return out
cols_leak = ["PULocationID", "DOLocationID"] + spec["num"] + ["pair_median_all"]
pre = ColumnTransformer([("te", TargetEncoder(target_type="continuous", random_state=SEED), ["PULocationID", "DOLocationID"]),
                         ("num", "passthrough", spec["num"] + ["pair_median_all"])])
m_leak = make_pipeline(pre, HistGradientBoostingRegressor(max_iter=300, learning_rate=0.08, random_state=SEED))
m_leak.fit(with_pair_stat(train_c)[cols_leak], train_c.duration_min)
p_leak = m_leak.predict(with_pair_stat(test_c)[cols_leak])
prep_leak = pd.DataFrame([
    {"variant": "Route statistic learned on training months only", **metrics(test_c.duration_min.values, keep[("Chronological", "Model D · Booked trip (+ destination zone)")])},
    {"variant": "Route statistic learned on all months (incl. test)", **metrics(test_c.duration_min.values, p_leak)},
]).round(2)
prep_leak.to_csv(OUT / "preprocessing_leak.csv", index=False)
prep_leak

# %% [markdown]
# **07 · Error analysis** — Model D, chronological test (March).

# %%
MD = "Model D · Booked trip (+ destination zone)"
ea = test_c.copy()
ea["pred"] = keep[("Chronological", MD)]
ea["pred_S"] = keep[("Chronological", "Model S · Street hail (time + pickup zone)")]
ea["pred_route"] = keep[("Chronological", "Baseline · median for this route (zone → zone)")]
ea["err"] = ea.pred - ea.duration_min
ea["abs_err"] = ea.err.abs()

by_hour = ea.groupby("hour").agg(trips=("abs_err", "size"), mean_duration=("duration_min", "mean"),
                                 MAE_model_D=("abs_err", "mean"),
                                 MAE_route_baseline=("pred_route", lambda s: np.abs(s - ea.loc[s.index, "duration_min"]).mean())).round(2)
by_hour.to_csv(OUT / "error_by_hour.csv")

bands = [0, 5, 10, 20, 30, 45, 60, 180]
ea["duration_band"] = pd.cut(ea.duration_min, bands, labels=["1–5", "5–10", "10–20", "20–30", "30–45", "45–60", "60–180"])
by_dur = ea.groupby("duration_band", observed=True).agg(trips=("abs_err", "size"), MAE=("abs_err", "mean"),
                                                        mean_signed_err=("err", "mean")).round(2)
by_dur["share_of_trips_pct"] = (100 * by_dur.trips / by_dur.trips.sum()).round(1)
by_dur.to_csv(OUT / "error_by_duration_band.csv")

# Distance is used ONLY to slice errors after the fact — it is not a model input.
ea["distance_band"] = pd.cut(ea.trip_distance, [0, 1, 2, 5, 10, 20, 200], labels=["<1 mi", "1–2", "2–5", "5–10", "10–20", "20+"])
by_dist = ea.groupby("distance_band", observed=True).agg(trips=("abs_err", "size"), MAE=("abs_err", "mean")).round(2)
by_dist.to_csv(OUT / "error_by_distance_band_posthoc.csv")
print(by_hour, by_dur, by_dist, sep="\n\n")

# %% [markdown]
# **Long tail.** How much of the squared error (what RMSE punishes) comes from the worst 1% / 5% of trips?

# %%
se = np.sort((ea.err ** 2).values)[::-1]
tail = pd.DataFrame([{"worst_pct_of_trips": k, "share_of_squared_error_pct": round(100 * se[:int(len(se) * k / 100)].sum() / se.sum(), 1),
                      "share_of_abs_error_pct": round(100 * np.sort(ea.abs_err.values)[::-1][:int(len(se) * k / 100)].sum() / ea.abs_err.sum(), 1)}
                     for k in [1, 5, 10]])
tail.to_csv(OUT / "long_tail_share.csv", index=False)

hist_edges = [0, 1, 2, 3, 4, 5, 7.5, 10, 15, 20, 30, 60, 180]
h = pd.cut(ea.abs_err, hist_edges, right=False).value_counts(sort=False)
abs_hist = pd.DataFrame({"abs_error_min": [f"{a:g}–{b:g}" for a, b in zip(hist_edges[:-1], hist_edges[1:])],
                         "trips": h.values, "pct": (100 * h.values / h.values.sum()).round(2)})
abs_hist.to_csv(OUT / "abs_error_hist.csv", index=False)

med_ae = float(ea.abs_err.median())
print(tail, abs_hist, "median abs error:", round(med_ae, 2), sep="\n\n")

# %% [markdown]
# Representative worst misses (with zone names) — for hypotheses, not explanations.

# %%
worst = ea.nlargest(8, "abs_err")[["tpep_pickup_datetime", "PULocationID", "DOLocationID", "trip_distance", "duration_min", "pred"]].copy()
worst["pickup_zone"] = worst.PULocationID.map(zn); worst["dropoff_zone"] = worst.DOLocationID.map(zn)
worst = worst.round(1)
worst.to_csv(OUT / "worst_trips.csv", index=False)
typical = ea[(ea.abs_err < 3)].sample(3, random_state=SEED)[["tpep_pickup_datetime", "PULocationID", "DOLocationID", "duration_min", "pred"]]
typical["pickup_zone"] = typical.PULocationID.map(zn); typical["dropoff_zone"] = typical.DOLocationID.map(zn)
typical.round(1).to_csv(OUT / "typical_trips.csv", index=False)
worst

# %% [markdown]
# **Changing conditions within the test month:** daily MAE through March.

# %%
daily = ea.groupby(ea.tpep_pickup_datetime.dt.date).agg(trips=("abs_err", "size"), MAE=("abs_err", "mean"),
                                                         mean_duration=("duration_min", "mean")).round(2)
daily.to_csv(OUT / "daily_mae_march.csv")
daily.sort_values("MAE", ascending=False).head(5)

# %% [markdown]
# **Street hail vs booking** — how much does knowing the destination buy, by trip length?

# %%
sv = ea.groupby("duration_band", observed=True).apply(
    lambda g: pd.Series({"MAE_S_street_hail": np.abs(g.pred_S - g.duration_min).mean(),
                         "MAE_D_booked": g.abs_err.mean()}), include_groups=False).round(2)
sv.to_csv(OUT / "street_vs_booked_by_band.csv")
sv

# %% [markdown]
# **09 · Figures**

# %%
fig, ax = plt.subplots(1, 3, figsize=(16, 4))
by_hour[["MAE_model_D", "MAE_route_baseline"]].plot(ax=ax[0], title="March test: MAE by pickup hour")
abs_hist.plot.bar(x="abs_error_min", y="pct", ax=ax[1], legend=False, title="Absolute error distribution (%)")
by_dur["MAE"].plot.bar(ax=ax[2], title="MAE by actual duration band")
fig.tight_layout(); fig.savefig(OUT / "fig_overview.png", dpi=150)

# %%
summary = {"env": env, "dst_spanning_trips": dst_trips, "median_abs_err_D": round(med_ae, 2),
           "test_mean_duration": round(test_c.duration_min.mean(), 2), "test_median_duration": round(test_c.duration_min.median(), 2),
           "train_median_duration": round(train_c.duration_min.median(), 2), "n_train": len(train_c), "n_test": len(test_c)}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
