// Shared design system for both masterclass decks.
// Motif: every concept slide carries a "kicker" pill (which trap / which step) and ends with
// an "Ask:" chip — the one question that slide teaches you to ask.
const fs = require("fs");
const path = require("path");
const pptxgen = require("pptxgenjs");

const SKILL = "/Users/nathanjacob/.claude/skills/synced/99d537ae-74ab-4d75-bf03-2ab9e70b55cd_2537263d-c5ec-415c-9b69-7119c4426945/pptx";
const { applyTheme } = require(path.join(SKILL, "scripts/apply_theme.js"));

const HEX = {
  ink: "17212B", slate: "3D4C57", mist: "EEF2F1", white: "FFFFFF",
  signal: "E0552B", teal: "1F7A72", gray: "8E9AA3", amber: "E8A33A", sky: "5C8FB8", wine: "9C3D54",
  grid: "DDE3E1", faint: "C9D2CF",
};
const THEME = {
  name: "Masterclass Ink",
  headFontFace: "Cambria",
  bodyFontFace: "Calibri",
  colors: {
    dk1: HEX.ink, lt1: HEX.white, dk2: HEX.slate, lt2: HEX.mist,
    accent1: HEX.signal, accent2: HEX.teal, accent3: HEX.gray, accent4: HEX.amber,
    accent5: HEX.sky, accent6: HEX.wine, hlink: HEX.teal, folHlink: HEX.slate,
  },
};
const W = 13.333, H = 7.5, MX = 0.6;

function newDeck(sessionLabel, title) {
  const pres = new pptxgen();
  pres.layout = "LAYOUT_WIDE";
  pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
  pres.author = "Nathan Jacob";
  pres.title = title;
  const C = pres.SchemeColor;
  const footer = (dark) => [
    { text: { text: `What Nobody Teaches You About Being a Data Scientist  ·  ${sessionLabel}`,
      options: { x: MX, y: 7.02, w: 9, h: 0.3, fontSize: 10, color: dark ? C.accent3 : C.accent3, margin: 0 } } },
  ];
  const num = (dark) => ({ x: 12.2, y: 7.02, w: 0.55, h: 0.3, fontSize: 10, color: C.accent3, align: "right" });

  pres.defineSlideMaster({
    title: "TITLE_DARK", background: { color: C.text1 },
    objects: [
      { placeholder: { options: { name: "kicker", type: "body", x: MX, y: 1.3, w: 10, h: 0.45, fontSize: 16, bold: true, color: C.accent1, margin: 0 }, text: "" } },
      { placeholder: { options: { name: "title", type: "title", x: MX, y: 1.9, w: 11.6, h: 2.2, fontFace: THEME.headFontFace, fontSize: 44, bold: true, color: C.background1, valign: "top", align: "left", margin: 0 }, text: "" } },
      { placeholder: { options: { name: "subtitle", type: "body", x: MX, y: 4.25, w: 11.6, h: 1.0, fontSize: 26, color: C.background2, valign: "top", margin: 0 }, text: "" } },
      { placeholder: { options: { name: "meta", type: "body", x: MX, y: 5.9, w: 11.6, h: 0.8, fontSize: 16, color: C.accent3, valign: "top", margin: 0 }, text: "" } },
    ],
  });
  pres.defineSlideMaster({
    title: "STATEMENT_DARK", background: { color: C.text1 },
    objects: [
      { placeholder: { options: { name: "kicker", type: "body", x: MX + 0.4, y: 1.25, w: 10, h: 0.45, fontSize: 16, bold: true, color: C.accent1, margin: 0 }, text: "" } },
      { placeholder: { options: { name: "title", type: "title", x: MX + 0.4, y: 1.85, w: 11.2, h: 2.6, fontFace: THEME.headFontFace, fontSize: 40, bold: true, color: C.background1, valign: "top", align: "left", margin: 0 }, text: "" } },
      { placeholder: { options: { name: "body", type: "body", x: MX + 0.4, y: 4.7, w: 11.2, h: 1.6, fontSize: 20, color: C.background2, valign: "top", margin: 0 }, text: "" } },
      ...footer(true),
    ],
    slideNumber: num(true),
  });
  pres.defineSlideMaster({
    title: "LIST_DARK", background: { color: C.text1 },
    objects: [
      { placeholder: { options: { name: "title", type: "title", x: MX, y: 0.82, w: 12.1, h: 0.8, fontFace: THEME.headFontFace, fontSize: 32, bold: true, color: C.background1, valign: "top", align: "left", margin: 0 }, text: "" } },
      ...footer(true),
    ],
    slideNumber: num(true),
  });
  pres.defineSlideMaster({
    title: "CONTENT", background: { color: C.background1 },
    margin: [0.5, 0.6, 0.6, 0.6],
    objects: [
      { placeholder: { options: { name: "title", type: "title", x: MX, y: 0.82, w: 12.1, h: 0.8, fontFace: THEME.headFontFace, fontSize: 30, bold: true, color: C.text1, valign: "top", align: "left", margin: 0 }, text: "" } },
      ...footer(false),
    ],
    slideNumber: num(false),
  });
  return { pres, C };
}

// ---------- building blocks ----------
let objN = 0;
const oid = (p) => `${p}-${++objN}`;

function kicker(slide, C, text, opts = {}) {
  const w = Math.max(1.6, 0.11 * text.length + 0.5);
  slide.addShape("roundRect", { x: MX, y: 0.38, w, h: 0.34, rectRadius: 0.17, fill: { color: opts.dark ? C.text2 : C.background2 }, line: { type: "none" }, objectName: oid("kicker-pill") });
  slide.addText(text.toUpperCase(), { x: MX, y: 0.38, w, h: 0.34, fontSize: 11, bold: true, color: C.accent1, align: "center", valign: "middle", margin: 0, charSpacing: 1.5, isTextBox: true, objectName: oid("kicker") });
}

function content(pres, C, section, { kick, title }) {
  const s = pres.addSlide({ masterName: "CONTENT", sectionTitle: section });
  if (kick) kicker(s, C, kick);
  s.addText(title, { placeholder: "title", align: "left" });
  return s;
}

function ask(slide, C, text, y = 6.28) {
  slide.addShape("roundRect", { x: MX, y, w: 12.1, h: 0.56, rectRadius: 0.12, fill: { color: C.background2 }, line: { type: "none" }, objectName: oid("ask-bg") });
  slide.addText([
    { text: "Ask:  ", options: { bold: true, color: C.accent1 } },
    { text, options: { color: C.text1, italic: true } },
  ], { x: MX + 0.25, y, w: 11.6, h: 0.56, fontSize: 16, valign: "middle", margin: 0, isTextBox: true, objectName: oid("ask") });
}

function card(slide, C, x, y, w, h, { head, body, fill, headColor, bodyColor, headSize = 18, bodySize = 14, num, numColor }) {
  slide.addShape("roundRect", { x, y, w, h, rectRadius: 0.1, fill: { color: fill || C.background2 }, line: { type: "none" }, objectName: oid("card") });
  let ty = y + 0.22;
  if (num !== undefined) {
    slide.addShape("ellipse", { x: x + 0.25, y: y + 0.25, w: 0.46, h: 0.46, fill: { color: numColor || C.accent1 }, line: { type: "none" }, objectName: oid("num-dot") });
    slide.addText(String(num), { x: x + 0.25, y: y + 0.25, w: 0.46, h: 0.46, fontSize: 16, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true, objectName: oid("num") });
    ty = y + 0.85;
  }
  if (head) slide.addText(head, { x: x + 0.25, y: ty, w: w - 0.5, h: 0.5, fontSize: headSize, bold: true, color: headColor || C.text1, valign: "top", margin: 0, fontFace: THEME.headFontFace, isTextBox: true, objectName: oid("card-head") });
  if (body) slide.addText(body, { x: x + 0.25, y: ty + (head ? 0.55 : 0), w: w - 0.5, h: h - (ty - y) - (head ? 0.65 : 0.2), fontSize: bodySize, color: bodyColor || C.text2, valign: "top", margin: 0, isTextBox: true, paraSpaceAfter: 4, objectName: oid("card-body") });
}

function bullets(items, opts = {}) {
  return items.map((t, i) => {
    const runs = typeof t === "string" ? { text: t } : t;
    return { text: runs.text, options: { bullet: opts.bullet === false ? false : { indent: 16 }, breakLine: i < items.length - 1, bold: runs.bold, color: runs.color, paraSpaceAfter: opts.space ?? 8 } };
  });
}

function stat(slide, C, x, y, w, { value, label, color, size = 60, labelSize = 14 }) {
  slide.addText(value, { x, y, w, h: size / 60, fontSize: size, bold: true, color: color || C.accent1, fontFace: THEME.headFontFace, margin: 0, valign: "bottom", isTextBox: true, objectName: oid("stat") });
  slide.addText(label, { x, y: y + size / 60 + 0.08, w, h: 0.75, fontSize: labelSize, color: C.text2, margin: 0, valign: "top", isTextBox: true, objectName: oid("stat-label") });
}

function arrowRight(slide, C, x, y, w, color) {
  slide.addShape("line", { x, y, w, h: 0, line: { color: color || HEX.gray, width: 1.75, endArrowType: "triangle" }, objectName: oid("arrow") });
}

function note(slide, C, text, x = MX, y = 5.85, w = 12.1) {
  slide.addText(text, { x, y, w, h: 0.35, fontSize: 11, color: C.accent3, margin: 0, italic: true, isTextBox: true, objectName: oid("caption") });
}

// Consistent native chart styling: same fonts, sizes and colours on every chart.
function chartOpts(C, extra = {}) {
  return {
    catAxisLabelColor: HEX.slate, valAxisLabelColor: HEX.slate,
    catAxisLabelFontSize: 12, valAxisLabelFontSize: 12,
    catAxisLabelFontFace: "+mn-lt", valAxisLabelFontFace: "+mn-lt",
    valGridLine: { color: HEX.grid, size: 0.75 }, catGridLine: { style: "none" },
    catAxisLineShow: true, catAxisLineColor: HEX.faint, valAxisLineShow: false,
    showTitle: true, titleFontSize: 14, titleColor: HEX.ink, titleFontFace: "+mn-lt", titleBold: true,
    dataLabelFontSize: 11, dataLabelFontFace: "+mn-lt", dataLabelColor: HEX.ink,
    legendFontSize: 12, legendFontFace: "+mn-lt", legendColor: HEX.slate,
    valAxisTitleFontSize: 12, valAxisTitleColor: HEX.slate, valAxisTitleFontFace: "+mn-lt",
    catAxisTitleFontSize: 12, catAxisTitleColor: HEX.slate, catAxisTitleFontFace: "+mn-lt",
    ...extra,
  };
}

// ---------- script → notes ----------
function loadScript(file) {
  const md = fs.readFileSync(file, "utf8");
  const parts = md.split(/^## \[(\d{2})\][^\n]*\n/m);
  const notes = {};
  for (let i = 1; i < parts.length; i += 2) {
    const n = parseInt(parts[i], 10);
    notes[n] = parts[i + 1].replace(/^\*([^*]+)\*\s*\n/, "TIMING: $1\n").replace(/\*\*/g, "").trim();
  }
  return notes;
}

// Charts are recorded here and inserted by add_charts.py (python-pptx) after the deck is written:
// pptxgenjs charts don't survive import into Keynote, python-pptx charts do (and stay native/editable).
const CHARTS = [];
function chart(pres, spec) {
  CHARTS.push({ slide: pres.slides.length, ...spec });
}

async function write(pres, file) {
  await pres.writeFile({ fileName: file });
  await applyTheme(file, THEME);
  const spec = file.replace(/\.pptx$/, ".charts.json");
  fs.writeFileSync(spec, JSON.stringify(CHARTS, null, 1));
  const py = path.join(__dirname, "../.venv/bin/python");
  console.log(require("child_process").execFileSync(py, ["-I", path.join(__dirname, "add_charts.py"), file, spec]).toString().trim());
  console.log("wrote", file);
}

function csv(file) {
  const [head, ...rows] = fs.readFileSync(file, "utf8").trim().split("\n");
  const split = (l) => l.match(/("([^"]|"")*"|[^,]*)(,|$)/g).slice(0, -1).map((c) => c.replace(/,$/, "").replace(/^"|"$/g, ""));
  const h = split(head);
  return rows.map((r) => Object.fromEntries(split(r).map((v, i) => [h[i], v])));
}

module.exports = { chart, newDeck, content, kicker, ask, card, bullets, stat, arrowRight, note, chartOpts, loadScript, write, csv, HEX, THEME, W, H, MX, oid };

// Adapter: accept pptxgenjs-style addChart arguments, record a python-pptx chart spec instead.
function addChart(pres, type, data, o) {
  const kind = type === "LINE" ? "line" : o.barDir === "bar" ? "bar" : o.barGrouping === "stacked" ? "col_stacked" : "col";
  const single = data.length === 1 && (o.chartColors || []).length > 1;
  chart(pres, {
    kind, x: o.x, y: o.y, w: o.w, h: o.h, title: o.title, name: o.objectName,
    categories: data[0].labels, series: data.map((d) => ({ name: d.name, values: d.values })),
    colors: single ? [o.chartColors[0]] : o.chartColors, pointColors: single ? o.chartColors : undefined,
    showValue: !!o.showValue, labelFmt: o.dataLabelFormatCode, legend: !!o.showLegend,
    valMin: o.valAxisMinVal, valMax: o.valAxisMaxVal,
    valTitle: o.showValAxisTitle ? o.valAxisTitle : undefined, catTitle: o.showCatAxisTitle ? o.catAxisTitle : undefined,
    reverseCat: o.catAxisOrientation === "maxMin", gap: o.barGapWidthPct, markers: o.lineDataSymbol && o.lineDataSymbol !== "none",
    catFontSize: o.catAxisLabelFontSize, lineWidth: o.lineSize,
  });
}
module.exports.addChart = addChart;
