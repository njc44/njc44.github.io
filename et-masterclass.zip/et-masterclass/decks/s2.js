// Session 2 deck — When a Good Model Fails in the Real World. Numbers are read from outputs/s2/*.csv.
const fs = require("fs");
const path = require("path");
const L = require("./lib");
const { content, ask, card, bullets, stat, arrowRight, note, chartOpts, csv, HEX, MX, oid } = L;

const ROOT = path.join(__dirname, "..");
const O = (f) => csv(path.join(ROOT, "outputs/s2", f));
const notes = L.loadScript(path.join(ROOT, "scripts/s2_script.md"));
const summary = JSON.parse(fs.readFileSync(path.join(ROOT, "outputs/s2/summary.json"), "utf8"));

const res = O("results_all.csv");
const get = (split, prefix, k = "MAE") => Number(res.find((x) => x.split === split && x.candidate.startsWith(prefix))[k]);
const cleanLog = O("cleaning_log.csv");
const audit = O("feature_audit.csv");
const byHour = O("error_by_hour.csv");
const byDur = O("error_by_duration_band.csv");
const tail = O("long_tail_share.csv");
const hist = O("abs_error_hist.csv");
const worst = O("worst_trips.csv");
const daily = O("daily_mae_march.csv");
const sv = O("street_vs_booked_by_band.csv");
const prep = O("preprocessing_leak.csv");
const fmt = (v) => Number(v).toLocaleString("en-US");
const f2 = (v) => Number(v).toFixed(2);

const { pres, C } = L.newDeck("Session 2", "When a Good Model Fails in the Real World");
const SEC = ["Opening", "Target & contract", "Data & features", "Baseline, model, validation", "Error analysis", "Conclusions"];
let n = 0;
const done = (s) => { n += 1; s.addNotes(notes[n] || ""); return s; };
const CH = "Chronological";
const MD = "Model D", MS = "Model S", ML = "Model L", BR = "Baseline · median for this route", BO = "Baseline · overall", BH = "Baseline · median for weekday";

// 01 Title
pres.addSection({ title: SEC[0] });
{
  const s = pres.addSlide({ masterName: "TITLE_DARK", sectionTitle: SEC[0] });
  s.addText("ET Masterclass  ·  Session 2 of 2", { placeholder: "kicker" });
  s.addText("What Nobody Teaches You About Being a Data Scientist", { placeholder: "title" });
  s.addText("When a Good Model Fails in the Real World", { placeholder: "subtitle" });
  s.addText("Nathan Jacob  ·  Data Scientist, Meesho\nNo coding required: just watch and think along", { placeholder: "meta" });
  done(s);
}

// 02 Who I am
{
  const s = content(pres, C, SEC[0], { kick: "Before we start", title: "One realistic problem, followed all the way through" });
  card(s, C, MX, 1.95, 4.3, 3.0, {
    head: "Nathan Jacob", headSize: 22,
    body: bullets(["Data Scientist, Meesho (Bangalore)", "Delivery-time prediction, voice & language AI, counterfeit detection", "Kaggle Expert"], { space: 10 }), bodySize: 15,
  });
  s.addText("You'll leave with", { x: 5.3, y: 1.95, w: 7, h: 0.45, fontSize: 18, bold: true, color: C.text1, fontFace: "Cambria", margin: 0, isTextBox: true });
  const items = [
    ["A precise task definition", "When the prediction happens, and what it's allowed to see"],
    ["A credible baseline before any model", "And an evaluation that answers the right question"],
    ["The habit of reading errors, and the limits of what you showed", "Evidence vs hypothesis vs untested"],
  ];
  items.forEach(([h, b], i) => {
    const y = 2.5 + i * 1.15;
    s.addShape("ellipse", { x: 5.3, y: y + 0.05, w: 0.5, h: 0.5, fill: { color: C.accent1 }, line: { type: "none" }, objectName: oid("dot") });
    s.addText(String(i + 1), { x: 5.3, y: y + 0.05, w: 0.5, h: 0.5, fontSize: 16, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true });
    s.addText([{ text: h, options: { bold: true, color: C.text1, fontSize: 17, breakLine: true } }, { text: b, options: { color: C.text2, fontSize: 14 } }],
      { x: 6.0, y, w: 6.7, h: 0.95, valign: "top", margin: 0, isTextBox: true });
  });
  note(s, C, "This session stands on its own. You don't need yesterday's session to follow it.", MX, 6.35);
  done(s);
}

// 03 Scenario
{
  const s = content(pres, C, SEC[0], { kick: "The scenario", title: "Estimate trip duration at the moment of pickup" });
  const users = [["Rider", "“You'll be there in about 15 minutes”"], ["Operator", "When will this car be free for the next pickup?"], ["Planner", "Typical durations by area and hour, to size the fleet"]];
  s.addText("Who would use the number?", { x: MX, y: 1.95, w: 8, h: 0.45, fontSize: 18, bold: true, color: C.text1, fontFace: "Cambria", margin: 0, isTextBox: true });
  users.forEach(([h, b], i) => card(s, C, MX + i * 2.62, 2.5, 2.45, 2.2, { num: i + 1, head: h, body: b, headSize: 17, bodySize: 14 }));
  card(s, C, 8.65, 1.95, 4.05, 2.75, { fill: C.text1, head: "Out of scope today", headColor: C.accent1, bodyColor: C.background2,
    body: bullets(["Choosing routes", "Setting prices", "Explaining traffic: historical data measures prediction, not cause"], { space: 6 }), bodySize: 14 });
  s.addText([{ text: "Different users, different costs: ", options: { bold: true, color: C.text1 } }, { text: "“10 minutes” that turns out to be 30 is not the same mistake as “30” that turns out to be 10.", options: { color: C.text2 } }],
    { x: MX, y: 5.0, w: 12.1, h: 0.8, fontSize: 16, margin: 0, isTextBox: true });
  ask(s, C, "Who will use this number, and which mistake hurts them more?");
  done(s);
}

// 04 Contract
pres.addSection({ title: SEC[1] });
{
  const s = content(pres, C, SEC[1], { kick: "The contract", title: "Draw the line at pickup. Nothing to its right is an input" });
  const y = 2.55, x0 = MX, xp = 4.6, xd = 10.2, x1 = 12.7;
  s.addShape("rect", { x: x0, y, w: xp - x0, h: 0.6, fill: { color: C.accent2 }, line: { type: "none" }, objectName: oid("tl") });
  s.addShape("rect", { x: xp, y, w: xd - xp, h: 0.6, fill: { color: C.background2 }, line: { type: "none" }, objectName: oid("tl") });
  s.addShape("rect", { x: xd, y, w: x1 - xd, h: 0.6, fill: { color: C.background2 }, line: { type: "none" }, objectName: oid("tl") });
  s.addText("Before & at pickup", { x: x0, y, w: xp - x0, h: 0.6, fontSize: 15, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addText("The trip", { x: xp, y, w: xd - xp, h: 0.6, fontSize: 15, bold: true, color: C.text1, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addText("After", { x: xd, y, w: x1 - xd, h: 0.6, fontSize: 15, bold: true, color: C.text1, align: "center", valign: "middle", margin: 0, isTextBox: true });
  [[xp, "Pickup = prediction moment", C.accent1, HEX.signal], [xd, "Drop-off", C.text2, HEX.slate]].forEach(([x, t, c, h]) => {
    s.addShape("line", { x, y: 2.15, w: 0, h: 1.4, line: { color: h, width: 3, dashType: x === xp ? "dash" : "solid" }, objectName: oid("cut") });
    s.addText(t, { x: x - 1.6, y: 1.85, w: 3.2, h: 0.3, fontSize: 14, bold: true, color: c, align: "center", margin: 0, isTextBox: true });
  });
  s.addShape("line", { x: xp, y: 3.4, w: xd - xp, h: 0, line: { color: HEX.slate, width: 1.5, beginArrowType: "triangle", endArrowType: "triangle" }, objectName: oid("label-span") });
  s.addText("Label = drop-off − pickup, in minutes. Drop-off time builds the label and is never an input", { x: xp + 0.2, y: 3.45, w: xd - xp - 0.4, h: 0.5, fontSize: 14, color: C.text2, align: "center", margin: 0, isTextBox: true });
  const rows = [["Predict at", "Pickup"], ["Target", "Minutes from pickup to drop-off"], ["Allowed", "Only what exists at pickup: time, pickup zone (and destination, if booked)"], ["Forbidden", "Anything known after the trip, or computed from the answer"]];
  s.addTable(rows.map(([a, b], i) => [{ text: a, options: { bold: true, color: i === 3 ? HEX.signal : HEX.ink, fill: { color: HEX.mist } } }, { text: b, options: { color: HEX.slate } }]),
    { x: MX, y: 4.2, w: 12.1, colW: [1.8, 10.3], fontSize: 14, fontFace: "Calibri", border: { type: "solid", pt: 0.75, color: HEX.grid }, rowH: 0.45, valign: "middle", margin: [3, 8, 3, 8] });
  ask(s, C, "Would this field exist at the moment of pickup?");
  done(s);
}

// 05 Same column, different verdict
{
  const s = content(pres, C, SEC[1], { kick: "The contract", title: "Same column, different verdict: the destination zone" });
  card(s, C, MX, 1.95, 5.9, 3.6, { head: "Street hail", headSize: 22, body: [
    { text: "A hand goes up on Fifth Avenue. At pickup, the system doesn't know where the rider is going.", options: { breakLine: true, paraSpaceAfter: 10 } },
    { text: "Destination zone = information from the future → leakage", options: { bold: true, color: HEX.signal, breakLine: true, paraSpaceAfter: 10 } },
    { text: "Model S: time + pickup zone", options: { bold: true, color: HEX.ink } }], bodySize: 16 });
  card(s, C, 6.8, 1.95, 5.9, 3.6, { head: "Booked trip", headSize: 22, body: [
    { text: "The rider types a destination into an app before the car arrives.", options: { breakLine: true, paraSpaceAfter: 10 } },
    { text: "Destination zone = known before pickup → legitimate input", options: { bold: true, color: HEX.teal, breakLine: true, paraSpaceAfter: 10 } },
    { text: "Model D: time + pickup zone + destination zone", options: { bold: true, color: HEX.ink } }], bodySize: 16 });
  note(s, C, "Caveat: yellow-taxi trips are mostly street hails. Scenario D simulates a booking flow where the destination would have been known.", MX, 5.75);
  ask(s, C, "Is this leakage, or is it the product? It depends on the moment of prediction");
  done(s);
}

// 06 Provenance
pres.addSection({ title: SEC[2] });
{
  const s = content(pres, C, SEC[2], { kick: "The data", title: "NYC yellow taxis, January to March 2024" });
  const loaded = Number(cleanLog[0].rows_remaining);
  stat(s, C, MX, 1.95, 4, { value: (loaded / 1e6).toFixed(2) + "M", label: "trip records loaded (Jan–Mar 2024)" });
  stat(s, C, MX, 3.6, 4, { value: "600K", label: `cleaned trips sampled: ${fmt(summary.env.sample_per_month)} per month, seed ${summary.env.seed}`, color: C.accent2 });
  card(s, C, 5.0, 1.95, 7.7, 3.95, { head: "Source & dictionary", body: bullets([
    "NYC Taxi & Limousine Commission, Trip Record Data: yellow_tripdata_2024-01/02/03.parquet + taxi zone lookup",
    "NYC Open Data terms; records come from technology providers, and TLC doesn't guarantee accuracy",
    "trip_distance: “elapsed trip distance in miles reported by the taximeter”",
    "fare_amount: “time-and-distance fare calculated by the meter”",
    "PULocationID / DOLocationID: TLC taxi zones (263 zones + unknown)"], { space: 6 }), bodySize: 14 });
  ask(s, C, "Which column definitions did I check against the dictionary, rather than guess from the name?");
  done(s);
}

// 07 Cleaning
{
  const s = content(pres, C, SEC[2], { kick: "Cleaning", title: "Cleaning decides the population you model" });
  const steps = cleanLog.slice(1).filter((r) => Number(r.rows_removed) > 0);
  s.addTable([
    ["Filter", "Removed", "Remaining"].map((t) => ({ text: t, options: { bold: true, color: HEX.ink, fill: { color: HEX.mist } } })),
    ...steps.map((r) => [
      { text: r.step, options: { color: HEX.slate } },
      { text: fmt(r.rows_removed), options: { color: Number(r.rows_removed) > 80000 ? HEX.signal : HEX.slate, bold: Number(r.rows_removed) > 80000, align: "right" } },
      { text: fmt(r.rows_remaining), options: { color: HEX.slate, align: "right" } }]),
  ], { x: MX, y: 1.95, w: 7.6, colW: [4.6, 1.4, 1.6], fontSize: 13, fontFace: "Calibri", border: { type: "solid", pt: 0.75, color: HEX.grid }, rowH: 0.42, valign: "middle", margin: [3, 6, 3, 6] });
  const last = cleanLog[cleanLog.length - 1];
  stat(s, C, 8.65, 1.95, 4.05, { value: last.pct_of_loaded_remaining + "%", label: `kept: ${fmt(last.rows_remaining)} trips`, size: 48, color: C.accent2 });
  card(s, C, 8.65, 3.45, 4.05, 2.5, { head: `${fmt(summary.dst_spanning_trips)} trips`, headColor: C.accent1,
    body: "span the daylight-saving jump (10 Mar 2024, 02:00 → 03:00). Naive local timestamps make them look 60 minutes longer than they were.", bodySize: 14 });
  note(s, C, "Removing “distance = 0” uses a post-trip field to filter. That's acceptable for cleaning, but it changes who is in the data.", MX, 5.6, 7.6);
  ask(s, C, "Who did my filters remove, and will those trips still happen in production?");
  done(s);
}

// 08 Feature audit
{
  const s = content(pres, C, SEC[2], { kick: "The contract", title: "Audit every field: known at pickup, or only after?" });
  const col = (u) => (u.startsWith("Used") ? HEX.teal : u.startsWith("Scenario") ? HEX.amber : u.startsWith("Not") ? HEX.gray : HEX.signal);
  s.addTable([
    ["Field", "When it's known", "Use"].map((t) => ({ text: t, options: { bold: true, color: HEX.ink, fill: { color: HEX.mist } } })),
    ...audit.map((a) => [{ text: a.field, options: { color: HEX.ink, bold: true } }, { text: a.when_known, options: { color: HEX.slate } }, { text: a.use, options: { color: col(a.use), bold: true } }]),
  ], { x: MX, y: 1.95, w: 12.1, colW: [4.4, 4.6, 3.1], fontSize: 14, fontFace: "Calibri", border: { type: "solid", pt: 0.75, color: HEX.grid }, rowH: 0.44, valign: "middle", margin: [3, 8, 3, 8] });
  ask(s, C, "For each column: when, exactly, did this value come into existence?");
  done(s);
}

// 09 Leakage
{
  const s = content(pres, C, SEC[2], { kick: "Leakage", title: "Add the meter's distance and fare: a better score, an impossible model" });
  const l = get(CH, ML), d = get(CH, MD);
  card(s, C, MX, 1.95, 5.6, 2.95, {});
  stat(s, C, MX + 0.35, 2.15, 5.0, { value: f2(l), label: "", color: C.accent1, size: 72 });
  s.addText([{ text: "Leaky model", options: { bold: true, color: C.text1, breakLine: true } }, { text: "booked-trip inputs + trip_distance + fare_amount", options: { color: C.text2 } }],
    { x: MX + 0.35, y: 3.65, w: 5.0, h: 1.0, fontSize: 15, margin: 0, valign: "top", isTextBox: true });
  card(s, C, 7.1, 1.95, 5.6, 2.95, {});
  stat(s, C, 7.45, 2.15, 5.0, { value: f2(d), label: "", color: C.accent2, size: 72 });
  s.addText([{ text: "Booked-trip model (honest)", options: { bold: true, color: C.text1, breakLine: true } }, { text: "time + pickup zone + destination zone", options: { color: C.text2 } }],
    { x: 7.45, y: 3.65, w: 5.0, h: 1.0, fontSize: 15, margin: 0, valign: "top", isTextBox: true });
  s.addText("Both fields come from the taximeter at the end of the trip. Nobody knows them at pickup.", { x: MX, y: 5.08, w: 12.1, h: 0.5, fontSize: 18, bold: true, color: C.accent1, margin: 0, isTextBox: true });
  note(s, C, "MAE in minutes on the March 2024 test month (200,000 trips). Same model settings.", MX, 5.7);
  ask(s, C, "If a model suddenly gets much better: what does it know that it shouldn't?");
  done(s);
}

// 10 Baselines
pres.addSection({ title: SEC[3] });
{
  const s = content(pres, C, SEC[3], { kick: "Baseline first", title: "Time alone barely helps. The route does most of the work" });
  const names = ["Overall median", "Weekday × hour", "Model S", "Route median", "Model D"];
  const vals = [get(CH, BO), get(CH, BH), get(CH, MS), get(CH, BR), get(CH, MD)];
  L.addChart(pres, "BAR", [{ name: "MAE", labels: names, values: vals }], chartOpts(C, {
    x: MX, y: 1.85, w: 8.1, h: 4.25, barDir: "col", barGapWidthPct: 45, title: "MAE on March 2024 (minutes), lower is better",
    chartColors: [HEX.faint, HEX.faint, HEX.gray, HEX.slate, HEX.signal], showValue: true, dataLabelFormatCode: "0.00",
    showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 10, objectName: "chart-baselines",
  }));
  stat(s, C, 9.1, 1.95, 3.6, { value: `${f2(vals[0])} → ${f2(vals[1])}`, label: "adding weekday × hour to a median", size: 36, color: C.accent3 });
  stat(s, C, 9.1, 3.25, 3.6, { value: f2(vals[3]), label: "a route lookup table, with no ML at all", size: 36, color: C.text2 });
  stat(s, C, 9.1, 4.55, 3.6, { value: `−${Math.round(100 * (1 - vals[4] / vals[3]))}%`, label: "Model D vs the route baseline", size: 36 });
  ask(s, C, "What's the simplest comparator that someone could already be using?");
  done(s);
}

// 11 Model setup
{
  const s = content(pres, C, SEC[3], { kick: "Setup", title: "One model, one target, one test month" });
  const boxes = [["Pickup-time inputs", "time · pickup zone · destination zone"], ["Target encoders", "fitted inside the pipeline, on training rows only"], ["Gradient-boosted trees", "standard settings, not tuned"], ["Predicted minutes", "scored with MAE, RMSE, P90"]];
  const bw = 2.7, g = 0.43;
  boxes.forEach(([h, b], i) => {
    const x = MX + i * (bw + g);
    card(s, C, x, 2.05, bw, 1.9, { head: h, body: b, headSize: 16, bodySize: 14, fill: i === 2 ? C.accent2 : C.background2, headColor: i === 2 ? C.background1 : C.text1, bodyColor: i === 2 ? C.background1 : C.text2 });
    if (i < 3) arrowRight(s, C, x + bw + 0.05, 3.0, g - 0.1);
  });
  const fixed = [["Fixed target", "minutes, pickup → drop-off"], ["Fixed test period", "1–31 March 2024"], ["Fixed metrics", "same code for every candidate"]];
  fixed.forEach(([h, b], i) => {
    s.addText([{ text: h + "  ", options: { bold: true, color: C.accent1 } }, { text: b, options: { color: C.text2 } }], { x: MX + i * 4.05, y: 4.4, w: 3.9, h: 0.5, fontSize: 15, margin: 0, isTextBox: true });
  });
  note(s, C, "Model complexity is deliberately secondary. Everything that matters today happens before and after this box.", MX, 5.3);
  ask(s, C, "Is anything in my pipeline learning from rows it will later be tested on?");
  done(s);
}

// 12 Chronological split
{
  const s = content(pres, C, SEC[3], { kick: "Validation", title: "Train on January and February. Test on a March it never saw" });
  const x0 = MX, bw = 12.1, y = 2.6;
  const months = [["January 2024", C.accent2, C.background1], ["February 2024", C.accent2, C.background1], ["March 2024", C.accent1, C.background1]];
  months.forEach(([t, f, tc], i) => {
    s.addShape("rect", { x: x0 + i * (bw / 3), y, w: bw / 3 - 0.06, h: 0.75, fill: { color: f }, line: { type: "none" }, objectName: oid("month") });
    s.addText(t, { x: x0 + i * (bw / 3), y, w: bw / 3 - 0.06, h: 0.75, fontSize: 16, bold: true, color: tc, align: "center", valign: "middle", margin: 0, isTextBox: true });
  });
  s.addText("TRAIN · 1 Jan – 29 Feb 2024 · 400,000 trips", { x: x0, y: 2.1, w: bw * 2 / 3, h: 0.4, fontSize: 15, bold: true, color: C.accent2, align: "center", margin: 0, isTextBox: true });
  s.addText("TEST · 1–31 Mar 2024 · 200,000 trips", { x: x0 + bw * 2 / 3, y: 2.1, w: bw / 3, h: 0.4, fontSize: 15, bold: true, color: C.accent1, align: "center", margin: 0, isTextBox: true });
  card(s, C, MX, 3.75, 5.9, 2.15, { head: "Chronological: the question it answers", headSize: 16, body: "“If I'd trained at the end of February and switched it on, how would March have gone?”", bodySize: 15 });
  card(s, C, 6.8, 3.75, 5.9, 2.15, { head: "Random contrast: same 600,000 rows, shuffled", headSize: 16, body: "Same test size (200,000). It answers: “how well does it fill in trips from a period it has mostly seen?”", bodySize: 15 });
  ask(s, C, "What future is this validation asking the model to generalise to?");
  done(s);
}

// 13 Results table
{
  const s = content(pres, C, SEC[3], { kick: "Results", title: "Results: chronological test, March 2024" });
  const order = [[BO, "Baseline · overall median"], [BH, "Baseline · median for weekday × hour"], [BR, "Baseline · median for this route (zone → zone)"], [MS, "Model S · street hail (time + pickup zone)"], [MD, "Model D · booked trip (+ destination zone)"], [ML, "Leaky model (+ metered distance & fare)"]];
  s.addTable([
    ["Candidate", "MAE", "RMSE", "P90 abs. error"].map((t, i) => ({ text: t, options: { bold: true, color: HEX.ink, fill: { color: HEX.mist }, align: i ? "right" : "left" } })),
    ...order.map(([k, lab]) => {
      const leaky = k === ML, best = k === MD;
      const c = leaky ? HEX.gray : best ? HEX.teal : HEX.slate;
      return [{ text: lab + (leaky ? "  ✕ not usable at pickup" : ""), options: { color: leaky ? HEX.signal : c, bold: best, italic: leaky } },
        ...["MAE", "RMSE", "P90_abs_err"].map((m) => ({ text: f2(get(CH, k, m)), options: { color: c, bold: best, align: "right", italic: leaky } }))];
    }),
  ], { x: MX, y: 1.95, w: 12.1, colW: [6.8, 1.7, 1.7, 1.9], fontSize: 15, fontFace: "Calibri", border: { type: "solid", pt: 0.75, color: HEX.grid }, rowH: 0.5, valign: "middle", margin: [3, 8, 3, 8] });
  note(s, C, `All values in minutes. Train 1 Jan – 29 Feb 2024 (400,000 trips) · test 1–31 Mar 2024 (200,000 trips; mean ${summary.test_mean_duration} min, median ${summary.test_median_duration} min). P90 = 90% of trips are within this error.`, MX, 5.6);
  ask(s, C, "Are all of these numbers measured on exactly the same test rows? (Yes, so they're comparable)");
  done(s);
}

// 14 Random vs chrono
{
  const s = content(pres, C, SEC[3], { kick: "Validation", title: "Random vs chronological: here, the gap is small, and that's a finding" });
  const cats = ["Route baseline", "Model S (street hail)", "Model D (booked)"], keys = [BR, MS, MD];
  L.addChart(pres, "BAR", [
    { name: "Random split", labels: cats, values: keys.map((k) => get("Random", k)) },
    { name: "Chronological split", labels: cats, values: keys.map((k) => get(CH, k)) },
  ], chartOpts(C, {
    x: MX, y: 1.85, w: 7.3, h: 4.25, barDir: "col", barGrouping: "clustered", barGapWidthPct: 60, title: "MAE (minutes), same 600,000 rows",
    chartColors: [HEX.gray, HEX.signal], showValue: true, dataLabelFormatCode: "0.00", showLegend: true, valAxisMinVal: 0, valAxisMaxVal: 8, objectName: "chart-split-contrast",
  }));
  card(s, C, 8.25, 1.95, 4.45, 2.0, { head: "Why might it be small?", headSize: 16, body: "Hypotheses: test is only one month ahead, same season, huge sample, stable city patterns. Test it: train on winter, test on summer or a holiday week.", bodySize: 13 });
  const pl = prep.map((p) => Number(p.MAE));
  card(s, C, 8.25, 4.1, 4.45, 1.95, { head: `Preprocessing leak: ${f2(pl[0])} → ${f2(pl[1])}`, headColor: C.accent1, headSize: 16, body: "Same model, but the route median was computed on all months, including March, before splitting. Only when it was learned changed.", bodySize: 13 });
  ask(s, C, "Did I measure the gap, or assume it?");
  done(s);
}

// 15 Destination value
pres.addSection({ title: SEC[4] });
{
  const s = content(pres, C, SEC[4], { kick: "Error analysis", title: "What knowing the destination buys, by trip length" });
  L.addChart(pres, "BAR", [
    { name: "Model S · street hail", labels: sv.map((b) => b.duration_band), values: sv.map((b) => Number(b.MAE_S_street_hail)) },
    { name: "Model D · booked", labels: sv.map((b) => b.duration_band), values: sv.map((b) => Number(b.MAE_D_booked)) },
  ], chartOpts(C, {
    x: MX, y: 1.85, w: 8.6, h: 4.25, barDir: "col", barGrouping: "clustered", barGapWidthPct: 50, title: "MAE (minutes) by actual trip duration (minutes), March 2024",
    chartColors: [HEX.gray, HEX.teal], showValue: true, dataLabelFormatCode: "0.0", showLegend: true, valAxisMinVal: 0, objectName: "chart-s-vs-d",
  }));
  const b1 = sv[0], b7 = sv[sv.length - 1];
  stat(s, C, 9.5, 1.95, 3.2, { value: `${f2(b1.MAE_S_street_hail)} → ${f2(b1.MAE_D_booked)}`, label: "1–5 minute trips: short hops are invisible without a destination", size: 36 });
  stat(s, C, 9.5, 3.55, 3.2, { value: `${Number(b7.MAE_S_street_hail).toFixed(1)} → ${Number(b7.MAE_D_booked).toFixed(1)}`, label: "60–180 minute trips: better, still large", size: 36, color: C.accent2 });
  note(s, C, "Bands use the actual duration, so this is analysis after the fact, not an input.", 9.5, 5.3, 3.2);
  ask(s, C, "How much is one line of the contract worth? Measure it");
  done(s);
}

// 16 By hour
{
  const s = content(pres, C, SEC[4], { kick: "Error analysis", title: "Where it fails, by pickup hour" });
  const labs = byHour.map((h) => h.hour.padStart(2, "0"));
  L.addChart(pres, "LINE", [
    { name: "Model D · booked", labels: labs, values: byHour.map((h) => Number(h.MAE_model_D)) },
    { name: "Route baseline", labels: labs, values: byHour.map((h) => Number(h.MAE_route_baseline)) },
  ], chartOpts(C, {
    x: MX, y: 1.85, w: 8.6, h: 4.25, title: "MAE (minutes) by pickup hour, March 2024", chartColors: [HEX.signal, HEX.faint], lineSize: 2.5, lineDataSymbol: "circle",
    showLegend: true, catAxisTitle: "pickup hour", showCatAxisTitle: true, valAxisMinVal: 0, objectName: "chart-err-hour",
  }));
  const h = (k) => byHour.find((x) => x.hour === String(k));
  stat(s, C, 9.5, 1.95, 3.2, { value: f2(h(15).MAE_model_D), label: `MAE at 15:00, the worst hour. Mean trip ${Number(h(15).mean_duration).toFixed(1)} min: longer trips, bigger misses`, size: 44 });
  stat(s, C, 9.5, 3.7, 3.2, { value: `${Number(h(5).MAE_route_baseline).toFixed(1)} → ${Number(h(5).MAE_model_D).toFixed(1)}`, label: `05:00: biggest gain over the route baseline (only ${fmt(h(5).trips)} trips)`, size: 36, color: C.accent2 });
  ask(s, C, "Is this segment hard to predict, or just made of longer trips?");
  done(s);
}

// 17 Bias by trip length
{
  const s = content(pres, C, SEC[4], { kick: "Error analysis", title: "It overestimates short trips and underestimates long ones" });
  const vals = byDur.map((b) => Number(b.mean_signed_err));
  L.addChart(pres, "BAR", [{ name: "Mean signed error", labels: byDur.map((b) => b.duration_band), values: vals }], chartOpts(C, {
    x: MX, y: 1.85, w: 8.6, h: 4.25, barDir: "col", barGapWidthPct: 45, title: "Mean (predicted − actual), minutes, by actual trip duration",
    chartColors: vals.map((v) => (v >= 0 ? HEX.teal : HEX.signal)), showValue: true, dataLabelFormatCode: "0.0", showLegend: false, objectName: "chart-bias",
  }));
  const share = byDur.filter((b) => ["45–60", "60–180"].includes(b.duration_band)).reduce((a, b) => a + Number(b.share_of_trips_pct), 0);
  stat(s, C, 9.5, 1.95, 3.2, { value: "+" + Number(byDur[0].mean_signed_err).toFixed(1), label: "1–5 minute trips: predicted too long", size: 44, color: C.accent2 });
  stat(s, C, 9.5, 3.35, 3.2, { value: "−" + Math.abs(Number(byDur[byDur.length - 1].mean_signed_err)).toFixed(1), label: "60–180 minute trips: far too short", size: 44 });
  note(s, C, `Pulled toward the middle. Trips over 45 min are ${share.toFixed(1)}% of March, but they're where riders get the nastiest surprise. Bands use the actual outcome, so this is analysis only.`, 9.5, 4.95, 3.2);
  ask(s, C, "Which direction of error does the user feel more?");
  done(s);
}

// 18 Long tail
{
  const s = content(pres, C, SEC[4], { kick: "Error analysis", title: "RMSE is mostly about the tail" });
  L.addChart(pres, "BAR", [{ name: "% of trips", labels: hist.map((h) => h.abs_error_min), values: hist.map((h) => Number(h.pct)) }], chartOpts(C, {
    x: MX, y: 1.85, w: 8.6, h: 4.25, barDir: "col", barGapWidthPct: 25, title: "Share of March trips (%) by absolute error (minutes), Model D",
    chartColors: hist.map((h, i) => (i >= 8 ? HEX.signal : HEX.teal)), showValue: true, dataLabelFormatCode: "0.0", showLegend: false, valAxisMinVal: 0, catAxisLabelFontSize: 11, objectName: "chart-abs-hist",
  }));
  const t1 = tail.find((t) => t.worst_pct_of_trips === "1"), t5 = tail.find((t) => t.worst_pct_of_trips === "5");
  stat(s, C, 9.5, 1.95, 3.2, { value: f2(summary.median_abs_err_D), label: "median absolute error (minutes): a typical trip is close", size: 44, color: C.accent2 });
  stat(s, C, 9.5, 3.35, 3.2, { value: t1.share_of_squared_error_pct + "%", label: `of squared error comes from the worst 1% of trips (${t5.share_of_squared_error_pct}% from the worst 5%)`, size: 44 });
  ask(s, C, "Is my headline metric describing typical trips, or a handful of extreme ones?");
  done(s);
}

// 19 Rows
{
  const s = content(pres, C, SEC[4], { kick: "Error analysis", title: "Look at the rows: facts first, then hypotheses" });
  const rows = worst.slice(0, 4);
  s.addTable([
    ["Pickup", "From → to", "Metered mi", "Actual", "Predicted"].map((t, i) => ({ text: t, options: { bold: true, color: HEX.ink, fill: { color: HEX.mist }, align: i > 1 ? "right" : "left" } })),
    ...rows.map((w) => [w.tpep_pickup_datetime.slice(5, 16), `${w.pickup_zone} → ${w.dropoff_zone}`, Number(w.trip_distance).toFixed(1), Number(w.duration_min).toFixed(0) + " min", Number(w.pred).toFixed(0) + " min"]
      .map((t, i) => ({ text: t, options: { color: i === 3 ? HEX.signal : HEX.slate, bold: i === 3, align: i > 1 ? "right" : "left" } }))),
  ], { x: MX, y: 1.95, w: 7.4, colW: [1.35, 3.25, 0.95, 0.9, 0.95], fontSize: 12, fontFace: "Calibri", border: { type: "solid", pt: 0.75, color: HEX.grid }, rowH: 0.5, valign: "middle", margin: [3, 5, 3, 5] });
  s.addText([{ text: "Hypotheses, not explanations: ", options: { bold: true, color: C.text1 } }, { text: "a meter left running? a stop-and-wait trip? a recording error? 50 miles from the Upper East Side to Midtown isn't a normal ride.", options: { color: C.text2 } }],
    { x: MX, y: 4.7, w: 7.4, h: 1.2, fontSize: 14, margin: 0, valign: "top", isTextBox: true });
  const labs = daily.map((d) => d.tpep_pickup_datetime.slice(8, 10));
  L.addChart(pres, "LINE", [{ name: "Daily MAE", labels: labs, values: daily.map((d) => Number(d.MAE)) }], chartOpts(C, {
    x: 8.25, y: 1.85, w: 4.45, h: 3.0, title: "Daily MAE (min), March 2024", chartColors: [HEX.signal], lineSize: 2, lineDataSymbol: "none", showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 6, catAxisLabelFontSize: 10, objectName: "chart-daily",
  }));
  const top = daily.reduce((a, b) => (Number(b.MAE) > Number(a.MAE) ? b : a));
  s.addText([{ text: `Fact: ${top.tpep_pickup_datetime.slice(8, 10)} March had MAE ${top.MAE}`, options: { bold: true, color: C.accent1, breakLine: true } }, { text: `and mean trip ${top.mean_duration} min. Other days: 3.3–4.1. Next: check event calendars, traffic advisories, weather.`, options: { color: C.text2 } }],
    { x: 8.25, y: 4.95, w: 4.45, h: 1.2, fontSize: 13, margin: 0, valign: "top", isTextBox: true });
  ask(s, C, "What do I actually know about this row, and what am I guessing?");
  done(s);
}

// 20 Conclusions
pres.addSection({ title: SEC[5] });
{
  const s = content(pres, C, SEC[5], { kick: "What can we conclude?", title: "Evidence, hypothesis, untested: keep them apart" });
  const cols = [
    ["Evidence", C.accent2, HEX.teal, [`Booked-trip model: MAE ${f2(get(CH, MD))} min on March vs ${f2(get(CH, BR))} for the route lookup`, "Most of the gain comes from knowing the route", "Metered distance & fare: great score, unusable at pickup", `Learning the route median on all months flatters MAE (${f2(prep[1].MAE)} vs ${f2(prep[0].MAE)})`, "Random split only slightly better here", "Long tail; long trips underestimated"]],
    ["Plausible hypothesis", C.accent4, HEX.amber, ["Small split gap: March is close to training, same season", "Afternoon error reflects longer trips", "Some extreme errors are meter / recording issues", "28 March had something unusual going on"]],
    ["Untested", C.accent1, HEX.signal, ["Better rider experience", "Shorter waits, better dispatch", "More revenue", "Any causal effect at all", "Needs a controlled experiment (e.g. A/B) on the outcome you care about"]],
  ];
  cols.forEach(([h, c, hx, items], i) => {
    const x = MX + i * 4.1;
    s.addShape("roundRect", { x, y: 1.95, w: 3.9, h: 4.1, rectRadius: 0.1, fill: { color: C.background2 }, line: { type: "none" }, objectName: oid("col") });
    s.addShape("ellipse", { x: x + 0.25, y: 2.17, w: 0.3, h: 0.3, fill: { color: c }, line: { type: "none" }, objectName: oid("col-dot") });
    s.addText(h, { x: x + 0.7, y: 2.1, w: 3.0, h: 0.45, fontSize: 18, bold: true, color: C.text1, fontFace: "Cambria", margin: 0, isTextBox: true });
    s.addText(bullets(items, { space: 5 }), { x: x + 0.25, y: 2.7, w: 3.45, h: 3.25, fontSize: 13, color: C.text2, margin: 0, valign: "top", isTextBox: true });
  });
  ask(s, C, "Which column does each sentence of my write-up belong in?");
  done(s);
}

// 21 Production
{
  const s = content(pres, C, SEC[5], { kick: "Before shipping", title: "What production would additionally require" });
  const items = [
    ["Live inputs", "Destination captured at booking and delivered before pickup, with a fallback (Model S) when it's missing"],
    ["Latency", "The estimate lands while the rider is still looking"],
    ["Drift", "Seasons, events, holidays, and daylight saving twice a year"],
    ["Monitoring", "Inputs, prediction spread, and error, which arrives only when the trip ends"],
    ["Decision evaluation", "A controlled test of the outcome users care about, not MAE"],
    ["Cost of being wrong", "Under-estimates hurt more, so consider predicting a high percentile instead of the middle"],
  ];
  items.forEach(([h, b], i) => card(s, C, MX + (i % 3) * 4.1, 1.95 + Math.floor(i / 3) * 2.1, 3.9, 1.95, { head: h, body: b, headSize: 17, bodySize: 14, headColor: i === 5 ? C.accent2 : C.text1 }));
  ask(s, C, "What evidence would justify shipping this model, and what would we measure after?");
  done(s);
}

// 22 Close
{
  const s = pres.addSlide({ masterName: "STATEMENT_DARK", sectionTitle: SEC[5] });
  s.addText("Close", { placeholder: "kicker" });
  s.addText("The model is an artifact. The reasoning around it is the craft", { placeholder: "title" });
  s.addText("The contract, the baseline, the split, the errors, and an honest line between evidence and hope. As code gets cheaper, that's the part that remains yours.", { placeholder: "body" });
  done(s);
}

// 23 References
{
  const s = content(pres, C, SEC[5], { kick: "References", title: "Sources, companion notebook, and your questions" });
  card(s, C, MX, 1.95, 6.0, 3.0, { head: "Data", body: bullets([
    "NYC TLC Trip Record Data, Yellow Taxi, Jan–Mar 2024: nyc.gov/site/tlc/about/tlc-trip-record-data.page",
    "Yellow trip data dictionary (TLC, PDF) · taxi zone lookup table",
    "NYC Open Data terms of use; accuracy not guaranteed by TLC"], { space: 6 }), bodySize: 13 });
  card(s, C, 6.75, 1.95, 5.95, 3.0, { head: "Companion notebook", body: bullets([
    "s2_taxi_duration.ipynb: cleaning log, contract, baselines, models, splits, error analysis",
    `Train Jan–Feb / test Mar 2024 · ${fmt(summary.env.sample_per_month)} trips per month · seed ${summary.env.seed} · scikit-learn ${summary.env.sklearn}`,
    "Every chart and number in this deck is exported from it"], { space: 6 }), bodySize: 13 });
  s.addText([{ text: "Try this: ", options: { bold: true, color: C.accent1 } }, { text: "for your next model, write the contract, beat a smart baseline, and sort your conclusions into three columns.", options: { color: C.text1 } }],
    { x: MX, y: 5.15, w: 12.1, h: 0.5, fontSize: 16, margin: 0, isTextBox: true });
  s.addText("Questions?", { x: MX, y: 5.75, w: 12.1, h: 0.8, fontSize: 36, bold: true, color: C.text1, fontFace: "Cambria", margin: 0, isTextBox: true });
  done(s);
}

if (n !== Object.keys(notes).length) console.warn(`WARNING: ${n} slides but ${Object.keys(notes).length} script sections`);
L.write(pres, path.join(__dirname, "Session2_Good_Model_Fails.pptx"));
