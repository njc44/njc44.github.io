"""Second build stage: insert native charts with python-pptx.

pptxgenjs charts are dropped by Keynote on import; python-pptx charts render in PowerPoint, Keynote and
Google Slides. The JS builder writes <deck>.charts.json; this script adds each chart to its slide.
usage: python add_charts.py deck.pptx deck.charts.json
"""
import json
import sys

from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION, XL_MARKER_STYLE
from pptx.util import Inches, Pt

INK, SLATE, GRID, FAINT = "17212B", "3D4C57", "DDE3E1", "C9D2CF"
FONT = "Calibri"
KIND = {
    "line": XL_CHART_TYPE.LINE_MARKERS,
    "col": XL_CHART_TYPE.COLUMN_CLUSTERED,
    "col_stacked": XL_CHART_TYPE.COLUMN_STACKED,
    "bar": XL_CHART_TYPE.BAR_CLUSTERED,
}


def rgb(h):
    return RGBColor.from_string(h)


def style_font(font, size, color=SLATE, bold=False):
    font.name, font.size, font.bold = FONT, Pt(size), bold
    font.color.rgb = rgb(color)


def axis_title(axis, text):
    axis.has_title = True
    tf = axis.axis_title.text_frame
    tf.text = text
    style_font(tf.paragraphs[0].runs[0].font, 12)


def add(slide, c):
    data = CategoryChartData()
    data.categories = c["categories"]
    for s in c["series"]:
        data.add_series(s["name"], s["values"])
    gf = slide.shapes.add_chart(KIND[c["kind"]], Inches(c["x"]), Inches(c["y"]), Inches(c["w"]), Inches(c["h"]), data)
    gf.name = c.get("name", "chart")
    ch = gf.chart
    style_font(ch.font, 12)

    ch.has_title = True
    ch.chart_title.text_frame.text = c["title"]
    style_font(ch.chart_title.text_frame.paragraphs[0].runs[0].font, 14, INK, True)

    ch.has_legend = bool(c.get("legend"))
    if ch.has_legend:
        ch.legend.position = XL_LEGEND_POSITION.BOTTOM
        ch.legend.include_in_layout = False
        style_font(ch.legend.font, 12)

    va, ca = ch.value_axis, ch.category_axis
    va.has_major_gridlines = True
    va.major_gridlines.format.line.color.rgb = rgb(GRID)
    va.major_gridlines.format.line.width = Pt(0.75)
    va.format.line.fill.background()
    ca.format.line.color.rgb = rgb(FAINT)
    ca.has_major_gridlines = False
    style_font(va.tick_labels.font, 12)
    style_font(ca.tick_labels.font, c.get("catFontSize", 12))
    if "valMin" in c: va.minimum_scale = c["valMin"]
    if "valMax" in c: va.maximum_scale = c["valMax"]
    if c.get("valFmt"):
        va.tick_labels.number_format, va.tick_labels.number_format_is_linked = c["valFmt"], False
    if c.get("valTitle"): axis_title(va, c["valTitle"])
    if c.get("catTitle"): axis_title(ca, c["catTitle"])
    if c.get("reverseCat"): ca.reverse_order = True

    plot = ch.plots[0]
    if c["kind"] != "line":
        plot.gap_width = c.get("gap", 60)
        if c["kind"] == "col_stacked":
            plot.overlap = 100
    colors = c.get("colors", [])
    for i, s in enumerate(plot.series):
        col = colors[i % len(colors)] if colors else SLATE
        if c["kind"] == "line":
            s.format.line.color.rgb = rgb(col)
            s.format.line.width = Pt(c.get("lineWidth", 2.5))
            s.smooth = False
            if c.get("markers"):
                s.marker.style, s.marker.size = XL_MARKER_STYLE.CIRCLE, 5
                s.marker.format.fill.solid(); s.marker.format.fill.fore_color.rgb = rgb(col)
                s.marker.format.line.color.rgb = rgb(col)
            else:
                s.marker.style = XL_MARKER_STYLE.NONE
        else:
            s.format.fill.solid(); s.format.fill.fore_color.rgb = rgb(col)
            s.format.line.fill.background()
            s.invert_if_negative = False
    if c.get("pointColors"):
        s0 = plot.series[0]
        for j, col in enumerate(c["pointColors"]):
            p = s0.points[j]
            p.format.fill.solid(); p.format.fill.fore_color.rgb = rgb(col)
    if c.get("showValue"):
        plot.has_data_labels = True
        dl = plot.data_labels
        dl.number_format, dl.number_format_is_linked = c.get("labelFmt", "0.0"), False
        dl.show_value = True
        if c["kind"] != "line":
            dl.position = XL_LABEL_POSITION.OUTSIDE_END
        style_font(dl.font, 11, INK)


def main(deck, spec):
    prs = Presentation(deck)
    charts = json.load(open(spec))
    for c in charts:
        add(prs.slides[c["slide"] - 1], c)
    prs.save(deck)
    print(f"added {len(charts)} charts to {deck}")


if __name__ == "__main__":
    main(*sys.argv[1:3])
