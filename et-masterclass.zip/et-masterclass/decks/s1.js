// Session 1 deck — The ML Traps Nobody Warns You About. Numbers are read from outputs/s1/*.csv.
const path = require("path");
const L = require("./lib");
const { content, ask, card, bullets, stat, arrowRight, note, chartOpts, csv, HEX, MX, oid, kicker } = L;

const ROOT = path.join(__dirname, "..");
const O = (f) => csv(path.join(ROOT, "outputs/s1", f));
const notes = L.loadScript(path.join(ROOT, "scripts/s1_script.md"));

const res = O("results_all.csv");
const r = (split, prefix) => Number(res.find((x) => x.split === split && x.candidate.startsWith(prefix)).MAE);
const rm = (split, prefix) => Number(res.find((x) => x.split === split && x.candidate.startsWith(prefix)).RMSE);
const prof = O("hourly_profile.csv");
const byHour = O("error_by_hour.csv");
const monthly = O("monthly_mean.csv");
const bands = O("error_by_demand_band.csv");
const share = O("error_share_by_band.csv");
const wx = O("error_by_weather.csv");
const split = O("split_info.csv")[0];

const { pres, C } = L.newDeck("Session 1", "The ML Traps Nobody Warns You About");
const SEC = ["Opening", "Formulate the problem", "Leakage & validation", "Baselines, metrics, errors", "Notebook to production", "Close"];
SEC.forEach((t) => {}); // sections are added just before their first slide
let n = 0;
const done = (s) => { n += 1; s.addNotes(notes[n] || ""); return s; };

// 01 Title
pres.addSection({ title: SEC[0] });
{
  const s = pres.addSlide({ masterName: "TITLE_DARK", sectionTitle: SEC[0] });
  s.addText("ET Masterclass  ·  Session 1 of 2", { placeholder: "kicker" });
  s.addText("What Nobody Teaches You About Being a Data Scientist", { placeholder: "title" });
  s.addText("The ML Traps Nobody Warns You About", { placeholder: "subtitle" });
  s.addText("Nathan Jacob  ·  Data Scientist, Meesho\nNo coding required: just watch and think along", { placeholder: "meta" });
  done(s);
}

// 02 Who I am
{
  const s = content(pres, C, SEC[0], { kick: "Before we start", title: "Kaggle hands you the target, split and metric. A job doesn't" });
  card(s, C, MX, 1.95, 4.3, 3.0, {
    head: "Nathan Jacob", headSize: 22,
    body: bullets(["Data Scientist, Meesho (Bangalore)", "Delivery-time prediction, voice & language AI, counterfeit detection", "Kaggle Expert"], { space: 10 }),
    bodySize: 15,
  });
  s.addText("You'll leave with", { x: 5.3, y: 1.95, w: 7, h: 0.45, fontSize: 18, bold: true, color: C.text1, fontFace: "Cambria", margin: 0, isTextBox: true });
  const items = [
    ["Frame it", "Turn a vague request into a decision, a target and a prediction moment"],
    ["Ask “when was this knowable?”", "The one question that catches most leakage"],
    ["Read the errors, then think past launch", "Baselines, segment errors, and what changes after deployment"],
  ];
  items.forEach(([h, b], i) => {
    const y = 2.5 + i * 1.15;
    s.addShape("ellipse", { x: 5.3, y: y + 0.05, w: 0.5, h: 0.5, fill: { color: C.accent1 }, line: { type: "none" }, objectName: oid("dot") });
    s.addText(String(i + 1), { x: 5.3, y: y + 0.05, w: 0.5, h: 0.5, fontSize: 16, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true });
    s.addText([{ text: h, options: { bold: true, color: C.text1, fontSize: 17, breakLine: true } }, { text: b, options: { color: C.text2, fontSize: 14 } }],
      { x: 6.0, y, w: 6.7, h: 0.95, valign: "top", margin: 0, isTextBox: true });
  });
  note(s, C, "Each session stands on its own. Tomorrow's session isn't required to follow this one, and this one isn't required for tomorrow's.", MX, 6.35);
  done(s);
}

// 03 Opening question
{
  const s = pres.addSlide({ masterName: "STATEMENT_DARK", sectionTitle: SEC[0] });
  s.addText("Opening question", { placeholder: "kicker" });
  s.addText("If a demand forecast is accurate, will there be a bike when you need one?", { placeholder: "title" });
  s.addText("A forecast is a number. A bike at the dock is an outcome. Someone has to act in between.", { placeholder: "body" });
  done(s);
}

// 04 Decision system
{
  const s = content(pres, C, SEC[0], { kick: "The mental model", title: "A model is one link in a decision system" });
  const steps = ["Decision", "Target", "Data", "Features", "Model", "Validation", "Action", "Outcome"];
  const bw = 1.28, gap = 0.26, y = 2.45;
  steps.forEach((t, i) => {
    const x = MX + i * (bw + gap);
    const mid = i === 3 || i === 4;
    s.addShape("roundRect", { x, y, w: bw, h: 0.95, rectRadius: 0.1, fill: { color: mid ? C.accent2 : C.background2 }, line: { type: "none" }, objectName: oid("step") });
    s.addText(t, { x, y, w: bw, h: 0.95, fontSize: 15, bold: true, color: mid ? C.background1 : C.text1, align: "center", valign: "middle", margin: 0, isTextBox: true });
    if (i < steps.length - 1) arrowRight(s, C, x + bw + 0.02, y + 0.475, gap - 0.04);
  });
  // brackets
  const bx = (i) => MX + i * (bw + gap);
  s.addShape("line", { x: bx(3), y: 3.6, w: bx(5) - bx(3) - gap, h: 0, line: { color: HEX.teal, width: 2 }, objectName: oid("bracket") });
  s.addText("Where tutorials spend their time", { x: bx(3) - 0.3, y: 3.7, w: 3.4, h: 0.4, fontSize: 14, color: C.accent2, bold: true, align: "center", margin: 0, isTextBox: true });
  s.addShape("line", { x: bx(0), y: 1.95, w: bx(3) - bx(0) - gap, h: 0, line: { color: HEX.signal, width: 2 }, objectName: oid("bracket") });
  s.addShape("line", { x: bx(5), y: 1.95, w: bx(8) - bx(5) - gap, h: 0, line: { color: HEX.signal, width: 2 }, objectName: oid("bracket") });
  s.addText("Where real failures usually start", { x: bx(0), y: 1.95, w: bx(3) - bx(0) - gap, h: 0.4, fontSize: 14, color: C.accent1, bold: true, align: "center", margin: 0, isTextBox: true });
  s.addText("Where real failures usually show up", { x: bx(5), y: 1.95, w: bx(8) - bx(5) - gap, h: 0.4, fontSize: 14, color: C.accent1, bold: true, align: "center", margin: 0, isTextBox: true });
  card(s, C, MX, 4.4, 12.1, 1.5, {
    fill: C.background1,
    body: [
      { text: "The score measures one link: ", options: { bold: true, color: C.text1 } },
      { text: "how well predictions match labels on your test set. It can't tell you whether you chose the right labels, whether the test set looks like the future, or whether anyone acted on the predictions.", options: { color: C.text2 } },
    ], bodySize: 17,
  });
  ask(s, C, "What decision will this model support, and does our experiment tell us whether it will?");
  done(s);
}

// 05 Four problems
pres.addSection({ title: SEC[1] });
{
  const s = content(pres, C, SEC[1], { kick: "Trap 1 · Formulation", title: "“Predict bike demand” is four different problems" });
  const cards = [
    ["Rebalancing", "Per station · 1–2 hours ahead", "Which stations will run empty or full before a truck can get there?"],
    ["Staffing", "Whole system · a day or week ahead", "How many people do we need on shift?"],
    ["Capacity planning", "Monthly / seasonal · months ahead", "The trend, not any single hour: how many bikes and docks to buy"],
    ["App availability", "Per station · minutes ahead", "The chance a station hits zero when a rider looks"],
  ];
  const cw = 2.86, g = 0.22;
  cards.forEach(([h, meta, b], i) => {
    const x = MX + i * (cw + g);
    card(s, C, x, 1.95, cw, 3.55, { num: i + 1, head: h, body: [
      { text: meta, options: { bold: true, color: C.accent2, breakLine: true, paraSpaceAfter: 8 } },
      { text: b, options: { color: C.text2 } }], bodySize: 14 });
  });
  note(s, C, "Today we pick one: system-wide rebalancing and staffing for the next hour.", MX, 5.72);
  ask(s, C, "What will you do differently depending on what my model says?");
  done(s);
}

// 06 Contract
{
  const s = content(pres, C, SEC[1], { kick: "Trap 1 · Formulation", title: "Write the prediction-time contract before you train" });
  const rows = [
    ["Decision", "Bikes to rebalance and staff to schedule for the coming hour"],
    ["Target", "Total rentals that start in hour t (system-wide)"],
    ["Predict at", "The start of hour t, e.g. 17:00 for 17:00–18:00"],
    ["Allowed", "Calendar for hour t · rentals up to 16:59 · weather up to 16:59 (+ a forecast)"],
    ["Forbidden", "Anything from 17:00–18:00: its rentals, its observed weather, casual & registered"],
  ];
  s.addTable(rows.map(([a, b], i) => [
    { text: a, options: { bold: true, color: i === 4 ? HEX.signal : HEX.ink, fill: { color: HEX.mist } } },
    { text: b, options: { color: HEX.slate } }]),
  { x: MX, y: 1.95, w: 6.6, colW: [1.45, 5.15], fontSize: 14, fontFace: "Calibri", border: { type: "solid", pt: 0.75, color: HEX.grid }, rowH: 0.74, valign: "middle", margin: [4, 8, 4, 8] });
  // timeline
  const x0 = 7.65, x1 = 12.7, ty = 3.35, cut = 10.0;
  s.addShape("rect", { x: x0, y: ty, w: cut - x0, h: 0.5, fill: { color: C.accent2 }, line: { type: "none" }, objectName: oid("tl-known") });
  s.addShape("rect", { x: cut, y: ty, w: x1 - cut, h: 0.5, fill: { color: C.background2 }, line: { type: "none" }, objectName: oid("tl-unknown") });
  s.addText("hour t − 1", { x: x0, y: ty, w: cut - x0, h: 0.5, fontSize: 14, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addText("hour t (the target)", { x: cut, y: ty, w: x1 - cut, h: 0.5, fontSize: 14, bold: true, color: C.text1, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addShape("line", { x: cut, y: 2.25, w: 0, h: 2.75, line: { color: HEX.signal, width: 3, dashType: "dash" }, objectName: oid("cut") });
  s.addText("Prediction moment · 17:00", { x: cut - 1.5, y: 1.9, w: 3.0, h: 0.35, fontSize: 14, bold: true, color: C.accent1, align: "center", margin: 0, isTextBox: true });
  s.addText([{ text: "Can use", options: { bold: true, color: C.accent2, breakLine: true } }, { text: "calendar, past rentals, past weather, forecasts", options: { color: C.text2 } }],
    { x: x0, y: 4.1, w: cut - x0 - 0.15, h: 1.2, fontSize: 14, margin: 0, valign: "top", isTextBox: true });
  s.addText([{ text: "Cannot use", options: { bold: true, color: C.accent1, breakLine: true } }, { text: "anything that happens after 17:00, however predictive", options: { color: C.text2 } }],
    { x: cut + 0.15, y: 4.1, w: x1 - cut - 0.15, h: 1.2, fontSize: 14, margin: 0, valign: "top", isTextBox: true });
  ask(s, C, "Can I fill in all five lines before training anything?");
  done(s);
}

// 07 Dataset is not the world
{
  const s = content(pres, C, SEC[1], { kick: "Trap 1 · Formulation", title: "The dataset is a partial record, not the world" });
  const steps = [["Wanted a bike", 5.4, C.background2, C.text1], ["Found one at the dock", 4.3, C.background2, C.text1], ["Rented it  →  a row in hour.csv", 3.2, C.accent2, C.background1]];
  steps.forEach(([t, w, f, tc], i) => {
    const y = 2.0 + i * 0.95;
    s.addShape("roundRect", { x: MX + (5.4 - w) / 2, y, w, h: 0.78, rectRadius: 0.1, fill: { color: f }, line: { type: "none" }, objectName: oid("funnel") });
    s.addText(t, { x: MX + (5.4 - w) / 2, y, w, h: 0.78, fontSize: 15, bold: true, color: tc, align: "center", valign: "middle", margin: 0, isTextBox: true });
  });
  s.addText([
    { text: "Invisible to the data: ", options: { bold: true, color: C.accent1 } },
    { text: "people who met an empty dock, or checked the app and took a cab. Rentals under-count demand exactly when stations run empty.", options: { color: C.text2 } }],
  { x: MX, y: 4.95, w: 5.4, h: 1.1, fontSize: 14, margin: 0, valign: "top", isTextBox: true });
  const facts = [
    ["165 hours", "have no row at all. “Previous row” isn’t always “previous hour”."],
    ["Observed weather", "The weather columns are what happened, not what was forecast."],
    ["cnt = casual + registered", "True for every one of the 17,379 rows."],
  ];
  facts.forEach(([h, b], i) => card(s, C, 6.6, 1.95 + i * 1.38, 6.1, 1.22, { head: h, headColor: C.accent1, body: b, headSize: 18, bodySize: 14 }));
  ask(s, C, "What exactly is the target, and what does the dataset fail to observe?");
  done(s);
}

// 08 Meet the data
{
  const s = content(pres, C, SEC[1], { kick: "The data", title: "Commuters make two peaks; weekends make one hump" });
  L.addChart(pres, "LINE", [
    { name: "Working day", labels: prof.map((p) => p.hr.padStart(2, "0")), values: prof.map((p) => Number(p["Working day"])) },
    { name: "Weekend / holiday", labels: prof.map((p) => p.hr.padStart(2, "0")), values: prof.map((p) => Number(p["Weekend / holiday"])) },
  ], chartOpts(C, {
    x: MX, y: 1.85, w: 8.2, h: 4.3, title: "Mean rentals per hour, by hour of day (2011–2012)",
    chartColors: [HEX.signal, HEX.teal], lineSize: 2.5, lineDataSymbol: "none",
    showLegend: true, legendPos: "t", valAxisTitle: "rentals / hour", showValAxisTitle: true,
    catAxisTitle: "hour of day", showCatAxisTitle: true, objectName: "chart-hourly-profile",
  }));
  const wd17 = Number(prof.find((p) => p.hr === "17")["Working day"]);
  const we13 = Number(prof.find((p) => p.hr === "13")["Weekend / holiday"]);
  stat(s, C, 9.3, 2.0, 3.4, { value: String(Math.round(wd17)), label: "average rentals, 17:00–18:00 on a working day", color: C.accent1 });
  stat(s, C, 9.3, 3.9, 3.4, { value: String(Math.round(we13)), label: "weekend / holiday peak, 13:00–14:00", color: C.accent2 });
  note(s, C, "UCI Bike Sharing Dataset · Capital Bikeshare, Washington D.C. · 17,379 hourly records, 1 Jan 2011 – 31 Dec 2012", MX, 6.35);
  done(s);
}

// 09 Leakage kinds
pres.addSection({ title: SEC[2] });
{
  const s = content(pres, C, SEC[2], { kick: "Trap 2 · Leakage", title: "Leakage: the model knows something it couldn’t" });
  const ks = [
    ["Future information", "Weather observed during the hour you're predicting. At 17:00 you only have a forecast, and forecasts are sometimes wrong."],
    ["Post-outcome fields", "Columns created with the outcome. Here, casual + registered = the target, so you're handing the model the answer."],
    ["Learning before the split", "Scaling, imputing, encoding or selecting features using all rows lets the test set shape training."],
  ];
  ks.forEach(([h, b], i) => card(s, C, MX + i * 4.12, 1.95, 3.86, 3.95, { num: i + 1, head: h, body: b, bodySize: 15 }));
  ask(s, C, "For every input and every statistic: when did this become knowable?");
  done(s);
}

// 10 Leak in action
{
  const s = content(pres, C, SEC[2], { kick: "Trap 2 · Leakage", title: "Too good to be true is a signal, not a success" });
  const A = r("Chronological", "Model A"), Cm = r("Chronological", "Model C");
  card(s, C, MX, 1.95, 5.6, 2.95, { fill: C.background2 });
  stat(s, C, MX + 0.35, 2.15, 5.0, { value: A.toFixed(1), label: "", color: C.accent1, size: 72 });
  s.addText([{ text: "Model A · everything in the file", options: { bold: true, color: C.text1, breakLine: true } }, { text: "includes casual + registered (they sum to the target)", options: { color: C.text2 } }],
    { x: MX + 0.35, y: 3.65, w: 5.0, h: 1.0, fontSize: 15, margin: 0, valign: "top", isTextBox: true });
  card(s, C, 7.1, 1.95, 5.6, 2.95, { fill: C.background2 });
  stat(s, C, 7.45, 2.15, 5.0, { value: Cm.toFixed(1), label: "", color: C.accent2, size: 72 });
  s.addText([{ text: "Model C · honest at 17:00", options: { bold: true, color: C.text1, breakLine: true } }, { text: "calendar + past rentals + last hour's weather", options: { color: C.text2 } }],
    { x: 7.45, y: 3.65, w: 5.0, h: 1.0, fontSize: 15, margin: 0, valign: "top", isTextBox: true });
  s.addText(`About ${Math.round(Cm / A)}× “better”, and impossible to use at 17:00`, { x: MX, y: 5.08, w: 12.1, h: 0.5, fontSize: 18, bold: true, color: C.accent1, margin: 0, isTextBox: true });
  note(s, C, `MAE in rentals per hour. Same chronological test: ${split.test_from} → ${split.test_to} (${Number(split.n_test).toLocaleString("en-US")} hours, mean 240 rentals/hour). Same gradient-boosted tree settings.`, MX, 5.75);
  ask(s, C, "If a model suddenly gets much better: what does it know that it shouldn’t?");
  done(s);
}

// 11 Split timelines
{
  const s = content(pres, C, SEC[2], { kick: "Trap 3 · Validation", title: "A random split and a time split ask different questions" });
  const x0 = MX, bw = 7.6;
  const lane = (y, label) => s.addText(label, { x: x0, y: y - 0.45, w: bw, h: 0.4, fontSize: 16, bold: true, color: C.text1, margin: 0, fontFace: "Cambria", isTextBox: true });
  lane(2.35, "Random split: shuffle hours, hold out a quarter");
  s.addShape("rect", { x: x0, y: 2.4, w: bw, h: 0.55, fill: { color: C.accent2 }, line: { type: "none" }, objectName: oid("rand-bar") });
  let seed = 7; const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
  for (let i = 0; i < 70; i++) s.addShape("rect", { x: x0 + 0.05 + rnd() * (bw - 0.12), y: 2.4, w: 0.04, h: 0.55, fill: { color: C.accent1 }, line: { type: "none" }, objectName: oid("tick") });
  lane(3.95, "Chronological split: train on the past, test on what came next");
  const cut = x0 + bw * (20 / 24);
  s.addShape("rect", { x: x0, y: 4.0, w: cut - x0, h: 0.55, fill: { color: C.accent2 }, line: { type: "none" }, objectName: oid("chr-train") });
  s.addShape("rect", { x: cut, y: 4.0, w: x0 + bw - cut, h: 0.55, fill: { color: C.accent1 }, line: { type: "none" }, objectName: oid("chr-test") });
  s.addText(`Train · 8 Jan 2011 – 31 Aug 2012 · ${Number(split.n_train).toLocaleString("en-US")} h`, { x: x0, y: 4.0, w: cut - x0, h: 0.55, fontSize: 14, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addText("Test", { x: cut, y: 4.0, w: x0 + bw - cut, h: 0.55, fontSize: 14, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true });
  s.addText(`Sep – Dec 2012 · ${Number(split.n_test).toLocaleString("en-US")} h`, { x: cut - 1.2, y: 4.6, w: x0 + bw - cut + 1.2, h: 0.35, fontSize: 12, color: C.accent1, align: "right", margin: 0, isTextBox: true });
  s.addText("2011", { x: x0, y: 5.0, w: 1, h: 0.3, fontSize: 12, color: C.accent3, margin: 0, isTextBox: true });
  s.addText("2012", { x: x0 + bw / 2, y: 5.0, w: 1, h: 0.3, fontSize: 12, color: C.accent3, margin: 0, isTextBox: true });
  card(s, C, 8.6, 1.95, 4.1, 1.55, { head: "Answers", headSize: 14, headColor: C.accent2, body: "“How well can it fill in hours from a period it has mostly seen?”", bodySize: 15 });
  card(s, C, 8.6, 3.6, 4.1, 1.55, { head: "Answers", headSize: 14, headColor: C.accent1, body: "“If I'd switched it on at the end of August, how would it have done?”", bodySize: 15 });
  note(s, C, "Random splitting isn't always wrong. It's wrong when it doesn't match how the model will be used.", MX, 5.55);
  ask(s, C, "What future is this validation asking the model to generalise to?");
  done(s);
}

// 12 Same rows different question
{
  const s = content(pres, C, SEC[2], { kick: "Trap 3 · Validation", title: "Same rows, same model: the split changed which model you'd pick" });
  const B = ["Model B", "Model C"];
  L.addChart(pres, "BAR", [
    { name: "Random split", labels: ["Model B · calendar + same-hour weather", "Model C · calendar + past rentals + last hour's weather"], values: B.map((m) => r("Random", m)) },
    { name: "Chronological split", labels: ["Model B · calendar + same-hour weather", "Model C · calendar + past rentals + last hour's weather"], values: B.map((m) => r("Chronological", m)) },
  ], chartOpts(C, {
    x: MX, y: 1.85, w: 7.6, h: 4.25, barDir: "col", barGrouping: "clustered", barGapWidthPct: 60,
    title: "MAE (rentals / hour), lower is better", chartColors: [HEX.gray, HEX.signal],
    showValue: true, dataLabelPosition: "outEnd", dataLabelFormatCode: "0.0", showLegend: true, legendPos: "t",
    valAxisMinVal: 0, valAxisMaxVal: 50, objectName: "chart-split-contrast",
  }));
  const bR = r("Random", "Model B"), cR = r("Random", "Model C"), bC = r("Chronological", "Model B"), cC = r("Chronological", "Model C");
  card(s, C, 8.55, 1.95, 4.15, 1.95, { head: "Random split", headColor: C.accent3, body: `B ≈ C (${bR.toFixed(1)} vs ${cR.toFixed(1)}). Conclusion you'd draw: “past rentals barely help, keep it simple.”`, bodySize: 15 });
  card(s, C, 8.55, 4.05, 4.15, 1.95, { head: "Chronological split", headColor: C.accent1, body: `${bC.toFixed(1)} vs ${cC.toFixed(1)}. Past rentals matter a lot: they keep the model in step when demand drifts.`, bodySize: 15 });
  ask(s, C, "Did the split change the decision, not just the score?");
  done(s);
}

// 13 Growth
{
  const s = content(pres, C, SEC[2], { kick: "Trap 3 · Validation", title: "The system grew, and a time split makes you face it" });
  const lab = monthly.map((m) => { const d = new Date(m.ts); return d.toLocaleString("en-US", { month: "short" }) + (d.getMonth() === 0 ? " ’" + String(d.getFullYear()).slice(2) : ""); });
  L.addChart(pres, "BAR", [
    { name: "Train months", labels: lab, values: monthly.map((m) => (m.period === "train" ? Number(m.mean_rentals_per_hour) : 0)) },
    { name: "Test months", labels: lab, values: monthly.map((m) => (m.period === "test" ? Number(m.mean_rentals_per_hour) : 0)) },
  ], chartOpts(C, {
    x: MX, y: 1.85, w: 8.4, h: 4.25, barDir: "col", barGrouping: "stacked", barGapWidthPct: 35,
    title: "Mean rentals per hour, by month", chartColors: [HEX.teal, HEX.signal], showLegend: true, legendPos: "t",
    catAxisLabelFontSize: 11, valAxisMinVal: 0, objectName: "chart-monthly",
  }));
  const jan = Math.round(Number(monthly[0].mean_rentals_per_hour)), sep = Math.round(Number(monthly.find((m) => m.ts.startsWith("2012-09")).mean_rentals_per_hour));
  stat(s, C, 9.4, 2.0, 3.3, { value: `${jan} → ${sep}`, label: "rentals / hour, Jan 2011 → Sep 2012", size: 44 });
  stat(s, C, 9.4, 3.75, 3.3, { value: "181 vs 240", label: "mean across all train hours vs test hours", size: 44, color: C.accent2 });
  note(s, C, "Model B (calendar + weather) has no input that tells it the system grew. Model C sees last hour, yesterday and last week.", MX, 6.15 - 0.02, 12.1);
  done(s);
}

// 14 Baselines
pres.addSection({ title: SEC[3] });
{
  const s = content(pres, C, SEC[3], { kick: "Trap 4 · Metrics", title: "A baseline turns a number into a result" });
  const names = ["Training mean", "Weekday × hour average", "Same hour last week", "Model C (honest)"];
  const vals = [r("Chronological", "Baseline · training mean"), r("Chronological", "Baseline · avg"), r("Chronological", "Baseline · same hour"), r("Chronological", "Model C")];
  L.addChart(pres, "BAR", [{ name: "MAE", labels: names, values: vals }], chartOpts(C, {
    x: MX, y: 1.85, w: 7.9, h: 4.25, barDir: "col", barGapWidthPct: 45, title: "MAE on the same chronological test (rentals / hour)",
    chartColors: [HEX.faint, HEX.gray, HEX.slate, HEX.signal], showValue: true, dataLabelPosition: "outEnd", dataLabelFormatCode: "0.0",
    showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 200, objectName: "chart-baselines",
  }));
  const cut = Math.round(100 * (1 - vals[3] / vals[2]));
  stat(s, C, 9.0, 2.0, 3.7, { value: `−${cut}%`, label: "error vs the best simple rule (“same hour last week”)" });
  s.addText(bullets(["Score every candidate on the same test rows", "Make it a smart baseline, not a straw man", "If the baseline wins, that's a finding"]),
    { x: 9.0, y: 3.85, w: 3.7, h: 2.1, fontSize: 15, color: C.text2, margin: 0, valign: "top", isTextBox: true });
  ask(s, C, "What would a simple rule, or the current spreadsheet, get on the same test set?");
  done(s);
}

// 15 84 vs 86 → MAE/RMSE
{
  const s = content(pres, C, SEC[3], { kick: "Trap 4 · Metrics", title: "One number hides which errors you make" });
  card(s, C, MX, 1.95, 5.7, 4.1, {});
  s.addText("ILLUSTRATIVE · A CLASSIFICATION THOUGHT EXPERIMENT", { x: MX + 0.3, y: 2.1, w: 5.2, h: 0.3, fontSize: 11, bold: true, color: C.accent3, margin: 0, charSpacing: 1, isTextBox: true });
  [["A", "84%"], ["B", "86%"]].forEach(([m, v], i) => {
    const x = MX + 0.3 + i * 2.6;
    s.addShape("roundRect", { x, y: 2.5, w: 2.4, h: 1.15, rectRadius: 0.1, fill: { color: C.background1 }, line: { type: "none" }, objectName: oid("acc") });
    s.addText([{ text: v, options: { fontSize: 36, bold: true, color: i ? C.accent1 : C.text2, fontFace: "Cambria", breakLine: true } }, { text: `Model ${m} accuracy`, options: { fontSize: 12, color: C.text2 } }],
      { x, y: 2.5, w: 2.4, h: 1.15, align: "center", valign: "middle", margin: 0, isTextBox: true });
  });
  s.addText([{ text: "Would you ship B? ", options: { bold: true, color: C.text1, breakLine: true } },
    ...bullets(["Class balance? “Always no” might score 85%", "Which errors does B fix, and what do they cost?", "Same test set? Is 2 points beyond noise?"], { space: 4 })],
  { x: MX + 0.3, y: 3.85, w: 5.2, h: 2.1, fontSize: 14, color: C.text2, margin: 0, valign: "top", isTextBox: true });
  const mae = r("Chronological", "Model C"), rmse = rm("Chronological", "Model C");
  s.addText("For a count, measure how far off you are", { x: 6.75, y: 1.95, w: 5.95, h: 0.45, fontSize: 18, bold: true, color: C.text1, fontFace: "Cambria", margin: 0, isTextBox: true });
  card(s, C, 6.75, 2.5, 5.95, 1.65, { fill: C.background1, head: `MAE = ${mae.toFixed(1)}`, headColor: C.accent2, body: "Mean absolute error: the typical miss, in rentals. Easy to explain to anyone.", bodySize: 15 });
  card(s, C, 6.75, 4.3, 5.95, 1.75, { fill: C.background1, head: `RMSE = ${rmse.toFixed(1)}`, headColor: C.accent1, body: "Root mean squared error: squares each miss, so big misses count far more. RMSE well above MAE hints at a tail of large errors.", bodySize: 15 });
  [2.5, 4.3].forEach((y) => s.addShape("rect", { x: 6.75, y, w: 5.95, h: y === 2.5 ? 1.65 : 1.75, fill: { type: "none" }, line: { color: HEX.grid, width: 1 }, objectName: oid("outline") }));
  ask(s, C, "Which errors matter most, and for whom?");
  done(s);
}

// 16 Error by hour
{
  const s = content(pres, C, SEC[3], { kick: "Trap 4 · Error analysis", title: "An average of 29 hides 73 at 5 pm" });
  const labs = byHour.map((h) => h.hr.padStart(2, "0"));
  L.addChart(pres, "LINE", [
    { name: "Model C", labels: labs, values: byHour.map((h) => Number(h.abs_err_C)) },
    { name: "Baseline · weekday × hour avg", labels: labs, values: byHour.map((h) => Number(h.abs_err_base)) },
  ], chartOpts(C, {
    x: MX, y: 1.85, w: 8.4, h: 4.25, title: "MAE by hour of day, chronological test (rentals / hour)",
    chartColors: [HEX.signal, HEX.faint], lineSize: 2.5, lineDataSymbol: "circle", lineDataSymbolSize: 5,
    showLegend: true, legendPos: "t", catAxisTitle: "hour of day", showCatAxisTitle: true, valAxisMinVal: 0, objectName: "chart-err-hour",
  }));
  const e = (h) => Number(byHour.find((x) => x.hr === String(h)).abs_err_C);
  stat(s, C, 9.4, 1.95, 3.3, { value: e(17).toFixed(1), label: "MAE at 17:00, the evening commute", size: 48 });
  stat(s, C, 9.4, 3.3, 3.3, { value: e(8).toFixed(1), label: "MAE at 08:00, the morning commute", size: 48 });
  stat(s, C, 9.4, 4.65, 3.3, { value: `${Math.round(e(4))}–${Math.round(e(2))}`, label: "MAE 02:00–04:00, when nobody rebalances", size: 48, color: C.accent3 });
  ask(s, C, "What's the error where the decision actually matters?");
  done(s);
}

// 17 Peaks
{
  const s = content(pres, C, SEC[3], { kick: "Trap 4 · Error analysis", title: "Peak hours: 10% of the time, 23% of the error" });
  const bl = share.map((b) => b.demand_band);
  L.addChart(pres, "BAR", [
    { name: "Share of test hours (%)", labels: bl, values: share.map((b) => Number(b.share_of_hours_pct)) },
    { name: "Share of absolute error (%)", labels: bl, values: share.map((b) => Number(b.share_of_abs_error_pct)) },
  ], chartOpts(C, {
    x: MX, y: 1.85, w: 6.6, h: 4.25, barDir: "col", barGrouping: "clustered", barGapWidthPct: 60, title: "By demand band (rentals in the hour)",
    chartColors: [HEX.faint, HEX.signal], showValue: true, dataLabelPosition: "outEnd", dataLabelFormatCode: "0.0", showLegend: true, legendPos: "t",
    valAxisMinVal: 0, valAxisMaxVal: 60, objectName: "chart-band-share",
  }));
  s.addTable([
    ["Band", "MAE", "MAE as % of demand"].map((t) => ({ text: t, options: { bold: true, color: HEX.ink, fill: { color: HEX.mist } } })),
    ...bands.map((b) => [b.demand_band, b.MAE_model, b.MAE_as_pct_of_demand + "%"].map((t) => ({ text: String(t), options: { color: HEX.slate } }))),
  ], { x: 7.55, y: 1.95, w: 5.15, colW: [2.15, 1.0, 2.0], fontSize: 14, fontFace: "Calibri", border: { type: "solid", pt: 0.75, color: HEX.grid }, rowH: 0.45, margin: [3, 6, 3, 6] });
  s.addText("Worst in bikes, best in percent. The decision decides which framing counts.", { x: 7.55, y: 3.95, w: 5.15, h: 0.7, fontSize: 15, bold: true, color: C.text1, margin: 0, isTextBox: true });
  const wr = wx.find((w) => w.weather.startsWith("Light")), wc = wx.find((w) => w.weather.startsWith("Clear"));
  s.addText([{ text: `Light rain / snow: MAE ${wr.MAE_model}`, options: { bold: true, color: C.accent1 } }, { text: ` vs ${wc.MAE_model} when clear (${wr.hours} vs ${Number(wc.hours).toLocaleString("en-US")} hours). The model sees last hour's weather, so sudden changes catch it out. A hint, not a proof.`, options: { color: C.text2 } }],
    { x: 7.55, y: 4.7, w: 5.15, h: 1.4, fontSize: 14, margin: 0, valign: "top", isTextBox: true });
  ask(s, C, "Bikes off, or percent off: which one does the decision feel?");
  done(s);
}

// 18 Limits
{
  const s = content(pres, C, SEC[3], { kick: "Limits", title: "What this result does not tell us" });
  card(s, C, MX, 1.95, 4.6, 4.05, { fill: C.accent2, head: "What we measured", headColor: C.background1, bodyColor: C.background1,
    body: `On four months it never saw, Model C predicts system-wide hourly rentals with a typical miss of ${r("Chronological", "Model C").toFixed(1)}, less than half the best simple rule's.`, bodySize: 16 });
  const nots = ["Whether a bike was available when someone wanted one", "How much demand went unmet: only rentals are recorded",
    "Whether rebalancing on this forecast beats today's practice (an experiment or labelled simulation)", "Anything about individual stations", "Whether anyone would act differently because of it"];
  nots.forEach((t, i) => {
    const y = 2.0 + i * 0.8;
    s.addShape("ellipse", { x: 5.6, y: y + 0.08, w: 0.42, h: 0.42, fill: { color: C.background2 }, line: { type: "none" }, objectName: oid("x-dot") });
    s.addText("✕", { x: 5.6, y: y + 0.08, w: 0.42, h: 0.42, fontSize: 14, bold: true, color: C.accent1, align: "center", valign: "middle", margin: 0, isTextBox: true });
    s.addText(t, { x: 6.2, y, w: 6.5, h: 0.6, fontSize: 15, color: C.text1, valign: "middle", margin: 0, isTextBox: true });
  });
  ask(s, C, "What would we need to measure next to support the bigger claim?");
  done(s);
}

// 19 Production loop
pres.addSection({ title: SEC[4] });
{
  const s = content(pres, C, SEC[4], { kick: "Trap 5 · Production", title: "The notebook stops at evaluation. Production keeps going" });
  const nodes = ["Data", "Target", "Features", "Split", "Model", "Evaluation", "Deploy", "Monitor", "Feedback"];
  const bw = 1.17, g = 0.2, y = 1.95;
  nodes.forEach((t, i) => {
    const x = MX + i * (bw + g), live = i >= 6;
    s.addShape("roundRect", { x, y, w: bw, h: 0.7, rectRadius: 0.1, fill: { color: live ? C.accent1 : C.background2 }, line: { type: "none" }, objectName: oid("node") });
    s.addText(t, { x, y, w: bw, h: 0.7, fontSize: 14, bold: true, color: live ? C.background1 : C.text1, align: "center", valign: "middle", margin: 0, isTextBox: true });
    if (i < nodes.length - 1) arrowRight(s, C, x + bw + 0.01, y + 0.35, g - 0.02);
  });
  const xe = MX + 8 * (bw + g) + bw / 2, xs = MX + bw / 2;
  s.addShape("line", { x: xe, y: y + 0.7, w: 0, h: 0.35, line: { color: HEX.signal, width: 1.75 }, objectName: oid("loop") });
  s.addShape("line", { x: xs, y: y + 1.05, w: xe - xs, h: 0, line: { color: HEX.signal, width: 1.75 }, objectName: oid("loop") });
  s.addShape("line", { x: xs, y: y + 0.72, w: 0, h: 0.33, flipV: true, line: { color: HEX.signal, width: 1.75, endArrowType: "triangle" }, objectName: oid("loop") });
  s.addText("Notebook", { x: MX, y: 3.08, w: 3, h: 0.3, fontSize: 12, color: C.accent3, margin: 0, isTextBox: true });
  s.addText("…and round again", { x: xe - 3, y: 3.08, w: 3, h: 0.3, fontSize: 12, color: C.accent1, align: "right", margin: 0, isTextBox: true });
  const risks = [
    ["Freshness", "Is last hour's count there by 17:00? What if the weather feed is down?"],
    ["Drift", "Growth, new stations, holidays, pricing, city events"],
    ["Latency", "Late is useless, down is worse. Keep a baseline as the fallback"],
    ["Monitoring", "Inputs, prediction spread, delayed truth, segment error, outcomes"],
    ["Feedback loops", "Acting on forecasts changes the data you retrain on"],
  ];
  const cw = 2.3, cg = 0.15;
  risks.forEach(([h, b], i) => card(s, C, MX + i * (cw + cg), 3.5, cw, 2.55, { num: i + 1, head: h, headSize: 16, body: b, bodySize: 14 }));
  ask(s, C, "How will we know it's working, and what happens when an input is late?");
  done(s);
}

// 20 Five rules
pres.addSection({ title: SEC[5] });
{
  const s = pres.addSlide({ masterName: "LIST_DARK", sectionTitle: SEC[5] });
  s.addText("Five rules to remember", { placeholder: "title" });
  const rules = [
    ["Understand the decision before touching the data", "“Predict bike demand” was four problems"],
    ["Ask when every feature became knowable", "Draw the line at the prediction moment"],
    ["Make validation resemble how the model will be used", "The split changed which model we'd pick"],
    ["Never celebrate a metric without inspecting the errors", "An average of 29 hid 73 at 5 pm"],
    ["Think about what happens after deployment", "Freshness · drift · latency · monitoring · feedback"],
  ];
  rules.forEach(([h, b], i) => {
    const y = 1.9 + i * 0.98;
    s.addShape("ellipse", { x: MX, y: y + 0.05, w: 0.6, h: 0.6, fill: { color: C.accent1 }, line: { type: "none" }, objectName: oid("rule-dot") });
    s.addText(String(i + 1), { x: MX, y: y + 0.05, w: 0.6, h: 0.6, fontSize: 20, bold: true, color: C.background1, align: "center", valign: "middle", margin: 0, isTextBox: true });
    s.addText([{ text: h, options: { fontSize: 22, bold: true, color: C.background1, breakLine: true, fontFace: "Cambria" } }, { text: b, options: { fontSize: 15, color: C.accent3 } }],
      { x: MX + 0.85, y, w: 11.2, h: 0.85, valign: "top", margin: 0, isTextBox: true });
  });
  done(s);
}

// 21 Close
{
  const s = pres.addSlide({ masterName: "STATEMENT_DARK", sectionTitle: SEC[5] });
  s.addText("Close", { placeholder: "kicker" });
  s.addText("AI can write the model. Judgment decides what to build, and what evidence is enough", { placeholder: "title" });
  s.addText("As code gets cheaper, the job shifts towards framing the problem, designing the evaluation, interpreting the errors, and thinking about the system around the model.", { placeholder: "body" });
  done(s);
}

// 22 References
{
  const s = content(pres, C, SEC[5], { kick: "References", title: "Sources, companion notebook, and your questions" });
  card(s, C, MX, 1.95, 6.0, 3.0, { head: "Data", body: bullets([
    "UCI Machine Learning Repository: Bike Sharing Dataset (id 275), hour.csv. archive.ics.uci.edu/dataset/275",
    "Fanaee-T & Gama (2013), Event labeling combining ensemble detectors and background knowledge. Progress in AI",
    "Source records: Capital Bikeshare system data · CC BY 4.0"], { space: 6 }), bodySize: 13 });
  card(s, C, 6.75, 1.95, 5.95, 3.0, { head: "Companion notebook", body: bullets([
    "s1_bike_demand.ipynb: contract, splits, baselines, models, error analysis",
    `Chronological split at 2012-09-01 · seed 42 · scikit-learn 1.9.1`,
    "Every chart and number in this deck is exported from it"], { space: 6 }), bodySize: 13 });
  s.addText([{ text: "Try this: ", options: { bold: true, color: C.accent1 } }, { text: "write the five-line prediction-time contract for a model you've built, and check every feature against it.", options: { color: C.text1 } }],
    { x: MX, y: 5.15, w: 12.1, h: 0.5, fontSize: 16, margin: 0, isTextBox: true });
  s.addText("Questions?", { x: MX, y: 5.75, w: 12.1, h: 0.8, fontSize: 36, bold: true, color: C.text1, fontFace: "Cambria", margin: 0, isTextBox: true });
  done(s);
}

if (n !== Object.keys(notes).length) console.warn(`WARNING: ${n} slides but ${Object.keys(notes).length} script sections`);
L.write(pres, path.join(__dirname, "Session1_ML_Traps.pptx"));
