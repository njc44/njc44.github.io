# Slide plan (source of truth for deck builders and scripts)

Speaker: Nathan Jacob — Data Scientist II, Meesho (Bangalore). Kaggle Expert.
Pace for scripts: ~130 words/min spoken. Each session = 60:00 including a ~3 min buffer for Q&A/transitions.
All numbers below are measured outputs from `notebooks/` → `outputs/s1|s2/*.csv`. Never use any other number.

---------------------------------------------------------------------------
## SESSION 1 — The ML Traps Nobody Warns You About (bike demand, UCI)
Times are cumulative start → end.

01  0:00–1:30   Title. "What Nobody Teaches You About Being a Data Scientist" / "Session 1 · The ML Traps Nobody Warns You About"
02  1:30–3:30   Who I am + what you'll leave with (3 promises). No coding required.
03  3:30–5:30   Opening question (dark): "If a demand forecast is accurate, will there be a bike when you need one?"
04  5:30–8:00   A model is one part of a decision system: decision → target → data → features → validation → action → outcome
05  8:00–10:30  "Predict bike demand." Four decisions hiding inside (rebalancing next hour / staffing / capacity planning / app availability) — each changes target, horizon, granularity
06  10:30–13:30 The prediction-time contract: decision, target (system rentals in hour t), prediction moment (start of hour t), allowed inputs, forbidden inputs. Timeline t−1 | t
07  13:30–15:30 The dataset is not the world: wanted a bike → found one → rented. Data only sees the last step. 165 missing hours; weather is observed, not forecast; cnt = casual + registered
08  15:30–17:00 Meet the data (chart: mean rentals by hour, working day vs weekend/holiday). Two commuter peaks vs one midday hump
09  17:00–19:30 Trap: leakage — three kinds: (1) future information (2) post-outcome fields (3) preprocessing/statistics learned before the split
10  19:30–21:30 Leak in action: Model A (all columns incl casual+registered) MAE 3.2 vs honest Model C MAE 29.1 (chronological). "Too good to be true is a signal"
11  21:30–24:00 Random vs chronological split (timeline diagram). Train < 2012-09-01 (14,330 hours), test 2012-09-01→12-31 (2,888 hours). Each answers a different question
12  24:00–27:00 Same rows, different question (chart): Model B (calendar + same-hour observed weather) random 25.2 vs chrono 43.6; Model C random 21.9 vs chrono 29.1. Random split made B look almost as good as C
13  27:00–29:00 Why: demand grew. Monthly mean rentals/hour 51 (Jan 2011) → 303.6 (Sep 2012). Train mean 180.7 vs test mean 240.2
14  29:00–32:00 Baseline first (chart): training mean 170.5 · weekday×hour avg 93.7 · same hour last week 70.0 · Model C 29.1 (MAE, chrono test, rentals/hour)
15  32:00–35:00 "84% vs 86% — would you ship B?" ILLUSTRATIVE classification thought experiment → regression metrics: MAE (typical miss, in rentals) vs RMSE (punishes big misses). Model C MAE 29.1 / RMSE 46.8
16  35:00–38:30 Error analysis by hour (chart: model MAE vs baseline MAE by hour). Model error peaks at 17:00 (73.1) and 08:00 (53.8)
17  38:30–41:30 Peaks carry the cost: peak hours (>566 rentals) are 10% of test hours but 22.8% of absolute error; MAE 66.4 at peak vs 15.8 at low. Light rain/snow MAE 39.5 vs clear 28.3. As % of demand, peak error is smaller (9.3%) — which framing matters depends on the decision
18  41:30–44:00 What this metric does not tell us: whether bikes were available, whether rebalancing worked, unmet demand, customer experience, whether a forecast changed any action
19  44:00–51:00 Notebook → production loop: data → target → features → split → model → evaluation → deployment → monitoring → feedback. Five risks: feature freshness, drift (new stations, holidays, growth), latency/reliability, monitoring (inputs, prediction distribution, delayed truth, segment error, outcomes), feedback loops (conceptual)
20  51:00–54:00 Five rules (dark)
21  54:00–57:00 Close: AI can write the model; judgment decides what to build and what evidence is enough
22  57:00–60:00 References + Q&A

---------------------------------------------------------------------------
## SESSION 2 — When a Good Model Fails in the Real World (NYC TLC trip duration)

01  0:00–1:30   Title. "What Nobody Teaches You About Being a Data Scientist" / "Session 2 · When a Good Model Fails in the Real World"
02  1:30–3:30   Who I am + standalone framing (no need for yesterday) + what you'll leave with
03  3:30–6:00   Scenario: estimate trip duration at the moment of pickup. Who uses it: rider ETA, dispatch/planning, upfront expectations. Out of scope: routing, pricing, traffic causality
04  6:00–9:00   Prediction-time contract (timeline: booking/pickup → trip → drop-off). Label = drop-off − pickup in minutes. Inputs only from the left of pickup
05  9:00–11:30  Same column, different verdict: Street hail (destination unknown) vs Booked trip (rider enters destination). Destination zone is leakage in one, a legitimate input in the other
06  11:30–13:00 Data provenance: NYC TLC Yellow Taxi, Jan–Mar 2024, 9,554,778 trips loaded; sample 200,000 cleaned trips per month (seed 42); zone lookup; terms
07  13:00–16:30 Cleaning funnel (chart/table): 9,554,778 → 9,213,159 (96.42% kept). Biggest removals: metered distance 0 (138,959), <1 min (106,722), unknown zones (86,594). DST: 992 trips span 2024-03-10 02:00 jump and look 60 min longer. "Cleaning decides the population you model"
08  16:30–19:00 Feature availability audit table (at pickup vs after trip)
09  19:00–22:00 Leakage trap: + trip_distance & fare_amount (taximeter, post-trip) → MAE 1.82 vs honest booked-trip model 3.76. Impossible at pickup
10  22:00–25:00 Baseline first (chart): overall median 8.47 · weekday×hour median 8.39 · route (zone→zone) median 4.87 · Model D 3.76 · Model S (street hail) 7.11. Time alone barely helps; the route does most of the work
11  25:00–27:00 Model + evaluation setup: one gradient-boosted tree model; target fixed; encoders fitted inside pipeline on train only; test = March
12  27:00–29:30 Chronological split timeline: train 1 Jan–29 Feb 2024 (400,000 trips) · test 1–31 Mar 2024 (200,000 trips)
13  29:30–32:30 Results table (chronological, minutes): MAE / RMSE / P90 for all 6 candidates
14  32:30–36:00 Random vs chronological — honest result: Model D 3.62 vs 3.76; route baseline 4.54 vs 4.87; Model S 6.88 vs 7.11. Small gap. What it does and doesn't tell us (only 1 month ahead, one season, no regime change). Plus preprocessing leak: route statistic learned on all months → 3.55 vs 3.76
15  36:00–38:30 What knowing the destination buys, by trip length (chart S vs D by duration band). 1–5 min: 8.95 vs 2.97; 60–180 min: 40.5 vs 21.93
16  38:30–41:00 Where it fails by hour (chart: Model D vs route baseline by pickup hour). Worst afternoon 15:00 (4.53). Model gains most at 4–6 am
17  41:00–44:00 Bias by trip length (chart: mean signed error by actual duration band): overpredicts short (+2.96 for 1–5 min), underpredicts long (−21.62 for 60–180). Duration bands defined using the actual outcome — analysis only
18  44:00–47:30 The long tail (chart: absolute-error distribution). Median abs error 2.52 min; worst 1% of trips = 39.4% of squared error (9.4% of absolute error); worst 5% = 64.2%. RMSE is mostly about the tail
19  47:30–50:00 Look at the rows: worst misses (e.g. Upper East Side → Midtown, 164.6 min actual, 11.0 predicted, 50.6 metered miles; Central Park → Clinton West, 152.9 min, 0.0 mi). Daily MAE peaked on 2024-03-28 (5.25 vs ~3.3–4.1 other days). Facts vs hypotheses
20  50:00–53:30 What can we conclude: Evidence / Plausible hypothesis / Untested (three columns)
21  53:30–56:30 What production would additionally require: destination at booking time, live feature pipeline, latency, drift (seasons, events, DST), monitoring with delayed labels, decision evaluation (A/B on rider experience), asymmetric cost of under- vs over-estimation
22  56:30–58:30 Close: the model is an artifact; the reasoning around it is the craft
23  58:30–60:00 References + Q&A
