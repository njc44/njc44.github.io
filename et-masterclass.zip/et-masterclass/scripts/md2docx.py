"""Minimal markdown → HTML → .docx (via macOS textutil) for reviewing scripts in Word / Google Docs."""
import html, re, subprocess, sys
from pathlib import Path

def inline(t):
    t = html.escape(t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"\*(.+?)\*", r"<i>\1</i>", t)
    t = re.sub(r"`(.+?)`", r"<code>\1</code>", t)
    return t

def convert(md):
    out, in_table, in_list = [], False, False
    for line in md.splitlines():
        if in_list and not line.startswith("- ") and not re.match(r"^\d+\. ", line):
            out.append("</ul>"); in_list = False
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if set("".join(cells)) <= set("-: "): continue
            if not in_table: out.append('<table border="1" cellpadding="4">'); in_table = True
            out.append("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in cells) + "</tr>"); continue
        elif in_table: out.append("</table>"); in_table = False
        if m := re.match(r"^(#{1,3}) (.*)", line): out.append(f"<h{len(m[1])}>{inline(m[2])}</h{len(m[1])}>")
        elif line.startswith("> "): out.append(f'<p style="color:#555"><i>{inline(line[2:])}</i></p>')
        elif line.startswith("- ") or re.match(r"^\d+\. ", line):
            if not in_list: out.append("<ul>"); in_list = True
            out.append(f"<li>{inline(re.sub(r'^(- |\\d+\\. )', '', line))}</li>")
        elif re.match(r"^\[.*\]$", line.strip()): out.append(f'<p style="color:#c0502b"><b>{inline(line)}</b></p>')
        elif line.strip(): out.append(f"<p>{inline(line)}</p>")
    if in_table: out.append("</table>")
    if in_list: out.append("</ul>")
    return '<html><head><meta charset="utf-8"><style>body{font-family:Calibri;font-size:12pt} h2{margin-top:18pt}</style></head><body>' + "\n".join(out) + "</body></html>"

for f in sys.argv[1:]:
    src = Path(f); h = src.with_suffix(".html")
    h.write_text(convert(src.read_text()))
    subprocess.run(["textutil", "-convert", "docx", "-output", str(src.with_suffix(".docx")), str(h)], check=True)
    h.unlink(); print("wrote", src.with_suffix(".docx"))
