# What Nobody Teaches You About Being a Data Scientist: Quick reference

## The one question
**What decision will this model support, and does our experiment actually tell us whether it will support that decision?**

## The decision system
Decision → Target → Data → Features → Model → Validation → Action → Outcome.
The score measures one link: predictions vs labels on your test set.

## The prediction-time contract (write it before you train)
- **Decision:** what will someone do differently because of the prediction?
- **Target:** exactly what is predicted, in what units, and what the data fails to observe
- **Predict at:** the moment the prediction is made
- **Allowed:** only information that exists at that moment
- **Forbidden:** anything known later, or computed from the answer (including statistics learned on test rows)

## Five rules
1. **Understand the decision before touching the data.** One vague request can hide several different problems.
2. **Ask when every feature became knowable.** Draw the line at the prediction moment. A model that's too good to be true usually has a leak.
3. **Make validation resemble how the model will be used.** Predicting the future means testing on a future the model hasn't seen. Measure the gap; don't assume it.
4. **Never celebrate a metric without inspecting the errors.** Beat a smart baseline on the same test rows, then break errors down by the segments the decision cares about. Check whether a few extreme cases dominate RMSE.
5. **Think about what happens after deployment.** Freshness, drift, latency and reliability, monitoring with delayed labels, and feedback loops.

## Sorting your conclusions
| Evidence | Plausible hypothesis | Untested |
|---|---|---|
| What your experiment measured | Fits the evidence, with an experiment you could run | Business impact and causal claims. These need an intervention, e.g. an A/B test |

## Questions to carry
- What decision changes if this prediction changes?
- What exactly is the target, and what does the dataset fail to observe?
- Would this feature exist at the moment the prediction is required?
- What future is the validation split asking the model to generalise to?
- Which errors matter most, and for whom?
- What evidence would justify shipping this model?
- What would we need to measure after deployment?
