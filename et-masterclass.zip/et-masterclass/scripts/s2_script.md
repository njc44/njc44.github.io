# Session 2 — When a Good Model Fails in the Real World · Speaker script

> Presenter note (not spoken). Written for roughly 130 words a minute, with about 10% slack for pauses and slide changes, so each section should take about its stated time when read at a relaxed pace. The cues in square brackets are for you and are not read aloud. [PAUSE] means stop for two or three seconds. [ASK THE ROOM] is a rhetorical question: leave a short silence, but don't wait for chat answers, because the session has to work for someone watching the recording. [POINT TO …] tells you where to direct attention on the slide. [OPTIONAL STORY] marks a personal aside you can keep or cut depending on time. Every number in this script comes from `notebooks/s2_taxi_duration.ipynb` (outputs in `outputs/s2/`). If you rerun the notebook and anything changes, update the script before you present.

## [01] Title
*0:00 → 1:30 · ~175 words*

Good evening, everyone, and welcome. Thank you for spending an hour with me.

The series is called "What Nobody Teaches You About Being a Data Scientist." Today's session is called "When a Good Model Fails in the Real World."

I want to say up front what that title does *not* mean. I won't be showing you a model that blew up in production, and I won't be laughing at anyone's mistakes. What I'll show you is quieter, and I think more useful. A model can be technically good, with clean code, a sensible algorithm and a decent score, and still not answer the question you think it answers.

We'll do that with one problem, start to finish. We'll take public New York City taxi data and try to predict how long a trip will take, at the moment the passenger gets in. We'll define the task, clean the data, build baselines, train a model, test it two different ways, and then look hard at where it goes wrong.

You don't need to code along. Just watch and ask yourself the questions with me.

## [02] Who I am, and what you'll leave with
*1:30 → 3:30 · ~235 words*

A quick word about me so you know where I'm coming from.

I'm Nathan Jacob. I'm a data scientist at Meesho, in Bangalore. A lot of my work is prediction problems that touch real customers. One of them is delivery-time prediction: the date you see when you enter your pincode. So "how long will this take?" is a question I think about a lot. I also compete on Kaggle, where I'm an Expert. Kaggle is great at teaching you to squeeze a score. It's less good at teaching you whether the score means anything, and that gap is really what today is about.

If you were here yesterday for Session 1, welcome back. Today stands on its own. If you missed it, you won't be lost. We'll rebuild every idea we need from scratch, on a different and slightly messier problem.

By the end of the hour, I'd like you to leave with three things.

First, the habit of writing down a *prediction-time contract*. That means saying exactly when the prediction happens and what information exists at that moment.

Second, the habit of building a baseline before you build a model, so you know what "good" actually means.

Third, the habit of reading errors, not just scores. You'll ask *where* the model fails, *for whom*, and *how badly*, and you'll be honest about what your experiment can and can't prove.

Let's start with the scenario.

## [03] The scenario: estimate trip duration at pickup
*3:30 → 6:00 · ~290 words*

Here's the setup. A passenger gets into a yellow taxi in New York. At that moment, we want to estimate how many minutes the trip will take.

Before we touch any data, it's worth asking who would actually use that number, because the answer shapes everything after it.

[ASK THE ROOM — who would want this estimate?]

A few possibilities. The rider might want an arrival estimate: "you'll be there in about fifteen minutes." An operator might want to know when a car will be free again, to plan the next pickup. A planning team might want typical durations by area and time of day, to think about how many cars they need on the road.

Notice that these users want slightly different things. A rider cares about *their* trip. A planner might care more about averages across thousands of trips. And some users care much more about one kind of mistake than the other. Telling a rider "ten minutes" when it's actually thirty is not the same as telling them "thirty" when it's actually ten. We'll come back to that at the end.

Just as important is what's *out of scope* today. We are not choosing routes. We are not setting prices. And we are not going to explain traffic. This is historical data, so we can measure how well we *predict* duration. We can't say what *causes* a trip to be slow. If you hear me drift into "the model is slow at 3 pm *because* of traffic," call me out, because I'd be making a claim the data can't support.

So, one sentence for the task: estimate trip duration in minutes, at the moment of pickup, using only what we know at that moment. That last clause is doing a lot of work, so let's write it down properly.

## [04] The prediction-time contract
*6:00 → 9:00 · ~350 words*

This is the most important slide of the session. If you take one diagram home, take this one.

[POINT TO THE TIMELINE]

Time runs left to right. There's the moment of pickup, then the trip happens, then there's drop-off. Our prediction happens *here*, at pickup. Everything on the left of that line is fair game. Everything on the right of it doesn't exist yet, as far as the model is concerned.

Now, the label: the thing we're trying to predict. In the data, every trip has a pickup timestamp and a drop-off timestamp. Our label is simply drop-off minus pickup, in minutes.

Here's the subtle part. To *build* that label, we need the drop-off timestamp. So drop-off time is in our dataset, sitting in a column right next to everything else. But it's only allowed to make the label. It is never allowed as an input. Same dataset, same table, completely different roles.

I call this the prediction-time contract, and I'd encourage you to write one for every project, even a toy one. It's four lines:

When is the prediction made? Here, at pickup.

What exactly is the target? Here, minutes from pickup to drop-off.

What inputs are allowed? Only information that genuinely exists at pickup.

What's forbidden? Anything that is only known after the trip, or anything computed from the answer.

Why bother writing this down? Because when you open a data file, every column looks equally available. They're all just columns. The file doesn't tell you *when* each value came into existence. A drop-off time, a fare and a pickup zone all sit side by side, in the same font, looking equally innocent.

[PAUSE]

Most of the trouble in applied machine learning comes from that one illusion. The file makes the future look like the present. The contract is how you break the illusion, deliberately, before you train anything.

And notice that the contract isn't something the data can tell you. You decide it, together with whoever will use the prediction. If the product team later says "actually, we want the estimate at booking, five minutes before pickup," the contract changes, and so does the list of allowed inputs. That's why it belongs on paper, where everyone can see it, and not just in your head.

Let me show you how quickly this gets interesting, with one column.

## [05] Same column, different verdict
*9:00 → 11:30 · ~290 words*

Here's a question that sounds like it has an obvious answer. Is the *destination zone*, where the trip ends, allowed as an input?

[ASK THE ROOM — is destination allowed or not?]

The honest answer is: it depends on the product. Let me show you two versions of the same business.

On the left, a *street hail*. Someone raises their hand on Fifth Avenue, gets in, and says where they're going. At the moment of pickup, the system doesn't know the destination. Or at least, the taxi meter doesn't. If we predict at pickup in this world, the destination zone is information from the future. Using it would be leakage. Leakage just means letting the model see information it wouldn't have at prediction time.

On the right, a *booked trip*. The rider opens an app, types in where they want to go, and then the car arrives. Now the destination is known *before* pickup. Using it isn't cheating at all. It's the most useful piece of information we have.

Same column. Same data file. Opposite verdicts. The difference isn't in the data. It's in the product and the moment of prediction.

So today I'm going to build *both*. I'll call them the street-hail model, which uses only time and pickup zone, and the booked-trip model, which also gets the destination zone. That lets us see, with real numbers, how much a single decision in the contract is worth.

One caveat, said clearly: yellow-taxi records are mostly street hails. When I build the booked-trip model, I'm *simulating* a scenario where the destination would have been known in advance. That's a legitimate experiment, as long as we say so, and I just did.

## [06] Data provenance
*11:30 → 13:00 · ~175 words*

Quickly, where the data comes from, because you should always be able to answer that in one breath.

This is the New York City Taxi and Limousine Commission's public trip record data, for yellow taxis, covering January, February and March of 2024. Three files, one per month. Together that's 9,554,778 trip records. There's also a small lookup file that maps each numbered taxi zone to a name and a borough.

The commission publishes a data dictionary, and I'd strongly encourage reading it before you write a line of code. It's where you'll find out what each column really means, including two we'll come back to: the trip distance and the fare.

These records are submitted by technology providers, and the commission doesn't guarantee their accuracy. So we should expect some mess.

To keep the notebook fast, after cleaning I take a random sample of 200,000 trips from each month, with a fixed random seed so anyone can reproduce it. Six hundred thousand trips is plenty for what we're doing.

## [07] Cleaning decides the population you model
*13:00 → 16:30 · ~410 words*

Now, cleaning. People often talk about cleaning as a janitorial step, something you get out of the way before the real work. I want to push back on that. Every cleaning rule is a decision about *which trips your model is about*.

[POINT TO THE FUNNEL]

We start with 9,554,778 trips. Here's each rule and how many rows it removed.

First, pickup dates that fall outside the file's month. There were 56 rows with pickups dated 2002 or 2008, which is clearly not a real 2024 trip.

Then durations of zero or less: 2,801 trips that end before, or exactly when, they begin.

Then trips shorter than one minute: 106,722. That's a big group. Some might be real but tiny trips. Many are probably cancellations or meter glitches.

Then trips longer than three hours: 6,102.

Then trips where the pickup or drop-off zone is "unknown": 86,594.

Then trips where the metered distance is zero: 138,959. This is the single biggest removal.

And finally, trips with an implied average speed above 80 miles an hour, which in New York is not a taxi, it's a data error: 385.

At the end we have 9,213,159 trips, about 96.4% of what we started with.

Here's why this matters. Take the one-minute rule. If I'd drawn the line at two minutes instead, I'd be modelling a slightly different population, and my error numbers would change. Neither is "correct." But if I don't report the rule, nobody reading my results knows which population the numbers describe. So the rule is: log every filter, with its count, every time.

One more thing I found that I didn't expect. On the 10th of March 2024, daylight saving time started in New York. At 2 am, clocks jumped to 3 am. The timestamps in this data are local clock times. So a trip that starts at 1:50 am and ends at 3:10 am on the clock looks like eighty minutes, when it was actually about twenty.

[PAUSE]

In our cleaned data, 992 trips cross that jump. That's small next to nine million. But it's a perfect example of a bug that no model will ever warn you about. You only find it by asking, "how exactly was this timestamp recorded?" In this notebook I've counted them and left them in, which is fine for a demo, but correcting them is one more thing to check before anything goes near production.

## [08] Feature availability audit
*16:30 → 19:00 · ~290 words*

With clean data, the tempting next step is to throw every column into the model. Let's resist that for two minutes and do an audit instead. For each field, we ask one question: *when does this become knowable?*

[POINT TO THE TABLE, ROW BY ROW]

The pickup timestamp is known at pickup. From it we can derive the hour, the day of the week and the minute of the day. Those are safe.

The pickup zone is known at pickup. Safe.

The destination zone, as we just discussed, is known only if the rider enters it in advance, so we use it in the booked-trip scenario only.

Passenger count is entered by the driver. It's known at pickup in principle, but it's often missing or unreliable in this data, so I've left it out. That's a judgment call, and I'm telling you about it.

Now the bottom half of the table. Drop-off timestamp: that's after the trip, and it *defines* the label. Never an input.

Trip distance. This one's interesting. It *sounds* like something you'd know: "it's a five-mile trip." But read the data dictionary, and it says this is the distance *reported by the taximeter*. It's measured as the trip happens and finalised at the end. It reflects the route the driver actually took, including detours.

Fare amount is calculated by the meter from time and distance. It literally contains the duration inside it.

And tips, tolls, total amount and payment type are all after the trip.

[PAUSE]

Here's the takeaway. You can't do this audit from the column names. "Trip distance" sounds harmless. You have to read the documentation and ask, honestly, "at the moment of prediction, does this number exist yet?"

## [09] The leakage trap
*19:00 → 22:00 · ~350 words*

Let's see what happens if we skip that audit. It's an easy mistake to make, and I want to show you how good it looks.

Here's the naive path. And it really is reasonable-sounding. "Duration obviously depends on distance. Longer trips take longer. Let's include trip distance. Fare too, while we're at it. It's all in the file." A competent person could absolutely do this, especially under time pressure.

So I took the booked-trip model, which already knows the pickup zone, the destination zone and the time, and I added metered distance and fare.

[POINT TO THE TWO NUMBERS]

We'll measure error with MAE, which stands for mean absolute error. It's the average size of a miss, in minutes. If MAE is 4, then on average our prediction is off by 4 minutes, either too high or too low.

The honest booked-trip model has an MAE of 3.76 minutes on our test month. The model with distance and fare has an MAE of 1.82 minutes. That's less than half the error.

[PAUSE]

If you saw that on someone's slide, you'd be impressed. I would be too. But that model is impossible to run. At the moment of pickup, the meter has not measured the distance. The fare doesn't exist. The model is predicting the trip's duration using numbers that are partly *made out of* the trip's duration.

This is what makes leakage dangerous. It doesn't make your model look broken. It makes your model look *great*. The offline score goes up, everyone's happy, and then you deploy and the feature simply isn't there. Either the system crashes, or you fill in a placeholder and the model's performance collapses to something you never measured.

So here's a habit worth building. When a result is surprisingly good, treat that as a signal to investigate, not a reason to celebrate. Ask: "which feature is doing the work, and when did it become knowable?" Nine times out of ten, a too-good number has a boring explanation, and the boring explanation is usually a leak.

## [10] Baseline first
*22:00 → 25:00 · ~350 words*

Now let's build things properly. And the first thing I build is not a model. It's a baseline.

A baseline is the simplest reasonable prediction you can make without any machine learning. It tells you what "good" means. Without one, a number like 3.76 minutes is meaningless. Is that impressive? Terrible? You can't tell.

[POINT TO THE BARS, TOP TO BOTTOM]

Baseline one: predict the overall median trip duration from the training months for every trip. The median is the middle value. I use it instead of the average because a few very long trips would drag an average up. That gives an MAE of 8.47 minutes.

Baseline two: the median for that day of the week and hour of the day. So Monday at 9 am gets its own number, Saturday at 11 pm gets another. This feels much smarter. And its MAE is 8.39. Almost no improvement.

[PAUSE]

That's genuinely surprising, and it's worth sitting with. Our instinct says time of day matters enormously in New York traffic. Maybe it does matter for *speed*. But across all trips, knowing the hour barely helps you guess the *duration*. Why? Because the biggest thing that determines a trip's duration is *where it's going*, and time of day doesn't tell you that.

Which brings us to baseline three: the median duration for this route, meaning this pickup zone to this destination zone, as seen in the training months. That's a simple lookup table. No learning, just a table. Its MAE is 4.87 minutes. A huge jump.

And then the models. The street-hail model, with time and pickup zone only, gets 7.11. Better than the time-only baseline, but nowhere near the route table. The booked-trip model, which adds the destination, gets 3.76.

So here's the honest story. The model *does* beat the best baseline, by about a minute. But most of the improvement over "predict the median" comes from one thing: knowing the route. A lookup table gets you most of the way there. If I hadn't built that baseline, I might have credited the model with work that a lookup table does for free.

## [11] Model and evaluation setup
*25:00 → 27:00 · ~235 words*

Let me be precise about how the model was built, because the details matter for whether the comparison is fair.

There's one model: a gradient-boosted tree regressor. If that's new to you, think of it as a large number of small decision trees, each one correcting the mistakes of the ones before. It's a standard, strong choice for tabular data. I deliberately didn't try ten algorithms. This isn't a leaderboard. The reasoning matters more than the algorithm.

The target is fixed: minutes, pickup to drop-off. Every candidate, baselines and models, is scored on exactly the same test trips, with exactly the same metric code.

Now the part people skip. The pickup and destination zones are just ID numbers, 1 to 263. To make them useful, I turn each zone, and each route, into a number based on typical durations. That's called target encoding. It's powerful, but it learns from the label. So it must be learned *only* from the training data. In the notebook, it sits *inside* the modelling pipeline. When the model is fitted on training data, the encoding is fitted on training data too, and it's simply *applied* to the test set.

Hold onto that, because in a few slides I'll show you what happens when you learn that encoding from all the data instead. It's a subtle leak, and it's one that a lot of us have made at some point.

## [12] Chronological split
*27:00 → 29:30 · ~290 words*

Next decision: how do we test?

[POINT TO THE TIMELINE]

I trained on everything from the 1st of January to the 29th of February 2024: that's 400,000 trips. And I tested on the 1st to the 31st of March: 200,000 trips the model never saw.

This is called a chronological split, sometimes a time-based split. The model learns from the past and is tested on a period that comes after it.

Why do it this way? Go back to the contract. When this model is used for real, it'll be trained on data up to some date, and then it will make predictions about trips that haven't happened yet. A chronological split copies that situation. It asks a specific question: "if I'd trained this model at the end of February, how well would it have done in March?"

The common alternative is a random split. You shuffle all the trips from all three months together and pick a random quarter to test on. That's what most tutorials do, and it's not wrong in itself. It answers a *different* question: "how well does this model do on trips drawn from the same mix of days it was trained on?"

Neither question is wrong. The point is to pick the one that matches how the model will be used. For a model that will predict the future, the chronological question is the one we care about.

One honest limitation. March is just one month, and it's right next to the training period. It's a fairly gentle test of the future. We'll talk about what a tougher test would look like in a moment.

## [13] Results table
*29:30 → 32:30 · ~350 words*

Here's the full results table, all on the chronological test: March 2024, 200,000 trips. All numbers are in minutes.

[POINT TO THE COLUMNS]

There are three metrics, and I want to explain each in plain language.

MAE, mean absolute error: the average size of a miss.

RMSE, root mean squared error. It squares each miss before averaging, then takes the square root. Squaring makes big misses count much more than small ones. A 20-minute miss counts four hundred times as much as a one-minute miss before the square root. So RMSE is a measure that's very sensitive to your worst predictions.

P90 absolute error: 90% of trips have an error smaller than this number. It answers, "how bad is a bad-ish day for a typical rider?"

Now the rows. Overall median: MAE 8.47, RMSE 13.55, P90 19.28. Weekday-and-hour median: 8.39, 13.45, 19.1. Route median: 4.87, 8.77, 10.5. Street-hail model: 7.11, 10.49, 14.15. Booked-trip model: 3.76, 6.16, 7.78. And, for reference only, the leaky model: 1.82, 4.28, 4.3, which, remember, can't actually run.

A few things to notice.

The booked-trip model is the best legitimate candidate on all three metrics. That's a consistent result, which is reassuring.

The gap between MAE and RMSE is large for every row. For the booked-trip model, a typical miss is under four minutes, but RMSE is above six. That gap is a hint that some trips have very large errors. We'll go hunting for them shortly.

Also notice where the street-hail model sits. It's at 7.11, worse than the simple route lookup table at 4.87. That isn't a flaw in the street-hail model. It's playing a harder game, because it doesn't know the destination. Comparing those two rows directly would be unfair, because they answer different product questions. The fair comparison for the street-hail model is against the time-only baselines, where it wins by more than a minute.

And look at P90 for the booked-trip model: 7.78. So nine out of ten riders would see an estimate within about eight minutes. Whether that's good enough isn't a modelling question. It depends entirely on what the estimate is being used for, which is why we started with the user.

## [14] Random vs chronological: the honest result
*32:30 → 36:00 · ~410 words*

Now the experiment I promised. Let's take the same 600,000 trips, shuffle them, and test on a random 200,000 instead of on March. Same model, same features, same metric code.

[ASK THE ROOM — how much better do you think the random split will look?]

A common expectation, and one I had too, is that the random split will look much rosier. Here's what we actually measured.

[POINT TO THE PAIRS]

Booked-trip model: random 3.62, chronological 3.76. Route baseline: random 4.54, chronological 4.87. Street-hail model: random 6.88, chronological 7.11.

The random split looks a little better every time. But the gap is small, roughly a tenth to a third of a minute.

[PAUSE]

I want to be very clear: this small gap is a real finding, not a failed demo. I could have hunted for a different month or a different setup that made the gap dramatic. That would have been dishonest, and it would have taught you the wrong lesson: that random splits are always wildly optimistic. They're not. Sometimes the past and the future just look similar.

Why might they look similar here? These are hypotheses, not conclusions. We're only predicting one month ahead. January to March is all roughly the same season. The sample is very large, so the model isn't memorising individual days. And taxi patterns in a big city are fairly stable week to week.

What this experiment *doesn't* tell us is how the model would do on a genuinely different future. To test that, you'd design a harder split. For example, you could train on winter and test on summer, or hold out holiday weeks, or test on a period after a known change in the city. That's the next experiment I'd run before trusting this model across a whole year.

And one more contrast on this slide: the subtle leak I mentioned. Remember the route encoding, which has to be learned only from training data? I deliberately broke that rule. I computed each route's median duration using *all three months*, including March, and then trained and tested the same model. MAE dropped from 3.76 to 3.55. RMSE dropped from 6.16 to 5.69.

That's a fairly small improvement, but it's *fake*. The model was quietly given a summary of the test month. Nothing in the code looks wrong, and nothing crashes. It's only visible if you ask, "where was this statistic learned from?"

## [15] What knowing the destination buys
*36:00 → 38:30 · ~290 words*

Let's go back to the two scenarios, street hail versus booked trip, and look at *where* knowing the destination helps.

[POINT TO THE CHART]

I've grouped the March trips by how long they actually took, and for each group, I'm showing the MAE of both models.

One note on method first. I'm grouping trips by their *actual* duration. That's fine for analysis, after the fact, because we're asking "which trips did we get wrong?" But you couldn't use these groups as an input, because you don't know the duration in advance.

Now, the pattern. For very short trips, one to five minutes, the street-hail model's MAE is 8.95 minutes and the booked-trip model's is 2.97. The street-hail model is way off, because it has no idea the trip is short. It's guessing something closer to a typical trip.

In the middle, ten to twenty minutes, the two models are almost the same: 3.16 versus 2.99. That makes sense. Those are typical trips, and "typical" is exactly what the street-hail model predicts.

And at the long end, sixty minutes and up, the street-hail model is off by 40.5 minutes on average, and the booked-trip model by 21.93. Better, but still huge.

There's also a lesson about metrics hiding here. If you only looked at the middle band, where most trips sit, you might conclude that the destination barely matters, since 3.16 versus 2.99 isn't much. The value of that information shows up at the edges, in exactly the trips an average tends to wash out.

So the product decision, "do we ask riders where they're going?", isn't a small modelling detail. It changes the error at the extremes by a factor of two or three. That's the kind of finding you can take to a product manager. It's not "my model is better." It's "here's what this piece of information is worth, and for which trips."

## [16] Where it fails, by hour
*38:30 → 41:00 · ~290 words*

Now let's break the booked-trip model's error down by the hour of pickup, and put the route baseline next to it.

[POINT TO THE TWO LINES]

The model's error is lowest late in the evening, around 9 pm, at about 2.86 minutes. It climbs through the day and peaks in the mid-afternoon: 4.53 minutes at 3 pm.

Here's a mistake I'd gently warn you against. It's tempting to read that line and say "afternoon traffic is unpredictable." That might be true. But this chart can't show it. Afternoon trips might simply be longer on average, and longer trips have bigger errors in minutes. In fact, the average trip duration in March is highest around 3 pm, at 19.39 minutes. So part of what we're seeing is just *which trips happen* at that hour. Before blaming traffic, you'd want to compare like with like, for example by looking at error as a percentage of duration, or within route.

The second interesting thing is the gap between the model and the baseline. The model beats the route lookup at every hour, but the gap is biggest in the early morning. At 5 am, the route baseline is off by 7.89 minutes and the model by 3.88. A plausible reason is that a route's typical duration is dominated by daytime trips, so the lookup table is wrong for empty early-morning roads, while the model also knows the hour. That's a hypothesis, but a sensible one, and it tells you where the model's "learning" is actually adding value over a table.

Also keep the sample sizes in mind. There are about 1,250 test trips at 5 am, and over 14,000 at 6 pm. The early-morning numbers are still based on plenty of trips, but they're noisier, and a few odd trips can move them more. Always check how many rows sit behind a segment before you read too much into it.

## [17] Bias by trip length
*41:00 → 44:00 · ~350 words*

So far we've looked at the *size* of errors. Now let's look at their *direction*. Is the model too high or too low?

[POINT TO THE BARS]

This chart shows the mean *signed* error, by actual trip duration. Positive means the model predicted too long. Negative means it predicted too short.

For trips that actually took one to five minutes, the model overestimates by 2.96 minutes on average. For five to ten minutes, it overestimates by 1.27. For ten to twenty minutes, it's almost spot on: minus 0.38. Then it flips. For twenty to thirty minutes, it underestimates by 2.48. Thirty to forty-five, by 5.07. Forty-five to sixty, by 8.37. And for trips longer than an hour, it underestimates by 21.62 minutes on average.

[PAUSE]

This is a very common pattern, and it has a name: regression toward the mean. When a model is uncertain, it hedges towards typical values. So it pulls short trips up and long trips down.

Again, a word on method. Grouping by the *actual* outcome will always exaggerate this pattern somewhat, because the trips that ended up very long are partly the ones where something unusual happened that no model could foresee. So this isn't proof the model is badly built. But it's still extremely important to know, for a reason that has nothing to do with statistics.

Think back to our users. If this estimate is shown to a rider, then the trips where we're most wrong are the long ones, and we're wrong in the *optimistic* direction. We tell people they'll arrive earlier than they do. For many products, that's the worse direction to be wrong in. An aggregate MAE of 3.76 hides that completely.

So the question isn't just "how big is the error?" It's "which way is it wrong, for which trips, and which direction hurts more?" That third question isn't a data science question. It's a product question, and you have to go and ask it.

## [18] The long tail
*44:00 → 47:30 · ~410 words*

Let's zoom out to the whole distribution of errors.

[POINT TO THE HISTOGRAM]

This chart shows, for every trip in March, how far off the booked-trip model was, in absolute minutes, grouped into bins.

The left side is reassuring. About 21% of trips are within one minute. Another 20% are off by one to two minutes. Add the next bin, and more than half of all trips, around 57%, are within three minutes. The median absolute error, the middle trip, is 2.52 minutes. That's lower than the MAE of 3.76, which already tells you a few large errors are pulling the average up.

And then there's the right side. It's small, but it goes a long way: errors of ten, twenty, thirty minutes, even more than an hour. Only about 6% of trips are off by more than ten minutes. But look at what they do to the metric.

[PAUSE]

If you take the worst 1% of trips, just one in a hundred, they account for 39.4% of the total squared error. Remember, squared error is what RMSE is built from. The worst 5% of trips account for 64.2% of it.

Now compare that to absolute error, what MAE is built from. The same worst 1% of trips account for just 9.4% of the total absolute error.

So here's the practical lesson. RMSE, for this model, is mostly a measure of the tail. If you optimise for RMSE, you're mainly trying to fix a small number of very bad trips. If you optimise for MAE, you're mainly trying to improve the typical trip. Neither is wrong, but they are *different goals*, and you should choose the metric on purpose, based on which errors matter for the decision, not because it's the default in a library.

One more way to see it. Suppose next week someone tells you, "I improved RMSE by ten percent." Before you get excited, ask, "Did the typical trip get better, or did you fix a handful of three-hour outliers, some of which might not even be real trips?" Both could be true, but they mean very different things for a rider.

And there's a second lesson. When a small fraction of rows dominates a metric, you should always go and *look at those rows*. Some of them will be real, rare events. Some of them will be data problems. And until you look, you don't know which, and you don't know whether "improving the model" even makes sense for them. So let's look.

## [19] Look at the rows
*47:30 → 50:00 · ~290 words*

Here are some of the worst misses in March.

[POINT TO THE FIRST ROW]

A trip from Upper East Side South to Midtown Center. That's a short hop in Manhattan. The model predicted 11 minutes. The recorded duration is 164.6 minutes, and the meter recorded 50.6 miles. To go fifty miles between two neighbouring areas, either the passenger took a very long detour, or the meter was left running, or something else happened that we can't see.

Another one: Central Park to Clinton West. It was recorded as 152.9 minutes, with a metered distance that rounds to zero miles. The model predicted about 14.

[PAUSE]

Here's where I want to be disciplined. What do we actually *know*? We know the recorded timestamps and the recorded distance. Everything else, whether it's "the meter was left on," "the passenger was waiting," or "there was a road closure," is a hypothesis. Some of these rows may be valid trips. Some may be data errors that slipped past our cleaning rules. The right response is not to invent a story. It's to write down the hypothesis and what evidence would test it.

Second observation, on the daily chart: across March, the model's daily MAE mostly sits between about 3.3 and 4.1 minutes. But on the 28th of March, it jumped to 5.25, and the average trip that day was noticeably longer, at 19 minutes.

That's a fact. And notice the two numbers move together: when trips are longer than usual, errors tend to be larger too. What we *don't* know is why. What I'd check next is an event calendar, city traffic advisories and the weather for that day. Until then, it goes in the "unexplained, worth investigating" column, not in the "cause" column.

## [20] What can we conclude?
*50:00 → 53:30 · ~410 words*

Let's pull this together. I find it really useful to sort every claim into three columns: what the evidence supports, what's a plausible hypothesis, and what we simply haven't tested.

[POINT TO THE LEFT COLUMN]

*Evidence.* These are things our experiment actually measured.

On March 2024 yellow-taxi trips, a booked-trip model that uses time, pickup zone and destination zone has an MAE of 3.76 minutes, beating the best baseline, the route lookup, at 4.87.

Most of the improvement over a naive median comes from knowing the route.

A model that uses metered distance and fare scores far better, but it can't be run at pickup, so its score is irrelevant to this task.

Learning the route statistic from all months, including the test month, makes results look better than they should.

On this data, the random split looked only slightly better than the chronological split.

And errors are concentrated in a long tail, with long trips systematically underestimated.

[POINT TO THE MIDDLE COLUMN]

*Plausible hypotheses.* These are things that fit the evidence but that we haven't tested.

The small gap between the random and chronological splits might be because March is close to the training period and in the same season.

Afternoon errors might reflect longer trips rather than harder-to-predict conditions.

Some of the extreme errors might be meter or recording problems rather than real trips.

The 28th of March might have had something unusual going on.

Each of these comes with an experiment you could run.

[POINT TO THE RIGHT COLUMN]

*Untested*, and you should be very careful here. We have not shown that this model would improve rider satisfaction. We have not shown it would reduce waiting times, help dispatch, increase revenue or cause anything at all. We've shown that it *predicts* durations, on one month of historical data, with a certain error.

Going from "it predicts well" to "it improves something" needs a different kind of evidence. Usually that's a controlled experiment, like an A/B test, where some users get the estimate and some don't, and you measure the outcome you actually care about.

[PAUSE]

If you get into the habit of writing these three columns at the end of every analysis, you'll be more trusted than people with better models. Because the person reading your work knows exactly how far they can lean on it.

## [21] What production would additionally require
*53:30 → 56:30 · ~350 words*

Suppose we're happy with the evidence, and someone says, "Great, ship it." What else would have to be true?

First, the inputs have to exist *live*. In the booked-trip scenario, the destination has to be captured at booking time, reliably, and handed to the model before pickup. If the app sometimes doesn't have it, what does the model do? Fall back to the street-hail model? That needs to be designed.

Second, latency. The estimate has to arrive while it's still useful: before the rider looks away, not thirty seconds later.

Third, drift. That's the world changing out from under the model. We tested on March. The city in July, during a heatwave or a big event week or a holiday, might look different. And remember the daylight-saving bug? That happens twice a year, every year. Something has to watch for it.

Fourth, monitoring. You'd watch the inputs for missing or strange values. You'd watch the distribution of predictions. And you'd watch the actual error, which is a little tricky, because the true duration only arrives once the trip ends. So your monitoring is always running slightly behind.

There's also a subtler loop to think about. If the estimate is shown to riders and drivers, it might change behaviour. Riders might choose differently, and dispatch might plan around it. Then the data you collect next month is partly shaped by your own model. That's not something this historical data can show us, but it's something to plan for.

Fifth, deciding whether it actually helps. That's the experiment we just talked about: a controlled test, measuring the outcome users care about, not just MAE.

And sixth, the cost of being wrong. Remember, our model underestimates long trips. For a rider, being told "fifteen minutes" when it's forty is much worse than being told "twenty" when it's fifteen. In that situation, you might not want the model to predict the *middle* outcome. You might want it to predict a slightly cautious number, a high percentile, so most people arrive before the estimate. That's a change to the target and the loss function, driven entirely by the decision.

[OPTIONAL STORY — keep it short and generic. Something like: "This is very close to a problem I work on: the delivery date you see when you enter your pincode. If the promise is too optimistic, deliveries arrive late, and you get cancellations and returns. If it's too cautious, people don't buy. So we deliberately predict a high percentile, not the average. The hard part wasn't the algorithm. It was deciding which mistake costs more." No internal numbers.]

## [22] Close: the model is an artifact; the reasoning is the craft
*56:30 → 58:30 · ~235 words*

Let me close with the idea in the title of this slide.

Today, the model was the easy part. Training a gradient-boosted tree on six hundred thousand rows took a few lines of code. And with AI coding assistants, those lines are getting easier to write every month. That's genuinely good news. It frees up your time.

But look at what actually decided whether our results meant anything. It wasn't the algorithm.

It was writing down the prediction-time contract, and spotting that the destination zone is fine in one product and leakage in another.

It was reading the data dictionary and realising that "trip distance" is measured by the meter, after the trip.

It was logging the cleaning rules and finding the daylight-saving bug.

It was building a lookup-table baseline that did most of the model's work for free.

It was running the random split and reporting the small gap honestly, instead of hunting for a dramatic one.

And it was looking at the tail, at the rows, and sorting our claims into evidence, hypothesis and untested.

[PAUSE]

None of that gets automated away by better tools. If anything, as models get easier to build, this kind of judgment becomes the main thing that makes a data scientist valuable. The model is the artifact. The reasoning around it is the craft.

## [23] References and Q&A
*58:30 → 60:00 · ~175 words*

On the screen are the sources. There's the TLC trip record data and its data dictionary, the taxi zone lookup, and the scikit-learn tools we used. The companion notebook records every cleaning rule, the split dates, the sample sizes, the random seed and the package versions, so every number you saw today can be reproduced.

If you take away just one habit from this session, make it this one. Before you train anything, write down the moment of prediction and what genuinely exists at that moment. Then, at the end, write down what your evidence supports, what's a hypothesis, and what's untested. Do those two things and you'll already be ahead of a lot of models that look great on paper.

Thank you so much for your attention and your time.

[PAUSE]

I'd love to take your questions now. Anything about the experiments, about how you'd handle this in your own work, or about being a data scientist more generally. Fire away.
