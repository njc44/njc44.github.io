<!-- Slide number: 1 -->
ET Masterclass  ·  Session 1 of 2
What Nobody Teaches You About Being a Data Scientist
The ML Traps Nobody Warns You About
Nathan Jacob  ·  Data Scientist, Meesho
No coding required: just watch and think along

### Notes:
TIMING: 0:00 → 1:30 · ~175 words
Good evening, everyone, and thank you for being here.

This masterclass is called "What Nobody Teaches You About Being a Data Scientist." Today is the first of two sessions. This one is called "The ML Traps Nobody Warns You About."

Let me say up front what this session is not. It's not a tutorial on a new algorithm. You won't need to open a laptop, install anything, or write a line of code. Just watch, and think along with me.

What we will do is take one simple, very public prediction problem, forecasting how many bikes people will rent in a city, and walk through it the way it usually gets done. And at a few points along the way, we'll stop and ask a question that changes the answer.

None of the mistakes we'll look at are silly. Every one of them is something a smart, well-trained person does by default. That's exactly why they're worth an hour.

So let's begin.

<!-- Slide number: 2 -->
BEFORE WE START
Kaggle hands you the target, split and metric. A job doesn't
You'll leave with
Nathan Jacob
Frame it
Turn a vague request into a decision, a target and a prediction moment
1
Data Scientist, Meesho (Bangalore)
Delivery-time prediction, voice & language AI, counterfeit detection
Kaggle Expert
Ask “when was this knowable?”
The one question that catches most leakage
2
Read the errors, then think past launch
Baselines, segment errors, and what changes after deployment
3
Each session stands on its own. Tomorrow's session isn't required to follow this one, and this one isn't required for tomorrow's.
2

### Notes:
TIMING: 1:30 → 3:30 · ~235 words
A quick word about me, so you know where these examples come from.

I'm Nathan Jacob. I'm a data scientist at Meesho in Bangalore, and I've spent the last few years building models that have to survive contact with production. That includes delivery-time prediction, voice and language systems, and fraud and counterfeit detection. Outside work, I compete on Kaggle.

I mention Kaggle on purpose. Kaggle is wonderful for learning how to build a model. But a competition hands you a lot of things for free: the target is already defined, the split is already made, and the metric is already chosen. In a real job, those three are usually the hardest part, and nobody hands them to you.

So here's what I'd like you to leave with today. Three things.

One: a way to turn a vague request into a precise prediction task, so you know what decision the model supports, what it predicts, and exactly when.

Two: the habit of asking, for every single input, "when did this become knowable?" That one question catches most leakage.

Three: the instinct not to trust a single metric until you've looked at where the errors are, and to think about what happens after the model is switched on.

And one more thing: if you only come to one of the two sessions, that's completely fine. Each one stands on its own.

<!-- Slide number: 3 -->
Opening question
If a demand forecast is accurate, will there be a bike when you need one?
A forecast is a number. A bike at the dock is an outcome. Someone has to act in between.
3

### Notes:
TIMING: 3:30 → 5:30 · ~235 words
Let me start with a question. I'd like you to actually think about it before I answer.

[PAUSE]

If a demand forecast is accurate, will there be a bike when you need one?

[ASK THE ROOM — rhetorical, don't wait]

Most people's first instinct is "yes, probably." If we know how many people will want bikes, we can make sure there are enough bikes. That sounds right.

But look at what's hiding inside that sentence. The forecast is a number. A bike being there when you need it is an outcome in the physical world. To get from one to the other, somebody has to act: a truck has to move bikes from a full station to an empty one, at the right time, with enough lead time, and with enough capacity on the truck.

The forecast can be perfect and you can still walk up to an empty dock. Maybe the truck was already busy. Maybe the forecast arrived after the decision was made. Maybe it predicted the city total when the problem was one particular station.

So right away there's a gap between predicting something and changing something. Our whole job lives in that gap.

I'm going to come back to this question at the end. For now, just hold on to it: a good prediction is necessary, but it's not the same thing as a good outcome.

<!-- Slide number: 4 -->
THE MENTAL MODEL
A model is one link in a decision system
Where real failures usually start
Where real failures usually show up
Decision
Target
Data
Features
Model
Validation
Action
Outcome
Where tutorials spend their time
The score measures one link: how well predictions match labels on your test set. It can't tell you whether you chose the right labels, whether the test set looks like the future, or whether anyone acted on the predictions.
Ask:  What decision will this model support, and does our experiment tell us whether it will?
4

### Notes:
TIMING: 5:30 → 8:00 · ~290 words
Here's the picture I'd like you to carry through the whole session.

[POINT TO THE CHAIN]

When we say "the model," we usually mean the thing in the middle that gets trained. But a model never stands alone. It sits inside a chain.

On the left there's a decision: something someone will do differently because of the prediction. That decision tells us what the target should be. The target tells us what data we need. The data limits which features we can build. Then validation tells us how much to trust the result. Then there's an action in the world. And finally there's an outcome, which is the thing we actually care about.

Notice where most courses and most tutorials spend their time: features and the model, the middle of this chain. Notice where most real failures happen: at the edges. A wrong target. Features that wouldn't exist at prediction time. A validation set that answers the wrong question. An action that never happens because the prediction arrived too late.

Here's the uncomfortable part. Every link in this chain can quietly break while the model's score looks great. The score only measures one link: how well the predictions match the labels in your test set. It doesn't tell you whether you chose the right labels, whether the test set looks like the future, or whether anyone acted on the predictions.

So throughout this session I'll keep asking one question. It's the same question at every stage:

What decision will this model support, and does our experiment actually tell us whether it will support that decision?

That's the whole talk in one sentence. Everything else is examples.

<!-- Slide number: 5 -->
TRAP 1 · FORMULATION
“Predict bike demand” is four different problems
1
2
3
4
Rebalancing
Staffing
Capacity planning
App availability
Per station · 1–2 hours ahead
Which stations will run empty or full before a truck can get there?
Whole system · a day or week ahead
How many people do we need on shift?
Monthly / seasonal · months ahead
The trend, not any single hour: how many bikes and docks to buy
Per station · minutes ahead
The chance a station hits zero when a rider looks
Today we pick one: system-wide rebalancing and staffing for the next hour.
Ask:  What will you do differently depending on what my model says?
5

### Notes:
TIMING: 8:00 → 10:30 · ~290 words
Let's make it concrete.

Imagine your manager walks over and says, "We run a bike-sharing system. Can you predict bike demand?"

That sounds like a perfectly well-defined task. There's a public dataset, it has a column called "count," and you could have a model training in ten minutes. And honestly, that's what most of us would do.

But "predict bike demand" could mean at least four quite different things, depending on what decision it's meant to support.

[POINT TO THE FOUR CARDS]

If it's for rebalancing, moving bikes between stations, you need predictions per station, an hour or two ahead, early enough for a truck to get there.

If it's for staffing, how many people to put on shift, you probably need the whole system, a day or a week ahead.

If it's for capacity planning, how many bikes and docks to buy next year, you need monthly or seasonal totals, months ahead, and you care about the trend much more than any single hour.

And if it's for showing riders in the app whether a bike will be there, you need station-level predictions minutes ahead, and what you really care about is the chance a station hits zero.

Four decisions. Four different targets, horizons, and levels of detail. Same three words: "predict bike demand."

So the first trap isn't technical at all. It's starting to model before you know which of these questions you're answering. The fix is simple and slightly awkward: go back and ask, "What will you do differently depending on what my model says?" That one conversation saves weeks.

For today, I'll pick one: system-wide rebalancing and staffing for the next hour.

<!-- Slide number: 6 -->
TRAP 1 · FORMULATION
Write the prediction-time contract before you train
Prediction moment · 17:00

| Decision | Bikes to rebalance and staff to schedule for the coming hour |
| --- | --- |
| Target | Total rentals that start in hour t (system-wide) |
| Predict at | The start of hour t, e.g. 17:00 for 17:00–18:00 |
| Allowed | Calendar for hour t · rentals up to 16:59 · weather up to 16:59 (+ a forecast) |
| Forbidden | Anything from 17:00–18:00: its rentals, its observed weather, casual & registered |

hour t − 1
hour t (the target)
Can use
calendar, past rentals, past weather, forecasts
Cannot use
anything that happens after 17:00, however predictive
Ask:  Can I fill in all five lines before training anything?
6

### Notes:
TIMING: 10:30 → 13:30 · ~350 words
Once you know the decision, write down what I call a prediction-time contract. It's five lines, and I'd encourage you to write one for every model you ever build.

[POINT TO EACH ROW AS YOU SAY IT]

The decision: how many bikes to rebalance and how many staff to schedule for the coming hour, across the whole system.

The target: total rentals that start during hour t. Notice I'm saying rentals, not demand. I'll come back to why in a minute.

The prediction moment: the start of hour t. So we're making the prediction at, say, five o'clock, for the hour from five to six.

Allowed inputs: anything we genuinely know at five o'clock. The calendar is fine: we know it's a Tuesday, we know it's not a holiday, we know it's 5 pm. Rentals up to the end of the previous hour are fine, because they've already happened. Weather up to the previous hour is fine too, and in a real system you'd add a weather forecast for the coming hour.

Forbidden inputs: anything we only learn during or after the hour we're predicting. Rentals during hour t, obviously. But also, less obviously, the weather actually observed during hour t. And in this dataset, two columns called "casual" and "registered." I'll show you what happens with those shortly.

[POINT TO THE TIMELINE]

This little timeline is the most useful picture in this session. There's a line at the moment of prediction. Everything to the left of the line, you can use. Everything to the right, you cannot, however predictive it is.

It sounds obvious when it's drawn like this. In practice it isn't, because a dataset doesn't come with that line drawn on it. Every column just sits there in a row, looking equally available. Real weather and forecast weather look identical in a CSV. The dataset doesn't know when you'll be making the prediction. Only you know that.

So this contract is how you put that knowledge back into the problem. If you can't fill in these five lines, you're not ready to train anything yet.

<!-- Slide number: 7 -->
TRAP 1 · FORMULATION
The dataset is a partial record, not the world
Wanted a bike
165 hours
have no row at all. “Previous row” isn’t always “previous hour”.
Found one at the dock
Observed weather
Rented it  →  a row in hour.csv
The weather columns are what happened, not what was forecast.
cnt = casual + registered
Invisible to the data: people who met an empty dock, or checked the app and took a cab. Rentals under-count demand exactly when stations run empty.
True for every one of the 17,379 rows.
Ask:  What exactly is the target, and what does the dataset fail to observe?
7

### Notes:
TIMING: 13:30 → 15:30 · ~235 words
Now, about that word "rentals."

[POINT TO THE FUNNEL]

Think about what has to happen for a rental to show up in our data. First, someone wants a bike. Then they walk to a station and find one. Then they actually take it. The dataset only sees that last step.

If someone walks up to an empty station and leaves, there's no row for them. If someone checks the app, sees no bikes nearby, and takes a cab instead, there's no row for them either. So when stations run empty, which is exactly when rebalancing matters most, the data under-counts the real demand. Rentals are a stand-in for demand, and the stand-in is weakest exactly where we care most.

The public dataset can't tell us how many people tried and failed. So for the rest of today I'll be careful to say "rentals" and not "demand," and I won't claim anything about unmet demand.

Three more facts about this dataset that you'd only find by reading the documentation and checking the data.

First, 165 hours are simply missing from the two years. No row at all. So "the previous row" is not always "the previous hour."

Second, the weather columns are observed weather, not forecasts.

Third, the count column is exactly casual riders plus registered riders, for every single row. Remember that one.

A dataset is a partial record of a system, not the system itself.

<!-- Slide number: 8 -->
THE DATA
Commuters make two peaks; weekends make one hump

### Chart: Mean rentals per hour, by hour of day (2011–2012)

| Category | Working day | Weekend / holiday |
| --- | --- | --- |
| 00 | 36.5 | 90.4 |
| 01 | 16.4 | 69.2 |
| 02 | 8.5 | 52.5 |
| 03 | 4.6 | 25.3 |
| 04 | 5.1 | 8.1 |
| 05 | 24.7 | 8.4 |
| 06 | 101.7 | 18.6 |
| 07 | 288.3 | 43.4 |
| 08 | 473.2 | 105.7 |
| 09 | 239.6 | 171.6 |
| 10 | 134.3 | 255.9 |
| 11 | 157.0 | 315.3 |
| 12 | 199.6 | 366.3 |
| 13 | 197.6 | 372.7 |
| 14 | 182.8 | 364.6 |
| 15 | 200.5 | 358.8 |
| 16 | 292.5 | 352.7 |
| 17 | 524.2 | 323.5 |
| 18 | 490.3 | 279.8 |
| 19 | 347.0 | 230.7 |
| 20 | 248.7 | 174.0 |
| 21 | 185.5 | 141.4 |
| 22 | 137.8 | 115.6 |
| 23 | 88.4 | 85.6 |

524
average rentals, 17:00–18:00 on a working day
373
weekend / holiday peak, 13:00–14:00
UCI Bike Sharing Dataset · Capital Bikeshare, Washington D.C. · 17,379 hourly records, 1 Jan 2011 – 31 Dec 2012
8

### Notes:
TIMING: 15:30 → 17:00 · ~175 words
Here's what the data actually looks like. This is Capital Bikeshare in Washington, D.C., in 2011 and 2012, published by the UCI Machine Learning Repository. There's one row per hour: just over seventeen thousand hours.

[POINT TO THE CHART]

This chart shows average rentals by hour of the day, split into working days and weekends or holidays.

On working days you get two sharp peaks: around eight in the morning and around five or six in the evening. That's commuters. At 5 pm on a working day the average is about 524 rentals in that hour.

On weekends and holidays the shape is completely different: one broad hump from late morning to late afternoon, peaking at about 370 around 1 pm.

Two things to take from this. First, the hour of the day matters enormously, so any sensible model will lean on it. Second, those commuter peaks are where rebalancing is hardest. Keep an eye on 8 am and 5 pm. They'll come back when we look at errors.

<!-- Slide number: 9 -->
TRAP 2 · LEAKAGE
Leakage: the model knows something it couldn’t
1
2
3
Future information
Post-outcome fields
Learning before the split
Weather observed during the hour you're predicting. At 17:00 you only have a forecast, and forecasts are sometimes wrong.
Columns created with the outcome. Here, casual + registered = the target, so you're handing the model the answer.
Scaling, imputing, encoding or selecting features using all rows lets the test set shape training.
Ask:  For every input and every statistic: when did this become knowable?
9

### Notes:
TIMING: 17:00 → 19:30 · ~290 words
Now we get to the first technical trap, and it's the one I see most often. Leakage.

Here's a plain-language definition. Leakage is when your model, or your evaluation, gets to use information that wouldn't actually be available at the moment the prediction is made. The result is a model that looks better in testing than it can ever be in real use.

It comes in three main forms.

[POINT TO CARD 1]

The first is future information. You use something from after the prediction moment, like the weather observed during the very hour you're predicting. In a CSV it looks like an ordinary column. In real life, at five o'clock, you only have a forecast for five to six, and forecasts are wrong some of the time.

[POINT TO CARD 2]

The second is post-outcome fields. These are columns that are created by, or at the same time as, the thing you're predicting. In our dataset, casual plus registered equals the total. If you feed those in, you're basically handing the model the answer.

[POINT TO CARD 3]

The third is the sneakiest: preprocessing that learns from the whole dataset before you split it. Say you scale features using the mean of the full dataset, or fill in missing values using the full dataset, or pick features by checking which ones correlate with the target across all rows. Then your test set has quietly shaped your training process. Each case is small. Added together, they make your evaluation optimistic.

The question that catches all three is the one from the contract: for every input, and every statistic you compute, when did this become knowable? If the answer is "after the prediction moment," it doesn't go in.

<!-- Slide number: 10 -->
TRAP 2 · LEAKAGE
Too good to be true is a signal, not a success
3.2
29.1
Model A · everything in the file
includes casual + registered (they sum to the target)
Model C · honest at 17:00
calendar + past rentals + last hour's weather
About 9× “better”, and impossible to use at 17:00
MAE in rentals per hour. Same chronological test: 2012-09-01 → 2012-12-31 (2,888 hours, mean 240 rentals/hour). Same gradient-boosted tree settings.
Ask:  If a model suddenly gets much better: what does it know that it shouldn’t?
10

### Notes:
TIMING: 19:30 → 21:30 · ~235 words
Let me show you what this looks like in numbers. These come from an actual run in the companion notebook.

I trained the same kind of model, a gradient-boosted tree, which is a very standard choice for this sort of tabular data, in two ways. I evaluated both on the same test period: the last four months of 2012, which the model never saw during training.

[POINT TO THE LEFT NUMBER]

Model A gets everything in the file, including casual and registered. Its mean absolute error is 3.2 rentals per hour. In a period where the average hour has about 240 rentals, that's astonishing. You'd be tempted to put it in a slide for leadership.

[POINT TO THE RIGHT NUMBER]

Model C only gets what's honestly available at the start of the hour: the calendar, past rentals, and last hour's weather. Its error is 29.1 rentals per hour.

So the leaky model looks about nine times better. And it's completely useless, because at five o'clock nobody knows how many casual riders will rent between five and six. If we knew that, we wouldn't need a model.

Here's the lesson I'd like you to take from this slide. A result that's too good to be true isn't a reason to celebrate. It's a signal to go and look for the leak. Whenever a model suddenly gets dramatically better, the first question isn't "what did I do right?" It's "what does it know that it shouldn't?"

<!-- Slide number: 11 -->
TRAP 3 · VALIDATION
A random split and a time split ask different questions
Random split: shuffle hours, hold out a quarter
Answers
“How well can it fill in hours from a period it has mostly seen?”
Chronological split: train on the past, test on what came next
Answers
Train · 8 Jan 2011 – 31 Aug 2012 · 14,330 h
Test
“If I'd switched it on at the end of August, how would it have done?”
Sep – Dec 2012 · 2,888 h
2011
2012
Random splitting isn't always wrong. It's wrong when it doesn't match how the model will be used.
Ask:  What future is this validation asking the model to generalise to?
11

### Notes:
TIMING: 21:30 → 24:00 · ~290 words
The second trap is about how we split the data into training and test sets.

The default, the one in every tutorial, is a random split. You shuffle all your rows and hold out, say, a quarter of them for testing. For a lot of problems that's perfectly fine.

[POINT TO THE TOP TIMELINE]

But look at what a random split does to time-ordered data. Your test hours are scattered all through the two years. Each test hour has training hours right next to it: the hour before, the hour after, the same hour the day before. Those neighbours share the same season, the same weather pattern, and the same level of demand. So the model is mostly being asked to fill in gaps between hours it has already seen.

[POINT TO THE BOTTOM TIMELINE]

Now look at a chronological split. We train on everything before the first of September 2012. That's 14,330 hours. Then we test on September through December 2012, which is 2,888 hours the model has never seen, all of them after the training data ends.

These two splits are answering two different questions. The random split answers: "How well can this model fill in hours from a period it has mostly already seen?" The chronological split answers: "If I had trained this model at the end of August and switched it on, how would it have done over the next four months?"

Only one of those questions matches how we'd actually use the model. We'll always be predicting the future from the past.

I'll be careful here, because random splitting isn't always wrong. If your model will be used on the same kind of data, from the same period, it can be the right choice. The rule isn't "always split by time." The rule is: make your validation look like the way the model will be used.

<!-- Slide number: 12 -->
TRAP 3 · VALIDATION
Same rows, same model: the split changed which model you'd pick

### Chart: MAE (rentals / hour), lower is better

| Category | Random split | Chronological split |
| --- | --- | --- |
| Model B · calendar + same-hour weather | 25.2 | 43.6 |
| Model C · calendar + past rentals + last hour's weather | 21.9 | 29.1 |

Random split
B ≈ C (25.2 vs 21.9). Conclusion you'd draw: “past rentals barely help, keep it simple.”
Chronological split
43.6 vs 29.1. Past rentals matter a lot: they keep the model in step when demand drifts.
Ask:  Did the split change the decision, not just the score?
12

### Notes:
TIMING: 24:00 → 27:00 · ~350 words
So does it actually matter here? Let's measure it rather than assume it.

I took the same rows, the same features and the same model, and changed only one decision: how the test set is chosen. I made the random test set the same size as the chronological one, so it's a fair comparison.

[POINT TO MODEL B BARS]

Start with Model B. This is the one that looks perfectly reasonable: calendar features plus the weather observed in the same hour. A lot of public notebooks on this dataset do exactly this.

With a random split, Model B's error is 25.2 rentals per hour. With a chronological split, it's 43.6. Same model, same features. The only difference is which question we asked, and the error goes up by about seventy percent.

[POINT TO MODEL C BARS]

Now Model C, the honest one with past rentals. Random split: 21.9. Chronological: 29.1. It gets worse too, but by much less.

Here's the part I want you to notice. Under the random split, B and C look almost the same: 25 versus 22. If that was all you'd measured, you might reasonably say, "The lag features barely help, let's keep the simpler model." Under the chronological split, the gap is 44 versus 29. The lag features turn out to matter a lot, because they're how the model keeps up when demand drifts.

So the choice of split didn't just change the score. It changed which model you'd choose. That's what makes this trap expensive.

[PAUSE]

One caveat, because it matters. I'm not claiming the chronological number is the "true" error. It's the error over one particular four-month window: autumn into winter of 2012. A different window would give a different number. What I am saying is that it answers the question we actually care about, and the random split doesn't.

And notice that I measured this. I didn't assume the random split would look better. On another dataset the gap might be tiny, and that would be a perfectly good result too. In tomorrow's session, on taxi data, we'll see exactly that.

<!-- Slide number: 13 -->
TRAP 3 · VALIDATION
The system grew, and a time split makes you face it

### Chart: Mean rentals per hour, by month

| Category | Train months | Test months |
| --- | --- | --- |
| Jan ’11 | 51.3 | 0.0 |
| Feb | 71.7 | 0.0 |
| Mar | 86.1 | 0.0 |
| Apr | 131.8 | 0.0 |
| May | 182.6 | 0.0 |
| Jun | 199.3 | 0.0 |
| Jul | 190.0 | 0.0 |
| Aug | 183.7 | 0.0 |
| Sep | 177.0 | 0.0 |
| Oct | 166.0 | 0.0 |
| Nov | 141.9 | 0.0 |
| Dec | 117.4 | 0.0 |
| Jan ’12 | 130.0 | 0.0 |
| Feb | 148.2 | 0.0 |
| Mar | 221.6 | 0.0 |
| Apr | 242.0 | 0.0 |
| May | 263.3 | 0.0 |
| Jun | 281.7 | 0.0 |
| Jul | 273.7 | 0.0 |
| Aug | 288.3 | 0.0 |
| Sep | 0.0 | 303.6 |
| Oct | 0.0 | 267.3 |
| Nov | 0.0 | 212.0 |
| Dec | 0.0 | 166.3 |

51 → 304
rentals / hour, Jan 2011 → Sep 2012
181 vs 240
mean across all train hours vs test hours
Model B (calendar + weather) has no input that tells it the system grew. Model C sees last hour, yesterday and last week.
13

### Notes:
TIMING: 27:00 → 29:00 · ~235 words
Why did the random split flatter Model B so much? Here's the main reason.

[POINT TO THE CHART]

This is average rentals per hour, month by month, over the two years. The bars on the left are the training months, and the bars on the right are the four test months.

In January 2011 the system averaged about 51 rentals an hour. By September 2012 it was about 304. The system was growing: more stations, more members, more people using it. On top of that sits the seasonal rise and fall.

Now think about Model B. It only knows the calendar and the weather. Nothing in its inputs tells it the system has grown. When it trains on a random mix of months from both years, it sees plenty of autumn 2012 hours, and it simply memorises that autumn 2012 is busy. When it has to predict autumn 2012 having only seen up to August, it has no way of knowing how much bigger the system has got.

Model C has rentals from the previous hour, the previous day, and the same hour last week. Those carry the current level of the system into every prediction, so it adapts.

The average across all training hours is about 181 rentals an hour. The average across the test hours is about 240. A model that never sees the future can't know that jump is coming, unless something in its inputs carries it.

<!-- Slide number: 14 -->
TRAP 4 · METRICS
A baseline turns a number into a result

### Chart: MAE on the same chronological test (rentals / hour)

| Category | MAE |
| --- | --- |
| Training mean | 170.5 |
| Weekday × hour average | 93.7 |
| Same hour last week | 70.0 |
| Model C (honest) | 29.1 |

−58%
error vs the best simple rule (“same hour last week”)
Score every candidate on the same test rows
Make it a smart baseline, not a straw man
If the baseline wins, that's a finding
Ask:  What would a simple rule, or the current spreadsheet, get on the same test set?
14

### Notes:
TIMING: 29:00 → 32:00 · ~350 words
Trap number three is reporting a model's score without a baseline.

A baseline is the simplest reasonable thing you could do without any machine learning. It gives your metric a meaning. On its own, "Error of 29 rentals per hour" means nothing. Is that good? Bad? You can't tell until you know what a simple rule would get.

I evaluated three baselines on exactly the same test period as the model. That part's important: if you score a baseline on one split and the model on another, the comparison means nothing.

[POINT TO THE BARS FROM TOP TO BOTTOM]

Baseline one: always predict the average from the training data. Error: 170.5 rentals per hour. That's terrible, and it's partly because of the growth we just saw. The training average is stuck in the past.

Baseline two: predict the average for that weekday and hour. So for a Tuesday at 5 pm, predict the average of all Tuesday 5 pms in training. That's 93.7. Much better, because it captures the commuter peaks.

Baseline three: predict whatever happened at the same hour last week. That's 70.0, and it's better still. It's the simplest possible rule, but it automatically carries the current level of the system.

And Model C: 29.1.

So now 29.1 means something. The model cuts the error of the best simple rule by more than half. That's a real improvement, and it's a much stronger statement than "the model has an error of 29."

Two things I'd like you to take from this.

First, always build a baseline, and make it a smart one, not a straw man. "Same hour last week" is the kind of rule an operations manager might already be using on a spreadsheet. If your model can't beat what people already do, it doesn't matter how sophisticated it is.

Second, sometimes the baseline wins. That happens more often than you'd think. When it does, it's not a failure. It's a finding, and it may save your team from maintaining a model they don't need.

<!-- Slide number: 15 -->
TRAP 4 · METRICS
One number hides which errors you make
For a count, measure how far off you are
ILLUSTRATIVE · A CLASSIFICATION THOUGHT EXPERIMENT
84%
Model A accuracy
86%
Model B accuracy
MAE = 29.1
Mean absolute error: the typical miss, in rentals. Easy to explain to anyone.
Would you ship B? 
Class balance? “Always no” might score 85%
Which errors does B fix, and what do they cost?
Same test set? Is 2 points beyond noise?
RMSE = 46.8
Root mean squared error: squares each miss, so big misses count far more. RMSE well above MAE hints at a tail of large errors.
Ask:  Which errors matter most, and for whom?
15

### Notes:
TIMING: 32:00 → 35:00 · ~350 words
Let me take a short detour with a thought experiment. This one is about classification, not our bike problem; I'll come back to regression in a moment.

[POINT TO THE TWO CARDS]

You have two classifiers. Model A is 84% accurate. Model B is 86% accurate. Would you ship B?

[ASK THE ROOM — rhetorical, don't wait]

The tempting answer is yes. Two points better. But you can't actually answer without knowing more. What's the class balance? If 85% of cases are negative, a model that always says "no" is 85% accurate and completely useless. What do the errors cost? If B's extra correct answers are all easy cases, and it misses more of the rare, expensive cases, B might be worse in every way that matters. Are both numbers measured on the same test set? Is a two-point gap even outside the noise?

The lesson isn't really about accuracy. It's that a single number hides which errors you're making and how much they cost.

Now back to regression, because for bike rentals accuracy isn't even the right kind of metric. We're predicting a count, so we measure how far off we are.

[POINT TO THE DEFINITIONS]

The two most common metrics are MAE and RMSE. MAE, mean absolute error, is the average size of a miss, in the same units as the target. Our model's MAE is 29.1, so on a typical hour it's off by about 29 rentals. It's easy to explain to anyone.

RMSE, root mean squared error, squares each miss before averaging and then takes the square root. Squaring makes big misses count much more than small ones. Our model's RMSE is 46.8, noticeably higher than the MAE. That gap is a hint: some hours have misses much bigger than 29.

Which one should you use? It depends on the decision. If an error of 100 bikes is more than twice as bad as an error of 50, because a truck can't fix it in time, RMSE reflects that better. If every bike of error costs about the same, MAE is the more honest summary. Choose the metric that matches the cost, and report both.

<!-- Slide number: 16 -->
TRAP 4 · ERROR ANALYSIS
An average of 29 hides 73 at 5 pm

### Chart: MAE by hour of day, chronological test (rentals / hour)

| Category | Model C | Baseline · weekday × hour avg |
| --- | --- | --- |
| 00 | 20.3 | 26.8 |
| 01 | 10.3 | 17.6 |
| 02 | 6.9 | 11.3 |
| 03 | 5.3 | 6.3 |
| 04 | 3.7 | 3.5 |
| 05 | 8.5 | 13.0 |
| 06 | 14.9 | 39.1 |
| 07 | 35.0 | 118.8 |
| 08 | 53.8 | 201.7 |
| 09 | 33.6 | 107.9 |
| 10 | 34.5 | 84.1 |
| 11 | 30.1 | 105.6 |
| 12 | 39.2 | 136.1 |
| 13 | 39.1 | 132.9 |
| 14 | 30.2 | 125.9 |
| 15 | 38.2 | 137.0 |
| 16 | 42.3 | 167.8 |
| 17 | 73.1 | 229.8 |
| 18 | 56.2 | 201.6 |
| 19 | 32.6 | 133.0 |
| 20 | 24.8 | 90.2 |
| 21 | 25.5 | 64.6 |
| 22 | 19.7 | 50.8 |
| 23 | 18.8 | 37.4 |

73.1
MAE at 17:00, the evening commute
53.8
MAE at 08:00, the morning commute
4–7
MAE 02:00–04:00, when nobody rebalances
Ask:  What's the error where the decision actually matters?
16

### Notes:
TIMING: 35:00 → 38:30 · ~410 words
Here's the fourth trap, and it's the one I'd most like you to take home. Never celebrate a metric without looking at the errors.

A single MAE of 29 is an average over almost three thousand hours. Averages hide things. So the very next thing to do, every time, is to break the error down by segments that matter for the decision.

[POINT TO THE CHART]

This chart shows the error by hour of the day, on the test period. The darker line is our model and the lighter line is the weekday-and-hour baseline.

First, the model beats the baseline in nearly every hour, and by a long way. Good.

But look at the shape. In the small hours, between two and five in the morning, the model’s error is tiny, roughly four to seven rentals. That's partly because hardly anyone rides then, so there's not much to get wrong.

Then look at 8 am: the error is 53.8. And at 5 pm it's 73.1, two and a half times the overall average. Those are exactly the commuter peaks from earlier. The hours when the system is under the most stress, when stations run empty and trucks have the least slack, are the hours the model is least accurate.

[PAUSE]

Now, part of that is just scale. Busier hours have bigger numbers, so the misses are bigger. That's fair. But here's why it still matters. The decision we picked was rebalancing and staffing for the next hour. Nobody needs to rebalance at 4 am. The value of this model lives almost entirely between 7 and 9 in the morning and between 4 and 7 in the evening. So the overall MAE is averaging in a lot of hours that don't matter for the decision, and they make the model look better than it is when it counts.

Which is why the question to ask isn't "what's the error?" but "what's the error where it matters?"

When you do this kind of breakdown, there are a couple of rules. Use only segments you'd actually know at prediction time, or else be explicit that you're slicing after the fact. And make sure each segment has enough data to be meaningful. Here every hour of the day has about 120 test hours, so the numbers are reasonably stable. If a segment had five rows, I wouldn't put it on a slide.

<!-- Slide number: 17 -->
TRAP 4 · ERROR ANALYSIS
Peak hours: 10% of the time, 23% of the error

### Chart: By demand band (rentals in the hour)

| Category | Share of test hours (%) | Share of absolute error (%) |
| --- | --- | --- |
| Low (≤193) | 50.1 | 27.1 |
| Mid (193–566) | 39.9 | 50.0 |
| Peak (>566) | 10.0 | 22.8 |

| Band | MAE | MAE as % of demand |
| --- | --- | --- |
| Low (≤193) | 15.8 | 22.5% |
| Mid (193–566) | 36.5 | 10.9% |
| Peak (>566) | 66.4 | 9.3% |

Worst in bikes, best in percent. The decision decides which framing counts.
Light rain / snow: MAE 39.5 vs 28.3 when clear (204 vs 1,761 hours). The model sees last hour's weather, so sudden changes catch it out. A hint, not a proof.
Ask:  Bikes off, or percent off: which one does the decision feel?
17

### Notes:
TIMING: 38:30 → 41:30 · ~350 words
Let's push that one step further. Instead of hour of day, let's group the test hours by how busy they actually were.

[POINT TO THE LEFT PANEL]

I split them into three bands. Low is the quieter half of hours, up to 193 rentals. Mid runs from there to 566. Peak is the busiest ten percent of hours, above 566 rentals.

Peak hours are 10% of the test period, but they account for 22.8% of all the absolute error. The model's MAE in those hours is 66.4 rentals, compared with 15.8 in quiet hours. The best simple baseline is off by 298 in peak hours, so the model is still a massive improvement there. But peaks are where most of the remaining error is, and peaks are where the decision matters.

[POINT TO THE RIGHT PANEL]

Here's a twist, though, and it's a good example of why framing matters. As a percentage of demand, the peak-hour error is actually the smallest: about 9% of the rentals in that hour, compared with about 22% in quiet hours. So which is it? Is the model worst at peaks or best at peaks?

Both are true. It depends on the decision. If you're a truck driver who can move twenty bikes, the absolute number of bikes you're off by is what hurts, and peaks are the worst. If you're sizing staff as a proportion of load, the percentage view may be the right one. The data doesn't choose the framing for you. The decision does.

One more slice: weather. In hours with light rain or snow, the error goes up to 39.5, compared with 28.3 in clear weather. Remember, our model uses last hour's weather, not this hour's. So when weather changes suddenly, the model is a step behind. That's a hint about what to improve: a real weather forecast as an input. Note that it's a hint, not a proof; to show it would help, you'd have to actually add the forecast and measure.

This is what error analysis gives you that a single number never can: where the model is weak, what the weakness might cost, and what to try next.

<!-- Slide number: 18 -->
LIMITS
What this result does not tell us
Whether a bike was available when someone wanted one
✕
What we measured
On four months it never saw, Model C predicts system-wide hourly rentals with a typical miss of 29.1, less than half the best simple rule's.
How much demand went unmet: only rentals are recorded
✕
Whether rebalancing on this forecast beats today's practice (an experiment or labelled simulation)
✕
Anything about individual stations
✕
Whether anyone would act differently because of it
✕
Ask:  What would we need to measure next to support the bigger claim?
18

### Notes:
TIMING: 41:30 → 44:00 · ~290 words
Before we move on to production, let's be honest about the limits of everything I've shown so far.

We now have a model that, on four months it never saw, predicts system-wide hourly rentals with an average miss of about 29, and it beats a reasonable baseline by more than half. That's a real, defensible result.

[POINT TO EACH ITEM]

Here's what it doesn't tell us.

It doesn't tell us whether bikes were available when people wanted them. We never measured availability.

It doesn't tell us how much demand went unmet. The data only records rentals that happened.

It doesn't tell us whether rebalancing based on this forecast would work better than what the operators do today. That's an intervention, and you'd need an experiment to test it, or at least a clearly labelled simulation.

It doesn't tell us anything about individual stations. This is a system-wide forecast, and rebalancing happens station by station.

And it doesn't tell us whether anyone would actually change what they do because of the forecast. If the trucks are already fully booked at 5 pm, a better forecast changes nothing.

[PAUSE]

I'm not saying this to downplay the model. I'm saying it because this is the difference between an offline result and a real-world result. When you present your work, the strongest thing you can do is say clearly: "Here's what we measured, here's what it shows, and here's what we would need to measure next to support the bigger claim."

People who make decisions trust data scientists who do that. They stop trusting the ones who let an MAE turn into "this will reduce stockouts by twenty percent" with nothing in between.

<!-- Slide number: 19 -->
TRAP 5 · PRODUCTION
The notebook stops at evaluation. Production keeps going
Data
Target
Features
Split
Model
Evaluation
Deploy
Monitor
Feedback
Notebook
…and round again
1
2
3
4
5
Freshness
Drift
Latency
Monitoring
Feedback loops
Is last hour's count there by 17:00? What if the weather feed is down?
Growth, new stations, holidays, pricing, city events
Late is useless, down is worse. Keep a baseline as the fallback
Inputs, prediction spread, delayed truth, segment error, outcomes
Acting on forecasts changes the data you retrain on
Ask:  How will we know it's working, and what happens when an input is late?
19

### Notes:
TIMING: 44:00 → 51:00 · ~820 words
Let's now take the model out of the notebook and imagine switching it on. This is the fifth trap: assuming the work is done when the evaluation looks good.

[POINT TO THE LOOP]

Here's the full lifecycle. Data, target, features, split, model, evaluation. That's the part we've done. Then deployment, monitoring, and feedback, which loops back to the data. In a notebook, the arrow stops at evaluation. In real life it keeps going round, and every lap is a chance for something to change.

Let me walk through five things that start to matter the moment the model is live.

[POINT TO "FRESHNESS"]

First, feature freshness. In the notebook, "rentals in the last hour" is just a column that's always filled in. In production, it's a number that has to be computed from a live data pipeline and arrive before 5 pm for the 5 pm prediction. What if the pipeline runs fifteen minutes late? What if the weather feed is down? The model was trained assuming those inputs are always present and correct. You need to decide what happens when they're not: fall back to the baseline, use the last known value, or skip the prediction. And you need to know that it happened.

[POINT TO "DRIFT"]

Second, drift. The world the model learned from doesn't stay still. We already saw one kind: the system grew sixty or seventy percent from one year to the next. Other kinds would include new stations opening, a holiday that falls on an unusual day, a pricing change, a big event in the city, or a pandemic. Each of these changes the relationship between your inputs and the target. A model trained on last year can be confidently wrong this year.

[POINT TO "LATENCY & RELIABILITY"]

Third, latency and reliability. A prediction is only useful if it arrives before the decision is made. If the rebalancing plan is drawn up at 4:30, a forecast that lands at 4:55 is worthless, however accurate it is. And a model that's accurate but unavailable one day in ten may be worse than a simple rule that's always there. Sometimes the right production answer is the "same hour last week" baseline as a fallback, ready for when the fancy model fails.

[POINT TO "MONITORING"]

Fourth, monitoring. What should you watch once it's live? Not just accuracy. Here's a practical list. Input quality: are features arriving, and are they in the usual ranges? Prediction distribution: is the model suddenly predicting much higher or lower than usual? Delayed ground truth: for us the true answer comes an hour later, which is quick. For many problems it takes days or weeks, so you have to watch the inputs and predictions while you wait. Error by segment: the same breakdown we did, by hour and by peak, tracked over time. And, where you can, the actual outcome: did stations run empty less often? That last one is the one that matters, and it's the one that's usually hardest to get.

[POINT TO "FEEDBACK LOOPS"]

Fifth, and the most subtle: feedback loops. Suppose the forecast works and operators use it to move bikes to stations where demand is expected. Now more bikes are available at those stations, so more people rent them, so recorded rentals go up there. Next month you retrain the model on this new data. It learns that those stations are even busier, so it sends even more bikes, and so on. The model has started to shape the very data it learns from.

I want to be careful here: our public dataset doesn't show this loop. It was collected before any model like ours existed. I'm describing the mechanism, not claiming evidence of it. But it's a real thing in production systems, especially in recommendations, pricing, fraud, and anything where the prediction changes what people do. Once your model affects the world, your future training data is no longer a neutral record.

[PAUSE]

[OPTIONAL STORY — a short, real example from your own work of a model that looked fine offline and needed one of these five in production: a late feature, a fallback, or a drift alert. Keep it to about 60 seconds and use no internal numbers. If you skip it, go straight to the next line.]

So when you hand over a model, the question isn't just "is it accurate?" It's: where do its inputs come from, and what happens when they're late? What will change in the world that it doesn't know about? Does it arrive in time? How will we know it's working? And could it be changing the data it learns from?

None of these show up in a notebook. All of them show up in production.

<!-- Slide number: 20 -->
Five rules to remember
Understand the decision before touching the data
“Predict bike demand” was four problems
1
Ask when every feature became knowable
Draw the line at the prediction moment
2
Make validation resemble how the model will be used
The split changed which model we'd pick
3
Never celebrate a metric without inspecting the errors
An average of 29 hid 73 at 5 pm
4
Think about what happens after deployment
Freshness · drift · latency · monitoring · feedback
5
20

### Notes:
TIMING: 51:00 → 54:00 · ~350 words
Let me pull everything together into five rules. If you take a photo of one slide today, make it this one.

[POINT TO RULE 1]

Rule one: understand the decision before touching the data. "Predict bike demand" was four different problems. Ask what will be done differently based on your prediction, and let that decide the target, the horizon, and the level of detail.

[POINT TO RULE 2]

Rule two: ask when every feature became knowable. Draw the line at the moment of prediction. Anything to the right of it, whether it's observed weather, casual riders, or a statistic computed on the full dataset, doesn't go in. And if a model suddenly gets too good, go looking for the leak.

[POINT TO RULE 3]

Rule three: make validation resemble the way the model will be used. If you'll predict the future from the past, test on a future the model hasn't seen. And remember what we saw: changing the split didn't just change the score, it changed which model you'd pick.

[POINT TO RULE 4]

Rule four: never celebrate a metric without inspecting the errors. Compare against a smart baseline on the same test set. Then break the errors down by the segments that matter for the decision. For us, an average of 29 hid errors of 73 at 5 pm.

[POINT TO RULE 5]

Rule five: think about what happens after deployment. Freshness, drift, latency, monitoring, feedback. The model's score is measured once. Its behaviour in the world is measured every day.

[PAUSE]

You'll notice none of these rules is about algorithms. We used one standard model the whole time, and I didn't tune it. That's deliberate. In my experience, the biggest gains and the worst disasters almost never come from the choice of algorithm. They come from these five decisions around it.

There's also a one-page version of these rules in the materials, so you don't need to copy them down.

<!-- Slide number: 21 -->
Close
AI can write the model. Judgment decides what to build, and what evidence is enough
As code gets cheaper, the job shifts towards framing the problem, designing the evaluation, interpreting the errors, and thinking about the system around the model.
21

### Notes:
TIMING: 54:00 → 57:00 · ~350 words
Let me go back to the question I started with. If a demand forecast is accurate, will there be a bike when you need one?

We can now give a much better answer. Not necessarily. An accurate forecast is one link in a chain. You also need the right target, honest inputs, an evaluation that matches the future, errors that are small where they matter, a prediction that arrives in time, and an action that someone actually takes. The forecast is necessary. It isn't sufficient.

[PAUSE]

I'll finish with a thought about where our field is going, because I think it matters for everyone here who's early in their career.

AI tools are getting very good at writing modelling code. You can describe this whole notebook in a paragraph and get working code back in seconds: loading, feature engineering, gradient boosting, metrics, all of it. That's real, and it's a good thing. It removes a lot of tedious work.

But look at what it doesn't remove. A coding assistant will happily include casual and registered as features and report an error of 3.2. It will happily use a random split. It will happily report one MAE and stop. Nothing in the code is wrong. Every line runs. The mistakes are all in the decisions, and those decisions need someone who understands the problem, the data, and how the model will be used.

So as writing code gets easier, the parts of the job that are left are framing the problem, designing an evaluation you can trust, interpreting errors, and thinking about the whole system. Those parts become a bigger share of what a data scientist is for. That's not a reason to worry. It's a clear guide to what's worth getting good at.

Those are exactly the skills that make you trustworthy, and trust is what gets your models used.

Tomorrow, in the second session, we'll take a harder problem, predicting how long a New York taxi trip will take, and follow it all the way through, including some results that don't come out the way you'd expect. You don't need today to follow it, but I hope you'll come.

<!-- Slide number: 22 -->
REFERENCES
Sources, companion notebook, and your questions
Data
Companion notebook
UCI Machine Learning Repository: Bike Sharing Dataset (id 275), hour.csv. archive.ics.uci.edu/dataset/275
Fanaee-T & Gama (2013), Event labeling combining ensemble detectors and background knowledge. Progress in AI
Source records: Capital Bikeshare system data · CC BY 4.0
s1_bike_demand.ipynb: contract, splits, baselines, models, error analysis
Chronological split at 2012-09-01 · seed 42 · scikit-learn 1.9.1
Every chart and number in this deck is exported from it
Try this: write the five-line prediction-time contract for a model you've built, and check every feature against it.
Questions?
22

### Notes:
TIMING: 57:00 → 60:00 · ~150 words, then questions
Everything I showed you today is reproducible.

[POINT TO THE SOURCES]

The data is the UCI Bike Sharing Dataset, from Capital Bikeshare's public records, prepared by Fanaee-T and Gama. It's freely available under a Creative Commons licence. The companion notebook loads it, writes down the prediction-time contract, builds the chronological and random splits, trains the baselines and models, and exports every chart and number you saw on these slides. The split date, the random seed, and the package versions are all recorded in it.

If you'd like to try one thing after today, try this: take any model you've built recently, write its five-line prediction-time contract, and check every feature against it. You might be surprised.

Thank you. I'd love to take your questions now, about anything we covered, or about the messier parts of the job that didn't fit in an hour.

[OPEN FOR QUESTIONS]
