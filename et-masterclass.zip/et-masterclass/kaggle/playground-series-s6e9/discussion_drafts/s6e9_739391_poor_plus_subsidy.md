# Thread: Poor + Subsidy = Buy EV (739391)
# URL: https://www.kaggle.com/competitions/playground-series-s6e9/discussion/739391

---

This lines up with what I found at the population level — subsidy is a ~47x multiplier on buy rate (0.6% without → 27.5% with). Your $30k income finding is the micro-version of that pattern.

One layer deeper: even at $30k + subsidy, **range anxiety** acts as a hard veto. In the broader data:

- Subsidy + low range anxiety → 29.6% buy rate
- Subsidy + high range anxiety → 0.2% buy rate

So the story for low-income buyers is: subsidy is the on/off switch, but range anxiety is the circuit breaker. Money gets them to the door; fear of running out of charge keeps them from walking through it.

Practically for modeling, these conditional relationships are real but GBDTs already capture them via tree splits — explicitly adding `subsidy × income` interaction features only gave me +0.0002 OOF.
