# Thread: Fable 5.1 - XGB Starter (739321)
# URL: https://www.kaggle.com/competitions/playground-series-s6e9/discussion/739321

---

The decoded formula explains something I found empirically — the subsidy coefficient (+2) is roughly 3x the income coefficient (+1.2) and the environmental concern coefficient (+0.6). This maps almost perfectly to what I measured in the raw data:

- Without subsidy: 0.6% buy rate
- With subsidy: 27.5% buy rate
- That's a **47x multiplier** — and looking at the formula, it's because the +2 subsidy term swings the logistic curve past the 5.5 threshold for a huge chunk of the population that would otherwise fall just below it.

The really interesting interaction: even with subsidy = 1, high range anxiety (coefficient -3) basically cancels out the subsidy boost entirely. Subsidy + high anxiety = 0.2% buy rate. So the formula creates this asymmetry where subsidy is a necessary-but-not-sufficient condition, and range anxiety is a hard veto.

Re: your three approaches for feeding the formula to XGBoost — I tested adding hand-crafted interaction features (subsidy × concern, subsidy × income, concern × anxiety) and the OOF gain was only +0.0002. GBDTs already approximate the linear interactions natively, so the explicit terms are mostly redundant.

What *did* move the score was digit decomposition features (+0.0015 OOF) — which captures generator artifacts that the formula alone doesn't explain. Curious whether Fable found similar patterns in the synthetic data's numerical distribution.
