# Thread: Honest CV baseline — looking for teammates (739379)
# URL: https://www.kaggle.com/competitions/playground-series-s6e9/discussion/739379

---

Nice work — CV 0.9418 matching LB 0.9416 is a sign your validation setup is trustworthy (adversarial validation AUC ≈ 0.5 means train and test are well-aligned).

I was stuck at almost exactly the same score and found the same dead-ends you did (hand-crafted interactions: +0.0002, CatBoost blend: no gain). Two things that actually moved my OOF after that:

1. **Digit decomposition features** — extract the ones, tens, and hundreds digits from numeric columns like `Annual_Income_USD`, `Daily_Commute_km`, etc. and feed them as categorical features. This gave me +0.0015 OOF. It sounds hacky, but it captures artifacts from the synthetic data generator that GBDTs can't learn from the raw continuous values.

2. **Frequency encoding** on categorical features — +0.0009 OOF. Simple value_counts transform.

Between those two, I went from 0.9405 → 0.9419. Not a massive jump, but it's the only thing that reliably moved the needle after the domain features plateau.

I posted a longer ablation with everything I tested (including ~20 things that didn't work) in [this thread](https://www.kaggle.com/competitions/playground-series-s6e9/discussion/739354) if it helps you figure out what to try next.

Good luck with the teammate search!
