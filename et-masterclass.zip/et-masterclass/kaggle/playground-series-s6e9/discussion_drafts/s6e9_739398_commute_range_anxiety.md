# Thread: Commute distance, range anxiety, and buying an EV (739398)
# URL: https://www.kaggle.com/competitions/playground-series-s6e9/discussion/739398

---

Good analysis — and the key takeaway (small p ≠ strong relationship) is exactly right. Commute distance alone is essentially noise for prediction.

The interesting extension: **Range Anxiety Level** is the psychological operationalization of what commute distance *should* measure but doesn't. And it only matters conditionally:

- With subsidy + low range anxiety: 29.6% buy rate
- With subsidy + medium range anxiety: 6.9%
- With subsidy + high range anxiety: 0.2%

Without subsidy, range anxiety level barely matters because almost nobody buys regardless.

So the story is: actual commute distance is irrelevant (r ≈ -0.028 as you found), but *perceived* range sufficiency (captured by Range_Anxiety_Level) is a hard ceiling on purchase — but only for people who were otherwise going to buy (i.e., have subsidy + concern).

For feature engineering, `Range_Anxiety_Level` is already in the dataset and does the heavy lifting. The commute distance → range anxiety interaction doesn't add OOF signal because the anxiety variable already captures the psychological effect directly.
