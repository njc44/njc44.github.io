# Thread: A small Simpson's Paradox (738991)
# URL: https://www.kaggle.com/competitions/playground-series-s6e9/discussion/738991

---

Great catch on the Simpson's paradox. To answer the question about translating this into feature engineering action — here's what I actually tried:

**The practical translation:**

Create an explicit interaction term: `no_home_charging × nearby_stations`. The idea is that nearby stations only matter *conditional on* not having home charging — which is exactly what the Simpson's paradox is telling you. For people with home charging, nearby stations are irrelevant (they charge at home). For people without, nearby stations become the proxy for "can I even charge this thing?"

More broadly, this is an instance of the pattern I found across the whole dataset: **almost every feature in this competition only matters conditional on something else**.

The three biggest conditional relationships I measured:
- **Subsidy × Environmental Concern**: Concern level 5 + no subsidy = 2.5% buy rate. Concern level 5 + subsidy = 69.3%. Concern without subsidy is nearly inert.
- **Subsidy × Range Anxiety**: Subsidy + low anxiety = 29.6%. Subsidy + high anxiety = 0.2%. Even subsidy can't overcome fear.
- **Income × Subsidy**: Q4 income + subsidy = 43.5%. Q4 income, no subsidy ≈ 0%. High income alone doesn't drive purchase.

**The honest result though:** when I added these interaction terms explicitly to XGBoost, the OOF gain was only +0.0002. GBDTs already learn the splits implicitly. The Simpson's paradox is real in the data, but the model handles it without hand-holding.

Where the insight *does* help: feature selection and interpretability. If you're building a simpler model (logistic regression, as thread 739142 explored), then explicit interaction terms are essential — logistic regression with the right interactions matches GBDT on the original 10k data.
