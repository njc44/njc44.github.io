"""Kaggriculture Round-Robin Tournament Framework.

Runs all agents against each other in a full round-robin with configurable
games per matchup. Computes Elo ratings, win rates, confidence intervals,
and score margins.

Usage:
    /Users/nathanjacob/opt/miniconda3/bin/python tournament.py [--games 50] [--agents all]

Requires: conda python with kaggle-environments installed.
"""
import sys
import os
import time
import math
import json
import itertools
from collections import defaultdict
from datetime import datetime

from kaggle_environments import make

# ── Agent Registry ────────────────────────────────────────────────
AGENTS = {
    "hybrid_v1":    "/tmp/kaggriculture_latest/hybrid_v1/main.py",
    "reactive_v2":  "/tmp/kaggriculture_latest/reactive_v2_ext/main.py",
    "seven_turn":   "/tmp/kaggriculture_latest/seven_turn_ext/main.py",
    "shop_router":  "/tmp/kaggriculture_latest/shop_router_0909_ext/main.py",
    "base":         "/tmp/kaggriculture_agents/public_state_router/main.py",
    "tetsu":        "/tmp/kaggriculture_agents/tetsu_shape_shop/main.py",
    "top10_e776":   "/tmp/kaggriculture_agents/shape_shop_top10_extracted/main.py",
}

# ── Statistical Helpers ─────────────────────────────────────────────
def wilson_ci(wins, total, z=1.96):
    if total == 0:
        return (0.0, 0.0)
    p = wins / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denom
    return (max(0, center - margin), min(1, center + margin))


def z_score(wins, losses):
    n = wins + losses
    if n == 0:
        return 0.0
    p = wins / n
    se = math.sqrt(0.25 / n)
    return (p - 0.5) / se


def compute_elo(results, k=32, initial=1500):
    """Compute Elo ratings from game results using iterative updates."""
    names = set()
    for (a, b) in results:
        names.add(a)
        names.add(b)
    elo = {name: initial for name in names}
    # Flatten all games and sort by time (we just do multiple passes)
    games = []
    for (a, b), stats in results.items():
        for outcome in stats["outcomes"]:
            games.append((a, b, outcome))

    # Run 3 passes for convergence
    for _ in range(3):
        for a, b, outcome in games:
            ea = 1 / (1 + 10 ** ((elo[b] - elo[a]) / 400))
            eb = 1 - ea
            if outcome == "a_win":
                sa, sb = 1, 0
            elif outcome == "b_win":
                sa, sb = 0, 1
            else:
                sa, sb = 0.5, 0.5
            elo[a] += k * (sa - ea)
            elo[b] += k * (sb - eb)
    return elo


# ── Core Game Runner ────────────────────────────────────────────────
def run_single_game(agent_a_path, agent_b_path, debug=False):
    """Run a single game, return (reward_a, reward_b, status_a, status_b)."""
    try:
        env = make("kaggriculture", debug=debug)
        result = env.run([agent_a_path, agent_b_path])
        final = result[-1]
        return (
            final[0]["reward"], final[1]["reward"],
            final[0]["status"], final[1]["status"],
        )
    except Exception as e:
        return (0, 0, "ERROR", str(e))


def run_matchup(agent_a_name, agent_a_path, agent_b_name, agent_b_path,
                games_per_seat=25, verbose=True):
    """Run a full matchup with seat alternation. Returns detailed stats."""
    wins_a, wins_b, ties = 0, 0, 0
    scores_a, scores_b = [], []
    errors = 0
    outcomes = []
    total_games = games_per_seat * 2

    for i in range(total_games):
        # Alternate seats
        if i < games_per_seat:
            p0, p1, a_seat = agent_a_path, agent_b_path, 0
        else:
            p0, p1, a_seat = agent_b_path, agent_a_path, 1

        r0, r1, s0, s1 = run_single_game(p0, p1)

        if s0 != "DONE" or s1 != "DONE":
            errors += 1
            outcomes.append("error")
            continue

        ra = r0 if a_seat == 0 else r1
        rb = r1 if a_seat == 0 else r0
        scores_a.append(ra)
        scores_b.append(rb)

        if ra > rb:
            wins_a += 1
            outcomes.append("a_win")
        elif rb > ra:
            wins_b += 1
            outcomes.append("b_win")
        else:
            ties += 1
            outcomes.append("tie")

        if verbose and (i + 1) % 10 == 0:
            total = wins_a + wins_b + ties
            wr = wins_a / total if total else 0
            print(f"    [{i+1}/{total_games}] {agent_a_name} {wins_a}W-{wins_b}L-{ties}D ({wr*100:.0f}%)", flush=True)

    total = wins_a + wins_b + ties
    wr_a = wins_a / total if total else 0
    ci = wilson_ci(wins_a, total)
    z = z_score(wins_a, wins_b)
    avg_a = sum(scores_a) / len(scores_a) if scores_a else 0
    avg_b = sum(scores_b) / len(scores_b) if scores_b else 0

    return {
        "agent_a": agent_a_name, "agent_b": agent_b_name,
        "wins_a": wins_a, "wins_b": wins_b, "ties": ties, "errors": errors,
        "total": total, "win_rate_a": wr_a,
        "ci_95": ci, "z_score": z,
        "avg_score_a": avg_a, "avg_score_b": avg_b,
        "margin": avg_a - avg_b,
        "outcomes": outcomes,
    }


# ── Tournament Runner ──────────────────────────────────────────────
def run_tournament(agent_names, games_per_seat=25, verbose=True):
    """Full round-robin tournament."""
    agents = {name: AGENTS[name] for name in agent_names}
    pairs = list(itertools.combinations(agent_names, 2))
    n_matchups = len(pairs)
    total_games = n_matchups * games_per_seat * 2

    print(f"\n{'='*70}")
    print(f"  KAGGRICULTURE TOURNAMENT")
    print(f"  {len(agents)} agents, {n_matchups} matchups, {games_per_seat*2} games each")
    print(f"  Total games: {total_games}")
    print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}\n")

    all_results = {}
    matchup_data = {}
    start_time = time.time()

    for idx, (a, b) in enumerate(pairs, 1):
        print(f"[{idx}/{n_matchups}] {a} vs {b}...", flush=True)
        m_start = time.time()

        stats = run_matchup(a, agents[a], b, agents[b],
                           games_per_seat=games_per_seat, verbose=verbose)
        elapsed = time.time() - m_start

        # Store results for both directions
        all_results[(a, b)] = stats
        matchup_data[(a, b)] = stats

        print(f"  Result: {a} {stats['wins_a']}W-{stats['wins_b']}L-{stats['ties']}D "
              f"({stats['win_rate_a']*100:.0f}% WR, margin={stats['margin']:+,.0f}) "
              f"[{elapsed:.0f}s]\n", flush=True)

    total_elapsed = time.time() - start_time

    # ── Compute Elo ─────────────────────────────────────────────
    flat_results = {}
    for name in agent_names:
        flat_results[name] = name
    elo = compute_elo(matchup_data)

    # ── Head-to-Head Matrix ────────────────────────────────────
    h2h = defaultdict(dict)
    for (a, b), stats in matchup_data.items():
        h2h[a][b] = stats["win_rate_a"]
        h2h[b][a] = 1 - stats["win_rate_a"]

    # ── Aggregate Stats ────────────────────────────────────────
    agg = {}
    for name in agent_names:
        total_w, total_l, total_t, total_g = 0, 0, 0, 0
        total_score = 0
        for (a, b), stats in matchup_data.items():
            if a == name:
                total_w += stats["wins_a"]
                total_l += stats["wins_b"]
                total_t += stats["ties"]
                total_g += stats["total"]
                total_score += stats["avg_score_a"] * stats["total"]
            elif b == name:
                total_w += stats["wins_b"]
                total_l += stats["wins_a"]
                total_t += stats["ties"]
                total_g += stats["total"]
                total_score += stats["avg_score_b"] * stats["total"]
        agg[name] = {
            "wins": total_w, "losses": total_l, "ties": total_t,
            "games": total_g,
            "win_rate": total_w / total_g if total_g else 0,
            "avg_score": total_score / total_g if total_g else 0,
            "elo": elo.get(name, 1500),
        }

    # ── Print Results ──────────────────────────────────────────
    print(f"\n{'='*70}")
    print(f"  TOURNAMENT RESULTS")
    print(f"  Total time: {total_elapsed:.0f}s ({total_elapsed/60:.1f} min)")
    print(f"{'='*70}\n")

    # Power ranking by Elo
    ranked = sorted(agent_names, key=lambda n: -agg[n]["elo"])
    print("  POWER RANKING (by Elo)\n")
    print(f"  {'Rank':>4}  {'Agent':<15}  {'Elo':>6}  {'W-L-D':>10}  {'WR':>6}  {'Avg Score':>10}")
    print(f"  {'─'*4}  {'─'*15}  {'─'*6}  {'─'*10}  {'─'*6}  {'─'*10}")
    for rank, name in enumerate(ranked, 1):
        s = agg[name]
        wld = f"{s['wins']}-{s['losses']}-{s['ties']}"
        print(f"  {rank:>4}  {name:<15}  {s['elo']:>6.0f}  {wld:>10}  {s['win_rate']*100:>5.1f}%  {s['avg_score']:>10,.0f}")

    # Head-to-head matrix
    print(f"\n  HEAD-TO-HEAD (row win rate vs column)\n")
    header = f"  {'':15}" + "".join(f"  {n:>12}" for n in ranked)
    print(header)
    for a in ranked:
        row = f"  {a:15}"
        for b in ranked:
            if a == b:
                row += f"  {'---':>12}"
            elif b in h2h[a]:
                wr = h2h[a][b]
                row += f"  {wr*100:>11.0f}%"
            else:
                row += f"  {'N/A':>12}"
        print(row)

    # Detailed matchup results
    print(f"\n  MATCHUP DETAILS\n")
    for (a, b), stats in matchup_data.items():
        ci = stats["ci_95"]
        print(f"  {a:15} vs {b:15}: {stats['wins_a']:2d}W-{stats['wins_b']:2d}L-{stats['ties']:2d}D "
              f"({stats['win_rate_a']*100:5.1f}% WR)  "
              f"z={stats['z_score']:+5.2f}  "
              f"CI=[{ci[0]*100:.0f}%-{ci[1]*100:.0f}%]  "
              f"Margin={stats['margin']:+,.0f}")

    print(f"\n{'='*70}\n")

    # Save results
    save_data = {
        "timestamp": datetime.now().isoformat(),
        "games_per_seat": games_per_seat,
        "total_elapsed_s": total_elapsed,
        "rankings": [{"rank": i+1, "agent": n, **agg[n]} for i, n in enumerate(ranked)],
        "matchups": {f"{a}_vs_{b}": {k: v for k, v in s.items() if k != "outcomes"}
                     for (a, b), s in matchup_data.items()},
    }
    out = f"/Users/nathanjacob/Documents/kaggle/kaggriculture/tournament_results_{datetime.now().strftime('%m%d_%H%M')}.json"
    with open(out, "w") as f:
        json.dump(save_data, f, indent=2)
    print(f"  Results saved to: {out}")
    return save_data


# ── Main ───────────────────────────────────────────────────────────
def main():
    games_per_seat = 25  # 50 total per matchup
    agent_names = list(AGENTS.keys())

    for i, arg in enumerate(sys.argv[1:], 1):
        if arg == "--games" and i + 1 <= len(sys.argv) - 1:
            games_per_seat = int(sys.argv[i + 1]) // 2
        if arg == "--agents" and i + 1 <= len(sys.argv) - 1:
            requested = sys.argv[i + 1].split(",")
            if requested != ["all"]:
                agent_names = [n for n in requested if n in AGENTS]

    # Verify all agents exist
    for name in agent_names:
        path = AGENTS[name]
        if not os.path.exists(path):
            print(f"ERROR: {name} not found at {path}")
            sys.exit(1)

    run_tournament(agent_names, games_per_seat=games_per_seat)


if __name__ == "__main__":
    main()
