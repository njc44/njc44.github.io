"""LB Simulator V2 — test agents against REAL public opponents.

Uses actual extracted agent code from top Kaggle notebooks.
Each opponent is a real, reactive agent — not a replay tape.

Usage:
    python lb_sim_v2.py <candidate_path> [--games N] [--opponents opp1,opp2,...]

Available opponents:
    aurax7   — Reactive Router (63 votes, ~LB 1915)
    boatlee  — V16 Premium Market Lead (311 votes)
    tetsu    — Shape Shop Value-Aware (125 votes)
    base     — Public State Router (99 votes, ~LB 1891)

Run all candidates at once for comparison:
    python lb_sim_v2.py compare [--games N]
"""
import json
import math
import os
import sys
import time
from pathlib import Path

from kaggle_environments import make

# ── Opponent Registry ─────────────────────────────────────────────
OPPONENTS = {
    "aurax7": "/tmp/kaggriculture_opponents/real_agents/aurax7_reactive_extracted/main.py",
    "boatlee": "/tmp/kaggriculture_opponents/real_agents/boatlee_v16_extracted/main.py",
    "tetsu": "/tmp/kaggriculture_opponents/real_agents/tetsu_extracted/main.py",
    "base": "/tmp/kaggriculture_agents/public_state_router/main.py",
}

# ── Our Agent Registry (for compare mode) ─────────────────────────
CANDIDATES = {
    "shop_router": "/tmp/kaggriculture_latest/shop_router_0909_ext/main.py",
    "room_guard": "/tmp/kaggriculture_latest/room_guard_only/main.py",
    "hybrid_v1": "/tmp/kaggriculture_latest/hybrid_v1/main.py",
}

# ── Statistics ────────────────────────────────────────────────────
def wilson_ci(wins, total, z=1.96):
    if total == 0:
        return (0, 0)
    p = wins / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denom
    return (max(0, center - margin), min(1, center + margin))


def z_score(wins, losses):
    n = wins + losses
    if n == 0:
        return 0.0
    return (wins / n - 0.5) / math.sqrt(0.25 / n)


# ── Game Runner ───────────────────────────────────────────────────
def run_matchup(candidate_path, opponent_path, games_per_seat=5):
    """Run candidate vs opponent across both seats."""
    wins, losses, ties = 0, 0, 0
    margins = []
    errors = 0

    for i in range(games_per_seat * 2):
        cand_seat = 0 if i < games_per_seat else 1
        a0 = candidate_path if cand_seat == 0 else opponent_path
        a1 = opponent_path if cand_seat == 0 else candidate_path

        try:
            env = make("kaggriculture", debug=True)
            result = env.run([a0, a1])
            final = result[-1]
            r0, r1 = final[0]["reward"], final[1]["reward"]
            s0, s1 = final[0]["status"], final[1]["status"]

            if s0 != "DONE" or s1 != "DONE":
                errors += 1
                continue

            rc = r0 if cand_seat == 0 else r1
            ro = r1 if cand_seat == 0 else r0
            margin = rc - ro
            margins.append(margin)

            if rc > ro:
                wins += 1
            elif ro > rc:
                losses += 1
            else:
                ties += 1
        except Exception as e:
            errors += 1

    total = wins + losses + ties
    wr = wins / total if total else 0
    avg_margin = sum(margins) / len(margins) if margins else 0
    ci = wilson_ci(wins, total)

    return {
        "wins": wins, "losses": losses, "ties": ties, "errors": errors,
        "total": total, "win_rate": wr, "avg_margin": avg_margin,
        "ci_95": ci, "z_score": z_score(wins, losses),
    }


# ── Single Agent Test ─────────────────────────────────────────────
def test_agent(candidate_path, games_per_seat=5, opp_names=None):
    """Test a single candidate against all opponents."""
    if opp_names is None:
        opp_names = list(OPPONENTS.keys())

    candidate_name = Path(candidate_path).parent.name or Path(candidate_path).stem
    print(f"\nTesting: {candidate_name}")
    print(f"Games per matchup: {games_per_seat * 2} ({games_per_seat}/seat)")
    print()

    results = {}
    for opp_name in opp_names:
        opp_path = OPPONENTS.get(opp_name)
        if not opp_path or not os.path.exists(opp_path):
            continue

        start = time.time()
        stats = run_matchup(candidate_path, opp_path, games_per_seat)
        elapsed = time.time() - start

        results[opp_name] = stats
        print(f"  vs {opp_name:10s}: {stats['wins']:2d}W-{stats['losses']:2d}L-{stats['ties']:2d}D "
              f"({stats['win_rate']*100:5.1f}% WR) margin={stats['avg_margin']:+,.0f} "
              f"z={stats['z_score']:+.2f} [{elapsed:.0f}s]")

    # Aggregate
    total_w = sum(r["wins"] for r in results.values())
    total_l = sum(r["losses"] for r in results.values())
    total_t = sum(r["ties"] for r in results.values())
    total_n = total_w + total_l + total_t
    overall_wr = total_w / total_n if total_n else 0
    all_margins = []
    for r in results.values():
        # Reconstruct margins from stats
        all_margins.extend([r["avg_margin"]] * r["total"])

    print(f"\n  OVERALL: {total_w}W-{total_l}L-{total_t}D ({overall_wr*100:.1f}% WR)")

    return {"name": candidate_name, "results": results,
            "overall_wr": overall_wr, "total_w": total_w, "total_l": total_l}


# ── Compare Mode ──────────────────────────────────────────────────
def compare_all(games_per_seat=5, opp_names=None, cand_names=None):
    """Compare all our agents against the opponent pool."""
    if cand_names is None:
        cand_names = list(CANDIDATES.keys())

    print(f"{'='*70}")
    print(f"  LB SIMULATION V2 — Real Opponent Comparison")
    print(f"{'='*70}")

    all_results = {}
    for cand_name in cand_names:
        cand_path = CANDIDATES.get(cand_name)
        if not cand_path or not os.path.exists(cand_path):
            print(f"\n  SKIP: {cand_name} — not found")
            continue
        all_results[cand_name] = test_agent(cand_path, games_per_seat, opp_names)

    # Summary table
    print(f"\n{'='*70}")
    print(f"  SUMMARY")
    print(f"{'='*70}")
    print(f"\n  {'Agent':15s} {'W':>3} {'L':>3} {'WR':>7} {'vs aurax7':>10} {'vs boatlee':>10} {'vs tetsu':>10} {'vs base':>10}")
    print(f"  {'-'*15} {'-'*3} {'-'*3} {'-'*7} {'-'*10} {'-'*10} {'-'*10} {'-'*10}")

    ranked = sorted(all_results.items(), key=lambda x: -x[1]["overall_wr"])
    for cand_name, data in ranked:
        row = f"  {cand_name:15s} {data['total_w']:>3} {data['total_l']:>3} {data['overall_wr']*100:>6.1f}%"
        for opp in ["aurax7", "boatlee", "tetsu", "base"]:
            if opp in data["results"]:
                r = data["results"][opp]
                row += f" {r['win_rate']*100:>5.0f}%({r['wins']}/{r['total']})"
            else:
                row += f"{'N/A':>10}"
        print(row)

    print(f"\n{'='*70}")

    # Save
    save_data = {name: {
        "overall_wr": d["overall_wr"],
        "total_w": d["total_w"],
        "total_l": d["total_l"],
        "per_opponent": {k: {kk: vv for kk, vv in v.items() if kk != "margins"}
                         for k, v in d["results"].items()}
    } for name, d in all_results.items()}

    out_path = "/Users/nathanjacob/Documents/kaggle/kaggriculture/lb_sim_v2_results.json"
    with open(out_path, "w") as f:
        json.dump(save_data, f, indent=2)
    print(f"\n  Results saved to: {out_path}")


# ── Main ──────────────────────────────────────────────────────────
def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    games_per_seat = 5
    opp_names = None

    # Parse global args
    for i, arg in enumerate(sys.argv):
        if arg == "--games" and i + 1 < len(sys.argv):
            games_per_seat = int(sys.argv[i + 1]) // 2
        if arg == "--opponents" and i + 1 < len(sys.argv):
            opp_names = sys.argv[i + 1].split(",")

    if sys.argv[1] == "compare":
        cand_names = None
        for i, arg in enumerate(sys.argv):
            if arg == "--candidates" and i + 1 < len(sys.argv):
                cand_names = sys.argv[i + 1].split(",")
        compare_all(games_per_seat, opp_names, cand_names)
    else:
        candidate = sys.argv[1]
        if not os.path.exists(candidate):
            print(f"ERROR: {candidate} not found")
            sys.exit(1)
        test_agent(candidate, games_per_seat, opp_names)


if __name__ == "__main__":
    main()
