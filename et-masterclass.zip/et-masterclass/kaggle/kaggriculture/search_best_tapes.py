"""Search for the best tape assignment per shop pair.

Patches the Kaggle engine to force specific shop draws, then runs
each of our 13 tapes against a reference opponent across multiple seeds.

Usage:
    python search_best_tapes.py [--seeds 10] [--workers 4]

Output:
    - Per-pair results JSON with best tape and expected money
    - New SHOP_PLANS dict ready to paste into router_parent.py
"""
import copy
import json
import math
import multiprocessing
import os
import random
import sys
import time
from itertools import product as iterproduct
from pathlib import Path

# ── Configuration ─────────────────────────────────────────────────
SHOPS = ["BAKERY", "BRUNCH_SPOT", "FARMERS_MARKET", "ICE_CREAM_SHOP",
         "PET_CAFE", "PIZZA_SHOP", "SMOOTHIE_SHOP", "YARN_STORE"]

NUM_TAPES = 13
REFERENCE_AGENT = "/tmp/kaggriculture_latest/shop_router_0909_ext/main.py"
CANDIDATE_TEMPLATE = "/tmp/kaggriculture_latest/shop_router_0909_ext/main.py"
ACTIONS_JSON = "/tmp/kaggriculture_latest/shop_router_0909_ext/actions.json"
OUTPUT_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")

# We'll monkey-patch the engine to force shop draws
ENGINE_PATH = "/Users/nathanjacob/opt/miniconda3/lib/python3.12/site-packages/kaggle_environments/envs/kaggriculture/kaggriculture.py"


def build_forced_shop_agent(tape_index, actions_json_path):
    """Create an agent function that always uses a specific tape index."""
    with open(actions_json_path) as f:
        all_tapes = json.load(f)

    tape = all_tapes[tape_index]

    # Import the router code but override the plan selection
    import importlib.util
    spec = importlib.util.spec_from_file_location("_router", CANDIDATE_TEMPLATE)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    class ForcedPolicy:
        """Policy that always uses a specific tape, ignoring shop routing."""
        def __init__(self):
            self.tapes = all_tapes
            self.forced_tape = tape_index
            self.players = {}

        def act(self, observation):
            step = int(observation["step"])
            player = int(observation["player"])

            state = self.players.get(player)
            if state is None or step <= getattr(state, 'last_step', -1):
                state = self.players[player] = mod.DayState()
            state.last_step = step

            # Always use our forced tape (except endgame plan 2 at step 648+)
            if step < 648:
                state.plan = self.forced_tape
            else:
                state.plan = 2

            view = mod.FarmView(observation)
            tape = self.tapes[state.plan]
            action = copy.deepcopy(tape[step])
            mod.repair_weeds(action, view, state, step)
            mod.subtract_advanced_sales(action, state, step)
            mod.advance_sales(action, view, state, tape, step)
            action["market"] = action["market"][:10]

            if step == 718:
                return mod.liquidate(view)
            return action

    policy = ForcedPolicy()

    def agent(observation, configuration=None):
        return policy.act(observation)

    return agent


def run_single_game(args):
    """Run one game with forced shops. Returns (shop_pair, tape_idx, seed, money_candidate, money_reference)."""
    shop1, shop2, tape_idx, seed = args

    # We need to monkey-patch the engine's shop draw for this game
    # The cleanest way: use the env's seed mechanism and override _end_of_day
    from kaggle_environments import make

    env = make("kaggriculture", configuration={"seed": seed}, debug=True)

    # Monkey-patch the town shop unlock to force our desired shops
    import kaggle_environments.envs.kaggriculture.kaggriculture as engine

    original_end_of_day = engine._end_of_day
    forced_shops = [shop1, shop2]
    # We only force the first two. Shops 3-8 are random from seed.

    def patched_end_of_day(state, env_obj, day):
        original_end_of_day(state, env_obj, day)
        # After original runs, check if shops were just unlocked and override
        obs0 = state[0].observation
        town = obs0.town
        shops_list = town.get("unlocked_shops", [])
        # Shops unlock at days 3, 6, 9, ...
        # Day 3 → first shop, Day 6 → second shop
        # After _end_of_day for day 2, next_day=3, first shop unlocks
        # After _end_of_day for day 5, next_day=6, second shop unlocks
        next_day = day + 1
        shop_interval = 3
        if next_day > 0 and next_day % shop_interval == 0:
            shop_idx = len(shops_list) - 1  # The one just added
            if shop_idx == 0:
                shops_list[0] = forced_shops[0]
            elif shop_idx == 1:
                shops_list[1] = forced_shops[1]

    engine._end_of_day = patched_end_of_day

    try:
        # Create the forced-tape agent
        candidate_agent = build_forced_shop_agent(tape_idx, ACTIONS_JSON)

        result = env.run([candidate_agent, REFERENCE_AGENT])
        final = result[-1]
        r0 = final[0]["reward"]
        r1 = final[1]["reward"]
        s0 = final[0]["status"]
        s1 = final[1]["status"]

        if s0 != "DONE" or s1 != "DONE":
            return (shop1, shop2, tape_idx, seed, None, None, "ERROR")

        return (shop1, shop2, tape_idx, seed, r0, r1, "OK")
    except Exception as e:
        return (shop1, shop2, tape_idx, seed, None, None, str(e))
    finally:
        engine._end_of_day = original_end_of_day


def run_search(num_seeds=10, num_workers=4):
    """Run the full search: 64 pairs × 13 tapes × N seeds."""

    # Generate all shop pairs (with replacement — same shop can appear twice)
    all_pairs = list(iterproduct(SHOPS, repeat=2))
    print(f"Shop pairs: {len(all_pairs)}")
    print(f"Tapes: {NUM_TAPES}")
    print(f"Seeds per combo: {num_seeds}")
    total_games = len(all_pairs) * NUM_TAPES * num_seeds
    print(f"Total games: {total_games}")
    print(f"Estimated time at 2.5s/game: {total_games * 2.5 / 3600:.1f} hours")
    print(f"With {num_workers} workers: {total_games * 2.5 / 3600 / num_workers:.1f} hours")
    print()

    # Generate all game configs
    # Use deterministic seeds so results are reproducible
    rng = random.Random(42)
    base_seeds = [rng.randint(1, 999999999) for _ in range(num_seeds)]

    games = []
    for shop1, shop2 in all_pairs:
        for tape_idx in range(NUM_TAPES):
            for seed in base_seeds:
                games.append((shop1, shop2, tape_idx, seed))

    print(f"Running {len(games)} games...")
    start_time = time.time()

    # Run games (sequentially for now — monkey-patching isn't process-safe)
    results = []
    for i, game in enumerate(games):
        result = run_single_game(game)
        results.append(result)
        if (i + 1) % 100 == 0:
            elapsed = time.time() - start_time
            rate = (i + 1) / elapsed
            remaining = (len(games) - i - 1) / rate
            print(f"  [{i+1}/{len(games)}] {rate:.1f} games/s, ~{remaining/60:.0f}min remaining")

    elapsed = time.time() - start_time
    print(f"\nCompleted {len(results)} games in {elapsed:.0f}s ({elapsed/60:.1f}min)")

    # Analyze results
    pair_tape_money = {}  # (shop1, shop2, tape_idx) -> [money values]
    errors = 0

    for shop1, shop2, tape_idx, seed, r0, r1, status in results:
        if status != "OK":
            errors += 1
            continue
        key = (shop1, shop2, tape_idx)
        if key not in pair_tape_money:
            pair_tape_money[key] = []
        pair_tape_money[key].append(r0)  # Our candidate's money

    print(f"Errors: {errors}/{len(results)}")

    # Find best tape per pair
    best_plans = {}
    all_pair_results = {}

    for shop1, shop2 in all_pairs:
        pair_key = (shop1, shop2)
        tape_scores = {}
        for tape_idx in range(NUM_TAPES):
            key = (shop1, shop2, tape_idx)
            if key in pair_tape_money:
                values = pair_tape_money[key]
                tape_scores[tape_idx] = {
                    "mean": sum(values) / len(values),
                    "min": min(values),
                    "max": max(values),
                    "n": len(values),
                }

        if tape_scores:
            best_tape = max(tape_scores, key=lambda t: tape_scores[t]["mean"])
            best_mean = tape_scores[best_tape]["mean"]
            plan0_mean = tape_scores.get(0, {}).get("mean", 0)
            improvement = best_mean - plan0_mean

            best_plans[f"{shop1},{shop2}"] = {
                "best_tape": best_tape,
                "best_mean": best_mean,
                "plan0_mean": plan0_mean,
                "improvement": improvement,
                "all_tapes": tape_scores,
            }
            all_pair_results[pair_key] = best_tape

    # Save full results
    out_path = OUTPUT_DIR / "tape_search_results.json"
    with open(out_path, "w") as f:
        json.dump(best_plans, f, indent=2)
    print(f"\nFull results saved to: {out_path}")

    # Generate new SHOP_PLANS
    print(f"\n{'='*70}")
    print("  NEW SHOP_PLANS (paste into router_parent.py)")
    print(f"{'='*70}")
    print("SHOP_PLANS = {")
    for (shop1, shop2), tape_idx in sorted(all_pair_results.items()):
        pair_data = best_plans[f"{shop1},{shop2}"]
        imp = pair_data["improvement"]
        imp_str = f"  # +{imp:.0f}" if imp > 100 else ""
        print(f'    ("{shop1}", "{shop2}"): {tape_idx},{imp_str}')
    print("}")

    # Summary: top improvements over plan 0
    print(f"\n{'='*70}")
    print("  TOP IMPROVEMENTS OVER PLAN 0")
    print(f"{'='*70}")
    improvements = [(k, v["improvement"], v["best_tape"], v["best_mean"], v["plan0_mean"])
                    for k, v in best_plans.items()]
    improvements.sort(key=lambda x: -x[1])
    for pair, imp, tape, best, plan0 in improvements[:20]:
        print(f"  {pair:40s} tape={tape:2d}  best={best:>9,.0f}  plan0={plan0:>9,.0f}  Δ={imp:>+9,.0f}")


if __name__ == "__main__":
    num_seeds = 10
    num_workers = 4

    for i, arg in enumerate(sys.argv):
        if arg == "--seeds" and i + 1 < len(sys.argv):
            num_seeds = int(sys.argv[i + 1])
        if arg == "--workers" and i + 1 < len(sys.argv):
            num_workers = int(sys.argv[i + 1])

    run_search(num_seeds, num_workers)
