# V2 Threat Briefing — Sep 11 2026

## Gauntlet Results (220 games)

V2 overall: **156-62-2 (71% WR)**

### Dominating (100% WR)
- boatlee_v16 (20-0), kaito_v48 (20-0), tetsu_adaptive (20-0), tschinkel_router (20-0), yhay81_fieldbook (20-0)

### Winning
- tetsu_shape (19-1, 95%), shop_router (15-3-2, 75%), pilkwang (13-7, 65%)

### LOSING
- **prvsiyan_soil: 0-20 (0% WR, -4,970 margin)** — total wipeout
- **prvsiyan_moon: 1-19 (5% WR, -3,219 margin)** — near-total wipeout
- **hybrid_v1: 8-12 (40% WR, +314 margin)** — our own agent beats V2

---

## Threat #1: prvsiyan_soil (0-20)

### Architecture
Layered decorator stack on yhay81 Shop Router base:
```
Base (13 tapes, shop-pair routing at step 144)
  → V216: Day-1 wheat sale reserve (step 23)
  → V217: Idle-farmer starvation rescue (hours 16-21, max 2/game)
  → V218: Terminal fertilizer collection (steps 712-718, 3 workers BFS)
  → V219: Late tomato investment (days 18-29 in SE quadrant)
  → V224: Sell-before-buy reordering (bubble SELLs to front)
  → V226: Wheat top-up for scheduled pickups (buys missing wheat)
  → V231: Cow←sheep substitution (steps 216-227, max 4 cows)
  → V233: Sheep SE investment (day 12, 6 sheep in SE, requires 2 YARN_STORE)
  → V234: Rescue feed for sheep module
```

### Why it destroys V2
1. **SE quadrant monetization (V219 tomatoes + V233 sheep)** — V2 never uses SE land. Soil runs either 10 tomato plants (days 18-29) or 6 sheep (day 12+) there, adding $8K-22K revenue
2. **Livestock switching (V231)** — Upgrades sheep→cow when milk shops dominate, no YARN_STORE. Cap of 4 substitutions.
3. **Starvation rescue (V217)** — Catches dying animals using idle farmer evening turns. V2 has no equivalent.
4. **Wheat top-up (V226)** — Prevents PICKUP WHEAT failures by buying exact shortfall. V2 replays tape verbatim.
5. **Terminal fertilizer (V218)** — 3 idle workers collect fertilizer in final 7 turns. V2 has nothing here.
6. **Sales ordering (V224)** — Floats SELLs before BUYs, ensuring sells never truncated by 10-order limit.
7. **Day-1 hire safety (V216)** — Sells 1 wheat to fund hires. V2 can miss hires on bad seeds.

---

## Threat #2: prvsiyan_moon (1-19)

### Architecture
Same as soil **minus V233 (sheep SE module)**:
```
Base → V216 → V217 → V218 → V219 → V224 → V226 → V231
```

### Key differences from soil
- No sheep SE investment (V233/V234 absent)
- Still devastating because V216-V231 layers are the core advantage
- V219 tomato fires rarely (2/48 episodes) but adds $3-9K when it does
- V218 terminal fertilizer fires 42% of games

### Why it's nearly as deadly as soil
Same structural advantages minus the sheep module. The sheep module requires 2 YARN_STOREs + specific price conditions — fires rarely. Moon's 19-1 vs our 0-20 for soil suggests the sheep module adds ~1 game of margin.

---

## Threat #3: hybrid_v1 (12-8 vs V2)

### Architecture
Two-layer system on Shop Router base:
```
Base (same 13 tapes, same shop-pair routing)
  + Terminal physical planner (ShopClosure, steps 712-718)
    - MCTS-style search: 128 simulations, 8 proposals/actor
    - Full physics simulation via unit_model.py
    - Strict dominance criterion before accepting
    - Safety abort if observation diverges
```

### Why it beats V2
1. **Terminal planner finds unharvested resources** — At step 712, searches for harvestable tiles within worker reach, simulates exact game physics for 128 paths, accepts only strictly dominant plans. V2 follows tape blindly for steps 712-718.
2. **V2's reactive layers regressed performance:**
   - `room_guard` cheapest-first may dump wrong items in edge cases
   - `wool_hold` accumulates inventory pressure (45% of games have no Yarn Store ever)
   - `early_liquidate` at step 717 conflicts with what should be step 718 optimization
   - `drop_guard` PLACE conversion can lose multi-item carries
3. **No tape 1→9 regression** — hybrid_v1 still uses tape 1 for (YARN_STORE, FARMERS_MARKET). The "fix" in V2 may have been a regression for some seeds.

### Key insight
hybrid_v1's terminal planner captures late-game value on EVERY game. V2's reactive layers help in specific edge cases but hurt in others. Net effect: hybrid_v1 is more consistent.

---

## What V2 Has That Others Don't
- room_guard (cheapest-first) — prevents shed overflow
- tape 1→9 fix — corrects divergent prefix
- These appear to be net-negative or neutral vs the layers we're missing

---

## Gap Analysis: V2 vs Threats

| Layer | prvsiyan (soil/moon) | hybrid_v1 | V2 |
|-------|---------------------|-----------|-----|
| 13-tape shop routing | Yes | Yes | Yes |
| Weed repair | Yes | Yes | Yes |
| Advance sales | Yes | Yes | Yes |
| Liquidation | Yes | Yes | Yes |
| Terminal planner (712-718) | V218 (fertilizer BFS) | ShopClosure (MCTS) | None |
| SE quadrant use | V219 tomato + V233 sheep | No | No |
| Livestock switching | V231 (sheep→cow) | No | No |
| Starvation rescue | V217 (idle farmer) | No | No |
| Wheat top-up | V226 (exact shortfall) | No | No |
| Sales ordering | V224 (SELLs first) | No | No |
| Day-1 hire reserve | V216 (1 wheat sale) | No | No |
| Room guard | No | Expensive-first | Cheapest-first |
| Wool hold | No | No | Yes (may hurt) |
| Drop guard | No | No | Yes (may hurt) |
| Early liquidate 717 | No | No | Yes (may hurt) |

---

## Current LB Scores (Sep 11)
- Hybrid V1: 2294.3 (climbing → settled)
- Shop Router: 2222.2 (dropped from 2388)
- V2: Not yet submitted
- prvsiyan agents: Unknown LB score (not our submissions)

## Questions for Expert
1. Which layers give the most Elo per implementation hour?
2. Should we build V3 by layering onto V2 or onto hybrid_v1?
3. Is the terminal planner or the prvsiyan layers more important for LB?
4. Can we port prvsiyan's layers AND keep hybrid_v1's terminal planner?
5. Ship timeline: Sep 16-18 hard stop. What's achievable?
