"""Kaggriculture Agent Vetting Framework.

Run this before ANY submission. Tests a candidate agent against multiple
opponents across many games to establish statistical significance.

Usage:
    python vet_agent.py <candidate_path> [--games 50] [--opponents all]

Requirements:
    - conda python with kaggle-environments installed
    - Agent files at expected paths
"""
import sys
import os
import time
import math
import json

# Use conda python's kaggle_environments
from kaggle_environments import make

# ── Opponent Registry ───────────────────────────────────────────────
OPPONENTS = {
    "base":         "/tmp/kaggriculture_agents/public_state_router/main.py",
    "shop_router":  "/tmp/kaggriculture_latest/shop_router_0909_ext/main.py",
    "seven_turn":   "/tmp/kaggriculture_latest/seven_turn_ext/main.py",
    "reactive_v2":  "/tmp/kaggriculture_latest/reactive_v2_ext/main.py",
}

# ── Statistical Helpers ─────────────────────────────────────────────
def z_score(wins, losses):
    """Two-proportion z-test vs 50% baseline."""
    n = wins + losses
    if n == 0:
        return 0.0
    p = wins / n
    se = math.sqrt(0.25 / n)  # SE under H0: p=0.5
    return (p - 0.5) / se


def wilson_ci(wins, total, z=1.96):
    """Wilson score 95% confidence interval for win rate."""
    if total == 0:
        return (0, 0)
    p = wins / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denom
    return (max(0, center - margin), min(1, center + margin))


# ── Core Test Runner ────────────────────────────────────────────────
def run_matchup(candidate_path, opponent_path, n_games_per_seat=10):
    """Run candidate vs opponent, alternating seats. Returns dict of stats."""
    wins, losses, ties = 0, 0, 0
    scores_cand, scores_opp = [], []
    errors = 0

    for i in range(n_games_per_seat * 2):
        if i < n_games_per_seat:
            a0, a1, cand_seat = candidate_path, opponent_path, 0
        else:
            a0, a1, cand_seat = opponent_path, candidate_path, 1

        try:
            env = make("kaggriculture", debug=True)
            result = env.run([a0, a1])
            final = result[-1]
            r0, r1 = final[0]["reward"], final[1]["reward"]
            s0, s1 = final[0]["status"], final[1]["status"]

            if s0 != "DONE" or s1 != "DONE":
                errors += 1
                continue

            rc = r0 if cand_seat == 0 else r1
            ro = r1 if cand_seat == 0 else r0
            scores_cand.append(rc)
            scores_opp.append(ro)

            if rc > ro:
                wins += 1
            elif ro > rc:
                losses += 1
            else:
                ties += 1
        except Exception as e:
            errors += 1

    total = wins + losses + ties
    wr = wins / total if total else 0
    ci_low, ci_high = wilson_ci(wins, total)
    z = z_score(wins, losses)
    avg_c = sum(scores_cand) / len(scores_cand) if scores_cand else 0
    avg_o = sum(scores_opp) / len(scores_opp) if scores_opp else 0

    return {
        "wins": wins, "losses": losses, "ties": ties, "errors": errors,
        "total": total, "win_rate": wr,
        "ci_95": (ci_low, ci_high), "z_score": z,
        "avg_candidate": avg_c, "avg_opponent": avg_o,
        "margin": avg_c - avg_o,
    }


# ── Vetting Verdict ─────────────────────────────────────────────────
def verdict(results, candidate_name):
    """Determine if candidate passes vetting."""
    print(f"\n{'='*70}")
    print(f"  VETTING REPORT: {candidate_name}")
    print(f"{'='*70}\n")

    all_pass = True
    any_dominant = False

    for opp_name, stats in results.items():
        wr = stats["win_rate"]
        ci = stats["ci_95"]
        z = stats["z_score"]
        total = stats["total"]

        # Determine verdict for this matchup
        if wr >= 0.55 and z >= 2.0:
            tag = "DOMINANT"
            any_dominant = True
        elif wr >= 0.45 and ci[0] >= 0.35:
            tag = "NEUTRAL (safe)"
        elif wr < 0.40 or ci[1] < 0.45:
            tag = "INFERIOR"
            all_pass = False
        else:
            tag = "INCONCLUSIVE"

        print(f"  vs {opp_name:15s}: {stats['wins']:2d}W-{stats['losses']:2d}L-{stats['ties']:2d}D "
              f"({wr*100:5.1f}% WR)  z={z:+5.2f}  "
              f"CI=[{ci[0]*100:.0f}%-{ci[1]*100:.0f}%]  "
              f"Margin={stats['margin']:+,.0f}  → {tag}")

    print(f"\n{'─'*70}")

    if not all_pass:
        print(f"  VERDICT: ❌ FAIL — loses to at least one opponent")
        print(f"  ACTION:  Do NOT submit. Fix weaknesses first.")
    elif any_dominant:
        print(f"  VERDICT: ✅ PASS — dominates at least one opponent, safe against all")
        print(f"  ACTION:  Safe to submit (pending your approval).")
    else:
        print(f"  VERDICT: ⚠️  MARGINAL — doesn't lose, but no clear improvement")
        print(f"  ACTION:  Consider submitting only if no better option.")

    print(f"{'='*70}\n")
    return all_pass


# ── Main ────────────────────────────────────────────────────────────
def main():
    if len(sys.argv) < 2:
        print("Usage: python vet_agent.py <candidate_path> [--games N] [--opponents opp1,opp2]")
        print(f"\nAvailable opponents: {', '.join(OPPONENTS.keys())}")
        sys.exit(1)

    candidate = sys.argv[1]
    if not os.path.exists(candidate):
        print(f"ERROR: {candidate} not found")
        sys.exit(1)

    # Parse args
    games_per_seat = 10  # default 20 total per matchup
    opp_names = list(OPPONENTS.keys())

    for i, arg in enumerate(sys.argv[2:], 2):
        if arg == "--games" and i + 1 < len(sys.argv):
            games_per_seat = int(sys.argv[i + 1]) // 2
        if arg == "--opponents" and i + 1 < len(sys.argv):
            opp_names = sys.argv[i + 1].split(",")

    candidate_name = os.path.basename(candidate)
    print(f"Vetting: {candidate_name}")
    print(f"Games per matchup: {games_per_seat * 2} ({games_per_seat} per seat)")
    print(f"Opponents: {', '.join(opp_names)}")
    print()

    results = {}
    total_start = time.time()

    for opp_name in opp_names:
        if opp_name not in OPPONENTS:
            print(f"  WARNING: Unknown opponent '{opp_name}', skipping")
            continue
        opp_path = OPPONENTS[opp_name]
        if not os.path.exists(opp_path):
            print(f"  WARNING: {opp_path} not found, skipping {opp_name}")
            continue

        print(f"  Testing vs {opp_name}...", end="", flush=True)
        start = time.time()
        stats = run_matchup(candidate, opp_path, games_per_seat)
        elapsed = time.time() - start
        print(f" done ({elapsed:.0f}s) — {stats['wins']}W-{stats['losses']}L-{stats['ties']}D")
        results[opp_name] = stats

    total_elapsed = time.time() - total_start
    print(f"\nTotal time: {total_elapsed:.0f}s")

    passed = verdict(results, candidate_name)

    # Save results
    out_path = candidate.replace(".py", "_vet_results.json")
    with open(out_path, "w") as f:
        json.dump({"candidate": candidate, "results": results, "passed": passed}, f, indent=2)
    print(f"Results saved to: {out_path}")


if __name__ == "__main__":
    main()
