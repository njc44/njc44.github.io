"""Replay agent — replays a pre-extracted action tape from a real LB game.

Usage as a standalone agent file:
    Set REPLAY_TAPE_PATH env var to the path of the JSON action tape.

Usage as a module:
    from replay_agent import make_replay_agent
    agent_fn = make_replay_agent("/tmp/kaggriculture_opponents/opp_12345.json")
"""
import json
import os
from pathlib import Path


def make_replay_agent(tape_path):
    """Create an agent function that replays a recorded action tape."""
    with open(tape_path) as f:
        tape = json.load(f)

    def agent(observation, configuration=None):
        step = int(observation["step"])
        if step < len(tape):
            return tape[step]
        # Fallback: PASS everything
        return {"farmer": ["PASS"], "hands": [], "market": []}

    agent._tape_path = str(tape_path)
    return agent


# Standalone mode: load from env var
_AGENT = None

def agent(observation, configuration=None):
    global _AGENT
    if _AGENT is None:
        tape_path = os.environ.get("REPLAY_TAPE_PATH", "")
        if not tape_path:
            raise ValueError("Set REPLAY_TAPE_PATH env var")
        _AGENT = make_replay_agent(tape_path)
    return _AGENT(observation, configuration)
