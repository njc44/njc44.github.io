#!/bin/bash
# Package a multi-file agent directory into a proper submission tar.gz
# Usage: ./make_submission.sh <agent_dir> [output_name]
#
# This ensures ALL required files are bundled, not just main.py

set -e

AGENT_DIR="${1:?Usage: make_submission.sh <agent_dir> [output_name]}"
OUTPUT="${2:-submission.tar.gz}"
WORK_DIR="/Users/nathanjacob/Documents/kaggle/kaggriculture"

if [ ! -d "$AGENT_DIR" ]; then
    echo "ERROR: $AGENT_DIR is not a directory"
    exit 1
fi

if [ ! -f "$AGENT_DIR/main.py" ]; then
    echo "ERROR: $AGENT_DIR/main.py not found"
    exit 1
fi

echo "=== Packaging Agent ==="
echo "Source: $AGENT_DIR"
echo "Output: $WORK_DIR/$OUTPUT"
echo

# Build tar excluding __pycache__ and vet results
cd "$AGENT_DIR"
tar czf "$WORK_DIR/$OUTPUT" \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='*_vet_results*' \
    .

echo "Contents:"
tar tzf "$WORK_DIR/$OUTPUT" | while read f; do
    size=$(tar xzf "$WORK_DIR/$OUTPUT" --to-stdout "$f" 2>/dev/null | wc -c)
    printf "  %-40s %s bytes\n" "$f" "$size"
done

echo
total=$(stat -f%z "$WORK_DIR/$OUTPUT" 2>/dev/null || stat -c%s "$WORK_DIR/$OUTPUT" 2>/dev/null)
echo "Total archive size: $((total / 1024)) KB ($((total / 1024 / 1024)) MB)"
echo

# Verify main.py is present
if tar tzf "$WORK_DIR/$OUTPUT" | grep -q "main.py"; then
    echo "OK: main.py present"
else
    echo "ERROR: main.py NOT in archive!"
    exit 1
fi

# Check if actions.json is needed
if grep -q "actions.json" "$AGENT_DIR/main.py"; then
    if tar tzf "$WORK_DIR/$OUTPUT" | grep -q "actions.json"; then
        echo "OK: actions.json present (required by main.py)"
    else
        echo "ERROR: main.py references actions.json but it's NOT in archive!"
        exit 1
    fi
fi

echo
echo "=== Ready to submit ==="
echo "kaggle competitions submit -c kaggriculture -f $WORK_DIR/$OUTPUT -m 'description'"
