"""Cross-Entropy Method (CEM) optimizer for Kaggriculture capital allocation.

Optimises a parameterised allocation policy using the fluid model.
The policy maps (shops_revealed, day_bracket) -> asset allocation vector.

Standard library + numpy only.
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional, Tuple

import numpy as np

from fluid_model import (
    SHOPS,
    ALL_SHOP_NAMES,
    TOTAL_DAYS,
    simulate_allocation,
)


# ---------------------------------------------------------------------------
# Policy parameterisation
# ---------------------------------------------------------------------------

# Allocation vector layout (15 dimensions):
#   [0]:  n_sheep
#   [1]:  n_cow
#   [2]:  n_goose
#   [3]:  n_wheat (planted)
#   [4]:  n_carrot
#   [5]:  n_tomato
#   [6]:  n_strawberry
#   [7]:  n_melon
#   [8]:  n_hires_per_day
#   [9]:  land_buy_day_1 (NE)
#   [10]: land_buy_day_2 (SW)
#   [11]: land_buy_day_3 (SE)
#   [12]: animal_buy_day
#   [13]: crop_plant_day
#   [14]: sell_fert_threshold (day)

N_PARAMS = 15

# Reasonable initial means and standard deviations
DEFAULT_MEAN = np.array([
    8.0,   # n_sheep
    4.0,   # n_cow
    3.0,   # n_goose
    6.0,   # n_wheat
    4.0,   # n_carrot
    2.0,   # n_tomato
    2.0,   # n_strawberry
    2.0,   # n_melon
    12.0,  # n_hires
    2.0,   # land_day_1
    5.0,   # land_day_2
    10.0,  # land_day_3
    0.0,   # animal_buy_day
    0.0,   # crop_plant_day
    15.0,  # sell_fert_threshold
], dtype=np.float64)

DEFAULT_STD = np.array([
    4.0,   # n_sheep
    3.0,   # n_cow
    3.0,   # n_goose
    4.0,   # n_wheat
    3.0,   # n_carrot
    2.0,   # n_tomato
    2.0,   # n_strawberry
    2.0,   # n_melon
    3.0,   # n_hires
    3.0,   # land_day_1
    4.0,   # land_day_2
    5.0,   # land_day_3
    3.0,   # animal_buy_day
    3.0,   # crop_plant_day
    5.0,   # sell_fert_threshold
], dtype=np.float64)

# Parameter bounds (inclusive)
PARAM_LOWER = np.array([0, 0, 0,  0, 0, 0, 0, 0,  1,  0, 0, 0,  0, 0, 0], dtype=np.float64)
PARAM_UPPER = np.array([20, 15, 15,  20, 15, 10, 10, 10,  15,  25, 25, 25,  10, 10, 28], dtype=np.float64)


# ---------------------------------------------------------------------------
# Shop-aware policy: adjust mean based on shop reveals
# ---------------------------------------------------------------------------

def adjust_mean_for_shops(base_mean: np.ndarray, shops: List[str]) -> np.ndarray:
    """Shift the base allocation mean based on which shops are revealed.

    The idea: certain shops drive demand for specific products.
    Adjustments increase production of products with higher shop demand.
    """
    mean = base_mean.copy()

    # Count shop types
    n_yarn = shops.count("YARN_STORE")
    n_pizza = shops.count("PIZZA_SHOP")
    n_icecream = shops.count("ICE_CREAM_SHOP")
    n_smoothie = shops.count("SMOOTHIE_SHOP")
    n_brunch = shops.count("BRUNCH_SPOT")
    n_petcafe = shops.count("PET_CAFE")
    n_farmers = shops.count("FARMERS_MARKET")
    n_bakery = shops.count("BAKERY")

    # Milk shops (PIZZA, ICE_CREAM, SMOOTHIE): boost cows
    milk_shops = n_pizza + n_icecream + n_smoothie
    mean[1] += milk_shops * 2.0  # more cows

    # YARN_STORE: boost sheep significantly (wool is very high value with demand)
    mean[0] += n_yarn * 4.0  # more sheep

    # If no YARN_STORE: reduce sheep, boost geese (glut-immune eggs)
    if n_yarn == 0:
        mean[0] = max(0, mean[0] - 4.0)
        mean[2] += 3.0  # more geese

    # Strawberry shops (BRUNCH, ICE_CREAM, SMOOTHIE, FARMERS): boost strawberry
    straw_shops = n_brunch + n_icecream + n_smoothie + n_farmers
    if straw_shops > 0:
        mean[6] += straw_shops * 1.0

    # PET_CAFE: boost carrots
    mean[4] += n_petcafe * 2.0

    # Egg shops (BAKERY, BRUNCH): boost geese
    egg_shops = n_bakery + n_brunch
    mean[2] += egg_shops * 1.5

    return np.clip(mean, PARAM_LOWER, PARAM_UPPER)


# ---------------------------------------------------------------------------
# CEM Optimizer
# ---------------------------------------------------------------------------

class CEMOptimizer:
    """Cross-Entropy Method for optimising capital allocation."""

    def __init__(
        self,
        n_samples: int = 200,
        elite_frac: float = 0.2,
        n_generations: int = 50,
        min_std: float = 0.3,
        noise_injection: float = 0.0,
        seed: int = 42,
    ):
        self.n_samples = n_samples
        self.n_elite = max(1, int(n_samples * elite_frac))
        self.n_generations = n_generations
        self.min_std = min_std
        self.noise_injection = noise_injection
        self.rng = np.random.RandomState(seed)

    def optimise(
        self,
        shops: List[str],
        opponent_sell: Optional[Dict[str, int]] = None,
        initial_mean: Optional[np.ndarray] = None,
        initial_std: Optional[np.ndarray] = None,
        verbose: bool = True,
    ) -> Tuple[np.ndarray, float, List[float]]:
        """Run CEM optimisation for a given shop schedule.

        Returns:
            (best_params, best_score, history_of_best_per_gen)
        """
        mean = initial_mean.copy() if initial_mean is not None else DEFAULT_MEAN.copy()
        mean = adjust_mean_for_shops(mean, shops)
        std = initial_std.copy() if initial_std is not None else DEFAULT_STD.copy()

        best_ever_params = mean.copy()
        best_ever_score = -float("inf")
        history = []

        for gen in range(self.n_generations):
            # Sample parameters from Gaussian
            samples = self.rng.randn(self.n_samples, N_PARAMS) * std + mean

            # Clip to bounds
            samples = np.clip(samples, PARAM_LOWER, PARAM_UPPER)

            # Evaluate each sample
            scores = np.empty(self.n_samples)
            for i in range(self.n_samples):
                scores[i] = simulate_allocation(samples[i], shops, opponent_sell)

            # Select elite
            elite_idx = np.argsort(scores)[-self.n_elite:]
            elite = samples[elite_idx]
            elite_scores = scores[elite_idx]

            # Update distribution
            mean = elite.mean(axis=0)
            std = elite.std(axis=0) + self.noise_injection
            std = np.maximum(std, self.min_std)

            gen_best = elite_scores[-1]
            gen_mean = elite_scores.mean()
            if gen_best > best_ever_score:
                best_ever_score = gen_best
                best_ever_params = elite[-1].copy()

            history.append(best_ever_score)

            if verbose and (gen % 5 == 0 or gen == self.n_generations - 1):
                print(f"  Gen {gen:3d}: best=${gen_best:,.0f}  "
                      f"elite_mean=${gen_mean:,.0f}  "
                      f"best_ever=${best_ever_score:,.0f}")

        return best_ever_params, best_ever_score, history


# ---------------------------------------------------------------------------
# Multi-shop optimisation: find best allocation for each shop schedule
# ---------------------------------------------------------------------------

def generate_shop_schedules(n_schedules: int = 20, seed: int = 42) -> List[List[str]]:
    """Generate random shop schedules (8 shops drawn with replacement)."""
    rng = np.random.RandomState(seed)
    schedules = []
    for _ in range(n_schedules):
        schedule = [ALL_SHOP_NAMES[rng.randint(len(ALL_SHOP_NAMES))]
                    for _ in range(8)]
        schedules.append(schedule)
    return schedules


def optimise_for_schedules(
    schedules: List[List[str]],
    n_samples: int = 200,
    n_generations: int = 50,
    verbose: bool = True,
) -> Dict[str, Tuple[np.ndarray, float]]:
    """Run CEM for each shop schedule, return dict of schedule_key -> (params, score)."""
    results = {}
    cem = CEMOptimizer(n_samples=n_samples, n_generations=n_generations)

    for i, schedule in enumerate(schedules):
        key = ",".join(schedule[:2])  # Key by first 2 shops (what we see at routing time)
        if verbose:
            print(f"\n=== Schedule {i+1}/{len(schedules)}: {key} ===")
            print(f"  Full: {schedule}")

        params, score, history = cem.optimise(schedule, verbose=verbose)
        if key not in results or score > results[key][1]:
            results[key] = (params, score)

    return results


# ---------------------------------------------------------------------------
# Main: demo optimisation
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=" * 60)
    print("CEM Optimizer for Kaggriculture Capital Allocation")
    print("=" * 60)

    # Demo 1: Optimise for a YARN_STORE-heavy schedule
    print("\n--- Optimising for YARN_STORE schedule ---")
    yarn_shops = ["YARN_STORE", "BAKERY", "PIZZA_SHOP", "FARMERS_MARKET",
                  "BRUNCH_SPOT", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP", "YARN_STORE"]

    cem = CEMOptimizer(n_samples=50, n_generations=10, seed=42)
    t0 = time.perf_counter()
    best_params, best_score, history = cem.optimise(yarn_shops, verbose=True)
    elapsed = time.perf_counter() - t0

    print(f"\n  Best score: ${best_score:,.0f}")
    print(f"  Time: {elapsed:.1f}s ({elapsed/(10*50)*1000:.1f}ms/sim)")
    print(f"  Best allocation:")
    labels = ["sheep", "cow", "goose", "wheat", "carrot", "tomato",
              "strawberry", "melon", "hires", "land1", "land2", "land3",
              "animal_day", "crop_day", "fert_sell_day"]
    for label, val in zip(labels, best_params):
        print(f"    {label:15s} = {val:.1f}")

    # Demo 2: Optimise for a no-YARN schedule
    print("\n--- Optimising for no-YARN schedule ---")
    no_yarn_shops = ["PIZZA_SHOP", "BAKERY", "FARMERS_MARKET", "BRUNCH_SPOT",
                     "ICE_CREAM_SHOP", "SMOOTHIE_SHOP", "PET_CAFE", "PIZZA_SHOP"]

    t0 = time.perf_counter()
    best_params2, best_score2, history2 = cem.optimise(no_yarn_shops, verbose=True)
    elapsed = time.perf_counter() - t0

    print(f"\n  Best score: ${best_score2:,.0f}")
    print(f"  Time: {elapsed:.1f}s")
    print(f"  Best allocation:")
    for label, val in zip(labels, best_params2):
        print(f"    {label:15s} = {val:.1f}")

    # Demo 3: Multi-schedule optimisation
    print("\n--- Multi-schedule optimisation (5 random schedules) ---")
    schedules = generate_shop_schedules(n_schedules=5, seed=123)
    results = optimise_for_schedules(
        schedules, n_samples=50, n_generations=10, verbose=True
    )

    print("\n=== Summary ===")
    for key, (params, score) in sorted(results.items(), key=lambda x: -x[1][1]):
        print(f"  {key:30s} -> ${score:,.0f}")
        print(f"    sheep={params[0]:.0f} cow={params[1]:.0f} goose={params[2]:.0f} "
              f"hires={params[8]:.0f}")
