"""Search best tape per shop pair — V2 (excludes tape 1, uses absolute money).

Runs each of 12 safe tapes (0, 2-12) for all 64 ordered shop pairs.
Forces only the first two shops; later shops are random from seed.
Evaluates by ABSOLUTE MONEY (not relative to reference).

Usage:
    python search_tapes_v2.py [--seeds 5]
"""
import copy
import importlib
import importlib.util
import json
import os
import sys
import time
from itertools import product as iterproduct

SHOPS = ["BAKERY", "BRUNCH_SPOT", "FARMERS_MARKET", "ICE_CREAM_SHOP",
         "PET_CAFE", "PIZZA_SHOP", "SMOOTHIE_SHOP", "YARN_STORE"]
SAFE_TAPES = [0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]  # Exclude tape 1
ACTIONS_PATH = "/tmp/kaggriculture_latest/shop_router_0909_ext/actions.json"
AGENT_PATH = "/tmp/kaggriculture_latest/shop_router_0909_ext/main.py"


def run_game(shop1, shop2, tape_idx, seed):
    """Run one game with forced first two shops, specific tape. Returns candidate money."""
    # Fresh engine reload to avoid patch pollution
    import kaggle_environments.envs.kaggriculture.kaggriculture as K
    importlib.reload(K)

    # Patch shop draw
    _eod_orig = K._end_of_day
    def patched_eod(state, env_obj, day):
        _eod_orig(state, env_obj, day)
        obs0 = state[0].observation
        shops = obs0.town.get("unlocked_shops", [])
        if shops:
            idx = len(shops) - 1
            if idx == 0:
                shops[0] = shop1
            elif idx == 1:
                shops[1] = shop2
    K._end_of_day = patched_eod

    from kaggle_environments import make

    # Load module fresh
    with open(ACTIONS_PATH) as f:
        all_tapes = json.load(f)
    spec = importlib.util.spec_from_file_location(f"_r_{tape_idx}_{seed}", AGENT_PATH)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    class ForcedPolicy:
        def __init__(self):
            self.tapes = all_tapes
            self.players = {}
        def act(self, obs):
            step, player = int(obs["step"]), int(obs["player"])
            state = self.players.get(player)
            if state is None or step <= getattr(state, "last_step", -1):
                state = self.players[player] = mod.DayState()
            state.last_step = step
            state.plan = tape_idx if step < 648 else 2
            view = mod.FarmView(obs)
            tape = self.tapes[state.plan]
            action = copy.deepcopy(tape[step])
            mod.repair_weeds(action, view, state, step)
            mod.subtract_advanced_sales(action, state, step)
            mod.advance_sales(action, view, state, tape, step)
            action["market"] = action["market"][:10]
            return mod.liquidate(view) if step == 718 else action

    pol = ForcedPolicy()
    def agent(obs, config=None):
        return pol.act(obs)

    try:
        env = make("kaggriculture", configuration={"seed": seed}, debug=True)
        result = env.run([agent, AGENT_PATH])
        final = result[-1]
        if final[0]["status"] == "DONE":
            return final[0]["reward"]
    except:
        pass
    return None


def main():
    num_seeds = 5
    for i, arg in enumerate(sys.argv):
        if arg == "--seeds" and i + 1 < len(sys.argv):
            num_seeds = int(sys.argv[i + 1])

    all_pairs = list(iterproduct(SHOPS, repeat=2))
    seeds = [42, 123, 456, 789, 1337, 2468, 3579, 4680, 5791, 6802][:num_seeds]

    total = len(all_pairs) * len(SAFE_TAPES) * num_seeds
    print(f"64 pairs × {len(SAFE_TAPES)} tapes × {num_seeds} seeds = {total} games")
    print(f"Estimated: {total * 2.5 / 60:.0f} min")

    results = {}  # (shop1, shop2, tape_idx) -> [money]
    start = time.time()
    done = 0

    for pair_idx, (s1, s2) in enumerate(all_pairs):
        for tape_idx in SAFE_TAPES:
            for seed in seeds:
                money = run_game(s1, s2, tape_idx, seed)
                key = (s1, s2, tape_idx)
                results.setdefault(key, [])
                if money is not None:
                    results[key].append(money)
                done += 1

        if (pair_idx + 1) % 4 == 0:
            elapsed = time.time() - start
            rate = done / elapsed
            remaining = (total - done) / rate / 60
            print(f"  [{pair_idx+1}/64 pairs] {done}/{total} games, {rate:.1f}/s, ~{remaining:.0f}min left")

    elapsed = time.time() - start
    print(f"\nDone: {done} games in {elapsed/60:.1f} min")

    # Find best tape per pair
    shop_plans = {}
    improvements = []

    for s1, s2 in all_pairs:
        tape_means = {}
        for t in SAFE_TAPES:
            vals = results.get((s1, s2, t), [])
            if vals:
                tape_means[t] = sum(vals) / len(vals)

        if not tape_means:
            continue

        best_tape = max(tape_means, key=tape_means.get)
        best_mean = tape_means[best_tape]
        plan0_mean = tape_means.get(0, 0)
        imp = best_mean - plan0_mean

        shop_plans[(s1, s2)] = best_tape
        improvements.append((s1, s2, best_tape, best_mean, plan0_mean, imp))

    # Print new SHOP_PLANS
    print(f"\n{'='*70}")
    print("SHOP_PLANS = {")
    for (s1, s2), tape in sorted(shop_plans.items()):
        imp = next((x[5] for x in improvements if x[0] == s1 and x[1] == s2), 0)
        comment = f"  # +{imp:.0f}" if imp > 500 else ""
        print(f'    ("{s1}", "{s2}"): {tape},{comment}')
    print("}")

    # Top improvements
    improvements.sort(key=lambda x: -x[5])
    print(f"\nTop 20 improvements over plan 0:")
    for s1, s2, tape, best, p0, imp in improvements[:20]:
        print(f"  {s1+'+'+s2:45s} tape={tape:2d}  best={best:>9,.0f}  plan0={p0:>9,.0f}  Δ={imp:>+8,.0f}")

    # Save
    save_data = {f"{s1},{s2}": {"best_tape": t, "mean": tape_means.get(t, 0)}
                 for (s1, s2), t in shop_plans.items()
                 for tape_means in [
                     {tt: sum(results.get((s1, s2, tt), [0])) / max(1, len(results.get((s1, s2, tt), [1])))
                      for tt in SAFE_TAPES}]}
    with open("/Users/nathanjacob/Documents/kaggle/kaggriculture/tape_search_v2.json", "w") as f:
        json.dump(save_data, f, indent=2)
    print(f"\nSaved to tape_search_v2.json")


if __name__ == "__main__":
    main()
