# Fable Briefing Round 3 — V2 Threat Analysis
## Sep 11, 2026

---

## Where We Are

### Leaderboard (Sep 11)
- Hybrid V1: **2294 Elo** (our best, climbing then settled)
- Shop Router: **2222 Elo** (dropped from 2388, our other slot)
- V2 agent: **not submitted yet** — built from Shop Router + room_guard + tape 1→9 fix

### V2 Local Gauntlet (220 games, 20 per opponent)
We ran V2 against 11 agents extracted from the top public notebooks. Results:

| Opponent | Source | W-L-D | WR | Margin |
|----------|--------|-------|----|--------|
| **prvsiyan_soil** | Frontier Soil (102 votes, Sep 10) | **0-20-0** | **0%** | **-4,970** |
| **prvsiyan_moon** | Frontier Moon (93 votes, Sep 10) | **1-19-0** | **5%** | **-3,219** |
| **hybrid_v1** | Our own submitted agent | **8-12-0** | **40%** | +314 |
| pilkwang | Structured Economic Policy (Sep 11) | 13-7-0 | 65% | +3,534 |
| shop_router | Our own Shop Router base | 15-3-2 | 75% | +98 |
| tetsu_shape | Shape the Shop (Sep 6) | 19-1-0 | 95% | +8,238 |
| boatlee_v16 | V16-RC5 Premium Market (312 votes) | 20-0-0 | 100% | +25,983 |
| kaito_v48 | v48 Fast Routes (132 votes) | 20-0-0 | 100% | +15,919 |
| tetsu_adaptive | Adaptive Farming (142 votes) | 20-0-0 | 100% | +29,000 |
| tschinkel_router | Public State Router 74.5% (99 votes) | 20-0-0 | 100% | +8,892 |
| yhay81_fieldbook | Six-Day Fieldbook C++ (132 votes) | 20-0-0 | 100% | +15,694 |

**Overall: 156-62-2 (71% WR). Crushes 8/11 opponents. Gets destroyed by 3.**

---

## What V2 Is

V2 = yhay81's Shop Router 0909 (13 tapes, 15 shop-pair routing at step 144) + two changes:
1. **room_guard**: at day-close (step % 24 == 23), if shed + carried inventory > 99, sell cheapest items first to prevent overflow
2. **tape 1→9 fix**: (YARN_STORE, FARMERS_MARKET) remapped from tape 1 (divergent prefix at step 70) to tape 9

V2 also inherits: weed repair, advance_sales (move next-step sells forward 1 turn for premium items), final-step liquidation (step 718).

---

## What Hybrid V1 Is (our LB agent at 2294)

Hybrid V1 = same Shop Router base + a **terminal physical planner** (ShopClosure) for steps 712-718:
- At step 712, freezes the router state
- Runs 128 MCTS simulations × 8 proposals per actor
- Uses an exact replica of the kaggle engine (unit_model.py, SHA256-verified) to simulate the final 7 turns
- Accepts a candidate only if it satisfies strict dominance: no overflow, deposits ≥ baseline at every intermediate step, sells ≥ baseline at every step, positive net delta
- If observation diverges, aborts and falls back to tape
- Also has room_guard but with **expensive-first** (opposite of V2's cheapest-first)
- Still uses tape 1 for (YARN_STORE, FARMERS_MARKET) — does NOT have the tape 1→9 fix

**Hybrid V1 beats V2 12-8 in head-to-head.** The terminal planner is the edge — it captures late-game harvests and fertilizer that the fixed tape misses. V2's reactive layers (wool_hold, drop_guard, early_liquidate) appear to be net-negative regressions.

---

## Threat Deep-Dive: prvsiyan_soil (0-20 vs V2)

Built as a layered decorator stack on the same yhay81 Shop Router base. Each layer wraps the previous and fires conditionally:

### V216 — Day-1 Wheat Sale (step 23)
- If tape plans 1-5 HIRE orders at step 24 but player is cash-short
- Sells exactly 1 WHEAT to bridge the gap
- Prevents missed day-1 hires on bad seeds

### V217 — Idle-Farmer Starvation Rescue (hours 16-21)
- When farmer would PASS and an animal has consecutive_unfed ≥ 1
- Computes Manhattan round-trip: go to animal → FEED → return
- Max 2 rescues per game
- Prevents animal death (lost yield for rest of game)

### V218 — Terminal Fertilizer Collection (steps 712-718)
- At step 712, if plan 2 active and FERTILIZER price > 1
- BFS over up to 3 idle workers to collect fertilizer from animal tiles
- Routes must complete within 7 steps including DROP at shed
- Fires in ~42% of games
- Converts otherwise-abandoned fertilizer into cash

### V219 — Late Tomato Investment (days 18-29, SE quadrant)
- At step 432, checks: 10×10 board, SE locked, money ≥ 12K, TOMATO price ≥ 70, ≥3 pizza/farmers_market shops
- Buys SE land, hires 1-3 dedicated tomato workers
- Workers plant, water, fertilize, harvest tomatoes for 12 days
- Fires rarely (2/48 episodes in their dataset) but adds $3-9K when it does

### V224 — Sell-Before-Buy Market Reordering (steps ≥ 144)
- Bubbles SELL orders to front of market list (without crossing same-item BUY)
- Ensures SELLs execute first (generates cash for subsequent BUYs)
- Prevents SELL orders from being truncated by 10-order limit
- 65+ turns reordered per game

### V226 — Wheat Top-Up (steps 24-695)
- If next step has a PICKUP WHEAT but projected shed wheat is short
- Buys exactly the missing amount (cap: 4 units/order, 8/day)
- Prevents "worker picks up 2 wheat instead of 3 → 1 animal starves" cascades

### V231 — Cow←Sheep Substitution (steps 216-227)
- Window: day 9, hours 0-11
- Conditions: exactly 1 BUY_ANIMAL SHEEP order, milk_shops ≥ 2, no YARN_STORE, MILK price ≥ WOOL price, already own 4+ cows and 2+ sheep
- Replaces SHEEP→COW in the buy order, tracks through pickup/place
- Cap: 4 total substitutions per game
- Redirects worker PICKUP/PLACE commands from SHEEP to COW

### V233 — Sheep SE Investment (day 12+, requires 2 YARN_STOREs)
- At step 288: checks 2+ YARN_STOREs unlocked, WOOL ≥ 220, WHEAT ≤ 45, SE locked
- Buys SE land + 6 sheep + 6 wheat + hires 2 workers
- Dedicated workers manage 6-sheep flock in SE (BUILD_PASTURE, PLACE, FEED, CARE, HARVEST)
- V234 rescue feed: buys missing wheat for sheep workers (same logic as V226)
- Converts dead SE space into wool+fertilizer revenue over 17 days

### Why it goes 20-0 against V2
1. **V2 never uses SE land** — soil gets $8-22K extra from tomatoes or sheep there
2. **V2 has no animal safety net** — no starvation rescue, no wheat top-up, animals can die on bad seeds
3. **V2 has no terminal optimization** — idle workers do nothing in final 7 turns (soil collects fertilizer)
4. **V2's sell ordering is worse** — SELLs can get truncated by the 10-order cap
5. **V2 can miss day-1 hires** — no cash bridge mechanism

---

## Threat Deep-Dive: prvsiyan_moon (1-19 vs V2)

**Moon = soil minus V233 (sheep SE module).** Same V216→V217→V218→V219→V224→V226→V231 stack.

The sheep module requires 2 YARN_STOREs + WOOL ≥ 220 + WHEAT ≤ 45, so it fires rarely. Moon going 1-19 vs soil's 0-20 suggests the sheep module adds ~1 game of margin.

The core damage comes from V216 + V217 + V218 + V224 + V226 — these are the high-frequency layers.

---

## Meta Context

### What the whole LB field is doing
- **Universal paradigm**: pre-recorded 720-turn tape replay + public-state routing. Nobody plans online.
- **Table stakes**: weed repair, dead-stock sell, clamp sells, YARN_STORE detection
- **Contested**: sale timing (advance 1 turn), livestock mix, branching depth/timing
- **Frontier**: livestock switching, SE quadrant monetization, terminal optimization

### Our current agent stack
- **Shop Router base**: 13 tapes, 15 YARN shop-pair mappings at step 144, endgame switch to tape 2 at step 648
- **Hybrid V1 (on LB)**: base + terminal planner (ShopClosure MCTS, steps 712-718)
- **V2 (not submitted)**: base + room_guard cheapest-first + tape 1→9 fix + reactive layers (wool_hold, drop_guard, early_liquidate, steep-first ordering) — **these reactive layers appear to regress performance**

### What we DON'T have (that prvsiyan does)
- No animal safety net (starvation rescue, wheat top-up)
- No SE quadrant monetization
- No livestock switching
- No sell-before-buy ordering
- No day-1 hire reserve
- No dedicated terminal resource collection (our terminal planner does general MCTS but not fertilizer-specific BFS)

### Timeline
- Hard stop for submissions: **Sep 16-18** (need ~170 games for Elo convergence)
- Current date: Sep 11
- Available days: ~5-7

---

## Specific Questions for Fable

1. **V3 base**: Should we build V3 on top of hybrid_v1 (which has the terminal planner but beats V2) or on top of V2 (which has room_guard and tape fix but loses to hybrid_v1)?

2. **Layer priority**: Of the prvsiyan layers (V216, V217, V218, V219, V224, V226, V231, V233), which give the most Elo per implementation hour? Are any of them traps (look good in local sim but hurt on LB)?

3. **Terminal planner interaction**: Our hybrid_v1 already has a general MCTS terminal planner for steps 712-718. prvsiyan's V218 does a fertilizer-specific BFS for the same window. Can they coexist? Should we replace our MCTS with their BFS, combine them, or keep ours?

4. **V2 reactive layers**: V2 added wool_hold (don't sell wool below $100), drop_guard (DROP→PLACE near capacity), early_liquidate (sell at step 717), and steep-first sell ordering. These appear net-negative vs hybrid_v1. Should we discard all of them? Any worth salvaging?

5. **Sell ordering**: prvsiyan's V224 bubbles SELLs before BUYs. When we tested sell-before-buy on our tapes we measured -17 games. prvsiyan's tapes were recorded differently. Is this a tape-specific interaction, or is sell-first genuinely better and our measurement was wrong?

6. **SE quadrant**: V219 (tomatoes) and V233 (sheep) both monetize the idle SE quadrant. V219 fired 2/48 games (both losses for us), V233 requires 2 YARN_STOREs. Are these worth the implementation complexity given our 5-day window?

7. **Ship strategy**: We have 2 submission slots. Currently: hybrid_v1 (2294) and shop_router (2222). What should go in each slot, and when?

8. **Clone defense**: Many LB agents are forks of the same public notebooks. Does the prvsiyan-style layering specifically counter clone-heavy fields, or is it general-purpose improvement?
