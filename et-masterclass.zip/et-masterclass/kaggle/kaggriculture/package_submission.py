"""Package a Kaggriculture agent directory into a submission tar.gz.

Usage:
    python package_submission.py <agent_dir> [--output submission.tar.gz]

Bundles ALL files in the agent directory into the tarball. Verifies that
main.py exists and any referenced files (actions.json, settings.json, etc.)
are included.
"""
import sys
import os
import tarfile
import json
from pathlib import Path


def package_agent(agent_dir, output_path=None):
    agent_dir = Path(agent_dir).resolve()
    if not agent_dir.is_dir():
        print(f"ERROR: {agent_dir} is not a directory")
        sys.exit(1)

    main_py = agent_dir / "main.py"
    if not main_py.exists():
        print(f"ERROR: {agent_dir}/main.py not found")
        sys.exit(1)

    if output_path is None:
        output_path = Path.cwd() / "submission.tar.gz"
    else:
        output_path = Path(output_path).resolve()

    # Collect all files (skip __pycache__, .pyc, vet results)
    files = []
    for f in sorted(agent_dir.rglob("*")):
        if f.is_file() and "__pycache__" not in str(f) and not f.suffix == ".pyc" \
                and "_vet_results" not in f.name:
            files.append(f)

    # Check for common required files
    main_text = main_py.read_text()
    if "actions.json" in main_text:
        actions = agent_dir / "actions.json"
        if not actions.exists():
            print(f"WARNING: main.py references actions.json but it doesn't exist!")
        elif actions not in files:
            files.append(actions)

    if "settings.json" in main_text or "settings" in main_text:
        settings = agent_dir / "settings.json"
        if settings.exists() and settings not in files:
            files.append(settings)

    # Create tar.gz
    with tarfile.open(output_path, "w:gz") as tar:
        for f in files:
            arcname = f.relative_to(agent_dir)
            tar.add(f, arcname=arcname)
            size_kb = f.stat().st_size / 1024
            print(f"  Added: {arcname} ({size_kb:.1f} KB)")

    total_size = output_path.stat().st_size / (1024 * 1024)
    print(f"\nPackaged {len(files)} files into {output_path}")
    print(f"Total size: {total_size:.2f} MB")

    # Verify
    print(f"\nVerification:")
    with tarfile.open(output_path, "r:gz") as tar:
        members = tar.getnames()
        print(f"  Files in archive: {len(members)}")
        for m in members:
            print(f"    - {m}")
        if "main.py" not in members:
            print("  ERROR: main.py not in archive!")
        else:
            print("  OK: main.py present")
        if "actions.json" in main_text and "actions.json" not in members:
            print("  ERROR: actions.json MISSING but required by main.py!")
        elif "actions.json" in members:
            print("  OK: actions.json present")

    return output_path


def main():
    if len(sys.argv) < 2:
        print("Usage: python package_submission.py <agent_dir> [--output submission.tar.gz]")
        sys.exit(1)

    agent_dir = sys.argv[1]
    output = None
    for i, arg in enumerate(sys.argv[2:], 2):
        if arg == "--output" and i + 1 < len(sys.argv):
            output = sys.argv[i + 1]

    package_agent(agent_dir, output)


if __name__ == "__main__":
    main()
