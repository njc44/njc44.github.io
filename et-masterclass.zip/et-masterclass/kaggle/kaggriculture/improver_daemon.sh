#!/bin/bash
# ──────────────────────────────────────────────────────────────
# Kaggriculture Self-Improving Agent Daemon (Option C)
#
# Calls Claude Code CLI every 3 hours with a self-contained
# prompt. Claude reads state, picks an improvement, modifies
# the candidate agent, tests it, keeps or reverts.
#
# Also handles auto-submission every 12 hours.
#
# Usage:
#   ./improver_daemon.sh                    # foreground, continuous
#   nohup ./improver_daemon.sh &            # background, survives logout
#   ./improver_daemon.sh --once             # single improvement run
#   ./improver_daemon.sh --submit           # single submission run
#   ./improver_daemon.sh --status           # show current state
#
# Logs: kaggriculture/daemon_logs/improver_*.log
# State: kaggriculture/autoloop/state.json
# ──────────────────────────────────────────────────────────────

set -uo pipefail

WORK_DIR="/Users/nathanjacob/Documents/kaggle/kaggriculture"
LOG_DIR="$WORK_DIR/daemon_logs"
AUTOLOOP_DIR="$WORK_DIR/autoloop"
STATE_FILE="$AUTOLOOP_DIR/state.json"
IMPROVEMENT_LOG="$AUTOLOOP_DIR/improvement_log.md"
LEADERBOARD="$AUTOLOOP_DIR/leaderboard.md"

PYTHON="/Users/nathanjacob/opt/miniconda3/bin/python"
CLAUDE="/opt/homebrew/bin/claude"

BASELINE_DIR="/tmp/kaggriculture_latest/v3_agent"
CANDIDATE_DIR="/tmp/kaggriculture_latest/v3_agent_candidate"
BACKUP_DIR="$AUTOLOOP_DIR/backups"

IMPROVE_INTERVAL=10800  # 3 hours in seconds
SUBMIT_INTERVAL=43200   # 12 hours in seconds

mkdir -p "$LOG_DIR" "$BACKUP_DIR"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_DIR/improver.log"
}

# ── Status ──────────────────────────────────────────────────
show_status() {
    echo ""
    echo "═══════════════════════════════════════════════════════"
    echo "  KAGGRICULTURE AUTOLOOP STATUS"
    echo "═══════════════════════════════════════════════════════"
    if [ -f "$STATE_FILE" ]; then
        $PYTHON -c "
import json
with open('$STATE_FILE') as f:
    s = json.load(f)
print(f'  Iteration:          {s[\"iteration\"]}')
print(f'  Best Agent:         {s[\"best_agent_name\"]}')
print(f'  Best Score:         \${s[\"best_agent_score\"]:,.0f}')
print(f'  Win Rate:           {s[\"best_agent_win_rate\"]*100:.0f}%')
print(f'  Last Improvement:   {s[\"last_improvement_description\"] or \"none\"}')
print(f'  Last Gauntlet:      {s[\"last_gauntlet\"] or \"never\"}')
print(f'  Last Submission:    {s[\"last_submission_time\"] or \"never\"}')
print(f'  Submitted Score:    \${s[\"last_submitted_score\"]:,.0f}')
print(f'  Auto Submit:        {s[\"auto_submit_enabled\"]}')
print(f'  Submissions Today:  {s[\"submissions_today\"]}')
print(f'  Tried:              {len(s[\"improvements_tried\"])}')
print(f'  Pending:            {len(s[\"pending_improvements\"])}')
if s['pending_improvements']:
    print(f'  Next to try:        {s[\"pending_improvements\"][0]}')
print(f'  Tried list:         {s[\"improvements_tried\"]}')
"
    else
        echo "  No state file found at $STATE_FILE"
    fi
    echo "═══════════════════════════════════════════════════════"
    echo ""
}

# ── Build the Improver prompt ──────────────────────────────
build_improver_prompt() {
    cat <<'PROMPT_END'
You are the Kaggriculture Improver Agent. Your job is to make ONE improvement to the candidate agent, test it, and keep it only if it helps.

## File Paths
- Python: /Users/nathanjacob/opt/miniconda3/bin/python
- State: /Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop/state.json
- Improvement Log: /Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop/improvement_log.md
- Baseline (READ ONLY, never modify): /tmp/kaggriculture_latest/v3_agent/
- Candidate (modify this one): /tmp/kaggriculture_latest/v3_agent_candidate/
- Reactive layers reference: /Users/nathanjacob/Documents/kaggle/kaggriculture/reactive_layers_v3.py
- Tournament framework: /Users/nathanjacob/Documents/kaggle/kaggriculture/tournament_meta.py

## Key Opponents (for testing)
- prvsiyan_soil: /tmp/kaggriculture_opponents/prvsiyan_soil/main.py
- prvsiyan_moon: /tmp/kaggriculture_opponents/prvsiyan_moon/main.py
- shop_router: /tmp/kaggriculture_latest/shop_router_0909_ext/main.py

## Critical Rules
- NEVER modify files in /tmp/kaggriculture_latest/v3_agent/ (baseline)
- farm['money'] EXISTS, private['money'] does NOT
- Tiles (4,4),(5,4),(4,5),(5,5) ARE usable, not fixed shed
- Keep market orders <= 10 always
- New layers must be no-op for steps >= 712 (terminal planner owns those)
- actions.json is shared, never modify it
- The router_parent.py is the main file to modify in the candidate

## Procedure

### Step 1: Read state
Read /Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop/state.json
Pick the FIRST item from pending_improvements. If pending_improvements is empty, think of a novel improvement based on the code.

### Step 2: Backup candidate
Run: cp -r /tmp/kaggriculture_latest/v3_agent_candidate /tmp/kaggriculture_latest/v3_agent_candidate_backup_$(date +%s)

### Step 3: Read reference code
Read /tmp/kaggriculture_latest/v3_agent_candidate/router_parent.py to understand current state.
Read /Users/nathanjacob/Documents/kaggle/kaggriculture/reactive_layers_v3.py for the layer implementations.

### Step 4: Apply ONE improvement
Modify /tmp/kaggriculture_latest/v3_agent_candidate/router_parent.py to add the improvement.
Keep changes minimal and targeted. The improvement should be a reactive layer that:
- Checks a condition (e.g. shed > 99, step == 717, etc.)
- Modifies the action dict (market_orders, worker actions)
- Is a no-op when the condition isn't met
- Does NOT run at steps >= 712 (terminal planner)

### Step 5: Smoke test
Run a single game to make sure the candidate doesn't crash:
```
/Users/nathanjacob/opt/miniconda3/bin/python -c "
from kaggle_environments import make
env = make('kaggriculture')
r = env.run(['/tmp/kaggriculture_latest/v3_agent_candidate/main.py', '/tmp/kaggriculture_opponents/prvsiyan_soil/main.py'])
f = r[-1]
print(f'Status: {f[0][\"status\"]}, {f[1][\"status\"]}')
print(f'Score: {f[0][\"reward\"]}, {f[1][\"reward\"]}')
"
```
If the candidate errors, REVERT immediately by copying the backup back and update state.json marking this improvement as failed.

### Step 6: Run 6-game test
Run 6 games (3 per seat) of candidate vs baseline, both against prvsiyan_soil:
```
/Users/nathanjacob/opt/miniconda3/bin/python -c "
from kaggle_environments import make
import statistics

candidate = '/tmp/kaggriculture_latest/v3_agent_candidate/main.py'
baseline = '/tmp/kaggriculture_latest/v3_agent/main.py'
opponent = '/tmp/kaggriculture_opponents/prvsiyan_soil/main.py'

def test_agent(agent_path, n=6):
    scores = []
    for i in range(n):
        env = make('kaggriculture')
        if i < n//2:
            r = env.run([agent_path, opponent])
            score = r[-1][0]['reward']
        else:
            r = env.run([opponent, agent_path])
            score = r[-1][1]['reward']
        scores.append(score)
        print(f'  Game {i+1}: \${score:,.0f}')
    return scores

print('=== CANDIDATE ===')
cand_scores = test_agent(candidate)
print(f'Candidate avg: \${statistics.mean(cand_scores):,.0f}')

print()
print('=== BASELINE ===')
base_scores = test_agent(baseline)
print(f'Baseline avg: \${statistics.mean(base_scores):,.0f}')

diff = statistics.mean(cand_scores) - statistics.mean(base_scores)
print(f'\\nDifference: \${diff:+,.0f}')
print(f'VERDICT: {\"KEEP\" if diff > 500 else \"REVERT\" if diff < -1000 else \"NEUTRAL (keep)\"}')
"
```

### Step 7: Decide — Keep or Revert
- If candidate avg > baseline avg + $500: KEEP the improvement
- If candidate avg < baseline avg - $1000: REVERT (copy backup back)
- Otherwise: KEEP (neutral is fine, accumulated small gains matter)

To revert: cp -r /tmp/kaggriculture_latest/v3_agent_candidate_backup_*/  contents back to candidate dir

### Step 8: Update state
Update /Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop/state.json:
- Increment iteration
- Move the improvement from pending_improvements to improvements_tried
- Update best_agent_score and best_agent_win_rate if kept
- Set last_improvement and last_improvement_description
- Set last_gauntlet to current ISO timestamp

### Step 9: Log results
Append to /Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop/improvement_log.md:
```
## Iteration N — [improvement_name] — [KEPT/REVERTED]
- Date: YYYY-MM-DD HH:MM
- Candidate avg: $X vs Baseline avg: $Y
- Difference: +/-$Z
- Description: [what was changed]
- Verdict: [why kept or reverted]
---
```

Execute this procedure now. Start with Step 1.
PROMPT_END
}

# ── Build the Submitter prompt ────────────────────────────
build_submitter_prompt() {
    cat <<'PROMPT_END'
You are the Kaggriculture Submission Agent. Your job is to evaluate the current best agent and submit it to Kaggle if it passes all gates.

## File Paths
- Python: /Users/nathanjacob/opt/miniconda3/bin/python
- State: /Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop/state.json
- Package script: /Users/nathanjacob/Documents/kaggle/kaggriculture/package_submission.py
- Backups: /Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop/backups/

## Procedure

### Step 1: Read state
Read /Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop/state.json

### Step 2: Check gates
All of these must pass:
1. auto_submit_enabled is true
2. best_agent_score > 85000 (floor)
3. best_agent_score > last_submitted_score (improvement over last submission)
4. submissions_today < 2 (max 2 per day)
5. submissions_today_date matches today OR submissions_today resets to 0

If ANY gate fails, print which gate failed and exit WITHOUT submitting.

### Step 3: Smoke test
Run one game to verify the agent works:
```
/Users/nathanjacob/opt/miniconda3/bin/python -c "
from kaggle_environments import make
env = make('kaggriculture')
agent = '<best_agent_path>/main.py'
r = env.run([agent, '/tmp/kaggriculture_opponents/prvsiyan_soil/main.py'])
f = r[-1]
print(f'Status: {f[0][\"status\"]}')
print(f'Score: {f[0][\"reward\"]}')
assert f[0]['status'] == 'DONE', 'Agent errored!'
"
```

### Step 4: Package
```
/Users/nathanjacob/opt/miniconda3/bin/python /Users/nathanjacob/Documents/kaggle/kaggriculture/package_submission.py <best_agent_path>
```

### Step 5: Submit
```
kaggle competitions submit -c kaggriculture -f submission.tar.gz -m "autoloop iter N, score $X"
```

### Step 6: Backup
```
cp -r <best_agent_path> /Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop/backups/submitted_$(date +%Y%m%d_%H%M)
```

### Step 7: Update state
- Set last_submission_time to current ISO timestamp
- Set last_submitted_score to best_agent_score
- Set last_submitted_agent to best_agent_name
- Increment submissions_today (reset if date changed)
- Set submissions_today_date to today's date

Execute this procedure now.
PROMPT_END
}

# ── Run Improver ──────────────────────────────────────────
run_improver() {
    local run_log="$LOG_DIR/improver_$(date +%Y%m%d_%H%M%S).log"
    log "═══ IMPROVER RUN START ═══"
    log "Log: $run_log"

    local prompt
    prompt=$(build_improver_prompt)

    # Call Claude CLI with the prompt
    # NOTE: For fully unattended operation, you may need to add permission flags.
    # Run: claude settings to configure, or add --permission-mode to this command.
    echo "$prompt" | $CLAUDE -p \
        --allowedTools "Bash,Read,Write,Edit" \
        --model sonnet \
        --verbose 2>&1 | tee "$run_log"

    local exit_code=$?
    log "Claude exit code: $exit_code"
    log "═══ IMPROVER RUN END ═══"
    return $exit_code
}

# ── Run Submitter ─────────────────────────────────────────
run_submitter() {
    local run_log="$LOG_DIR/submitter_$(date +%Y%m%d_%H%M%S).log"
    log "═══ SUBMITTER RUN START ═══"
    log "Log: $run_log"

    local prompt
    prompt=$(build_submitter_prompt)

    echo "$prompt" | $CLAUDE -p \
        --allowedTools "Bash,Read,Write,Edit" \
        --model sonnet \
        --verbose 2>&1 | tee "$run_log"

    local exit_code=$?
    log "Claude exit code: $exit_code"
    log "═══ SUBMITTER RUN END ═══"
    return $exit_code
}

# ── Main Loop ──────────────────────────────────────────────
main() {
    local mode="${1:---loop}"

    case "$mode" in
        --once)
            log "Single improver run requested"
            run_improver
            ;;
        --submit)
            log "Single submission run requested"
            run_submitter
            ;;
        --status)
            show_status
            ;;
        --loop|*)
            log "════════════════════════════════════════════════════════════"
            log "  KAGGRICULTURE AUTOLOOP DAEMON (Option C)"
            log "  Improve every: ${IMPROVE_INTERVAL}s (3hrs)"
            log "  Submit every:  ${SUBMIT_INTERVAL}s (12hrs)"
            log "  PID: $$"
            log "════════════════════════════════════════════════════════════"

            local last_improve=0
            local last_submit=0

            while true; do
                local now
                now=$(date +%s)

                # Check if it's time to improve
                if (( now - last_improve >= IMPROVE_INTERVAL )); then
                    run_improver || log "Improver failed with exit code $?"
                    last_improve=$(date +%s)
                fi

                # Check if it's time to submit
                if (( now - last_submit >= SUBMIT_INTERVAL )); then
                    run_submitter || log "Submitter failed with exit code $?"
                    last_submit=$(date +%s)
                fi

                # Sleep 5 minutes between checks
                log "Sleeping 5 min until next check..."
                sleep 300
            done
            ;;
    esac
}

main "$@"
