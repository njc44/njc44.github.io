#!/usr/bin/env python3
"""Pattern Miner: Extract routing patterns from top Kaggle agents.

Runs a game, records the full 720-step trace, then extracts:
1. Worker circuits: which tiles each worker visits daily
2. Tile utilization: how fast tiles go from empty → productive
3. Market patterns: sell/buy timing and ordering
4. Production efficiency: $ earned per worker per day

Outputs a JSON report that can be fed into the planning agent as training data.

Usage:
    python pattern_miner.py [--agents all] [--games 3] [--output patterns/]
"""

import json
import os
import sys
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path

# Add kaggle-environments to path
PYTHON = "/Users/nathanjacob/opt/miniconda3/bin/python"
WORK_DIR = "/Users/nathanjacob/Documents/kaggle/kaggriculture"

TPD = 24
TOTAL_STEPS = 720
ANIMAL_SET = {"GOOSE", "COW", "SHEEP"}

# Agent registry — top performers to mine patterns from
AGENTS = {
    "prvsiyan_soil":    "/tmp/kaggriculture_opponents/prvsiyan_soil/main.py",
    "prvsiyan_moon":    "/tmp/kaggriculture_opponents/prvsiyan_moon/main.py",
    "shop_router":      "/tmp/kaggriculture_latest/shop_router_0909_ext/main.py",
    "hybrid_v1":        "/tmp/kaggriculture_latest/hybrid_v1/main.py",
    "tschinkel_router": "/tmp/kaggriculture_opponents/thomastschinkel_router/main.py",
    "tetsu_shape":      "/tmp/kaggriculture_opponents/tetsutani_shape/main.py",
    "kaito_v48":        "/tmp/kaggriculture_opponents/kaitofukami_v48/main.py",
}

# Our planning agent
OUR_AGENT = "/tmp/kaggriculture_latest/v4_agent/planning_agent.py"


def run_traced_game(agent_a, agent_b):
    """Run a game and return the full step-by-step trace for both players."""
    from kaggle_environments import make
    env = make("kaggriculture", debug=True)
    result = env.run([agent_a, agent_b])
    return result


def extract_worker_circuits(result, player=0):
    """Extract per-worker tile visit sequences for each day."""
    circuits = {}  # day → worker_idx → [(x,y,action), ...]

    for step in range(len(result)):
        day = step // TPD
        hour = step % TPD
        obs = result[step][player]["observation"]
        action = result[step][player].get("action", {})
        if not action:
            continue

        farm = obs["farms"][player]
        positions = [tuple(farm["farmer"])] + [tuple(h) for h in farm.get("hands", [])]

        if day not in circuits:
            circuits[day] = defaultdict(list)

        farmer_a = action.get("farmer", ["PASS"])
        hands_a = action.get("hands", [])
        all_actions = [farmer_a] + hands_a

        for w in range(min(len(all_actions), len(positions))):
            pos = tuple(positions[w])
            act = all_actions[w][0] if all_actions[w] else "PASS"
            if act not in ("PASS", "NORTH", "SOUTH", "EAST", "WEST"):
                circuits[day][w].append({
                    "pos": pos,
                    "action": all_actions[w],
                    "hour": hour,
                })

    return circuits


def extract_tile_timeline(result, player=0):
    """Track tile state changes over time."""
    timeline = {}  # (x,y) → [(step, state_change), ...]

    prev_tiles = None
    for step in range(len(result)):
        obs = result[step][player]["observation"]
        farm = obs["farms"][player]
        tiles = farm["tiles"]

        if prev_tiles is not None:
            for y in range(len(tiles)):
                for x in range(len(tiles[y])):
                    cur = tiles[y][x]
                    prev = prev_tiles[y][x]
                    if cur != prev:
                        key = f"{x},{y}"
                        if key not in timeline:
                            timeline[key] = []
                        # Summarize state
                        def _state(t):
                            if t is None: return "EMPTY"
                            if t == "LOCKED": return "LOCKED"
                            if isinstance(t, dict):
                                k = t.get("kind", "?")
                                if "animal" in t: return f"ANIMAL:{t['animal']}"
                                if k == "PLANT": return f"PLANT:{t.get('crop','?')}"
                                return k
                            return str(t)
                        timeline[key].append({
                            "step": step,
                            "day": step // TPD,
                            "from": _state(prev),
                            "to": _state(cur),
                        })

        prev_tiles = [[c for c in row] for row in tiles]

    return timeline


def extract_market_patterns(result, player=0):
    """Extract market order patterns per day."""
    patterns = {}  # day → {sells: [...], buys: [...], hires: int}

    for step in range(len(result)):
        day = step // TPD
        action = result[step][player].get("action", {})
        if not action:
            continue

        if day not in patterns:
            patterns[day] = {"sells": [], "buys": [], "hires": 0, "seeds": 0, "land": 0}

        for order in action.get("market", []):
            if not order:
                continue
            if order[0] == "SELL" and len(order) >= 3:
                patterns[day]["sells"].append({
                    "product": order[1],
                    "qty": int(order[2]),
                    "step": step,
                })
            elif order[0] == "HIRE":
                patterns[day]["hires"] += 1
            elif order[0] in ("BUY_ANIMAL", "BUY_PRODUCT"):
                patterns[day]["buys"].append({
                    "type": order[0],
                    "item": order[1] if len(order) > 1 else "?",
                    "qty": int(order[2]) if len(order) > 2 else 1,
                    "step": step,
                })
            elif order[0] == "BUY_SEED":
                patterns[day]["seeds"] += int(order[2]) if len(order) > 2 else 1
            elif order[0] == "BUY_LAND":
                patterns[day]["land"] += 1

    return patterns


def extract_production_stats(result, player=0):
    """Extract production statistics per day."""
    stats = {}
    for step in range(0, len(result), TPD):
        day = step // TPD
        obs = result[step][player]["observation"]
        farm = obs["farms"][player]
        priv = obs["private"]

        n_animals, n_plants, n_empty, n_locked = 0, 0, 0, 0
        crops = defaultdict(int)
        animals = defaultdict(int)
        for y, row in enumerate(farm["tiles"]):
            for x, tile in enumerate(row):
                if tile is None:
                    n_empty += 1
                elif tile == "LOCKED":
                    n_locked += 1
                elif isinstance(tile, dict):
                    if "animal" in tile:
                        n_animals += 1
                        animals[tile["animal"]] += 1
                    elif tile.get("kind") == "PLANT":
                        n_plants += 1
                        crops[tile.get("crop", "?")] += 1

        stats[day] = {
            "money": farm.get("money", 0),
            "hands": len(farm.get("hands", [])),
            "hires_today": farm.get("hires_today", 0),
            "n_animals": n_animals,
            "n_plants": n_plants,
            "n_empty": n_empty,
            "n_locked": n_locked,
            "animals": dict(animals),
            "crops": dict(crops),
            "shed": {k: int(v) for k, v in priv["shed"].items() if int(v) > 0},
            "quadrants": farm.get("unlocked_quadrants", ["NW"]),
        }

    return stats


def extract_worker_patterns(circuits):
    """Analyze circuits to extract reusable patterns."""
    patterns = defaultdict(lambda: defaultdict(int))

    for day, workers in circuits.items():
        for w, actions in workers.items():
            if not actions:
                continue
            # Classify worker by dominant action
            action_counts = defaultdict(int)
            for a in actions:
                act = a["action"][0] if a["action"] else "PASS"
                action_counts[act] += 1

            dominant = max(action_counts, key=action_counts.get)
            if dominant in ("FEED", "CARE"):
                worker_type = "ANIMAL_WORKER"
            elif dominant in ("WATER", "PLANT"):
                worker_type = "CROP_WORKER"
            elif dominant in ("HARVEST",):
                worker_type = "HARVESTER"
            elif dominant in ("BUILD_PASTURE", "BUILD_COOP"):
                worker_type = "BUILDER"
            elif dominant in ("DROP", "PICKUP"):
                worker_type = "PORTER"
            else:
                worker_type = "OTHER"

            patterns[day][worker_type] += 1

    return {d: dict(v) for d, v in patterns.items()}


def mine_agent(agent_name, agent_path, n_games=2):
    """Mine patterns from one agent across multiple games."""
    from kaggle_environments import make

    print(f"\n{'='*60}")
    print(f"  Mining: {agent_name}")
    print(f"  Path: {agent_path}")
    print(f"  Games: {n_games}")
    print(f"{'='*60}")

    all_stats = []
    all_patterns = []
    all_worker_types = []
    all_market = []
    scores = []

    dummy = "/tmp/kaggriculture_opponents/thomastschinkel_router/main.py"

    for g in range(n_games):
        print(f"  Game {g+1}/{n_games}...", end=" ", flush=True)
        t0 = time.time()

        try:
            # Alternate seats
            if g % 2 == 0:
                result = run_traced_game(agent_path, dummy)
                p = 0
            else:
                result = run_traced_game(dummy, agent_path)
                p = 1

            score = result[-1][p]["reward"]
            scores.append(score)

            # Extract patterns
            circuits = extract_worker_circuits(result, p)
            tile_tl = extract_tile_timeline(result, p)
            market = extract_market_patterns(result, p)
            prod = extract_production_stats(result, p)
            worker_types = extract_worker_patterns(circuits)

            all_stats.append(prod)
            all_market.append(market)
            all_worker_types.append(worker_types)

            elapsed = time.time() - t0
            print(f"${score:,.0f} [{elapsed:.1f}s]")

        except Exception as e:
            print(f"ERROR: {e}")
            continue

    if not scores:
        return None

    avg_score = sum(scores) / len(scores)
    print(f"\n  Avg score: ${avg_score:,.0f} ({len(scores)} games)")

    # Aggregate patterns
    report = {
        "agent": agent_name,
        "n_games": len(scores),
        "avg_score": avg_score,
        "scores": scores,
        "timestamp": datetime.now().isoformat(),
    }

    # Average daily stats
    avg_daily = {}
    for day in range(30):
        day_data = [s.get(day, {}) for s in all_stats if day in s]
        if not day_data:
            continue
        avg_daily[day] = {
            "money": sum(d.get("money", 0) for d in day_data) / len(day_data),
            "hands": sum(d.get("hands", 0) for d in day_data) / len(day_data),
            "n_animals": sum(d.get("n_animals", 0) for d in day_data) / len(day_data),
            "n_plants": sum(d.get("n_plants", 0) for d in day_data) / len(day_data),
            "n_empty": sum(d.get("n_empty", 0) for d in day_data) / len(day_data),
            "n_locked": sum(d.get("n_locked", 0) for d in day_data) / len(day_data),
        }
    report["daily_stats"] = avg_daily

    # Worker type distribution
    avg_workers = {}
    for day in range(30):
        day_types = [wt.get(day, {}) for wt in all_worker_types if day in wt]
        if not day_types:
            continue
        merged = defaultdict(float)
        for dt in day_types:
            for wtype, count in dt.items():
                merged[wtype] += count / len(day_types)
        avg_workers[day] = dict(merged)
    report["worker_types"] = avg_workers

    # Market summary
    avg_market = {}
    for day in range(30):
        day_markets = [m.get(day, {}) for m in all_market if day in m]
        if not day_markets:
            continue
        avg_market[day] = {
            "hires": sum(d.get("hires", 0) for d in day_markets) / len(day_markets),
            "seeds": sum(d.get("seeds", 0) for d in day_markets) / len(day_markets),
            "land": sum(d.get("land", 0) for d in day_markets) / len(day_markets),
            "n_sells": sum(len(d.get("sells", [])) for d in day_markets) / len(day_markets),
            "n_buys": sum(len(d.get("buys", [])) for d in day_markets) / len(day_markets),
        }
    report["market_summary"] = avg_market

    return report


def compare_reports(ours, theirs):
    """Generate a comparison/diff report."""
    diff = {
        "score_gap": theirs["avg_score"] - ours["avg_score"],
        "daily_gaps": {},
    }

    for day in range(30):
        our_d = ours.get("daily_stats", {}).get(day, {})
        their_d = theirs.get("daily_stats", {}).get(day, {})
        if not our_d or not their_d:
            continue

        gaps = {}
        for key in ("money", "n_animals", "n_plants", "n_empty", "hands"):
            our_v = our_d.get(key, 0)
            their_v = their_d.get(key, 0)
            if abs(their_v - our_v) > 0.5:
                gaps[key] = {"ours": round(our_v, 1), "theirs": round(their_v, 1),
                            "gap": round(their_v - our_v, 1)}

        if gaps:
            diff["daily_gaps"][day] = gaps

    # Worker type comparison
    our_wt = ours.get("worker_types", {})
    their_wt = theirs.get("worker_types", {})
    wt_diff = {}
    for day in range(30):
        our_w = our_wt.get(day, {})
        their_w = their_wt.get(day, {})
        all_types = set(list(our_w.keys()) + list(their_w.keys()))
        day_diff = {}
        for wt in all_types:
            o = our_w.get(wt, 0)
            t = their_w.get(wt, 0)
            if abs(t - o) > 0.3:
                day_diff[wt] = {"ours": round(o, 1), "theirs": round(t, 1)}
        if day_diff:
            wt_diff[day] = day_diff
    diff["worker_type_gaps"] = wt_diff

    return diff


def print_comparison(diff, our_name, their_name):
    """Print a human-readable comparison."""
    print(f"\n{'='*60}")
    print(f"  PATTERN COMPARISON: {our_name} vs {their_name}")
    print(f"  Score gap: ${diff['score_gap']:+,.0f}")
    print(f"{'='*60}\n")

    print("  Day-by-day gaps (where we're behind):\n")
    print(f"  {'Day':>4} {'Metric':>12} {'Ours':>8} {'Theirs':>8} {'Gap':>8}")
    print(f"  {'─'*4} {'─'*12} {'─'*8} {'─'*8} {'─'*8}")

    for day in sorted(diff["daily_gaps"].keys(), key=int):
        gaps = diff["daily_gaps"][day]
        for metric, vals in gaps.items():
            if vals["gap"] > 0:  # they're ahead
                print(f"  {day:>4} {metric:>12} {vals['ours']:>8.0f} {vals['theirs']:>8.0f} {vals['gap']:>+8.0f}")

    print(f"\n  Worker type differences:\n")
    for day in sorted(diff.get("worker_type_gaps", {}).keys(), key=int):
        wt = diff["worker_type_gaps"][day]
        for wtype, vals in wt.items():
            print(f"  Day {day:>2}: {wtype:>15} ours={vals['ours']:.0f} theirs={vals['theirs']:.0f}")


def run_pipeline(agents_to_mine=None, n_games=2, output_dir=None):
    """Run the full mining pipeline."""
    if output_dir is None:
        output_dir = os.path.join(WORK_DIR, "patterns")
    os.makedirs(output_dir, exist_ok=True)

    if agents_to_mine is None:
        agents_to_mine = list(AGENTS.keys())

    timestamp = datetime.now().strftime("%m%d_%H%M")

    # Mine our agent first
    print("\n" + "=" * 60)
    print("  PATTERN MINING PIPELINE")
    print(f"  Agents: {agents_to_mine}")
    print(f"  Games per agent: {n_games}")
    print(f"  Output: {output_dir}")
    print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    our_report = None
    if os.path.exists(OUR_AGENT):
        our_report = mine_agent("v4_planning", OUR_AGENT, n_games)
        if our_report:
            with open(os.path.join(output_dir, f"v4_planning_{timestamp}.json"), "w") as f:
                json.dump(our_report, f, indent=2, default=str)

    # Mine each opponent
    reports = {}
    for name in agents_to_mine:
        path = AGENTS.get(name)
        if not path or not os.path.exists(path):
            print(f"  SKIP {name}: not found at {path}")
            continue

        report = mine_agent(name, path, n_games)
        if report:
            reports[name] = report
            with open(os.path.join(output_dir, f"{name}_{timestamp}.json"), "w") as f:
                json.dump(report, f, indent=2, default=str)

    # Generate comparisons
    if our_report:
        comparisons = {}
        for name, report in reports.items():
            diff = compare_reports(our_report, report)
            comparisons[name] = diff
            print_comparison(diff, "v4_planning", name)

        # Save combined comparison
        summary = {
            "timestamp": datetime.now().isoformat(),
            "our_score": our_report["avg_score"],
            "comparisons": {
                name: {
                    "their_score": reports[name]["avg_score"],
                    "score_gap": diff["score_gap"],
                    "top_daily_gaps": {
                        str(d): gaps for d, gaps in
                        sorted(diff["daily_gaps"].items(), key=lambda x: -sum(
                            v["gap"] for v in x[1].values() if v["gap"] > 0
                        ))[:5]
                    },
                }
                for name, diff in comparisons.items()
            },
        }

        summary_path = os.path.join(output_dir, f"comparison_{timestamp}.json")
        with open(summary_path, "w") as f:
            json.dump(summary, f, indent=2, default=str)
        print(f"\n  Summary saved to: {summary_path}")

    # Generate actionable insights
    if our_report and reports:
        print(f"\n{'='*60}")
        print("  ACTIONABLE INSIGHTS")
        print(f"{'='*60}\n")

        best_opp = max(reports.keys(), key=lambda k: reports[k]["avg_score"])
        best = reports[best_opp]

        # What do they do differently?
        insights = []
        for day in range(30):
            our_d = our_report.get("daily_stats", {}).get(day, {})
            their_d = best.get("daily_stats", {}).get(day, {})
            if not our_d or not their_d:
                continue

            if their_d.get("n_animals", 0) > our_d.get("n_animals", 0) + 2:
                insights.append(f"Day {day}: They have {their_d['n_animals']:.0f} animals vs our {our_d['n_animals']:.0f}. Buy more animals earlier.")
            if their_d.get("n_plants", 0) > our_d.get("n_plants", 0) + 3:
                insights.append(f"Day {day}: They have {their_d['n_plants']:.0f} plants vs our {our_d['n_plants']:.0f}. Plant more crops.")
            if their_d.get("n_empty", 0) < our_d.get("n_empty", 0) - 3:
                insights.append(f"Day {day}: They have {their_d['n_empty']:.0f} empty tiles vs our {our_d['n_empty']:.0f}. Use all tiles.")
            if their_d.get("hands", 0) > our_d.get("hands", 0) + 2:
                insights.append(f"Day {day}: They hire {their_d['hands']:.0f} workers vs our {our_d['hands']:.0f}. Hire more.")
            if their_d.get("money", 0) > our_d.get("money", 0) * 2 and our_d.get("money", 0) > 100:
                insights.append(f"Day {day}: They have ${their_d['money']:,.0f} vs our ${our_d['money']:,.0f}. Revenue gap.")

        for i, insight in enumerate(insights[:10]):
            print(f"  {i+1}. {insight}")

        insights_path = os.path.join(output_dir, f"insights_{timestamp}.txt")
        with open(insights_path, "w") as f:
            f.write(f"Pattern Mining Insights — {datetime.now().isoformat()}\n")
            f.write(f"Our score: ${our_report['avg_score']:,.0f}\n")
            f.write(f"Best opponent ({best_opp}): ${best['avg_score']:,.0f}\n\n")
            for insight in insights:
                f.write(f"- {insight}\n")
        print(f"\n  Insights saved to: {insights_path}")

    return reports


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--agents", default="prvsiyan_soil,shop_router",
                       help="Comma-separated agent names to mine")
    parser.add_argument("--games", type=int, default=2, help="Games per agent")
    parser.add_argument("--output", default=None, help="Output directory")
    args = parser.parse_args()

    agents = args.agents.split(",") if args.agents != "all" else None
    run_pipeline(agents_to_mine=agents, n_games=args.games, output_dir=args.output)
