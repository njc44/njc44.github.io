"""Fluid (macro) model of the Kaggriculture economy.

Simulates 30-day game economics at the aggregate level: how many of each asset,
when they produce, market prices as inventory shifts, shop consumption, hiring
costs.  No tile routing -- just capital allocation.

Designed for speed: a full 30-day sim runs in <1ms using pure-python scalar
math throughout.

Standard library + numpy only.
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

import numpy as np

# ---------------------------------------------------------------------------
# Engine constants (mirrored from kaggriculture.py)
# ---------------------------------------------------------------------------

TOTAL_DAYS = 30
STEPS_PER_DAY = 24
TOTAL_STEPS = TOTAL_DAYS * STEPS_PER_DAY  # 720

STARTING_MONEY = 3000
MARKET_I0 = 10000
PRICE_FLOOR = 1
SHED_CAPACITY = 100
HINGE_GAIN = 8.0

# Land costs: NE=1000, SW=2000, SE=4000
LAND_COSTS = [1000, 2000, 4000]
TILES_PER_QUADRANT = 25  # 5x5
# 4 tiles always occupied by shed.
SHED_TILES = 4

# Hiring: cost = farmHandCostMult * fib(n)  where n = hires_today so far
# fib: 1,1,2,3,5,8,13,21,34,55,89,144,...
FARM_HAND_COST_MULT = 1

CROPS = {
    "WHEAT":      {"seed": 10,  "first_yield_day": 2,  "max_yield_day": 4,  "max_yield": 6, "ongoing": False, "interval": 0},
    "CARROT":     {"seed": 20,  "first_yield_day": 2,  "max_yield_day": 3,  "max_yield": 4, "ongoing": False, "interval": 0},
    "TOMATO":     {"seed": 50,  "first_yield_day": 8,  "max_yield_day": 8,  "max_yield": 4, "ongoing": True,  "interval": 1},
    "STRAWBERRY": {"seed": 100, "first_yield_day": 10, "max_yield_day": 10, "max_yield": 4, "ongoing": True,  "interval": 2},
    "MELON":      {"seed": 80,  "first_yield_day": 10, "max_yield_day": 12, "max_yield": 6, "ongoing": False, "interval": 0},
}

ANIMALS = {
    "GOOSE": {"cost": 300, "product": "EGG",  "first_yield_day": 4, "interval": 1, "max_held": 4},
    "COW":   {"cost": 400, "product": "MILK", "first_yield_day": 8, "interval": 2, "max_held": 6},
    "SHEEP": {"cost": 500, "product": "WOOL", "first_yield_day": 6, "interval": 3, "max_held": 6},
}

PRODUCTS = ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER"]
PROD_IDX = {p: i for i, p in enumerate(PRODUCTS)}
N_PRODUCTS = len(PRODUCTS)

MARKET_PARAMS = {
    "WHEAT":      {"base":  25, "T": 400, "below_func": "sqrt",   "below_target": 0.80, "above_func": "log",    "above_target": 0.20},
    "CARROT":     {"base":  35, "T": 450, "below_func": "hinge",  "below_target": 1.00, "above_func": "sqrt",   "above_target": 0.70},
    "TOMATO":     {"base":  60, "T": 200, "below_func": "hinge",  "below_target": 0.40, "above_func": "sqrt",   "above_target": 0.60},
    "STRAWBERRY": {"base": 120, "T": 100, "below_func": "sqrt",   "below_target": 0.70, "above_func": "linear", "above_target": 1.60},
    "MELON":      {"base": 250, "T": 300, "below_func": "log",    "below_target": 0.20, "above_func": "sq",     "above_target": 3.60},
    "EGG":        {"base":  50, "T": 332, "below_func": "hinge",  "below_target": 0.40, "above_func": "log",    "above_target": 0.20},
    "MILK":       {"base": 160, "T": 122, "below_func": "sqrt",   "below_target": 0.60, "above_func": "linear", "above_target": 1.60},
    "WOOL":       {"base": 200, "T": 105, "below_func": "log",    "below_target": 0.20, "above_func": "sq",     "above_target": 3.20},
    "FERTILIZER": {"base": 100, "T": 200, "below_func": "linear", "below_target": 0.40, "above_func": "linear", "above_target": 0.40},
}

SHOPS = {
    "BAKERY":         ["EGG", "WHEAT"],
    "PIZZA_SHOP":     ["MILK", "TOMATO", "WHEAT"],
    "BRUNCH_SPOT":    ["EGG", "WHEAT", "STRAWBERRY"],
    "YARN_STORE":     ["WOOL"],
    "ICE_CREAM_SHOP": ["STRAWBERRY", "MILK", "WHEAT"],
    "PET_CAFE":       ["CARROT"],
    "SMOOTHIE_SHOP":  ["STRAWBERRY", "MILK"],
    "FARMERS_MARKET": ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY"],
}

ALL_SHOP_NAMES = sorted(SHOPS.keys())
TOWN_CENTER_PRODUCTS = [p for p in PRODUCTS if p != "FERTILIZER"]

# Shop unlock schedule: day 3, 6, 9, 12, 15, 18, 21, 24 (max 8)
SHOP_UNLOCK_INTERVAL = 3
MAX_SHOP_INSTANCES = 8

# Shop consumption: every 4 steps for shops, every 24 steps for town center
SHOP_CONSUME_INTERVAL = 4   # steps
TOWN_CONSUME_INTERVAL = 24  # steps


# ---------------------------------------------------------------------------
# Price calculation (mirrors engine exactly)
# ---------------------------------------------------------------------------

def _shape(func: str, x: float, T: float = 0.0) -> float:
    x = max(0.0, x)
    if func == "linear":
        return x
    if func == "sq":
        return x * x
    if func == "sqrt":
        return math.sqrt(x)
    if func == "log":
        return math.log(1.0 + x)
    if func == "hinge":
        if T <= 0:
            return x
        u = x / T
        return u + HINGE_GAIN * max(0.0, u - 1.0) ** 2
    return x


def market_price(product: str, inventory: int) -> int:
    """Compute market price for a product given current inventory. Mirrors engine."""
    p = MARKET_PARAMS[product]
    base = p["base"]
    T = p["T"]
    if inventory < MARKET_I0:
        f = p["below_func"]
        amp = p["below_target"] * base / _shape(f, T, T)
        price = base + amp * _shape(f, MARKET_I0 - inventory, T)
    else:
        f = p["above_func"]
        amp = p["above_target"] * base / _shape(f, T, T)
        price = base - amp * _shape(f, inventory - MARKET_I0, T)
    return max(PRICE_FLOOR, int(round(price)))


def sell_n_units(product: str, n: int, inventory: int) -> Tuple[int, int]:
    """Sell n units one at a time, return (total_revenue, new_inventory).

    Sales at $1 do NOT increase market inventory (engine rule).
    """
    total = 0
    inv = inventory
    for _ in range(n):
        p = market_price(product, inv)
        total += p
        if p > PRICE_FLOOR:
            inv += 1
    return total, inv


# ---------------------------------------------------------------------------
# Fibonacci for hire costs
# ---------------------------------------------------------------------------

def _fib(n: int) -> int:
    a, b = 1, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def hire_cost_for_n(n_hires: int) -> int:
    """Total cost to hire n workers in one day."""
    return sum(FARM_HAND_COST_MULT * _fib(i) for i in range(n_hires))


# Precompute daily hire costs for up to 20 workers
_HIRE_COST_TABLE = [hire_cost_for_n(n) for n in range(21)]


# ---------------------------------------------------------------------------
# Precompute shop consumption per day
# ---------------------------------------------------------------------------

def shop_consumption_per_day(shops_unlocked: List[str]) -> Dict[str, int]:
    """How many units each product loses per day from shop + town center consumption.

    Shops consume every 4 steps (= 6 times per day of 24 steps).
    Town center consumes every 24 steps (= 1 time per day).
    Single-product shops consume 2x per tick.
    """
    consumption = {p: 0 for p in PRODUCTS}
    # Town center: 1 of each non-fertilizer product per day
    for p in TOWN_CENTER_PRODUCTS:
        consumption[p] += 1
    # Shops: 6 ticks per day, each tick consumes 1 per product (2x for single-product)
    ticks_per_day = STEPS_PER_DAY // SHOP_CONSUME_INTERVAL  # 24 / 4 = 6
    for shop_name in shops_unlocked:
        products = SHOPS[shop_name]
        multiplier = 2 if len(products) == 1 else 1
        for p in products:
            consumption[p] += multiplier * ticks_per_day
    return consumption


# ---------------------------------------------------------------------------
# Crop yield model
# ---------------------------------------------------------------------------

def crop_total_yield(crop: str, plant_day: int, game_end_day: int = TOTAL_DAYS,
                     fertilized: bool = False) -> Tuple[int, int]:
    """Total yield units and harvest day for a crop planted on plant_day.

    Returns (total_yield, harvest_day).

    For non-ongoing crops:
      Yield accumulates from watering during [window_start, max_yield_day].
      window_start = (max_yield_day + 1) // 2
      Assuming watered every day, yield = min(max_yield, days_in_window * fert_mult).
      Harvest happens at max_yield_day (when yield is maximised).

    For ongoing crops (TOMATO, STRAWBERRY):
      Produces 1 unit every `interval` days starting from first_yield_day.
      Max 4 production events.  Harvest each production day.
    """
    cd = CROPS[crop]
    fert_mult = 2 if fertilized else 1

    if cd["ongoing"]:
        total = 0
        first_harvest = game_end_day
        for prod_num in range(1, cd["max_yield"] + 1):
            # Production happens at end of day (plant_day + first_yield_day + (prod_num-1)*interval)
            # The engine produces at _daily_refresh on that day's end, harvestable next day
            prod_day = plant_day + cd["first_yield_day"] + (prod_num - 1) * cd["interval"]
            if prod_day < game_end_day:
                total += 1 * fert_mult
                if prod_num == 1:
                    first_harvest = prod_day
            else:
                break
        return total, first_harvest
    else:
        # Non-ongoing: yield accumulates by watering each day in the window
        max_yd = cd["max_yield_day"]
        window_start = (max_yd + 1) // 2
        # Window: from (plant_day + window_start) to (plant_day + max_yield_day)
        window_begin = plant_day + window_start
        window_end = min(plant_day + max_yd, game_end_day - 1)
        if window_begin > window_end:
            return 0, game_end_day

        days_in_window = window_end - window_begin + 1
        total = min(cd["max_yield"], days_in_window * fert_mult)
        harvest_day = plant_day + max_yd  # optimal harvest at max_yield_day
        if harvest_day >= game_end_day:
            harvest_day = game_end_day - 1
        return total, harvest_day


# ---------------------------------------------------------------------------
# Animal yield model
# ---------------------------------------------------------------------------

def animal_total_yield(animal: str, place_day: int, game_end_day: int = TOTAL_DAYS,
                       care: bool = True) -> Tuple[int, int, int]:
    """Total product yield, fertilizer yield, and first production day.

    Animals produce on production days (every `interval` days after first_yield_day).
    With CARE: base 1 + care_bonus 1 = 2 per production day.
    Without CARE: base 1 per production day.

    Also produces 1 fertilizer per day after being fed (every day alive).

    Returns (product_units, fertilizer_units, first_production_day).
    """
    a = ANIMALS[animal]
    first_prod_day = place_day + a["first_yield_day"]

    if first_prod_day >= game_end_day:
        alive_days = max(0, game_end_day - place_day)
        return 0, alive_days, game_end_day

    production_count = 0
    day = first_prod_day
    while day < game_end_day:
        production_count += 1
        day += a["interval"]

    base_per_prod = 2 if care else 1  # CARE adds +1 bonus
    total_product = production_count * base_per_prod

    # Fertilizer: 1 per day the animal is alive and fed
    alive_days = max(0, game_end_day - place_day)
    total_fert = alive_days

    return total_product, total_fert, first_prod_day


# ---------------------------------------------------------------------------
# Fluid Model: simulate one game
# ---------------------------------------------------------------------------

class FluidModel:
    """Fast macro simulator.  No tile routing, just aggregate economics.

    A 'plan' is a dict with daily decisions:
      plan[day] = {
          "buy_land": bool,
          "n_hires": int,
          "buy_animals": {"SHEEP": n, "COW": n, "GOOSE": n},
          "plant_crops": {"WHEAT": n, "CARROT": n, ...},
          "sell": {"product": n, ...} or "all" or "hold_wool",
          "care": bool,
      }
    """

    def __init__(self, shops_schedule: Optional[List[str]] = None,
                 opponent_sell_per_day: Optional[Dict[str, int]] = None):
        self.shops_schedule = shops_schedule or []
        self.opponent_sell_per_day = opponent_sell_per_day or {}

    def simulate(self, plan: Dict, care: bool = True) -> float:
        """Run a full 30-day simulation, return final money."""

        money = float(STARTING_MONEY)
        n_lands_bought = 0
        usable_tiles = TILES_PER_QUADRANT - SHED_TILES  # 21 usable in NW

        # Track active assets.  For each placed animal / planted crop, store
        # the day it was placed/planted so we know when it produces.
        animal_days = {"GOOSE": [], "COW": [], "SHEEP": []}  # list of place_day
        # Non-ongoing crops track (plant_day,) — they free their tile on harvest.
        # Ongoing crops stay until all productions done.
        crop_entries = {c: [] for c in CROPS}  # list of plant_day
        tiles_used = 0

        # Market state
        market_inv = {p: MARKET_I0 for p in PRODUCTS}

        # Shed stock (items waiting to be sold)
        shed = {p: 0 for p in PRODUCTS}

        # Wheat grown internally (for animal feed)
        wheat_stockpile = 0

        shops_unlocked: List[str] = []

        for day in range(TOTAL_DAYS):
            dp = plan.get(day, {})

            # --- Shop unlocks (at end-of-day on days 2,5,8,...  i.e. dawn of 3,6,9,...) ---
            # Engine: end_of_day checks (next_day % 3 == 0) and unlocks.
            # From the player's perspective the shop is available starting on that day.
            if day > 0 and day % SHOP_UNLOCK_INTERVAL == 0:
                shop_idx = day // SHOP_UNLOCK_INTERVAL - 1
                if shop_idx < len(self.shops_schedule):
                    shops_unlocked.append(self.shops_schedule[shop_idx])

            # --- Buy land ---
            if dp.get("buy_land", False) and n_lands_bought < 3:
                cost = LAND_COSTS[n_lands_bought]
                if money >= cost:
                    money -= cost
                    n_lands_bought += 1
                    usable_tiles += TILES_PER_QUADRANT

            # --- Hire workers (cost deducted, but we don't model per-worker actions) ---
            n_hires = min(dp.get("n_hires", 0), 15)
            if n_hires > 0:
                idx = min(n_hires, len(_HIRE_COST_TABLE) - 1)
                hcost = _HIRE_COST_TABLE[idx]
                if money >= hcost:
                    money -= hcost
                else:
                    # Hire as many as affordable
                    cost_so_far = 0
                    for i in range(n_hires):
                        c = FARM_HAND_COST_MULT * _fib(i)
                        if cost_so_far + c <= money:
                            cost_so_far += c
                        else:
                            break
                    money -= cost_so_far

            # --- Buy & place animals ---
            buy_animals = dp.get("buy_animals", {})
            for atype in ("SHEEP", "COW", "GOOSE"):
                n_buy = buy_animals.get(atype, 0)
                if n_buy <= 0:
                    continue
                cost_per = ANIMALS[atype]["cost"]
                for _ in range(n_buy):
                    if money >= cost_per and tiles_used < usable_tiles:
                        money -= cost_per
                        animal_days[atype].append(day)
                        tiles_used += 1

            # --- Buy seeds & plant crops ---
            plant_crops = dp.get("plant_crops", {})
            for ctype in ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON"):
                n_plant = plant_crops.get(ctype, 0)
                if n_plant <= 0:
                    continue
                seed_cost = CROPS[ctype]["seed"]
                for _ in range(n_plant):
                    if money >= seed_cost and tiles_used < usable_tiles:
                        money -= seed_cost
                        crop_entries[ctype].append(day)
                        tiles_used += 1

            # --- Animal feed: use internal wheat stockpile first, buy remainder ---
            total_animals = sum(len(v) for v in animal_days.values())
            wheat_needed = total_animals
            if wheat_needed > 0:
                from_stock = min(wheat_stockpile, wheat_needed)
                wheat_stockpile -= from_stock
                buy_wheat = wheat_needed - from_stock
                if buy_wheat > 0:
                    # Buy wheat from market
                    wcost = 0
                    inv = market_inv["WHEAT"]
                    for _ in range(buy_wheat):
                        p = market_price("WHEAT", inv - 1)
                        wcost += p
                        inv -= 1
                    if money >= wcost:
                        money -= wcost
                        market_inv["WHEAT"] = inv
                    # If can't afford, animals still fed (simplification — in
                    # practice you always have enough wheat or grow your own)

            # --- Production ---

            # Animals: check each for production & fertilizer
            for atype, pdays in animal_days.items():
                a = ANIMALS[atype]
                product = a["product"]
                for pd in pdays:
                    age = day - pd
                    if age < 0:
                        continue

                    # Production check
                    if age >= a["first_yield_day"]:
                        dsf = age - a["first_yield_day"]
                        if dsf % a["interval"] == 0:
                            base = 1
                            bonus = 1 if care else 0
                            shed[product] += base + bonus

                    # Fertilizer: every day the animal is alive & fed
                    shed["FERTILIZER"] += 1

            # Crops: check for harvest
            for ctype in list(crop_entries.keys()):
                cd = CROPS[ctype]
                new_entries = []
                for pd in crop_entries[ctype]:
                    age = day - pd
                    if cd["ongoing"]:
                        # Ongoing: produces every interval days after first_yield_day
                        if age >= cd["first_yield_day"]:
                            dsf = age - cd["first_yield_day"]
                            if dsf % cd["interval"] == 0:
                                prod_num = dsf // cd["interval"] + 1
                                if prod_num <= cd["max_yield"]:
                                    shed[ctype] += 1
                                if prod_num >= cd["max_yield"]:
                                    # Crop exhausted, free tile
                                    tiles_used -= 1
                                    continue  # don't keep
                        new_entries.append(pd)
                    else:
                        # Non-ongoing: harvest at max_yield_day
                        if age >= cd["max_yield_day"]:
                            # Yield from watering window
                            max_yd = cd["max_yield_day"]
                            window_start = (max_yd + 1) // 2
                            window_days = max_yd - window_start + 1
                            total_yield = min(cd["max_yield"], window_days)

                            if ctype == "WHEAT":
                                # Wheat goes to internal stockpile for animal feed
                                wheat_stockpile += total_yield
                            else:
                                shed[ctype] += total_yield

                            tiles_used -= 1
                            continue  # don't keep — tile freed
                        new_entries.append(pd)

                crop_entries[ctype] = new_entries

            # --- Replant freed tiles with wheat (auto-wheat for feed) ---
            # In the actual game, top agents plant wheat on tiles not used by
            # animals.  We model this as automatic wheat planting on free tiles.
            wheat_tiles_target = dp.get("wheat_tiles", 0)
            free_tiles = usable_tiles - tiles_used
            wheat_to_plant = min(wheat_tiles_target, free_tiles)
            for _ in range(wheat_to_plant):
                if money >= CROPS["WHEAT"]["seed"]:
                    money -= CROPS["WHEAT"]["seed"]
                    crop_entries["WHEAT"].append(day)
                    tiles_used += 1

            # --- Opponent production added to market ---
            for prod, units in self.opponent_sell_per_day.items():
                if units > 0 and prod in market_inv:
                    for _ in range(units):
                        p = market_price(prod, market_inv[prod])
                        if p > PRICE_FLOOR:
                            market_inv[prod] += 1

            # --- Shop consumption reduces market inventory ---
            cons = shop_consumption_per_day(shops_unlocked)
            for prod, consumed in cons.items():
                if consumed > 0:
                    market_inv[prod] -= consumed

            # --- Sell products ---
            sell_plan = dp.get("sell", "all")
            sell_wool = True

            if sell_plan == "hold_wool":
                # Sell everything except wool (hold for Yarn Store option value)
                for prod in PRODUCTS:
                    if prod == "WOOL":
                        # Check if any YARN_STORE is unlocked
                        if "YARN_STORE" in shops_unlocked:
                            sell_wool = True
                        else:
                            sell_wool = False
                        if sell_wool:
                            n = shed[prod]
                            if n > 0:
                                rev, new_inv = sell_n_units(prod, n, market_inv[prod])
                                money += rev
                                market_inv[prod] = new_inv
                                shed[prod] = 0
                    else:
                        n = shed[prod]
                        if n > 0:
                            rev, new_inv = sell_n_units(prod, n, market_inv[prod])
                            money += rev
                            market_inv[prod] = new_inv
                            shed[prod] = 0
            elif sell_plan == "all":
                for prod in PRODUCTS:
                    n = shed[prod]
                    if n > 0:
                        rev, new_inv = sell_n_units(prod, n, market_inv[prod])
                        money += rev
                        market_inv[prod] = new_inv
                        shed[prod] = 0
            elif isinstance(sell_plan, dict):
                for prod, n_sell in sell_plan.items():
                    n = min(n_sell, shed.get(prod, 0))
                    if n > 0:
                        rev, new_inv = sell_n_units(prod, n, market_inv[prod])
                        money += rev
                        market_inv[prod] = new_inv
                        shed[prod] -= n

        # --- Final liquidation ---
        for prod in PRODUCTS:
            n = shed.get(prod, 0)
            if n > 0:
                rev, new_inv = sell_n_units(prod, n, market_inv[prod])
                money += rev

        # Sell leftover wheat stockpile
        if wheat_stockpile > 0:
            rev, _ = sell_n_units("WHEAT", wheat_stockpile, market_inv.get("WHEAT", MARKET_I0))
            money += rev

        return money


# ---------------------------------------------------------------------------
# Convenience: simulate with a parameterised allocation vector
# ---------------------------------------------------------------------------

def simulate_allocation(
    alloc: np.ndarray,
    shops: List[str],
    opponent_sell: Optional[Dict[str, int]] = None,
) -> float:
    """Simulate a game given a flat allocation parameter vector.

    The vector encodes:
      [0]:     n_sheep (int)
      [1]:     n_cow (int)
      [2]:     n_goose (int)
      [3]:     n_wheat_tiles (int, dedicated wheat tiles for feed/sale)
      [4]:     n_carrot (int)
      [5]:     n_tomato (int)
      [6]:     n_strawberry (int)
      [7]:     n_melon (int)
      [8]:     n_hires_per_day (int)
      [9]:     land_buy_day_1 (day to buy NE)
      [10]:    land_buy_day_2 (day to buy SW)
      [11]:    land_buy_day_3 (day to buy SE)
      [12]:    animal_buy_day (day to start buying animals)
      [13]:    crop_plant_day (day to start planting crops)
      [14]:    sell_fert_day (day after which to sell fertilizer cheaply)
    """
    alloc = np.clip(alloc, -1, 100).astype(int)

    n_sheep = max(0, int(alloc[0]))
    n_cow = max(0, int(alloc[1]))
    n_goose = max(0, int(alloc[2]))
    n_wheat_tiles = max(0, int(alloc[3]))
    n_carrot = max(0, int(alloc[4]))
    n_tomato = max(0, int(alloc[5]))
    n_strawberry = max(0, int(alloc[6]))
    n_melon = max(0, int(alloc[7]))
    n_hires = max(0, min(int(alloc[8]), 15))
    land_days = [int(alloc[9]), int(alloc[10]), int(alloc[11])]
    animal_buy_day = max(0, int(alloc[12]))
    crop_plant_day = max(0, int(alloc[13]))
    sell_fert_day = max(0, int(alloc[14])) if len(alloc) > 14 else 15

    # Build plan
    plan = {}
    animals_bought = {"SHEEP": 0, "COW": 0, "GOOSE": 0}
    crops_planted = {"CARROT": 0, "TOMATO": 0, "STRAWBERRY": 0, "MELON": 0}

    for day in range(TOTAL_DAYS):
        dp = {"n_hires": n_hires}

        # Land purchases
        for i, ld in enumerate(land_days):
            if ld == day:
                dp["buy_land"] = True
                break

        # Buy animals (spread purchases — up to 3/day/type)
        buy_a = {}
        if day >= animal_buy_day:
            for atype, target in [("SHEEP", n_sheep), ("COW", n_cow), ("GOOSE", n_goose)]:
                remaining = target - animals_bought[atype]
                if remaining > 0:
                    n = min(remaining, 3)
                    buy_a[atype] = n
                    animals_bought[atype] += n
        if buy_a:
            dp["buy_animals"] = buy_a

        # Plant cash crops (spread — up to 4/day/type)
        plant_c = {}
        if day >= crop_plant_day:
            for ctype, target in [("CARROT", n_carrot), ("TOMATO", n_tomato),
                                  ("STRAWBERRY", n_strawberry), ("MELON", n_melon)]:
                remaining = target - crops_planted[ctype]
                if remaining > 0:
                    n = min(remaining, 4)
                    plant_c[ctype] = n
                    crops_planted[ctype] += n
        if plant_c:
            dp["plant_crops"] = plant_c

        # Wheat tiles: continuously replant on free tiles
        dp["wheat_tiles"] = n_wheat_tiles

        # Sell strategy
        if day < sell_fert_day:
            # Sell everything except fertilizer (hold for high early price)
            dp["sell"] = {p: 999 for p in PRODUCTS if p != "FERTILIZER"}
        else:
            dp["sell"] = "all"

        plan[day] = dp

    model = FluidModel(
        shops_schedule=shops,
        opponent_sell_per_day=opponent_sell or {},
    )
    return model.simulate(plan, care=True)


# ---------------------------------------------------------------------------
# Quick self-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Test price curves
    print("=== Price Curve Test ===")
    for prod in PRODUCTS:
        p_eq = market_price(prod, MARKET_I0)
        p_low = market_price(prod, MARKET_I0 - 50)
        p_high = market_price(prod, MARKET_I0 + 50)
        print(f"{prod:12s}  base={MARKET_PARAMS[prod]['base']:4d}  "
              f"@eq={p_eq:4d}  @-50={p_low:4d}  @+50={p_high:4d}")

    # Test hire costs
    print("\n=== Hire Costs ===")
    for n in range(1, 14):
        print(f"  {n} hires: ${hire_cost_for_n(n)}")

    # Test a simple simulation
    print("\n=== Simple Sim: 10 sheep, 5 wheat tiles, YARN shops ===")
    shops = ["YARN_STORE", "BAKERY", "PIZZA_SHOP", "FARMERS_MARKET",
             "BRUNCH_SPOT", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP", "PET_CAFE"]
    alloc = np.array([10, 0, 0,  # sheep, cow, goose
                       5, 0, 0, 0, 0,  # wheat, carrot, tomato, strawberry, melon
                       12,  # hires
                       2, 5, 10,  # land buy days
                       0, 0,  # animal/crop start days
                       15])  # sell fert day
    score = simulate_allocation(alloc, shops)
    print(f"  Final money: ${score:.0f}")

    # Benchmark speed
    import time
    N = 1000
    t0 = time.perf_counter()
    for _ in range(N):
        simulate_allocation(alloc, shops)
    elapsed = time.perf_counter() - t0
    print(f"\n  {N} sims in {elapsed:.3f}s = {elapsed/N*1000:.2f}ms/sim")
