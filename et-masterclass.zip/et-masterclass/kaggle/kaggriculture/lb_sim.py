"""LB Simulator — test agents against real LB opponent tapes.

Instead of testing against our own agents (self-play bias), this runs
our candidate against action tapes extracted from actual LB replays.

Usage:
    python lb_sim.py <candidate_path> [--opponents N] [--seats both|0|1]

Examples:
    python lb_sim.py /tmp/kaggriculture_latest/hybrid_v1/main.py
    python lb_sim.py /tmp/kaggriculture_latest/room_guard_only/main.py --opponents 30
"""
import json
import math
import os
import sys
import time
from pathlib import Path

from kaggle_environments import make
from replay_agent import make_replay_agent

OPPONENT_DIR = Path("/tmp/kaggriculture_opponents")
INDEX_PATH = OPPONENT_DIR / "index.json"


def wilson_ci(wins, total, z=1.96):
    if total == 0:
        return (0, 0)
    p = wins / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denom
    return (max(0, center - margin), min(1, center + margin))


def run_vs_replay(candidate_path, tape_path, seat=0):
    """Run candidate vs a replay opponent. Returns (cand_reward, opp_reward, status)."""
    replay_fn = make_replay_agent(tape_path)

    env = make("kaggriculture", debug=True)
    if seat == 0:
        result = env.run([candidate_path, replay_fn])
    else:
        result = env.run([replay_fn, candidate_path])

    final = result[-1]
    r0, r1 = final[0]["reward"], final[1]["reward"]
    s0, s1 = final[0]["status"], final[1]["status"]

    if seat == 0:
        return r0, r1, s0, s1
    else:
        return r1, r0, s1, s0


def main():
    if len(sys.argv) < 2:
        print("Usage: python lb_sim.py <candidate_path> [--opponents N] [--seats both|0|1]")
        sys.exit(1)

    candidate = sys.argv[1]
    if not os.path.exists(candidate):
        print(f"ERROR: {candidate} not found")
        sys.exit(1)

    # Parse args
    max_opponents = 30
    seat_mode = "both"  # both, 0, or 1

    for i, arg in enumerate(sys.argv[2:], 2):
        if arg == "--opponents" and i + 1 < len(sys.argv):
            max_opponents = int(sys.argv[i + 1])
        if arg == "--seats" and i + 1 < len(sys.argv):
            seat_mode = sys.argv[i + 1]

    # Load opponent index
    if not INDEX_PATH.exists():
        print("ERROR: Run extract_opponents.py first")
        sys.exit(1)

    with open(INDEX_PATH) as f:
        index = json.load(f)

    # Sort by opponent reward (strongest first) and take top N
    index.sort(key=lambda o: -o["opp_reward"])
    selected = index[:max_opponents]

    candidate_name = Path(candidate).parent.name or Path(candidate).stem
    print(f"LB Simulator: {candidate_name}")
    print(f"Testing against {len(selected)} real LB opponents")
    print(f"Seat mode: {seat_mode}")
    print()

    # Run games
    results = []
    total_start = time.time()

    for i, opp in enumerate(selected):
        ep_id = opp["episode_id"]
        tape_path = OPPONENT_DIR / f"opp_{ep_id}.json"
        if not tape_path.exists():
            continue

        seats_to_test = []
        if seat_mode == "both":
            seats_to_test = [0, 1]
        else:
            seats_to_test = [int(seat_mode)]

        for seat in seats_to_test:
            game_start = time.time()
            try:
                cr, opr, cs, ops = run_vs_replay(candidate, str(tape_path), seat)
                won = cr > opr
                margin = cr - opr
                elapsed = time.time() - game_start

                result = {
                    "episode_id": ep_id,
                    "seat": seat,
                    "candidate_reward": cr,
                    "opponent_reward": opr,
                    "opponent_orig_reward": opp["opp_reward"],
                    "won": won,
                    "margin": margin,
                    "candidate_status": cs,
                    "opponent_status": ops,
                    "elapsed": elapsed,
                    "shops": opp.get("shops", []),
                }
                results.append(result)

                tag = "W" if won else "L" if margin < 0 else "D"
                print(f"  [{i+1:2d}/{len(selected)}] Ep {ep_id} seat={seat}: "
                      f"us={cr:.0f} opp={opr:.0f} ({margin:+.0f}) "
                      f"[{elapsed:.0f}s] {tag}")

            except Exception as e:
                print(f"  [{i+1:2d}/{len(selected)}] Ep {ep_id} seat={seat}: ERROR {e}")
                results.append({
                    "episode_id": ep_id, "seat": seat,
                    "won": False, "margin": 0, "error": str(e),
                })

    total_elapsed = time.time() - total_start

    # Compute stats
    valid = [r for r in results if "error" not in r]
    wins = sum(1 for r in valid if r["won"])
    losses = sum(1 for r in valid if not r["won"] and r["margin"] < 0)
    ties = sum(1 for r in valid if r["margin"] == 0)
    total = len(valid)

    if total == 0:
        print("\nNo valid games completed!")
        return

    wr = wins / total
    ci = wilson_ci(wins, total)
    margins = [r["margin"] for r in valid]
    avg_margin = sum(margins) / len(margins)

    # Per-seat stats
    for s in [0, 1]:
        seat_results = [r for r in valid if r["seat"] == s]
        if seat_results:
            sw = sum(1 for r in seat_results if r["won"])
            st = len(seat_results)
            print(f"\n  Seat {s}: {sw}W-{st-sw}L ({sw/st*100:.0f}% WR)")

    # Win rate by opponent strength tier
    strong = [r for r in valid if r["opponent_orig_reward"] >= 100000]
    medium = [r for r in valid if 70000 <= r["opponent_orig_reward"] < 100000]
    weak = [r for r in valid if r["opponent_orig_reward"] < 70000]

    print(f"\n{'='*70}")
    print(f"  LB SIMULATION REPORT: {candidate_name}")
    print(f"{'='*70}")
    print(f"\n  Overall: {wins}W-{losses}L-{ties}D ({wr*100:.1f}% WR)")
    print(f"  95% CI: [{ci[0]*100:.0f}%-{ci[1]*100:.0f}%]")
    print(f"  Avg margin: {avg_margin:+,.0f}")
    print(f"  Total time: {total_elapsed:.0f}s ({total_elapsed/total:.1f}s/game)")

    if strong:
        sw = sum(1 for r in strong if r["won"])
        print(f"\n  vs Strong (100K+ reward): {sw}/{len(strong)} ({sw/len(strong)*100:.0f}% WR)")
    if medium:
        mw = sum(1 for r in medium if r["won"])
        print(f"  vs Medium (70-100K reward): {mw}/{len(medium)} ({mw/len(medium)*100:.0f}% WR)")
    if weak:
        ww = sum(1 for r in weak if r["won"])
        print(f"  vs Weak (<70K reward): {ww}/{len(weak)} ({ww/len(weak)*100:.0f}% WR)")

    # Biggest losses (for debugging)
    worst = sorted(valid, key=lambda r: r["margin"])[:5]
    print(f"\n  Worst losses:")
    for r in worst:
        if r["margin"] < 0:
            print(f"    Ep {r['episode_id']} seat={r['seat']}: {r['margin']:+,.0f} "
                  f"(us={r['candidate_reward']:.0f} opp={r['opponent_reward']:.0f}) "
                  f"shops={r.get('shops', '?')}")

    print(f"\n{'='*70}")

    # Save results
    out_path = os.path.join(os.path.dirname(candidate), "lb_sim_results.json")
    with open(out_path, "w") as f:
        json.dump({
            "candidate": candidate,
            "total": total,
            "wins": wins,
            "losses": losses,
            "win_rate": wr,
            "ci_95": ci,
            "avg_margin": avg_margin,
            "results": results,
        }, f, indent=2)
    print(f"\n  Results saved to: {out_path}")


if __name__ == "__main__":
    main()
