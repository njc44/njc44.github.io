"""Kaggriculture Meta Tournament — V2 vs Public Notebook Opponents.

Benchmarks our V2 agent (and Hybrid V1) against all extracted public notebook
agents to understand the competitive landscape.

Usage:
    /Users/nathanjacob/opt/miniconda3/bin/python tournament_meta.py [--games 20] [--v2-only]
"""
import sys
import os
import time
import math
import json
import itertools
from collections import defaultdict
from datetime import datetime

from kaggle_environments import make

# ── Agent Registry ────────────────────────────────────────────────
AGENTS = {
    # Our agents
    "v3_agent":         "/tmp/kaggriculture_latest/v3_agent/main.py",
    "v2_agent":         "/tmp/kaggriculture_latest/v2_agent/main.py",
    "hybrid_v1":        "/tmp/kaggriculture_latest/hybrid_v1/main.py",
    "shop_router":      "/tmp/kaggriculture_latest/shop_router_0909_ext/main.py",

    # Public notebook opponents
    "boatlee_v16":      "/tmp/kaggriculture_opponents/boatlee_v16/main.py",
    "kaito_v48":        "/tmp/kaggriculture_opponents/kaitofukami_v48/main.py",
    "pilkwang":         "/tmp/kaggriculture_opponents/pilkwang_policy/main.py",
    "prvsiyan_moon":    "/tmp/kaggriculture_opponents/prvsiyan_moon/main.py",
    "prvsiyan_soil":    "/tmp/kaggriculture_opponents/prvsiyan_soil/main.py",
    "tetsu_adaptive":   "/tmp/kaggriculture_opponents/tetsutani_adaptive/main.py",
    "tetsu_shape":      "/tmp/kaggriculture_opponents/tetsutani_shape/main.py",
    "tschinkel_router": "/tmp/kaggriculture_opponents/thomastschinkel_router/main.py",
    "yhay81_fieldbook": "/tmp/kaggriculture_opponents/yhay81_fieldbook/main.py",
}


# ── Statistical Helpers ─────────────────────────────────────────────
def wilson_ci(wins, total, z=1.96):
    if total == 0:
        return (0.0, 0.0)
    p = wins / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denom
    return (max(0, center - margin), min(1, center + margin))


def z_score(wins, losses):
    n = wins + losses
    if n == 0:
        return 0.0
    p = wins / n
    se = math.sqrt(0.25 / n)
    return (p - 0.5) / se


def compute_elo(results, k=32, initial=1500):
    names = set()
    for (a, b) in results:
        names.add(a)
        names.add(b)
    elo = {name: initial for name in names}
    games = []
    for (a, b), stats in results.items():
        for outcome in stats["outcomes"]:
            games.append((a, b, outcome))
    for _ in range(3):
        for a, b, outcome in games:
            ea = 1 / (1 + 10 ** ((elo[b] - elo[a]) / 400))
            eb = 1 - ea
            if outcome == "a_win":
                sa, sb = 1, 0
            elif outcome == "b_win":
                sa, sb = 0, 1
            else:
                sa, sb = 0.5, 0.5
            elo[a] += k * (sa - ea)
            elo[b] += k * (sb - eb)
    return elo


# ── Core Game Runner ────────────────────────────────────────────────
def run_single_game(agent_a_path, agent_b_path, debug=False):
    try:
        env = make("kaggriculture", debug=debug)
        result = env.run([agent_a_path, agent_b_path])
        final = result[-1]
        return (
            final[0]["reward"], final[1]["reward"],
            final[0]["status"], final[1]["status"],
        )
    except Exception as e:
        return (0, 0, "ERROR", str(e))


def run_matchup(agent_a_name, agent_a_path, agent_b_name, agent_b_path,
                games_per_seat=10, verbose=True):
    wins_a, wins_b, ties = 0, 0, 0
    scores_a, scores_b = [], []
    errors = 0
    outcomes = []
    total_games = games_per_seat * 2

    for i in range(total_games):
        if i < games_per_seat:
            p0, p1, a_seat = agent_a_path, agent_b_path, 0
        else:
            p0, p1, a_seat = agent_b_path, agent_a_path, 1

        r0, r1, s0, s1 = run_single_game(p0, p1)

        if s0 != "DONE" or s1 != "DONE":
            errors += 1
            outcomes.append("error")
            if verbose:
                err_msg = s1 if s0 == "DONE" else s0
                print(f"    [Game {i+1}] ERROR: {err_msg[:80]}", flush=True)
            continue

        ra = r0 if a_seat == 0 else r1
        rb = r1 if a_seat == 0 else r0
        scores_a.append(ra)
        scores_b.append(rb)

        if ra > rb:
            wins_a += 1
            outcomes.append("a_win")
        elif rb > ra:
            wins_b += 1
            outcomes.append("b_win")
        else:
            ties += 1
            outcomes.append("tie")

        if verbose and (i + 1) % 5 == 0:
            total = wins_a + wins_b + ties
            wr = wins_a / total if total else 0
            print(f"    [{i+1}/{total_games}] {agent_a_name} {wins_a}W-{wins_b}L-{ties}D ({wr*100:.0f}%)", flush=True)

    total = wins_a + wins_b + ties
    wr_a = wins_a / total if total else 0
    ci = wilson_ci(wins_a, total)
    z = z_score(wins_a, wins_b)
    avg_a = sum(scores_a) / len(scores_a) if scores_a else 0
    avg_b = sum(scores_b) / len(scores_b) if scores_b else 0

    return {
        "agent_a": agent_a_name, "agent_b": agent_b_name,
        "wins_a": wins_a, "wins_b": wins_b, "ties": ties, "errors": errors,
        "total": total, "win_rate_a": wr_a,
        "ci_95": ci, "z_score": z,
        "avg_score_a": avg_a, "avg_score_b": avg_b,
        "margin": avg_a - avg_b,
        "outcomes": outcomes,
    }


# ── V2-focused Tournament ──────────────────────────────────────────
def run_v2_gauntlet(games_per_seat=10, verbose=True):
    """Run V2 against every opponent (not full round-robin — too slow)."""
    hero = "v3_agent"
    hero_path = AGENTS[hero]
    opponents = [k for k in AGENTS if k != hero]

    n = len(opponents)
    total_games = n * games_per_seat * 2

    print(f"\n{'='*70}")
    print(f"  V2 AGENT GAUNTLET")
    print(f"  V2 vs {n} opponents, {games_per_seat*2} games each")
    print(f"  Total games: {total_games}")
    print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}\n")

    all_results = {}
    start_time = time.time()

    for idx, opp in enumerate(opponents, 1):
        opp_path = AGENTS[opp]
        if not os.path.exists(opp_path):
            print(f"[{idx}/{n}] SKIP {opp} — file not found at {opp_path}")
            continue

        print(f"[{idx}/{n}] v2_agent vs {opp}...", flush=True)
        m_start = time.time()

        stats = run_matchup(hero, hero_path, opp, opp_path,
                           games_per_seat=games_per_seat, verbose=verbose)
        elapsed = time.time() - m_start

        all_results[opp] = stats
        result_icon = "✓" if stats["win_rate_a"] > 0.5 else "✗" if stats["win_rate_a"] < 0.5 else "="
        print(f"  {result_icon} {hero} {stats['wins_a']}W-{stats['wins_b']}L-{stats['ties']}D "
              f"({stats['win_rate_a']*100:.0f}% WR, margin={stats['margin']:+,.0f}) "
              f"[{elapsed:.0f}s]\n", flush=True)

    total_elapsed = time.time() - start_time

    # ── Summary ─────────────────────────────────────────────
    print(f"\n{'='*70}")
    print(f"  V2 GAUNTLET RESULTS")
    print(f"  Total time: {total_elapsed:.0f}s ({total_elapsed/60:.1f} min)")
    print(f"{'='*70}\n")

    # Sort by V2's win rate (worst first to highlight threats)
    sorted_opps = sorted(all_results.keys(), key=lambda o: all_results[o]["win_rate_a"])

    total_w, total_l, total_t, total_e = 0, 0, 0, 0
    print(f"  {'Opponent':<20} {'W-L-D':>10} {'WR':>6} {'z':>6} {'CI 95%':>14} {'Margin':>10} {'Errors':>6}")
    print(f"  {'─'*20} {'─'*10} {'─'*6} {'─'*6} {'─'*14} {'─'*10} {'─'*6}")

    for opp in sorted_opps:
        s = all_results[opp]
        total_w += s["wins_a"]
        total_l += s["wins_b"]
        total_t += s["ties"]
        total_e += s["errors"]
        wld = f"{s['wins_a']}-{s['wins_b']}-{s['ties']}"
        ci = f"[{s['ci_95'][0]*100:.0f}%-{s['ci_95'][1]*100:.0f}%]"
        print(f"  {opp:<20} {wld:>10} {s['win_rate_a']*100:>5.0f}% {s['z_score']:>+5.1f} {ci:>14} {s['margin']:>+10,.0f} {s['errors']:>6}")

    total_g = total_w + total_l + total_t
    overall_wr = total_w / total_g if total_g else 0
    print(f"\n  {'OVERALL':<20} {f'{total_w}-{total_l}-{total_t}':>10} {overall_wr*100:>5.0f}%")
    if total_e > 0:
        print(f"  Total errors: {total_e}")

    # ── Threat Assessment ─────────────────────────────────────
    print(f"\n  THREAT ASSESSMENT:")
    threats = [o for o in sorted_opps if all_results[o]["win_rate_a"] < 0.5]
    even = [o for o in sorted_opps if all_results[o]["win_rate_a"] == 0.5]
    wins = [o for o in sorted_opps if all_results[o]["win_rate_a"] > 0.5]

    if threats:
        print(f"  LOSING TO ({len(threats)}): {', '.join(threats)}")
    else:
        print(f"  LOSING TO: none!")
    if even:
        print(f"  EVEN WITH ({len(even)}): {', '.join(even)}")
    if wins:
        print(f"  BEATING ({len(wins)}): {', '.join(wins)}")

    print(f"\n{'='*70}\n")

    # Save results
    save_data = {
        "timestamp": datetime.now().isoformat(),
        "hero": hero,
        "games_per_seat": games_per_seat,
        "total_elapsed_s": total_elapsed,
        "overall": {"wins": total_w, "losses": total_l, "ties": total_t,
                    "errors": total_e, "win_rate": overall_wr},
        "matchups": {opp: {k: v for k, v in s.items() if k != "outcomes"}
                     for opp, s in all_results.items()},
    }
    out = f"/Users/nathanjacob/Documents/kaggle/kaggriculture/gauntlet_results_{datetime.now().strftime('%m%d_%H%M')}.json"
    with open(out, "w") as f:
        json.dump(save_data, f, indent=2)
    print(f"  Results saved to: {out}")
    return save_data


# ── Full Round-Robin ────────────────────────────────────────────────
def run_full_tournament(agent_names, games_per_seat=10, verbose=True):
    """Full round-robin among selected agents."""
    agents = {name: AGENTS[name] for name in agent_names if name in AGENTS}
    # Verify
    missing = []
    for name, path in agents.items():
        if not os.path.exists(path):
            missing.append(name)
    if missing:
        print(f"WARNING: Missing agents: {missing}")
        for m in missing:
            del agents[m]
        agent_names = [n for n in agent_names if n in agents]

    pairs = list(itertools.combinations(agent_names, 2))
    n_matchups = len(pairs)
    total_games = n_matchups * games_per_seat * 2

    print(f"\n{'='*70}")
    print(f"  KAGGRICULTURE META TOURNAMENT")
    print(f"  {len(agents)} agents, {n_matchups} matchups, {games_per_seat*2} games each")
    print(f"  Total games: {total_games}")
    print(f"  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}\n")

    matchup_data = {}
    start_time = time.time()

    for idx, (a, b) in enumerate(pairs, 1):
        print(f"[{idx}/{n_matchups}] {a} vs {b}...", flush=True)
        m_start = time.time()

        stats = run_matchup(a, agents[a], b, agents[b],
                           games_per_seat=games_per_seat, verbose=verbose)
        elapsed = time.time() - m_start

        matchup_data[(a, b)] = stats
        print(f"  Result: {a} {stats['wins_a']}W-{stats['wins_b']}L-{stats['ties']}D "
              f"({stats['win_rate_a']*100:.0f}% WR, margin={stats['margin']:+,.0f}) "
              f"[{elapsed:.0f}s]\n", flush=True)

    total_elapsed = time.time() - start_time

    # Compute Elo
    elo = compute_elo(matchup_data)

    # Head-to-Head
    h2h = defaultdict(dict)
    for (a, b), stats in matchup_data.items():
        h2h[a][b] = stats["win_rate_a"]
        h2h[b][a] = 1 - stats["win_rate_a"]

    # Aggregate
    agg = {}
    for name in agent_names:
        total_w, total_l, total_t, total_g = 0, 0, 0, 0
        total_score = 0
        for (a, b), stats in matchup_data.items():
            if a == name:
                total_w += stats["wins_a"]
                total_l += stats["wins_b"]
                total_t += stats["ties"]
                total_g += stats["total"]
                total_score += stats["avg_score_a"] * stats["total"]
            elif b == name:
                total_w += stats["wins_b"]
                total_l += stats["wins_a"]
                total_t += stats["ties"]
                total_g += stats["total"]
                total_score += stats["avg_score_b"] * stats["total"]
        agg[name] = {
            "wins": total_w, "losses": total_l, "ties": total_t,
            "games": total_g,
            "win_rate": total_w / total_g if total_g else 0,
            "avg_score": total_score / total_g if total_g else 0,
            "elo": elo.get(name, 1500),
        }

    # Print Results
    print(f"\n{'='*70}")
    print(f"  META TOURNAMENT RESULTS")
    print(f"  Total time: {total_elapsed:.0f}s ({total_elapsed/60:.1f} min)")
    print(f"{'='*70}\n")

    ranked = sorted(agent_names, key=lambda n: -agg[n]["elo"])
    print("  POWER RANKING (by Elo)\n")
    print(f"  {'Rank':>4}  {'Agent':<20}  {'Elo':>6}  {'W-L-D':>10}  {'WR':>6}  {'Avg Score':>10}")
    print(f"  {'─'*4}  {'─'*20}  {'─'*6}  {'─'*10}  {'─'*6}  {'─'*10}")
    for rank, name in enumerate(ranked, 1):
        s = agg[name]
        wld = f"{s['wins']}-{s['losses']}-{s['ties']}"
        marker = " ◀ US" if name in ("v2_agent", "hybrid_v1", "shop_router") else ""
        print(f"  {rank:>4}  {name:<20}  {s['elo']:>6.0f}  {wld:>10}  {s['win_rate']*100:>5.1f}%  {s['avg_score']:>10,.0f}{marker}")

    # Head-to-head matrix
    print(f"\n  HEAD-TO-HEAD (row win rate vs column)\n")
    header = f"  {'':20}" + "".join(f"  {n[:12]:>12}" for n in ranked)
    print(header)
    for a in ranked:
        row = f"  {a:20}"
        for b in ranked:
            if a == b:
                row += f"  {'---':>12}"
            elif b in h2h[a]:
                wr = h2h[a][b]
                row += f"  {wr*100:>11.0f}%"
            else:
                row += f"  {'N/A':>12}"
        print(row)

    print(f"\n{'='*70}\n")

    # Save
    save_data = {
        "timestamp": datetime.now().isoformat(),
        "games_per_seat": games_per_seat,
        "total_elapsed_s": total_elapsed,
        "rankings": [{"rank": i+1, "agent": n, **agg[n]} for i, n in enumerate(ranked)],
        "matchups": {f"{a}_vs_{b}": {k: v for k, v in s.items() if k != "outcomes"}
                     for (a, b), s in matchup_data.items()},
    }
    out = f"/Users/nathanjacob/Documents/kaggle/kaggriculture/meta_tournament_{datetime.now().strftime('%m%d_%H%M')}.json"
    with open(out, "w") as f:
        json.dump(save_data, f, indent=2)
    print(f"  Results saved to: {out}")
    return save_data


# ── Main ───────────────────────────────────────────────────────────
def main():
    games_per_seat = 10  # 20 total per matchup (default)
    mode = "gauntlet"  # default: V2 vs all

    for i, arg in enumerate(sys.argv[1:], 1):
        if arg == "--games" and i + 1 <= len(sys.argv) - 1:
            games_per_seat = int(sys.argv[i + 1]) // 2
        if arg == "--full":
            mode = "full"
        if arg == "--v2-only":
            mode = "gauntlet"

    if mode == "gauntlet":
        run_v2_gauntlet(games_per_seat=games_per_seat)
    else:
        # Full round-robin with all agents
        agent_names = list(AGENTS.keys())
        run_full_tournament(agent_names, games_per_seat=games_per_seat)


if __name__ == "__main__":
    main()
