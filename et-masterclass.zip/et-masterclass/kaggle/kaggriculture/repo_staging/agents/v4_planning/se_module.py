"""SE Quadrant Animal Module — bolts onto a tape agent as extra workers.

Manages animals on SE quadrant tiles (x∈[5,9], y∈[5,9]), independently
of the tape's main-farm workers. Handles BUILD_PASTURE/COOP, FEED, CARE,
HARVEST, COLLECT_FERTILIZER, and sells product+fertilizer each step.

Designed to be driven by the CEM policy: the caller tells it which animal
type and how many, and it handles the rest.
"""

TPD = 24

# SE quadrant tiles near the shed — accessible from (5,5) area.
# The shed occupies (4,4),(5,4),(4,5),(5,5). Workers at (5,5) can
# access the shed. SE tiles are everything in x∈[5,9], y∈[5,9]
# excluding the shed tile at (5,5).
SE_TILES = [
    (6, 5), (7, 5), (8, 5), (9, 5),
    (5, 6), (6, 6), (7, 6), (8, 6), (9, 6),
    (5, 7), (6, 7), (7, 7), (8, 7), (9, 7),
    (5, 8), (6, 8), (7, 8), (8, 8), (9, 8),
    (5, 9), (6, 9), (7, 9), (8, 9), (9, 9),
]

# Shed-adjacent position for SE workers to pick up / drop items
SE_ACCESS = (5, 5)

# CEM policy lookup: (first_shop, second_shop) → {"animal": str, "count": int}
# Simplified from the full 64-pair table. Rules:
#   YARN_STORE in first 2 shops → SHEEP x 6
#   2+ milk shops (PIZZA/ICE_CREAM/SMOOTHIE) in first 2 → COW x 6
#   Otherwise → GOOSE x 4 (conservative filler)
MILK_SHOPS = {"PIZZA_SHOP", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP"}


def choose_se_animal(shops_unlocked):
    """Decide which animal to place on SE tiles given revealed shops."""
    has_yarn = "YARN_STORE" in shops_unlocked
    n_milk = sum(1 for s in shops_unlocked if s in MILK_SHOPS)

    if has_yarn:
        return "SHEEP", 6
    elif n_milk >= 2:
        return "COW", 6
    elif n_milk >= 1:
        return "COW", 4
    else:
        return "GOOSE", 4


def _step_toward(pos, target):
    x, y = pos
    tx, ty = target
    if x < tx: return ["EAST"]
    if x > tx: return ["WEST"]
    if y < ty: return ["SOUTH"]
    if y > ty: return ["NORTH"]
    return None


def _manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def _is_shed_adjacent(pos):
    """Check if position is adjacent to the shed (can do PICKUP/DROP/PLACE)."""
    x, y = pos
    return 3 <= x <= 6 and 3 <= y <= 6


class SEModule:
    """Manages animals on the SE quadrant, independently of the tape agent."""

    def __init__(self, animal="SHEEP", n_animals=6, care=True, start_day=6):
        self.animal = animal
        self.structure = "BUILD_COOP" if animal == "GOOSE" else "BUILD_PASTURE"
        self.cost = {"SHEEP": 500, "COW": 400, "GOOSE": 300}[animal]
        self.product = {"SHEEP": "WOOL", "COW": "MILK", "GOOSE": "EGG"}[animal]
        self.n_animals = n_animals
        self.care = care
        self.start_day = start_day

        # Use the first n_animals SE tiles
        self.tiles = SE_TILES[:n_animals]
        self.spw = 3  # sheep per worker
        self.n_wk = -(-n_animals // self.spw)  # ceil

        # Per-day state
        self.itin = {}      # worker_local_idx → remaining tile list
        self.done = {}      # worker_local_idx → finished today
        self.day = -1
        self.activated = False
        self.land_bought = False
        self.animals_placed = 0
        self.workers_hired = 0

    def n_workers_needed(self):
        return self.n_wk

    def generate_actions(self, obs, worker_indices):
        """Generate actions for the SE module's workers + market orders.

        Args:
            obs: full game observation
            worker_indices: list of global worker indices assigned to this module

        Returns:
            worker_actions: dict {global_worker_idx: ["ACTION", ...]}
            market_orders: list of market orders to merge
        """
        step = obs["step"]
        day = step // TPD
        hour = step % TPD

        if day < self.start_day:
            return {}, []

        farm = obs["farms"][obs["player"]]
        priv = obs["private"]
        shed = priv["shed"]
        tiles = farm["tiles"]
        positions = [tuple(farm["farmer"])] + [tuple(h) for h in farm["hands"]]
        invs = priv["inventories"]

        # Reset daily itineraries
        if day != self.day:
            self.day = day
            self.itin = {}
            self.done = {}
            for wl in range(self.n_wk):
                start = wl * self.spw
                end = min(start + self.spw, len(self.tiles))
                self.itin[wl] = list(self.tiles[start:end])

        market = []

        # ── Market: buy land, hire, buy animals, buy wheat, sell product ──

        # Buy SE land (once, on start_day)
        if not self.land_bought and day == self.start_day and hour == 0:
            market.append(["BUY_LAND"])
            self.land_bought = True

        # Hire workers for SE module (once, spread over first few days)
        if self.workers_hired < self.n_wk and hour == 0 and day >= self.start_day:
            needed = self.n_wk - self.workers_hired
            hires = min(needed, 2)  # max 2 hires per day for SE
            for _ in range(hires):
                market.append(["HIRE"])
                self.workers_hired += 1

        # Buy animals progressively
        placed_on_tiles = sum(1 for t in self.tiles
                             if t[1] < len(tiles) and t[0] < len(tiles[0])
                             and isinstance(tiles[t[1]][t[0]], dict)
                             and "animal" in tiles[t[1]][t[0]])
        in_shed = int(shed.get(self.animal, 0))
        carried = sum(int(inv.get(self.animal, 0)) for inv in invs)
        need = self.n_animals - placed_on_tiles - in_shed - carried
        if need > 0 and hour <= 2:
            n_buy = min(need, 3)
            market.append(["BUY_ANIMAL", self.animal, n_buy])

        # Buy wheat for feed
        total_animals = placed_on_tiles + in_shed + carried
        wheat_in_shed = int(shed.get("WHEAT", 0))
        wheat_carried = sum(int(inv.get("WHEAT", 0)) for inv in invs)
        wheat_need = max(0, total_animals - wheat_in_shed - wheat_carried)
        if wheat_need > 0 and hour <= 1:
            market.append(["BUY_PRODUCT", "WHEAT", min(wheat_need, 6)])

        # Sell product + fertilizer
        prod_in_shed = int(shed.get(self.product, 0))
        if prod_in_shed > 0:
            market.append(["SELL", self.product, prod_in_shed])
        fert_in_shed = int(shed.get("FERTILIZER", 0))
        if fert_in_shed > 0:
            market.append(["SELL", "FERTILIZER", fert_in_shed])

        # ── Worker actions ──
        worker_actions = {}
        for wl, gw in enumerate(worker_indices):
            if gw >= len(positions):
                worker_actions[gw] = ["PASS"]
                continue

            pos = tuple(positions[gw])
            inv = invs[gw] if gw < len(invs) else {}
            my_tiles = self.tiles[wl * self.spw:min((wl + 1) * self.spw, len(self.tiles))]

            # Ensure itinerary exists
            if wl not in self.itin and wl not in self.done:
                self.itin[wl] = list(my_tiles)

            is_access = _is_shed_adjacent(pos)

            # Phase 0: stock up at shed
            if self.itin.get(wl) and is_access:
                # Pick up wheat for feeding
                if hour <= 3 and int(inv.get("WHEAT", 0)) < len(my_tiles):
                    if wheat_in_shed > 0:
                        worker_actions[gw] = ["PICKUP", "WHEAT",
                                              len(my_tiles) - int(inv.get("WHEAT", 0))]
                        continue

                # Pick up animals to place
                my_need = sum(1 for t in my_tiles
                             if t[1] < len(tiles) and t[0] < len(tiles[0])
                             and not (isinstance(tiles[t[1]][t[0]], dict)
                                     and "animal" in tiles[t[1]][t[0]]))
                if my_need > int(inv.get(self.animal, 0)) and in_shed > 0:
                    worker_actions[gw] = ["PICKUP", self.animal,
                                          min(my_need - int(inv.get(self.animal, 0)), in_shed)]
                    continue

            # Phase 1: service tiles
            if self.itin.get(wl):
                target = self.itin[wl][0]

                # Check if target is in bounds
                if target[1] >= len(tiles) or target[0] >= len(tiles[0]):
                    # SE land not yet bought — wait
                    worker_actions[gw] = ["PASS"]
                    continue

                if pos != target:
                    step_cmd = _step_toward(pos, target)
                    if step_cmd:
                        worker_actions[gw] = step_cmd
                    else:
                        worker_actions[gw] = ["PASS"]
                    continue

                tile = tiles[target[1]][target[0]]

                # Build structure
                if tile is None or tile == "LOCKED":
                    worker_actions[gw] = ["PASS"]  # land not yet available
                    self.itin[wl].pop(0)
                    if not self.itin[wl]:
                        self.done[wl] = True
                        del self.itin[wl]
                    continue

                if isinstance(tile, dict) and tile.get("kind") == "WEED":
                    worker_actions[gw] = ["DIG"]
                    continue

                if isinstance(tile, str) and tile == "EMPTY":
                    worker_actions[gw] = [self.structure]
                    continue

                if isinstance(tile, dict) and tile.get("kind") in ("PASTURE", "COOP") and "animal" not in tile:
                    if int(inv.get(self.animal, 0)) > 0:
                        worker_actions[gw] = ["PLACE", self.animal]
                        continue
                    # No animal to place — skip this tile for now
                    self.itin[wl].pop(0)
                    if not self.itin[wl]:
                        self.done[wl] = True
                        del self.itin[wl]
                    worker_actions[gw] = ["PASS"]
                    continue

                if isinstance(tile, dict) and "animal" in tile:
                    if not tile.get("fed_today") and int(inv.get("WHEAT", 0)) > 0:
                        worker_actions[gw] = ["FEED"]
                        continue
                    if self.care and not tile.get("cared_today"):
                        worker_actions[gw] = ["CARE"]
                        continue
                    if tile.get("fertilizer_available"):
                        worker_actions[gw] = ["COLLECT_FERTILIZER"]
                        continue
                    if int(tile.get("yield_units", 0)) > 0:
                        worker_actions[gw] = ["HARVEST"]
                        continue

                # Done with this tile
                self.itin[wl].pop(0)
                if not self.itin[wl]:
                    self.done[wl] = True
                    del self.itin[wl]
                worker_actions[gw] = ["PASS"]
                continue

            # Phase 2: go home and drop
            if not is_access:
                step_cmd = _step_toward(pos, SE_ACCESS)
                worker_actions[gw] = step_cmd if step_cmd else ["PASS"]
                continue

            if any(int(v) > 0 for k, v in inv.items() if k != self.animal):
                worker_actions[gw] = ["DROP"]
                continue

            worker_actions[gw] = ["PASS"]

        return worker_actions, market
