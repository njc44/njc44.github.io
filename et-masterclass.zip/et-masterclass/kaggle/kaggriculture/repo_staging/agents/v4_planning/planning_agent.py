"""V4 Planning Agent: Animal-first with wheat bootstrap.

Key insight: against a melon-selling opponent, melon prices crash to $1-10.
Animal products (wool/milk/egg) with matching shops retain value ($40-250).
Strategy: maximize animals, use wheat for quick income + feed.

Day 0: Hire 5, buy 2 animals, build 2 structures, plant wheat on rest.
       Wheat costs $10/seed vs melon $80. Saves $1400 for animals.
Day 1-2: Buy more animals (2/dawn). Build structures. Water wheat.
Day 2-4: Harvest wheat ($25 * ~100 units = $2500). Buy more animals.
Day 3+: Keep buying animals until target (8-12).
Day 4+: Replant harvested wheat tiles with melon.
Day 10+: Melon harvests. Buy NE land if affordable.

Target: 8-12 animals (occupying structures), rest wheat/melon.
"""

TPD = 24
LAST_STEP = 718
MAX_ORDERS = 10
SHED_TILES = frozenset([(4, 4), (5, 4), (4, 5), (5, 5)])
CROPS_FYD = {"WHEAT": 2, "CARROT": 2, "MELON": 10, "TOMATO": 8, "STRAWBERRY": 10}
PRODUCTS = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON",
            "EGG", "MILK", "WOOL", "FERTILIZER")
ANIMAL_SET = frozenset(("GOOSE", "COW", "SHEEP"))
STRUCT_MAP = {"GOOSE": "COOP", "COW": "PASTURE", "SHEEP": "PASTURE"}
ACOST = {"GOOSE": 300, "COW": 400, "SHEEP": 500}
MILK_SHOPS = frozenset(("PIZZA_SHOP", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP"))

def _d(a, b): return abs(a[0]-b[0]) + abs(a[1]-b[1])
def _t(s, g):
    dx, dy = g[0]-s[0], g[1]-s[1]
    if abs(dx) >= abs(dy):
        if dx > 0: return "EAST"
        if dx < 0: return "WEST"
        if dy > 0: return "SOUTH"
        if dy < 0: return "NORTH"
    else:
        if dy > 0: return "SOUTH"
        if dy < 0: return "NORTH"
        if dx > 0: return "EAST"
        if dx < 0: return "WEST"
    return None
def _sh(p): return tuple(p) in SHED_TILES
def _ns(p): return min(SHED_TILES, key=lambda s: _d(p, s))

class Agent:
    def __init__(self):
        self.nl = 0; self.at = "GOOSE"; self.an = 6; self.decided = False

    def _decide(self, shops):
        if "YARN_STORE" in shops: self.at, self.an = "SHEEP", 8
        elif sum(1 for s in shops if s in MILK_SHOPS) >= 2: self.at, self.an = "COW", 6
        elif sum(1 for s in shops if s in MILK_SHOPS) >= 1: self.at, self.an = "COW", 6
        else: self.at, self.an = "GOOSE", 6
        self.decided = True

    def act(self, obs):
        step = int(obs["step"])
        day, hour = step // TPD, step % TPD
        player = int(obs["player"])
        farm = obs["farms"][player]
        priv = obs["private"]
        tiles = farm["tiles"]
        shed = priv["shed"]
        seeds = priv.get("seeds", {})
        shops = obs.get("town", {}).get("unlocked_shops", [])
        invs = priv.get("inventories", [{}])
        pos_list = [farm["farmer"]] + farm.get("hands", [])
        money = float(farm.get("money", 0))
        nw = len(pos_list)

        if not self.decided and (len(shops) >= 1 or day >= 2):
            self._decide(shops)
        if not self.decided:
            self.at, self.an = "GOOSE", 6
        self.nl = max(self.nl, len(farm.get("unlocked_quadrants", ["NW"])) - 1)

        # Scan
        E, WW, WH, AF, AC, AH, AFT, ES, WEEDS = [], [], [], [], [], [], [], [], []
        na, np = 0, 0; ti = {}
        for y in range(len(tiles)):
            for x in range(len(tiles[y])):
                t = tiles[y][x]; ti[(x,y)] = t
                if t is None: E.append((x,y))
                elif t == "LOCKED": pass
                elif isinstance(t, dict):
                    k = t.get("kind")
                    if "animal" in t:
                        na += 1
                        if int(t.get("yield_units",0)) > 0: AH.append((x,y))
                        if not t.get("fed_today"): AF.append((x,y))
                        if not t.get("cared_today"): AC.append((x,y))
                        if t.get("fertilizer_available"): AFT.append((x,y))
                    elif k == "PLANT":
                        np += 1
                        if not t.get("watered_today"): WW.append((x,y))
                        if int(t.get("yield_units",0)) > 0:
                            cr = t.get("crop","WHEAT")
                            if day - t.get("planted_day",0) >= CROPS_FYD.get(cr,2):
                                WH.append((x,y))
                    elif k in ("PASTURE","COOP"): ES.append((x,y))
                    elif k == "WEED": WEEDS.append((x,y))

        ashed = sum(int(shed.get(a,0)) for a in ANIMAL_SET)
        atot = na + len(ES) + ashed
        ne = len(E)
        rd = 29 - day

        # Crop decision: wheat early for income, melon later for value
        if day <= 2:
            crop = "WHEAT"  # cheap seeds, quick harvest for income
        elif rd >= 12:
            crop = "MELON"
        else:
            crop = "WHEAT"
        sc = 10 if crop == "WHEAT" else 80

        # ── MARKET ──
        O = []

        # SELL everything (every step)
        for p in PRODUCTS:
            q = int(shed.get(p,0))
            if q <= 0: continue
            if p == "WHEAT":
                keep = na + 2  # keep for feed
                sell = q - keep
                if sell > 0 and len(O) < MAX_ORDERS:
                    O.append(["SELL", "WHEAT", sell])
            elif len(O) < MAX_ORDERS:
                O.append(["SELL", p, q])

        # BUY_ANIMAL (every step until target, then stop)
        if atot < self.an and day <= 15 and hour <= 3:
            need = min(2, self.an - atot)
            ac = ACOST[self.at]
            if need > 0 and money >= need * ac + 100 and len(O) < MAX_ORDERS:
                O.append(["BUY_ANIMAL", self.at, need])

        # BUY_LAND - only buy NE land when very rich
        if hour == 0 and self.nl == 0:
            if day >= 12 and money >= 3000 and len(O) < MAX_ORDERS:
                O.append(["BUY_LAND"])
                self.nl += 1

        # BUY_SEED
        cs = int(seeds.get(crop, 0))
        plant_slots = max(0, ne - max(0, self.an - atot))
        if plant_slots > cs and len(O) < MAX_ORDERS:
            buy = min(plant_slots - cs, 10)
            if buy * sc <= max(money * 0.5, 30):
                O.append(["BUY_SEED", crop, buy])
        if cs < 3 and day >= 2 and len(O) < MAX_ORDERS:
            buy = min(5, max(1, 5 - cs))
            if buy * sc <= money * 0.3:
                O.append(["BUY_SEED", crop, buy])

        # BUY_PRODUCT WHEAT for feed (buy generously)
        wi = int(shed.get("WHEAT", 0))
        wc = sum(int(invs[w].get("WHEAT",0)) if w<len(invs) else 0 for w in range(nw))
        if na > 0 and wi + wc < na * 2 and len(O) < MAX_ORDERS:
            need = na * 2 - wi - wc
            if money >= need * 30:
                O.append(["BUY_PRODUCT", "WHEAT", min(need, 8)])

        # HIRE
        if hour == 0:
            sl = MAX_ORDERS - len(O)
            if money >= 88: nh = min(9, sl)
            elif money >= 33: nh = min(7, sl)
            elif money >= 12: nh = min(5, sl)
            elif money >= 4: nh = min(3, sl)
            else: nh = 0
            for _ in range(nh):
                if len(O) < MAX_ORDERS: O.append(["HIRE"])

        # Final liquidation
        if step >= LAST_STEP - 2:
            O = []
            for p in PRODUCTS:
                q = int(shed.get(p,0))
                if q > 0 and len(O) < MAX_ORDERS: O.append(["SELL", p, q])

        # ── TASKS ──
        tasks = []
        for p in WH: tasks.append((1000, p, "HARVEST"))
        for p in AH: tasks.append((950, p, "HARVEST"))
        for p in WW:
            t = ti[p]
            urg = 900 if t.get("consecutive_unwatered",0) >= 1 else 800
            tasks.append((urg, p, "WATER"))
        for p in AF: tasks.append((850, p, "FEED"))
        for p in AC: tasks.append((650, p, "CARE"))
        for p in ES:
            t = ti[p]
            for an in ANIMAL_SET:
                if int(shed.get(an,0)) > 0 and STRUCT_MAP[an] == t.get("kind"):
                    tasks.append((750, p, "PLACE_"+an)); break
        sn = max(0, self.an - atot)
        if sn > 0:
            ess = sorted(E, key=lambda p: _d(p,(4,4)))
            for p in ess[:sn]: tasks.append((500, p, "BUILD"))
        ca = int(seeds.get(crop, 0))
        for p in E:
            if ca > 0: tasks.append((400, p, "PLANT_"+crop)); ca -= 1
        for p in AFT: tasks.append((100, p, "FERT"))
        for p in WEEDS: tasks.append((250, p, "DIG"))
        tasks.sort(key=lambda t: -t[0])

        # ── WORKERS ──
        acts = []; cl = set(); ut = set()
        pc = {}; pl = {c: int(seeds.get(c,0)) for c in ("MELON","WHEAT")}
        rem = TPD - hour
        for w in range(nw):
            pos = tuple(pos_list[w])
            inv = invs[w] if w < len(invs) else {}
            acts.append(self._w(pos, inv, tasks, ut, cl, ti, shed, seeds,
                                day, hour, rem, pc, pl, crop, ES, E, WW, AF, na))
        if step >= LAST_STEP - 1:
            for w in range(nw):
                pos = tuple(pos_list[w]); inv = invs[w] if w<len(invs) else {}
                if _sh(pos) and any(int(v)>0 for v in inv.values()): acts[w] = ["DROP"]
        # Validate PLANTs
        pv = {}
        for a in acts:
            if isinstance(a,list) and len(a)>=2 and a[0]=="PLANT":
                pv[a[1]] = pv.get(a[1],0) + 1
        for c, n in pv.items():
            av = int(seeds.get(c,0))
            if n > av:
                ex = n - av
                for w in range(len(acts)-1,-1,-1):
                    if ex<=0: break
                    if acts[w]==["PLANT",c]: acts[w]=["PASS"]; ex-=1
        return {"farmer": acts[0] if acts else ["PASS"],
                "hands": acts[1:] if len(acts)>1 else [],
                "market": O[:MAX_ORDERS]}

    def _w(self, pos, inv, tasks, ut, cl, ti, shed, seeds,
           day, hour, rem, pc, pl, crop, ES, E, WW, AF, na):
        hp, ha, wh, tc = False, None, int(inv.get("WHEAT",0)), 0
        for it, q in inv.items():
            q = int(q)
            if q<=0: continue
            tc += q
            if it in ANIMAL_SET: ha = it
            elif it != "WHEAT": hp = True

        if hour >= 21 and tc > 0:
            if _sh(pos): return ["DROP"]
            return [_t(pos, _ns(pos)) or "PASS"]
        if hp:
            if _sh(pos): return ["DROP"]
            return [_t(pos, _ns(pos)) or "PASS"]
        if ha:
            tk = STRUCT_MAP[ha]
            best, bd = None, 999
            for sp in ES:
                if sp in cl: continue
                t = ti.get(sp)
                if isinstance(t,dict) and t.get("kind")==tk:
                    dd = _d(pos,sp)
                    if dd < bd: bd,best = dd,sp
            if best:
                cl.add(best)
                if pos == best: return ["PLACE", ha]
                return [_t(pos, best) or "PASS"]
            if ti.get(pos) is None and pos not in cl:
                cl.add(pos)
                return ["BUILD_COOP" if tk=="COOP" else "BUILD_PASTURE"]
            best, bd = None, 999
            for ep in E:
                if ep in cl: continue
                dd = _d(pos, ep)
                if dd < bd: bd, best = dd, ep
            if best and bd < rem-3:
                cl.add(best)
                return [_t(pos, best) or "PASS"]
            if _sh(pos): return ["DROP"]
            return [_t(pos, _ns(pos)) or "PASS"]

        if _sh(pos) and hour <= 18:
            for an in ANIMAL_SET:
                if int(shed.get(an,0)) > 0:
                    ast = STRUCT_MAP[an]
                    has_match = any(sp not in cl and isinstance(ti.get(sp),dict)
                                   and ti[sp].get("kind")==ast for sp in ES)
                    if has_match or E:
                        return ["PICKUP", an, 1]
            if wh == 0 and AF and int(shed.get("WHEAT",0)) > 0:
                return ["PICKUP", "WHEAT", min(8, int(shed.get("WHEAT",0)))]

        th = ti.get(pos)
        if isinstance(th, dict) and pos not in cl:
            k = th.get("kind")
            if k == "PLANT":
                if int(th.get("yield_units",0)) > 0:
                    cr = th.get("crop","WHEAT")
                    if day - th.get("planted_day",0) >= CROPS_FYD.get(cr,2):
                        cl.add(pos); return ["HARVEST"]
                if not th.get("watered_today"):
                    cl.add(pos); return ["WATER"]
            elif "animal" in th:
                if int(th.get("yield_units",0)) > 0:
                    cl.add(pos); return ["HARVEST"]
                if not th.get("fed_today") and wh > 0:
                    cl.add(pos); return ["FEED"]
                if not th.get("cared_today"):
                    cl.add(pos); return ["CARE"]
                if th.get("fertilizer_available"):
                    cl.add(pos); return ["COLLECT_FERTILIZER"]
            elif k == "WEED":
                cl.add(pos); return ["DIG"]
        elif th is None and pos not in cl:
            u = pc.get(crop,0)
            if u < pl.get(crop,0):
                pc[crop] = u+1; cl.add(pos); return ["PLANT", crop]

        bs, bi, bt = -9999, -1, None
        for i, (prio, tp, tt) in enumerate(tasks):
            if i in ut or tp in cl: continue
            dd = _d(pos, tp)
            if dd >= rem-2: continue
            if tt.startswith("PLANT_"):
                cr = tt[6:]
                if pc.get(cr,0) >= pl.get(cr,0): continue
            adj = prio
            if tt == "FEED" and wh <= 0:
                sd = _d(pos, _ns(pos)); dd = sd + _d(_ns(pos), tp)
                if dd >= rem-2: continue
                adj -= 200
            s = adj - dd*12
            if s > bs: bs, bi, bt = s, i, (prio,tp,tt)

        if bt:
            ut.add(bi); cl.add(bt[1])
            _, tp, tt = bt
            if tt.startswith("PLANT_"): pc[tt[6:]] = pc.get(tt[6:],0) + 1
            if tt == "FEED" and wh <= 0:
                if _sh(pos) and int(shed.get("WHEAT",0)) > 0:
                    return ["PICKUP", "WHEAT", min(8, int(shed.get("WHEAT",0)))]
                return [_t(pos, _ns(pos)) or "PASS"]
            if pos == tp: return self._do(tt, inv, seeds)
            return [_t(pos, tp) or "PASS"]

        if tc > 0:
            if _sh(pos): return ["DROP"]
            return [_t(pos, _ns(pos)) or "PASS"]
        bt2, bd2 = None, 999
        for p in WW:
            if p not in cl:
                dd = _d(pos,p)
                if dd < bd2: bd2,bt2 = dd,p
        if bt2 is None:
            for p in E:
                if p not in cl:
                    dd = _d(pos,p)
                    if dd < bd2: bd2,bt2 = dd,p
        if bt2 and bd2 > 0:
            cl.add(bt2); return [_t(pos, bt2) or "PASS"]
        return ["PASS"]

    def _do(self, tt, inv, seeds):
        if tt == "HARVEST": return ["HARVEST"]
        if tt == "WATER": return ["WATER"]
        if tt == "FEED": return ["FEED"] if int(inv.get("WHEAT",0))>0 else ["PASS"]
        if tt == "CARE": return ["CARE"]
        if tt == "FERT": return ["COLLECT_FERTILIZER"]
        if tt == "DIG": return ["DIG"]
        if tt == "BUILD":
            st = STRUCT_MAP.get(self.at, "PASTURE")
            return ["BUILD_COOP" if st=="COOP" else "BUILD_PASTURE"]
        if tt.startswith("PLANT_"):
            cr = tt[6:]
            if int(seeds.get(cr,0)) > 0: return ["PLANT", cr]
            return ["PASS"]
        if tt.startswith("PLACE_"):
            an = tt[6:]
            if int(inv.get(an,0)) > 0: return ["PLACE", an]
            return ["PASS"]
        return ["PASS"]

_A = None
def agent(obs, config=None):
    global _A
    if _A is None or int(obs["step"]) == 0: _A = Agent()
    return _A.act(obs)
