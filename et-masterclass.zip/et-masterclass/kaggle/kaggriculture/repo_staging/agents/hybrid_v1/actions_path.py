"""Resolve actions.json path — checks local dir first, then shared/."""
from pathlib import Path
def get_actions_path(reference_file):
    here = Path(reference_file).resolve().parent
    local = here / "actions.json"
    if local.exists():
        return local
    shared = here.parent.parent / "shared" / "actions.json"
    if shared.exists():
        return shared
    raise FileNotFoundError(f"actions.json not found in {here} or {shared}")
