"""Self-contained sheep routine: a set of workers run pastures independently of any tape.

Designed to be bolted onto a tape agent as an extra-hands layer once a YARN_STORE unlocks,
but runnable standalone (farmer + hired hands) for validation in the real engine.
Standard library only.
"""

SHED_TILES = [(3, 3), (4, 3), (3, 4), (2, 3), (2, 4), (3, 2), (4, 2), (2, 2), (1, 3), (1, 4)]
ACCESS = (4, 4)  # NW shed-access tile (also the farmer's daily spawn)
TPD = 24


def _step_toward(pos, target):
    x, y = pos
    tx, ty = target
    if x < tx: return ["EAST"]
    if x > tx: return ["WEST"]
    if y < ty: return ["SOUTH"]
    if y > ty: return ["NORTH"]
    return None


class SheepModule:
    def __init__(self, n_sheep=8, sheep_per_worker=3, care=True, start_day=0, animal="SHEEP"):
        self.animal = animal
        self.structure = "BUILD_COOP" if animal == "GOOSE" else "BUILD_PASTURE"
        self.cost = {"SHEEP": 500, "COW": 400, "GOOSE": 300}[animal]
        self.product = {"SHEEP": "WOOL", "COW": "MILK", "GOOSE": "EGG"}[animal]
        self.n_sheep = n_sheep
        self.spw = sheep_per_worker
        self.care = care
        self.start_day = start_day
        self.tiles = SHED_TILES[:n_sheep]
        self.itin = {}      # worker idx -> remaining tile itinerary for today
        self.done = {}      # worker idx -> finished route today (heading home)
        self.day = -1
        self.pending_buy = 0

    def n_workers(self):
        return -(-len(self.tiles) // self.spw)  # ceil

    def act(self, obs):
        step = obs["step"]; day = step // TPD; hour = step % TPD
        farm = obs["farms"][obs["player"]]
        priv = obs["private"]; shed = priv["shed"]; tiles = farm["tiles"]
        prices = obs["market"]["prices"]
        positions = [tuple(farm["farmer"])] + [tuple(h) for h in farm["hands"]]
        invs = priv["inventories"]
        market = []

        if day < self.start_day:
            return {"farmer": ["PASS"], "hands": [], "market": []}

        if day != self.day:                      # new day: reset itineraries
            self.day = day
            self.itin = {w: list(self.tiles[w * self.spw:(w + 1) * self.spw]) for w in range(self.n_workers())}
            self.done = {}

        # ---- market orders (processed after unit actions this step) ----
        placed = sum(1 for t in self.tiles if isinstance(tiles[t[1]][t[0]], dict) and "animal" in tiles[t[1]][t[0]])
        in_shed = shed.get(self.animal, 0)
        carried_sheep = sum(i.get(self.animal, 0) for i in invs)
        need = len(self.tiles) - placed - in_shed - carried_sheep
        if hour == 0:
            hires = self.n_workers() - 1 - len(farm["hands"])
            market += [["HIRE"]] * max(0, hires)
        if need > 0 and farm.get("money", 3000) >= self.cost:
            n = min(need, int(farm.get("money", 3000) // self.cost))
            market.append(["BUY_ANIMAL", self.animal, n])
        want_wheat = (placed + need) - shed.get("WHEAT", 0) - sum(i.get("WHEAT", 0) for i in invs)
        if want_wheat > 0 and hour <= 1:
            market.append(["BUY_PRODUCT", "WHEAT", want_wheat])
        # sell wool + fertilizer as soon as they hit the shed (steep item first)
        if shed.get(self.product, 0) > 0:
            market.append(["SELL", self.product, shed[self.product]])
        if shed.get("FERTILIZER", 0) > 0:
            market.append(["SELL", "FERTILIZER", shed["FERTILIZER"]])
        if hour == TPD - 1:                       # last turn: dump anything else
            for it, q in shed.items():
                if q > 0 and it not in (self.product, "FERTILIZER", self.animal, "WHEAT"):
                    market.append(["SELL", it, q])

        # ---- worker actions ----
        acts = []
        for w, pos in enumerate(positions):
            inv = invs[w] if w < len(invs) else {}
            if w >= self.n_workers():
                acts.append(["PASS"]); continue
            my_tiles = self.tiles[w * self.spw:(w + 1) * self.spw]
            my_need_sheep = sum(1 for t in my_tiles if not (isinstance(tiles[t[1]][t[0]], dict) and "animal" in tiles[t[1]][t[0]]))
            at_access = pos in {(3, 3), (4, 3), (3, 4), (4, 4)} or pos == ACCESS
            is_access = pos[0] in (4, 5) and pos[1] in (4, 5)

            # phase 0: at the shed, stock up
            if not self.itin.get(w) and not self.done.get(w):
                self.itin[w] = list(my_tiles)
            if self.itin.get(w) and hour <= 2 and is_access and inv.get("WHEAT", 0) < len(my_tiles):
                if shed.get("WHEAT", 0) > 0:
                    acts.append(["PICKUP", "WHEAT", len(my_tiles) - inv.get("WHEAT", 0)])
                    continue
            if self.itin.get(w) and is_access and my_need_sheep > inv.get(self.animal, 0) and shed.get(self.animal, 0) > 0:
                acts.append(["PICKUP", self.animal, my_need_sheep - inv.get(self.animal, 0)])
                continue

            # phase 1: service tiles
            if self.itin.get(w):
                target = self.itin[w][0]
                if pos != target:
                    acts.append(_step_toward(pos, target))
                    continue
                tile = tiles[target[1]][target[0]]
                if tile is None or (isinstance(tile, dict) and tile.get("kind") == "WEED"):
                    acts.append([self.structure] if tile is None else ["DIG"])
                    continue
                if isinstance(tile, dict) and tile.get("kind") == "PLANT":
                    acts.append(["DIG"])
                    continue
                if isinstance(tile, dict) and tile.get("kind") in ("PASTURE", "COOP") and "animal" not in tile:
                    if inv.get(self.animal, 0) > 0:
                        acts.append(["PLACE", self.animal])
                        continue
                    self.itin[w].pop(0)
                    acts.append(["PASS"])
                    continue   # no sheep yet, come back tomorrow
                if isinstance(tile, dict) and "animal" in tile:
                    if not tile["fed_today"] and inv.get("WHEAT", 0) > 0:
                        acts.append(["FEED"])
                        continue
                    if self.care and not tile["cared_today"]:
                        acts.append(["CARE"])
                        continue
                    if tile.get("fertilizer_available"):
                        acts.append(["COLLECT_FERTILIZER"])
                        continue
                    if tile.get("yield_units", 0) > 0:
                        acts.append(["HARVEST"])
                        continue
                self.itin[w].pop(0)
                if not self.itin[w]:
                    self.done[w] = True
                acts.append(["PASS"])
                continue

            # phase 2: go home and drop
            if not is_access:
                acts.append(_step_toward(pos, ACCESS))
                continue
            if any(v > 0 for k, v in inv.items() if k != self.animal):
                acts.append(["DROP"])
                continue
            acts.append(["PASS"])

        return {"farmer": acts[0], "hands": acts[1:], "market": market[:10]}


_MOD = None


def agent(obs, config=None):
    global _MOD
    if _MOD is None:
        _MOD = SheepModule()
    return _MOD.act(obs)
