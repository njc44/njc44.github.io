#!/usr/bin/env python3
"""Fix Search: Multi-step opening optimizer using exact Kaggle engine market model.

Takes v3 tracer signals (opening costs $X, sell timing Y steps behind) and searches
over multi-step opening configurations to find the optimal fix.

Uses the exact _process_market lockstep logic from kaggle_environments 1.32.7.

Usage:
    python fix_search.py --base v45 --opponents jaxa623,tetsutani,pipe7
    python fix_search.py --sweep-openings  # standalone opening sweep
"""
import json
import math
import os
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# EXACT ENGINE MARKET MODEL (from kaggriculture.py)
# ═══════════════════════════════════════════════════════════

HINGE_GAIN = 8.0
MARKET_PARAMS = {
    "WHEAT":      {"base":  25, "I0": 10000, "T": 400, "below_func": "sqrt",   "below_target": 0.80, "above_func": "log",    "above_target": 0.20},
    "CARROT":     {"base":  35, "I0": 10000, "T": 450, "below_func": "hinge",  "below_target": 1.00, "above_func": "sqrt",   "above_target": 0.70},
    "TOMATO":     {"base":  60, "I0": 10000, "T": 200, "below_func": "hinge",  "below_target": 0.40, "above_func": "sqrt",   "above_target": 0.60},
    "STRAWBERRY": {"base": 120, "I0": 10000, "T": 100, "below_func": "sqrt",   "below_target": 0.70, "above_func": "linear", "above_target": 1.60},
    "MELON":      {"base": 250, "I0": 10000, "T": 300, "below_func": "log",    "below_target": 0.20, "above_func": "sq",     "above_target": 3.60},
    "EGG":        {"base":  50, "I0": 10000, "T": 332, "below_func": "hinge",  "below_target": 0.40, "above_func": "log",    "above_target": 0.20},
    "MILK":       {"base": 160, "I0": 10000, "T": 122, "below_func": "sqrt",   "below_target": 0.60, "above_func": "linear", "above_target": 1.60},
    "WOOL":       {"base": 200, "I0": 10000, "T": 105, "below_func": "log",    "below_target": 0.20, "above_func": "sq",     "above_target": 3.20},
    "FERTILIZER": {"base": 100, "I0": 10000, "T": 200, "below_func": "linear", "below_target": 0.40, "above_func": "linear", "above_target": 0.40},
}

SEED_COST = {"WHEAT": 10, "CARROT": 20, "TOMATO": 50, "STRAWBERRY": 100, "MELON": 80}
ANIMAL_COST = {"GOOSE": 300, "COW": 400, "SHEEP": 500}
FEED_WHEAT_NEEDED = 5  # wheat units needed for animal feed


def _shape(func, x, T=None):
    x = max(0.0, x)
    if func == "linear": return x
    if func == "sq": return x * x
    if func == "sqrt": return math.sqrt(x)
    if func == "log": return math.log(1.0 + x)
    if func == "hinge":
        if not T or T <= 0: return x
        u = x / T
        return u + HINGE_GAIN * max(0.0, u - 1.0) ** 2
    return x


def market_price(item, inventory):
    """Exact Kaggle engine price formula."""
    p = MARKET_PARAMS[item]
    base, I0, T = p["base"], p["I0"], p["T"]
    if inventory < I0:
        amp = p["below_target"] * base / _shape(p["below_func"], T, T)
        v = base + amp * _shape(p["below_func"], I0 - inventory, T)
    else:
        amp = p["above_target"] * base / _shape(p["above_func"], T, T)
        v = base - amp * _shape(p["above_func"], inventory - I0, T)
    return max(1, int(round(v)))


# ═══════════════════════════════════════════════════════════
# EXACT LOCKSTEP SETTLEMENT (from _process_market)
# ═══════════════════════════════════════════════════════════

def simulate_lockstep(orders_a, orders_b, inv=10000, money_a=3000, money_b=3000, shed_a=0, shed_b=0):
    """Exact replica of kaggriculture.py _process_market lockstep.

    Both players' units at the same index are quoted at the SAME inventory,
    then both committed. This is the critical mechanism that determines
    which opening is optimal.

    Returns: dict with final state for both players.
    """
    def parse(orders):
        result = []
        for o in orders:
            if not o or not isinstance(o, (list, tuple)):
                result.append(None); continue
            op = o[0]
            if op in ("HIRE", "BUY_LAND"):
                result.append({"type": op}); continue
            if len(o) < 3:
                result.append(None); continue
            try:
                n = int(o[2])
            except (ValueError, TypeError):
                result.append(None); continue
            if n <= 0:
                result.append(None); continue
            result.append({"type": op, "item": o[1], "remaining": n})
        return result

    qa, qb = parse(orders_a), parse(orders_b)
    max_idx = max(len(qa), len(qb))
    sheds = [shed_a, shed_b]
    moneys = [money_a, money_b]

    for i in range(max_idx):
        ostates = [
            qa[i] if i < len(qa) else None,
            qb[i] if i < len(qb) else None,
        ]

        # Atomic orders (HIRE, BUY_LAND) — skip in market sim
        for pid in range(2):
            if ostates[pid] and ostates[pid]["type"] in ("HIRE", "BUY_LAND"):
                ostates[pid] = None

        # Per-unit lockstep loop
        escape = 0
        while True:
            escape += 1
            if escape > 100000:
                break

            quoted = [None, None]
            for pid, ostate in enumerate(ostates):
                if ostate is None or ostate.get("remaining", 0) <= 0:
                    continue
                op, item = ostate["type"], ostate["item"]
                if op == "SELL" and item in MARKET_PARAMS:
                    quoted[pid] = ("SELL", item, market_price(item, inv))
                elif op == "BUY_PRODUCT" and item in ("WHEAT", "FERTILIZER"):
                    quoted[pid] = ("BUY_PRODUCT", item, market_price(item, inv - 1))
                elif op == "BUY_SEED" and item in SEED_COST:
                    quoted[pid] = ("BUY_SEED", item, SEED_COST[item])
                elif op == "BUY_ANIMAL" and item in ANIMAL_COST:
                    quoted[pid] = ("BUY_ANIMAL", item, ANIMAL_COST[item])
                else:
                    ostates[pid] = None

            if all(q is None for q in quoted):
                break

            committed_any = False
            for pid, q in enumerate(quoted):
                if q is None:
                    continue
                op, item, p = q
                ostate = ostates[pid]

                if op == "SELL":
                    if sheds[pid] <= 0:
                        ostates[pid] = None
                        continue
                    sheds[pid] -= 1
                    moneys[pid] += p
                    if p > 1:
                        inv += 1
                    ostate["remaining"] -= 1
                    committed_any = True
                elif op == "BUY_PRODUCT":
                    if moneys[pid] < p or sheds[pid] >= 100:
                        ostates[pid] = None
                        continue
                    moneys[pid] -= p
                    sheds[pid] += 1
                    inv -= 1
                    ostate["remaining"] -= 1
                    committed_any = True
                elif op == "BUY_SEED":
                    if moneys[pid] < p:
                        ostates[pid] = None
                        continue
                    moneys[pid] -= p
                    ostate["remaining"] -= 1
                    committed_any = True
                elif op == "BUY_ANIMAL":
                    if moneys[pid] < p or sheds[pid] >= 100:
                        ostates[pid] = None
                        continue
                    moneys[pid] -= p
                    sheds[pid] += 1
                    ostate["remaining"] -= 1
                    committed_any = True

            if not committed_any:
                break

    return {
        "money_a": moneys[0], "money_b": moneys[1],
        "shed_a": sheds[0], "shed_b": sheds[1],
        "inv": inv,
    }


# ═══════════════════════════════════════════════════════════
# MULTI-STEP OPENING SEARCH
# ═══════════════════════════════════════════════════════════

# Known opponent openings (extracted from top public agents)
KNOWN_OPENINGS = {
    "v45_base": {"step0": [["BUY_PRODUCT", "WHEAT", 5], ["BUY_PRODUCT", "WHEAT", 10], ["SELL", "WHEAT", 60]]},
    "v45_open70": {"step0": [["BUY_PRODUCT", "WHEAT", 70], ["SELL", "WHEAT", 70]]},
    "pipe7": {"step0": [["BUY_PRODUCT", "WHEAT", 5], ["SELL", "WHEAT", 5]]},
    "pipe8": {"step0": [["BUY_PRODUCT", "WHEAT", 5]]},
    "jaxa623": {"step0": [["BUY_PRODUCT", "WHEAT", 10], ["SELL", "WHEAT", 10]]},
    "tetsutani": {"step0": [["BUY_PRODUCT", "WHEAT", 69], ["SELL", "WHEAT", 69]]},
    "ahmed_v46": {"step0": [["BUY_PRODUCT", "WHEAT", 7], ["SELL", "WHEAT", 2]]},
}


def discover_target_openings(agent_paths):
    """Auto-discover openings from target agents by extracting route 0 step 0."""
    import importlib.util
    for name, path in agent_paths.items():
        if name in KNOWN_OPENINGS:
            continue
        try:
            spec = importlib.util.spec_from_file_location("_tmp", str(path))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            routes = getattr(mod, "_ROUTES", None)
            if routes and 0 in routes and len(routes[0]) > 0:
                step0_market = routes[0][0].get("market", [])
                if step0_market:
                    KNOWN_OPENINGS[name] = {"step0": step0_market}
        except Exception:
            pass


# Native v43 tape step 1 market (from route 0)
NATIVE_STEP1 = [["SELL", "WHEAT", 13], ["BUY_PRODUCT", "WHEAT", 5]]


def evaluate_opening_3step(buy_n, sell_m, use_lift, lift_qty, opponent_step0, opponent_step1=None):
    """Evaluate a 3-step opening sequence against one opponent.

    Step 0: BUY buy_n / SELL sell_m
    Step 1: If use_lift, BUY lift_qty wheat (to inflate rival's price). Else native tape.
    Step 2: If use_lift, SELL lift_qty wheat back.

    Returns: dict with per-step and total advantage.
    """
    if opponent_step1 is None:
        opponent_step1 = NATIVE_STEP1

    # Our step 0 orders
    our_step0 = []
    if buy_n > 0:
        our_step0.append(["BUY_PRODUCT", "WHEAT", buy_n])
    if sell_m > 0:
        our_step0.append(["SELL", "WHEAT", sell_m])

    # Step 0 settlement
    s0 = simulate_lockstep(our_step0, opponent_step0)
    step0_adv = (s0["money_a"] - 3000) - (s0["money_b"] - 3000)

    # Step 1
    if use_lift and s0["money_a"] >= 2860:
        our_step1 = [["BUY_PRODUCT", "WHEAT", lift_qty]]
        opp_step1 = opponent_step1
    else:
        net_wheat = buy_n - sell_m
        if net_wheat >= FEED_WHEAT_NEEDED:
            our_step1 = []
        else:
            our_step1 = NATIVE_STEP1
        opp_step1 = opponent_step1

    s1 = simulate_lockstep(our_step1, opp_step1, s0["inv"], s0["money_a"], s0["money_b"], s0["shed_a"], s0["shed_b"])
    step1_adv = (s1["money_a"] - s0["money_a"]) - (s1["money_b"] - s0["money_b"])

    # Step 2: sell back lift wheat if used
    if use_lift and s0["money_a"] >= 2860:
        our_step2 = [["SELL", "WHEAT", lift_qty]]
    else:
        our_step2 = []

    s2 = simulate_lockstep(our_step2, [], s1["inv"], s1["money_a"], s1["money_b"], s1["shed_a"], s1["shed_b"])
    step2_adv = (s2["money_a"] - s1["money_a"]) - (s2["money_b"] - s1["money_b"])

    total = step0_adv + step1_adv + step2_adv

    return {
        "buy": buy_n, "sell": sell_m, "net_wheat": buy_n - sell_m,
        "use_lift": use_lift, "lift_qty": lift_qty if use_lift else 0,
        "step0_adv": step0_adv, "step1_adv": step1_adv, "step2_adv": step2_adv,
        "total_adv": total,
        "final_money_a": s2["money_a"], "final_money_b": s2["money_b"],
        "final_shed_a": s2["shed_a"],
    }


def sweep_openings(opponent_openings=None, lift_qtys=None, max_buy=10, max_lift=30):
    """Sweep all practical opening configurations against known opponents.

    Args:
        max_buy: Maximum BUY quantity (default 10). Higher values bankrupt the agent
                 when combined with step-1 non-market costs (~$1812 for hires + animals).
        max_lift: Maximum lift quantity (default 30). BUY 40+ at step 1 leaves <$100
                  after hires + animals, causing mid-game collapse.

    Returns: list of results sorted by average advantage, with the recommended opening.
    """
    if opponent_openings is None:
        opponent_openings = {k: v["step0"] for k, v in KNOWN_OPENINGS.items()}
    if lift_qtys is None:
        lift_qtys = [0] + [q for q in [20, 30] if q <= max_lift]

    results = []

    for buy_n in range(5, max_buy + 1):  # capped to prevent bankruptcy
        for sell_m in range(0, buy_n + 1):
            net_wheat = buy_n - sell_m
            can_lift = net_wheat >= FEED_WHEAT_NEEDED  # only if we already have feed wheat

            for lift_qty in lift_qtys:
                use_lift = lift_qty > 0 and can_lift

                if lift_qty > 0 and not can_lift:
                    continue  # can't lift without feed wheat

                per_opponent = {}
                total_adv = 0
                n_opponents = 0

                for opp_name, opp_step0 in opponent_openings.items():
                    result = evaluate_opening_3step(buy_n, sell_m, use_lift, lift_qty, opp_step0)
                    per_opponent[opp_name] = result
                    total_adv += result["total_adv"]
                    n_opponents += 1

                # Mirror matchup
                our_step0 = []
                if buy_n > 0:
                    our_step0.append(["BUY_PRODUCT", "WHEAT", buy_n])
                if sell_m > 0:
                    our_step0.append(["SELL", "WHEAT", sell_m])
                mirror = evaluate_opening_3step(buy_n, sell_m, use_lift, lift_qty, our_step0)
                per_opponent["mirror"] = mirror
                total_adv += mirror["total_adv"]
                n_opponents += 1

                avg_adv = total_adv / n_opponents if n_opponents > 0 else 0

                results.append({
                    "buy": buy_n, "sell": sell_m, "net_wheat": net_wheat,
                    "use_lift": use_lift, "lift_qty": lift_qty if use_lift else 0,
                    "avg_advantage": avg_adv,
                    "total_advantage": total_adv,
                    "per_opponent": per_opponent,
                })

    # Filter out configurations that bankrupt the agent.
    # Step 1 non-market costs (from the native tape): 5 HIRE ($12) + 2 COW ($800) + 2 SHEEP ($1000) = $1812
    # Plus need ~$500 buffer for day 2+ operations (seeds, more hires, etc.)
    STEP1_NON_MARKET_COST = 1812  # 5 hires + 2 COW + 2 SHEEP
    MIN_BUFFER_AFTER_ALL = 500
    MIN_CASH_AFTER_STEP2 = STEP1_NON_MARKET_COST + MIN_BUFFER_AFTER_ALL  # ~$2312

    filtered = []
    for r in results:
        # Check worst-case REAL cash remaining: final_money minus non-market step-1 costs
        # The simulator only tracks market trades; step 1 also costs ~$1812 for hires + animals
        min_real_cash = float('inf')
        for opp_name, opp_data in r["per_opponent"].items():
            final_money = opp_data.get("final_money_a", 3000)
            real_cash = final_money - STEP1_NON_MARKET_COST
            if real_cash < min_real_cash:
                min_real_cash = real_cash
        r["min_cash_remaining"] = min_real_cash
        if min_real_cash >= MIN_BUFFER_AFTER_ALL:
            filtered.append(r)

    if not filtered:
        # Fallback: relax constraint progressively
        for threshold in [1500, 1000, 500, 0]:
            filtered = [r for r in results if r.get("min_cash_remaining", 0) >= threshold]
            if filtered:
                break
        if not filtered:
            filtered = results

    filtered.sort(key=lambda x: -x["avg_advantage"])
    return filtered


def recommend_opening(results):
    """Pick the best opening from sweep results.

    Preferences:
    1. Highest average advantage
    2. Among ties, prefer non-negative mirror matchup (robust against clones)
    3. Among ties, prefer smaller round trip (less market distortion)
    """
    if not results:
        return None

    best = results[0]
    for r in results[1:]:
        if r["avg_advantage"] < best["avg_advantage"] - 0.5:
            break  # no more ties
        # Prefer neutral/positive mirror
        r_mirror = r["per_opponent"].get("mirror", {}).get("total_adv", 0)
        b_mirror = best["per_opponent"].get("mirror", {}).get("total_adv", 0)
        if r_mirror > b_mirror:
            best = r
        elif r_mirror == b_mirror and r["buy"] < best["buy"]:
            best = r

    return best


def print_sweep_report(results, top_n=20):
    """Print human-readable sweep report."""
    print("=" * 130)
    print("OPENING SWEEP RESULTS (multi-step, exact engine lockstep)")
    print("=" * 130)

    # Get opponent names from first result
    opp_names = [k for k in results[0]["per_opponent"].keys() if k != "mirror"][:5]

    header = f"{'Rank':>4} {'BUY':>4} {'SELL':>4} {'Net':>4} {'Lift':>4} |"
    for name in opp_names:
        header += f" {name[:8]:>9}"
    header += f" {'mirror':>9} | {'AVG':>7}"
    print(header)
    print("-" * 130)

    for i, r in enumerate(results[:top_n]):
        line = f"{i+1:>4} {r['buy']:>4} {r['sell']:>4} {r['net_wheat']:>4} {r['lift_qty']:>4} |"
        for name in opp_names:
            adv = r["per_opponent"].get(name, {}).get("total_adv", 0)
            line += f" {adv:>+9.0f}"
        mirror_adv = r["per_opponent"].get("mirror", {}).get("total_adv", 0)
        line += f" {mirror_adv:>+9.0f} | {r['avg_advantage']:>+7.1f}"
        print(line)

    # Recommendation
    rec = recommend_opening(results)
    if rec:
        lift_str = f" + turn-1 lift BUY {rec['lift_qty']}" if rec['use_lift'] else ""
        print(f"\n>>> RECOMMENDED: BUY {rec['buy']} / SELL {rec['sell']}{lift_str}"
              f" (avg advantage: ${rec['avg_advantage']:+.1f})")

    return rec


# ═══════════════════════════════════════════════════════════
# AGENT CODE GENERATOR
# ═══════════════════════════════════════════════════════════

def generate_opening_wrapper(rec, base_agent_path, output_path):
    """Generate the opening wrapper code for the recommended configuration.

    Takes the fix_search recommendation and produces a working agent wrapper
    that can be appended to (or wrap around) the base agent.
    """
    buy_n = rec["buy"]
    sell_m = rec["sell"]
    net_wheat = rec["net_wheat"]
    use_lift = rec["use_lift"]
    lift_qty = rec.get("lift_qty", 30)

    step0_orders = []
    if buy_n > 0:
        step0_orders.append(f"['BUY_PRODUCT','WHEAT',{buy_n}]")
    if sell_m > 0:
        step0_orders.append(f"['SELL','WHEAT',{sell_m}]")
    step0_str = "[" + ",".join(step0_orders) + "]"

    wrapper = f'''
# ═══════════════════════════════════════════════════════════
# AUTOLOOP-GENERATED OPENING (fix_search.py)
# Configuration: BUY {buy_n} / SELL {sell_m} (net {net_wheat} wheat)
# Turn-1 lift: {"BUY " + str(lift_qty) if use_lift else "disabled"}
# Average advantage: ${rec["avg_advantage"]:+.1f} across opponent field
# ═══════════════════════════════════════════════════════════
_AL_PARENT = agent
_AL_STEP0 = {step0_str}
_AL_LIFT = {use_lift}
_AL_LIFT_QTY = {lift_qty}
_AL_LIFT_MIN_CASH = 2860
_AL_REPORT = dict(al_open=0, al_lift=0, al_errors=0)

def _al_is_wheat_opening(market):
    """Detect ANY wheat buy/sell opening pattern (v43, v45, or any derivative)."""
    if not market or not isinstance(market, list):
        return False
    has_wheat_buy = any(o[0] == 'BUY_PRODUCT' and len(o) >= 3 and o[1] == 'WHEAT' for o in market if isinstance(o, (list, tuple)) and o)
    return has_wheat_buy

def agent(observation, configuration=None):
    action = _AL_PARENT(observation, configuration)
    try:
        step = int(observation['step'])
        if step == 0:
            _AL_REPORT.update(al_open=0, al_lift=0, al_errors=0)
        standard = configuration is None or all(
            configuration.get(k, v) == v
            for k, v in [('boardSize', 10), ('turnsPerDay', 24), ('shedCapacity', 100),
                         ('maxMarketOrdersPerTurn', 10), ('startingMoney', 3000)]
        )
        if standard and step == 0 and _al_is_wheat_opening(action.get('market')):
            action = dict(action, market=[list(o) for o in _AL_STEP0])
            _AL_REPORT['al_open'] += 1
'''

    if use_lift:
        wrapper += f'''        elif standard and step == 1:
            market = [list(o) for o in action.get('market', [])]
            if len(market) >= 2 and market[0] == ['SELL', 'WHEAT', 13] and market[1] == ['BUY_PRODUCT', 'WHEAT', 5]:
                market = market[2:]  # strip redundant SELL 13 + BUY 5 (feed already in shed)
                _AL_REPORT['al_open'] += 1
                if _AL_LIFT and float(observation['farms'][int(observation['player'])]['money']) >= _AL_LIFT_MIN_CASH:
                    market = [['BUY_PRODUCT', 'WHEAT', _AL_LIFT_QTY]] + market
                    _AL_REPORT['al_lift'] = 1
                action = dict(action, market=market)
        elif standard and step == 2 and _AL_REPORT.get('al_lift'):
            action = dict(action, market=[['SELL', 'WHEAT', _AL_LIFT_QTY]] + [list(o) for o in action.get('market', [])][:9])
            _AL_REPORT['al_open'] += 1
'''

    wrapper += '''    except Exception:
        _AL_REPORT['al_errors'] += 1
    _AL_REPORT.update(getattr(_AL_PARENT, 'telemetry', {}))
    return action
agent.telemetry = _AL_REPORT
agent = globals().pop('agent')
'''

    return wrapper


# ═══════════════════════════════════════════════════════════
# SELL TIMING FIX: FRONTLOAD + ADVANCE SALES
# ═══════════════════════════════════════════════════════════

def analyze_sell_timing_signal(tracer_results):
    """Analyze v3 tracer results to determine if sell timing fix is needed.

    Returns: dict with signal strength and recommended parameters.
    """
    if not tracer_results:
        return {"signal": False}

    total_diffs = sum(t.get("n_sell_timing_diffs", 0) for t in tracer_results)
    avg_diffs = total_diffs / len(tracer_results) if tracer_results else 0

    # Aggregate sell timing by item across all traces
    combined = {}
    for t in tracer_results:
        for item, data in t.get("sell_timing_by_item", {}).items():
            if item not in combined:
                combined[item] = {"count": 0, "total_extra": 0}
            combined[item]["count"] += data["count"]
            combined[item]["total_extra"] += data["total_extra"]

    return {
        "signal": avg_diffs >= 5,  # 5+ sell timing diffs per game = clear signal
        "avg_diffs_per_game": avg_diffs,
        "total_diffs": total_diffs,
        "items": combined,
        "recommended_lookahead": 3 if avg_diffs >= 15 else 2,
        "recommended_horizon": 24 if avg_diffs >= 20 else 12,
    }


def generate_sell_timing_wrapper(sell_signal):
    """Generate frontload + advance_sales wrapper code.

    This is adapted from jaxa623's proven implementation with:
    - Market simulation validation for frontload safety
    - Configurable lookahead for advance_sales
    - Horizon override for extended pre-selling
    """
    lookahead = sell_signal.get("recommended_lookahead", 3)
    horizon = sell_signal.get("recommended_horizon", 24)

    wrapper = f'''
# ═══════════════════════════════════════════════════════════
# AUTOLOOP-GENERATED SELL TIMING FIX (fix_search.py pass 2)
# Signal: {sell_signal.get("avg_diffs_per_game", 0):.0f} sell timing diffs/game
# Config: lookahead={lookahead}, horizon={horizon}
# Adapted from jaxa623 "Beyond 48-0" (frontload + advance_sales)
# ═══════════════════════════════════════════════════════════
import math as _st_math

# --- Horizon override (widens sale reservation from 4 to {horizon} turns) ---
class _ST_Horizons(dict):
    def get(self, key, default=None):
        v = dict.get(self, key, default)
        return {horizon} if v is not None and v >= 4 else v

try:
    _PARENT_NS = {{k: v for k, v in globals().items() if k == '_PARENT_NS'}}.get('_PARENT_NS')
    if _PARENT_NS is None:
        # Find the namespace that contains _R37_HORIZONS
        for _ns_name in list(globals().keys()):
            _ns = globals().get(_ns_name)
            if isinstance(_ns, dict) and '_R37_HORIZONS' in _ns:
                _PARENT_NS = _ns
                break
    if _PARENT_NS and '_R37_HORIZONS' in _PARENT_NS:
        _PARENT_NS['_R37_HORIZONS'] = _ST_Horizons()
except Exception:
    pass

# --- Market price model for frontload validation ---
_ST_HINGE_GAIN = 8.0
_ST_MARKET_PARAMS = {{
    "WHEAT":      {{"base":  25, "I0": 10000, "T": 400, "below_func": "sqrt",   "below_target": 0.80, "above_func": "log",    "above_target": 0.20}},
    "CARROT":     {{"base":  35, "I0": 10000, "T": 450, "below_func": "hinge",  "below_target": 1.00, "above_func": "sqrt",   "above_target": 0.70}},
    "TOMATO":     {{"base":  60, "I0": 10000, "T": 200, "below_func": "hinge",  "below_target": 0.40, "above_func": "sqrt",   "above_target": 0.60}},
    "STRAWBERRY": {{"base": 120, "I0": 10000, "T": 100, "below_func": "sqrt",   "below_target": 0.70, "above_func": "linear", "above_target": 1.60}},
    "MELON":      {{"base": 250, "I0": 10000, "T": 300, "below_func": "log",    "below_target": 0.20, "above_func": "sq",     "above_target": 3.60}},
    "EGG":        {{"base":  50, "I0": 10000, "T": 332, "below_func": "hinge",  "below_target": 0.40, "above_func": "log",    "above_target": 0.20}},
    "MILK":       {{"base": 160, "I0": 10000, "T": 122, "below_func": "sqrt",   "below_target": 0.60, "above_func": "linear", "above_target": 1.60}},
    "WOOL":       {{"base": 200, "I0": 10000, "T": 105, "below_func": "log",    "below_target": 0.20, "above_func": "sq",     "above_target": 3.20}},
    "FERTILIZER": {{"base": 100, "I0": 10000, "T": 200, "below_func": "linear", "below_target": 0.40, "above_func": "linear", "above_target": 0.40}},
}}
_ST_SEED_COST = {{"WHEAT": 10, "CARROT": 20, "TOMATO": 50, "STRAWBERRY": 100, "MELON": 80}}
_ST_ANIMAL_COST = {{"CHICKEN": 150, "GOOSE": 300, "COW": 400, "SHEEP": 500}}
_ST_LAND_PRICES = [1000, 2000, 4000]

def _st_shape(func, x, T=None):
    x = max(0.0, x)
    if func == "linear": return x
    if func == "sq": return x * x
    if func == "sqrt": return _st_math.sqrt(x)
    if func == "log": return _st_math.log(1.0 + x)
    if func == "hinge":
        if not T or T <= 0: return x
        u = x / T; return u + _ST_HINGE_GAIN * max(0.0, u - 1.0) ** 2
    return x

def _st_price(item, inventory):
    p = _ST_MARKET_PARAMS[item]; base = p["base"]; I0 = p["I0"]; T = p["T"]
    if inventory < I0:
        amp = p["below_target"] * base / _st_shape(p["below_func"], T, T)
        return max(1, int(round(base + amp * _st_shape(p["below_func"], I0 - inventory, T))))
    else:
        amp = p["above_target"] * base / _st_shape(p["above_func"], T, T)
        return max(1, int(round(base - amp * _st_shape(p["above_func"], inventory - I0, T))))

def _st_fib(n):
    a, b = 1, 1
    for _ in range(n): a, b = b, a + b
    return a

def _st_simulate(orders, money, shed_total, inv, hires_today, n_land_extra, opp_pressure=0):
    inv = dict(inv); money = float(money); shed = int(shed_total)
    for o in orders:
        if not isinstance(o, (list, tuple)) or not o: return False, money
        op = o[0]
        if op == "HIRE":
            c = _st_fib(hires_today)
            if money < c: return False, money
            money -= c; hires_today += 1; continue
        if op == "BUY_LAND":
            if n_land_extra >= len(_ST_LAND_PRICES): return False, money
            c = _ST_LAND_PRICES[n_land_extra]
            if money < c: return False, money
            money -= c; n_land_extra += 1; continue
        if len(o) < 3: return False, money
        try: n = int(o[2])
        except Exception: return False, money
        if n <= 0: return False, money
        item = o[1]
        if op == "SELL":
            if item not in _ST_MARKET_PARAMS: return False, money
            for _ in range(n):
                p = _st_price(item, inv.get(item, 10000))
                money += p
                if p > 1: inv[item] = inv.get(item, 10000) + 1 + opp_pressure
                shed -= 1
        elif op == "BUY_PRODUCT":
            if item not in ("WHEAT", "FERTILIZER"): return False, money
            for _ in range(n):
                p = _st_price(item, inv.get(item, 10000) - 1)
                if money < p or shed >= 100: return False, money
                money -= p; inv[item] = inv.get(item, 10000) - 1 - opp_pressure; shed += 1
        elif op == "BUY_SEED":
            if item not in _ST_SEED_COST: return False, money
            c = _ST_SEED_COST[item] * n
            if money < c: return False, money
            money -= c
        elif op == "BUY_ANIMAL":
            if item not in _ST_ANIMAL_COST: return False, money
            for _ in range(n):
                c = _ST_ANIMAL_COST[item]
                if money < c or shed >= 100: return False, money
                money -= c; shed += 1
        else: return False, money
    return True, money

# --- Frontload: reorder SELLs before BUYs with simulation safety check ---
def _st_frontload(obs, market):
    if not isinstance(market, list) or len(market) < 2: return market
    orders = [list(o) for o in market if isinstance(o, (list, tuple)) and o]
    if len(orders) != len(market): return market
    A, B, C = [], [], []
    for j, o in enumerate(orders):
        op = o[0]
        if op == "SELL":
            wash = any(p[0] == "BUY_PRODUCT" and len(p) > 1 and len(o) > 1 and p[1] == o[1] for p in orders[:j])
            (B if wash else A).append(o)
        elif op == "BUY_PRODUCT": B.append(o)
        else: C.append(o)
    new = A + B + C
    if new == orders: return market
    try:
        me = int(obs["player"]); farm = obs["farms"][me]; private = obs["private"]
        money = float(farm["money"]); shed_total = sum(int(v) for v in private["shed"].values())
        inv = {{k: int(v) for k, v in obs["market"]["inventory"].items()}}
        hires_today = int(farm.get("hires_today", 0))
        n_land_extra = max(0, len(farm.get("unlocked_quadrants", ["NW"])) - 1)
        for pressure in (0, 1):
            ok_old, _ = _st_simulate(orders, money, shed_total, inv, hires_today, n_land_extra, pressure)
            ok_new, _ = _st_simulate(new, money, shed_total, inv, hires_today, n_land_extra, pressure)
            if not ok_old or not ok_new: return market
    except Exception: return market
    return new

# --- Advance sales: pre-sell premium products from future tape turns ---
_ST_PREMIUM = ("STRAWBERRY", "WOOL", "EGG", "MILK", "MELON", "CARROT", "TOMATO")
_ST_LOOKAHEAD = {lookahead}
_ST_PROTECT_FIRST = True

def _st_future_market(obs, offset=1):
    try:
        step = int(obs["step"]) + offset
        if step >= 719: return None
        # Access the parent's chassis to read future tape actions
        impl = None
        for ns_name in ('_PARENT_NS', '_IMPL'):
            ns = globals().get(ns_name)
            if ns is not None:
                impl = ns.get('_IMPL', ns) if isinstance(ns, dict) else ns
                break
        if impl is None: return None
        chassis = getattr(impl, 'chassis', None) or (impl.get('chassis') if isinstance(impl, dict) else None)
        if chassis is None: return None
        players = chassis.players
        native = players.get(int(obs["player"])) if isinstance(players, dict) else None
        route = 2 if step >= 648 else (native or {{}}).get("route")
        if route is None: return None
        return chassis.routes[route][step].get("market")
    except Exception: return None

def _st_advance_sales(obs, market):
    try:
        step = int(obs["step"])
        if step % 24 == 23 or step >= 718: return market
        nxt = []
        for off in range(1, _ST_LOOKAHEAD + 1):
            m_off = _st_future_market(obs, off)
            if m_off:
                nxt += [o for o in m_off if isinstance(o, (list, tuple)) and o]
        if not nxt: return market
        want = {{}}
        first = next((o for o in nxt if isinstance(o, (list, tuple)) and o), None)
        protected = first[1] if first and len(first) > 2 and first[0] == "SELL" and _ST_PROTECT_FIRST else None
        for o in nxt:
            if isinstance(o, (list, tuple)) and len(o) > 2 and o[0] == "SELL" and o[1] in _ST_PREMIUM and o[1] != protected:
                try: want[o[1]] = want.get(o[1], 0) + max(0, int(o[2]))
                except Exception: pass
        if not want: return market
        shed = obs["private"]["shed"]
        cur = [list(o) for o in (market or []) if isinstance(o, (list, tuple)) and o]
        selling_now = {{}}
        for o in cur:
            if len(o) > 2 and o[0] == "SELL":
                try: selling_now[o[1]] = selling_now.get(o[1], 0) + max(0, int(o[2]))
                except Exception: pass
        extra = []
        for item, q in want.items():
            avail = int(shed.get(item, 0)) - selling_now.get(item, 0)
            n = min(q, avail)
            if n < 1: continue
            hit = next((o for o in cur if len(o) > 2 and o[0] == "SELL" and o[1] == item), None)
            if hit is not None:
                hit[2] = int(hit[2]) + n
            else:
                extra.append(["SELL", item, n])
        if len(cur) + len(extra) > 10:
            extra = extra[:max(0, 10 - len(cur))]
        if not extra and not any(True for _ in []):  # merged tracked via hit mutation
            pass
        return extra + cur if extra else cur
    except Exception: return market

# --- Combined wrapper ---
_ST_PARENT = agent
_ST_REPORT = dict(st_front=0, st_adv=0, st_errors=0)

def agent(observation, configuration=None):
    action = _ST_PARENT(observation, configuration)
    try:
        if int(observation['step']) == 0:
            _ST_REPORT.update(st_front=0, st_adv=0, st_errors=0)
        standard = configuration is None or all(
            configuration.get(k, v) == v
            for k, v in [('boardSize', 10), ('turnsPerDay', 24), ('shedCapacity', 100), ('maxMarketOrdersPerTurn', 10)]
        )
        if standard and isinstance(action, dict):
            m = action.get("market")
            m = list(m) if isinstance(m, list) else []
            # Advance sales (pre-sell from future tape turns)
            new = _st_advance_sales(observation, m)
            if new is not m:
                _ST_REPORT['st_adv'] += 1
            # Frontload (reorder SELLs before BUYs, with simulation safety)
            if len(new) > 1:
                fl = _st_frontload(observation, new)
                if fl is not new:
                    _ST_REPORT['st_front'] += 1
                new = fl
            if new is not m:
                action = dict(action); action["market"] = new
    except Exception:
        _ST_REPORT['st_errors'] += 1
    _ST_REPORT.update(getattr(_ST_PARENT, 'telemetry', {{}}))
    return action
agent.telemetry = _ST_REPORT
agent = globals().pop('agent')
'''
    return wrapper


# ═══════════════════════════════════════════════════════════
# FULL PIPELINE: TRACER SIGNAL → FIX SEARCH → CODE
# ═══════════════════════════════════════════════════════════

def run_fix_search(tracer_results=None, base_agent_path=None, output_dir=None):
    """Full fix search pipeline.

    Pass 1: Opening optimization (market microstructure)
    Pass 2: Sell timing optimization (frontload + advance_sales)

    Returns: dict with recommendation and generated code (both passes combined).
    """
    print("=" * 80)
    print("FIX SEARCH: Autoloop optimizer (pass 1: opening + pass 2: sell timing)")
    print("=" * 80)

    # Pass 1: Opening sweep
    print("\n[1/4] Sweeping opening configurations...")
    results = sweep_openings()
    rec = print_sweep_report(results)

    if rec is None:
        print("ERROR: No valid opening found")
        return None

    # Pass 1: Generate opening wrapper
    print(f"\n[2/4] Generating opening wrapper...")
    opening_code = generate_opening_wrapper(rec, base_agent_path, output_dir)

    # Pass 2: Sell timing analysis
    print(f"\n[3/4] Analyzing sell timing signal...")
    sell_signal = analyze_sell_timing_signal(tracer_results or [])

    sell_timing_code = ""
    if sell_signal["signal"]:
        print(f"  SIGNAL DETECTED: {sell_signal['avg_diffs_per_game']:.0f} sell timing diffs/game")
        items_str = ', '.join(f"{k}({v['count']})" for k,v in sorted(sell_signal['items'].items(), key=lambda x:-x[1]['count'])[:5])
        print(f"  Items: {items_str}")
        print(f"  Recommended: lookahead={sell_signal['recommended_lookahead']}, horizon={sell_signal['recommended_horizon']}")
        sell_timing_code = generate_sell_timing_wrapper(sell_signal)
        print(f"  Generated sell timing wrapper ({len(sell_timing_code)} chars)")
    else:
        print(f"  No sell timing signal (avg {sell_signal.get('avg_diffs_per_game', 0):.1f} diffs/game < 5 threshold)")

    # Combine both wrappers
    wrapper_code = opening_code + "\n" + sell_timing_code

    # Save
    print(f"\n[4/4] Saving...")
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        with open(os.path.join(output_dir, "combined_wrapper.py"), "w") as f:
            f.write(wrapper_code)
        with open(os.path.join(output_dir, "fix_search_results.json"), "w") as f:
            json.dump({
                "opening": {"buy": rec["buy"], "sell": rec["sell"], "lift_qty": rec.get("lift_qty", 0), "avg_advantage": rec["avg_advantage"]},
                "sell_timing": {"signal": sell_signal["signal"], "lookahead": sell_signal.get("recommended_lookahead"), "horizon": sell_signal.get("recommended_horizon")},
            }, f, indent=2)
        print(f"  Saved to {output_dir}")

    print("\nDone.")
    return {"recommendation": rec, "wrapper_code": wrapper_code, "results": results, "sell_signal": sell_signal}


if __name__ == "__main__":
    import sys
    output = "autoloop/corpus/fix_search_output"
    run_fix_search(output_dir=output)
