#!/usr/bin/env python3
"""Layer Code Gen: Generate improved agents by transplanting layers and building opponent plans.

Takes layer_diff output and produces a new agent by:
1. Copying the base agent
2. Appending new layers from a target agent
3. Patching modified layers (constant overrides)
4. Injecting opponent_plan for front_run

Usage:
    python layer_codegen.py --base _hero_from_v46 --donor v47 --output _hero_v2_from_v46
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

AUTOLOOP_DIR = Path(__file__).resolve().parent
AGENTS_DIR = AUTOLOOP_DIR / "agents"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"
sys.path.insert(0, str(AUTOLOOP_DIR))


def log(msg):
    print(f"[layer_codegen] {msg}", flush=True)


# ═══════════════════════════════════════════════════════════
# OPPONENT PLAN EXTRACTION
# ═══════════════════════════════════════════════════════════

def extract_opponent_plan(agent_path):
    """Extract _ROUTES from a target agent for use as opponent_plan in front_run.

    Returns: route 0 tape as list of action dicts (719 steps).
    """
    from tape_diff_tracer import extract_routes
    try:
        routes, _ = extract_routes(agent_path)
        # Route 0 is the default/most common route
        if 0 in routes:
            return routes[0]
        # Fallback: first available route
        if routes:
            return routes[min(routes.keys())]
    except Exception as e:
        log(f"  Warning: Could not extract routes from {agent_path}: {e}")
    return None


# ═══════════════════════════════════════════════════════════
# LAYER TRANSPLANT
# ═══════════════════════════════════════════════════════════

def replace_modified_layers(agent_path, diff_result, original_base_path):
    """Replace modified layers in agent with donor versions.

    For each modified layer (same name, different content), find the layer
    in the agent, extract the corresponding layer from the donor, and replace.
    """
    from layer_diff import extract_layers, LAYER_BOUNDARY, HOST_BOUNDARY

    agent_code = Path(agent_path).read_text()
    agent_lines = agent_code.split('\n')

    # We need the donor's extracted layers
    donor_layers = {}
    donor_path = diff_result.get('agent_b_path')
    if donor_path:
        ext = extract_layers(donor_path)
        donor_layers = {l['name']: l for l in ext['layers']}

    modified = diff_result.get('modified_layers', [])
    replacements = 0

    for name, info in modified:
        if name not in donor_layers:
            log(f"    SKIP {name}: not in donor")
            continue

        donor_layer = donor_layers[name]
        donor_code = donor_layer['code']

        # Find this layer in the agent file
        # Look for the _PREFIX_PARENT or _PREFIX_HOST line
        parent_pattern = f"_{name}_PARENT"
        host_pattern = f"_{name}_HOST"

        layer_start = None
        for i, line in enumerate(agent_lines):
            stripped = line.strip()
            if (stripped.startswith(parent_pattern) and '=' in stripped and 'agent' in stripped) or \
               (stripped.startswith(host_pattern) and '=' in stripped):
                layer_start = i
                break

        if layer_start is None:
            log(f"    SKIP {name}: not found in agent")
            continue

        # Find where this layer ends (next layer boundary or special markers)
        layer_end = len(agent_lines)
        for i in range(layer_start + 1, len(agent_lines)):
            line = agent_lines[i]
            if LAYER_BOUNDARY.match(line) or HOST_BOUNDARY.match(line):
                layer_end = i
                break
            # Also check for our custom layer markers
            if line.strip().startswith('_AL_PARENT') or line.strip().startswith('_ST_PARENT'):
                layer_end = i
                break

        old_code = '\n'.join(agent_lines[layer_start:layer_end])
        old_lines = layer_end - layer_start

        # Replace
        new_lines = donor_code.split('\n')
        agent_lines[layer_start:layer_end] = new_lines

        log(f"    REPLACED {name}: {old_lines} → {len(new_lines)} lines")
        replacements += 1

    if replacements > 0:
        Path(agent_path).write_text('\n'.join(agent_lines))
        log(f"  Replaced {replacements} layers")


def check_name_conflict(base_code, layer):
    """Check if transplanting a layer would cause naming conflicts."""
    prefix = '_' + layer['name'] + '_'
    prefix_lower = '_' + layer['name'].lower() + '_'
    # Check if the base already has this layer (_PARENT or _HOST style)
    if (prefix + 'PARENT' in base_code or prefix + 'HOST' in base_code
            or prefix_lower + 'parent' in base_code or prefix_lower + 'host' in base_code):
        return True
    return False


def transplant_layers(base_path, layers_to_add, output_path, skip_existing=True):
    """Copy base agent and append new closure layers.

    Args:
        base_path: Path to base agent main.py
        layers_to_add: List of layer dicts from layer_diff (must have 'code' key)
        output_path: Path for output main.py
        skip_existing: Skip layers whose prefix already exists in base
    """
    base_code = Path(base_path).read_text()

    added = []
    skipped = []
    for layer in layers_to_add:
        if skip_existing and check_name_conflict(base_code, layer):
            skipped.append(layer['name'])
            continue

        # Append the layer code
        base_code += '\n\n'
        base_code += layer['code']
        if not base_code.endswith('\n'):
            base_code += '\n'
        added.append(layer['name'])

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(base_code)

    log(f"  Transplanted {len(added)} layers: {added}")
    if skipped:
        log(f"  Skipped (already exists): {skipped}")

    return {'added': added, 'skipped': skipped}


# ═══════════════════════════════════════════════════════════
# CONSTANT PATCHING
# ═══════════════════════════════════════════════════════════

def patch_constants(agent_path, patches):
    """Apply constant value patches to an agent file.

    Args:
        agent_path: Path to agent main.py (modified in place)
        patches: dict of {variable_name: new_value_string}
                 e.g. {'_ADV_LOOK': '5', '_ADV_FROM': '120'}
    """
    code = Path(agent_path).read_text()
    patched = []

    for var, new_val in patches.items():
        # Match: _VAR = old_value (simple assignment on one line)
        pattern = re.compile(r'^(' + re.escape(var) + r'\s*=\s*)(.+)$', re.MULTILINE)
        m = pattern.search(code)
        if m:
            old_val = m.group(2).strip()
            code = pattern.sub(m.group(1) + new_val, code, count=1)
            patched.append(f"{var}: {old_val} → {new_val}")

    Path(agent_path).write_text(code)
    if patched:
        log(f"  Patched {len(patched)} constants: {patched}")
    return patched


# ═══════════════════════════════════════════════════════════
# OPPONENT PLAN INJECTION
# ═══════════════════════════════════════════════════════════

def inject_opponent_plan(agent_path, opponent_plan):
    """Inject opponent_plan into the Chassis construction for front_run.

    Modifies the make_agent() call to pass opponent_plan.
    """
    code = Path(agent_path).read_text()

    # Find _IMPL = make_agent(_ROUTES, _router, ...) or Chassis(...) construction
    # The pattern varies but typically: Chassis(routes, router, settings, opponent_plan)

    # Strategy: Add a module-level opponent plan and reference it in Chassis init
    plan_json = json.dumps(opponent_plan, separators=(',', ':'))

    # Check if opponent_plan is already set
    if '_OPPONENT_PLAN' in code:
        log("  opponent_plan already injected, updating...")
        code = re.sub(
            r'_OPPONENT_PLAN\s*=\s*\[.*?\]',
            f'_OPPONENT_PLAN = {plan_json}',
            code,
            count=1,
            flags=re.DOTALL
        )
    else:
        # Insert opponent_plan before make_agent/Chassis construction
        # Find the Chassis(...) call
        chassis_match = re.search(r'(Chassis\s*\([^)]*\))', code, re.DOTALL)
        if chassis_match:
            # Check if Chassis accepts opponent_plan parameter
            chassis_call = chassis_match.group(1)
            if 'opponent_plan' not in chassis_call:
                # Add opponent_plan parameter
                new_call = chassis_call.rstrip(')')
                if not new_call.endswith(','):
                    new_call += ','
                new_call += f' opponent_plan=_OPPONENT_PLAN)'
                code = code[:chassis_match.start()] + new_call + code[chassis_match.end():]

            # Insert plan data before the Chassis call
            insert_point = chassis_match.start()
            # Find the start of the line
            line_start = code.rfind('\n', 0, insert_point) + 1
            indent = ''
            for c in code[line_start:]:
                if c in ' \t':
                    indent += c
                else:
                    break
            plan_line = f"\n_OPPONENT_PLAN = {plan_json}\n\n"
            code = code[:line_start] + plan_line + code[line_start:]
            log(f"  Injected opponent_plan ({len(opponent_plan)} steps)")
        else:
            log("  Warning: Could not find Chassis() call to inject opponent_plan")

    Path(agent_path).write_text(code)


# ═══════════════════════════════════════════════════════════
# COMBINED HERO GENERATION
# ═══════════════════════════════════════════════════════════

def generate_hero_v2(
    base_path,
    diff_result,
    donor_path=None,
    output_name="_hero_v2_from_v46",
    inject_opp_plan=True,
    constant_patches=None,
):
    """Generate hero_v2 by absorbing innovations from a donor agent.

    Args:
        base_path: Path to base agent (e.g. _hero_from_v46/main.py)
        diff_result: Output from layer_diff.full_diff() containing added_layers
        donor_path: Path to donor agent for opponent_plan extraction
        output_name: Directory name for output agent
        inject_opp_plan: Whether to inject opponent_plan for front_run
        constant_patches: Dict of {var: value} to patch in the output

    Returns: path to generated agent, or None on failure.
    """
    log(f"\n{'='*60}")
    log(f"GENERATING: {output_name}")
    log(f"{'='*60}")

    output_dir = AGENTS_DIR / output_name
    output_path = output_dir / "main.py"

    # Step 1: Copy base
    output_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(base_path, output_path)
    base_lines = sum(1 for _ in open(output_path))
    log(f"  Base: {Path(base_path).parent.name} ({base_lines} lines)")

    # Step 2: Replace modified layers with donor versions
    modified = diff_result.get('modified_layers', [])
    if modified:
        log(f"  Replacing {len(modified)} modified layers with donor versions")
        replace_modified_layers(str(output_path), diff_result, str(base_path))

    # Step 3 (optional): Transplant added layers or innovation tail
    added_layers = diff_result.get('added_layers', [])
    tail = diff_result.get('innovation_tail')
    if added_layers:
        result = transplant_layers(str(output_path), added_layers, str(output_path))
    elif tail and tail.get('code') and tail['n_lines'] > 10:
        log(f"  Innovation tail available: {tail['n_lines']} lines (appending)")
        hero_code = Path(output_path).read_text()
        al_marker = '_AL_PARENT = agent'
        if al_marker in hero_code:
            insert_idx = hero_code.index(al_marker)
            hero_code = hero_code[:insert_idx] + tail['code'] + '\n\n' + hero_code[insert_idx:]
            log(f"  Inserted before _AL layer")
        else:
            hero_code += '\n\n' + tail['code'] + '\n'
            log(f"  Appended at end")
        Path(output_path).write_text(hero_code)

    # Step 3: Apply constant patches from modified layers
    if constant_patches:
        patch_constants(str(output_path), constant_patches)
    else:
        # Auto-extract patches from modified layers
        auto_patches = {}
        for name, info in diff_result.get('modified_layers', []):
            for var, change in info.get('changed_constants', {}).items():
                if change.get('new') is not None:
                    auto_patches[var] = change['new']
        if auto_patches:
            log(f"  Auto-patching {len(auto_patches)} constants from modified layers")
            patch_constants(str(output_path), auto_patches)

    # Step 4: Inject opponent plan
    if inject_opp_plan and donor_path:
        plan = extract_opponent_plan(donor_path)
        if plan:
            inject_opponent_plan(str(output_path), plan)

    # Report
    final_lines = sum(1 for _ in open(output_path))
    log(f"  Output: {output_path} ({final_lines} lines, +{final_lines - base_lines})")

    return str(output_path)


def smoke_test(agent_path, opponent_path=None):
    """Quick 2-game smoke test."""
    if opponent_path is None:
        opponent_path = agent_path
    python = sys.executable
    try:
        result = subprocess.run(
            [python, str(AUTOLOOP_DIR / "colosseum.py"),
             agent_path, opponent_path,
             "--games", "2", "--parallel", "2"],
            capture_output=True, text=True, timeout=60,
            cwd=str(AUTOLOOP_DIR.parent)
        )
        if result.returncode == 0 and "ERROR" not in result.stdout:
            log(f"  Smoke test: PASS")
            return True
        log(f"  Smoke test: FAIL")
        if result.stderr:
            log(f"    {result.stderr[:200]}")
        return False
    except Exception as e:
        log(f"  Smoke test error: {e}")
        return False


# ═══════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════

def resolve_agent_path(arg):
    p = Path(arg)
    if p.is_file():
        return str(p)
    candidate = AGENTS_DIR / arg / "main.py"
    if candidate.exists():
        return str(candidate)
    matches = list(AGENTS_DIR.glob(f"*{arg}*"))
    if matches:
        mp = matches[0] / "main.py"
        if mp.exists():
            return str(mp)
    raise FileNotFoundError(f"Agent not found: {arg}")


def main():
    parser = argparse.ArgumentParser(description="Layer Code Gen: build improved agents")
    parser.add_argument("--base", required=True, help="Base agent (name or path)")
    parser.add_argument("--donor", required=True, help="Donor agent to absorb from")
    parser.add_argument("--output", default="_hero_v2_from_v46", help="Output agent name")
    parser.add_argument("--no-opp-plan", action="store_true", help="Skip opponent plan injection")
    parser.add_argument("--patch", nargs="*", help="Constant patches (VAR=VALUE)")
    args = parser.parse_args()

    base_path = resolve_agent_path(args.base)
    donor_path = resolve_agent_path(args.donor)

    # Run layer diff
    from layer_diff import full_diff
    diff_result = full_diff(base_path, donor_path, save=True)

    # Parse patches
    patches = {}
    if args.patch:
        for p in args.patch:
            k, v = p.split('=', 1)
            patches[k] = v

    # Generate
    agent_path = generate_hero_v2(
        base_path=base_path,
        diff_result=diff_result,
        donor_path=donor_path,
        output_name=args.output,
        inject_opp_plan=not args.no_opp_plan,
        constant_patches=patches or None,
    )

    if agent_path:
        log(f"\nSmoke testing...")
        ok = smoke_test(agent_path)
        if not ok:
            log("WARNING: Smoke test failed. Agent may crash at runtime.")


if __name__ == "__main__":
    main()
