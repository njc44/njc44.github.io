#!/usr/bin/env python3
"""Twin Graph: BFS-based twin discovery and replay corpus management.

Builds a graph of teams connected by games. Expands outward from us via BFS,
fingerprinting opponents at each level. Twins (>90% similarity) get promoted
up a level. Focuses on top N models, self-prunes weak/old ones.

The graph persists to disk and is incrementally updated.

Usage:
    python twin_graph.py --expand 2              # BFS expand to depth 2
    python twin_graph.py --expand 3 --top 10     # Depth 3, track top 10 models
    python twin_graph.py --status                 # Show current graph state
    python twin_graph.py --download               # Download replays for tracked teams
    python twin_graph.py --prune                  # Remove weak/old models
    python twin_graph.py --refresh                # Full cycle: expand + download + prune
"""
import argparse
import json
import subprocess
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
REPLAY_DIR = AUTOLOOP_DIR / "replays"
GRAPH_FILE = AUTOLOOP_DIR / "corpus" / "twin_graph.json"

OUR_TEAM = "Nathan Jacob"
TWIN_THRESHOLD = 0.90   # 90%+ early action similarity = tape twin
TOP_N_MODELS = 10       # Focus on this many models
MAX_EPISODES_PER_SUB = 50  # Download cap per submission
PRUNE_ELO_FLOOR = 2200  # Remove teams below this Elo


def log(msg):
    print(f"[graph] {msg}", flush=True)


# ═══════════════════════════════════════════════════════════
# GRAPH STRUCTURE
# ═══════════════════════════════════════════════════════════

def new_graph():
    return {
        "teams": {},
        "edges": [],       # [{a, b, episode_id, result_for_a}]
        "fingerprints": {}, # team_name (or team_name::sub_ID) -> list of 144 action strings
        "twins": [],        # list of twin team names
        "top_models": [],   # focus set
        "meta": {
            "created": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat(),
            "total_episodes_downloaded": 0,
            "bfs_depth_reached": 0,
        }
    }


def load_graph():
    if GRAPH_FILE.exists():
        with open(GRAPH_FILE) as f:
            return json.load(f)
    return new_graph()


def save_graph(graph):
    GRAPH_FILE.parent.mkdir(exist_ok=True)
    graph["meta"]["last_updated"] = datetime.now().isoformat()
    with open(GRAPH_FILE, "w") as f:
        json.dump(graph, f, indent=2, default=str)


# ═══════════════════════════════════════════════════════════
# KAGGLE API HELPERS
# ═══════════════════════════════════════════════════════════

def get_leaderboard(max_entries=200):
    """Fetch leaderboard for team_id → Elo mapping."""
    all_entries = []
    page_token = None
    while len(all_entries) < max_entries:
        cmd = ["kaggle", "competitions", "leaderboard", "kaggriculture",
               "--show", "--format", "json", "--page-size", "100"]
        if page_token:
            cmd.extend(["--page-token", page_token])
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        lines = result.stdout.strip().split("\n")
        token_line = ""
        json_start = 0
        for i, line in enumerate(lines):
            if line.startswith("Next Page Token"):
                token_line = line.split("=", 1)[1].strip()
                json_start = i + 1
                break
        json_text = "\n".join(lines[json_start:])
        try:
            entries = json.loads(json_text)
            all_entries.extend(entries)
        except Exception:
            break
        if token_line:
            page_token = token_line
        else:
            break
    return {e["teamName"]: {"team_id": e["teamId"], "elo": float(e["score"])}
            for e in all_entries}


def get_team_submissions(team_id):
    """Get submission IDs for a team."""
    result = subprocess.run(
        ["kaggle", "competitions", "team-submissions", str(team_id), "--format", "json"],
        capture_output=True, text=True, timeout=15
    )
    # Handle mixed output (pagination token + json)
    lines = result.stdout.strip().split("\n")
    json_lines = [l for l in lines if not l.startswith("Next Page Token")]
    try:
        subs = json.loads("\n".join(json_lines))
        return [(s.get("ref", s.get("id")), s.get("publicScore", "?")) for s in subs]
    except Exception:
        # Table format fallback
        subs = []
        for line in result.stdout.strip().split("\n"):
            parts = line.strip().split()
            if parts and parts[0].isdigit():
                subs.append((int(parts[0]), "?"))
        return subs


def get_episode_ids(submission_id, max_eps=None):
    """Get episode IDs for a submission."""
    if max_eps is None:
        max_eps = MAX_EPISODES_PER_SUB
    result = subprocess.run(
        ["kaggle", "competitions", "episodes", str(submission_id)],
        capture_output=True, text=True, timeout=30
    )
    episodes = []
    for line in result.stdout.strip().split("\n"):
        parts = line.strip().split()
        if parts and parts[0].isdigit():
            episodes.append(int(parts[0]))
    return episodes[:max_eps]


def download_replay(episode_id, freshness_hours=None, replay_dir=None):
    """Download and cache a single replay. Returns path or None.

    Args:
        episode_id: the episode to download
        freshness_hours: if set, delete cached file older than this many hours
        replay_dir: override for the default REPLAY_DIR
    """
    rdir = Path(replay_dir) if replay_dir else REPLAY_DIR
    rdir.mkdir(parents=True, exist_ok=True)
    cached = rdir / f"{episode_id}.json"

    # Freshness check — delete stale cached files
    if cached.exists() and freshness_hours is not None:
        mtime = datetime.fromtimestamp(cached.stat().st_mtime)
        if datetime.now() - mtime > timedelta(hours=freshness_hours):
            cached.unlink()

    if cached.exists():
        return cached
    try:
        subprocess.run(
            ["kaggle", "competitions", "replay", str(episode_id),
             "-p", str(rdir.resolve()), "-q"],
            capture_output=True, text=True, timeout=60
        )
        downloaded = rdir / f"episode-{episode_id}-replay.json"
        if downloaded.exists():
            downloaded.rename(cached)
            return cached
        if cached.exists():
            return cached
        return None
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════
# FINGERPRINTING
# ═══════════════════════════════════════════════════════════

def fingerprint_from_replay(replay, seat, window=144):
    """Extract fingerprint from a replay for a given seat."""
    steps = replay.get("steps", [])
    actions = []
    for si in range(min(window, len(steps))):
        market = steps[si][seat].get("action", {}).get("market", [])
        actions.append(json.dumps(market, sort_keys=True))
    return actions


def compute_similarity(fp1, fp2):
    """Fraction of matching entries between two fingerprints."""
    if not fp1 or not fp2 or len(fp1) != len(fp2):
        return 0.0
    matches = sum(1 for a, b in zip(fp1, fp2) if a == b)
    return matches / len(fp1)


def _latest_fingerprint(graph, team_name):
    """Return the most recent submission fingerprint for a team.

    Looks for bot-level keys 'team_name::sub_*' and returns the one with the
    highest submission_id (most recent). Falls back to the plain team_name key.
    """
    prefix = f"{team_name}::sub_"
    bot_keys = [k for k in graph["fingerprints"] if k.startswith(prefix)]
    if bot_keys:
        # Highest submission_id = most recent
        best_key = max(bot_keys, key=lambda k: int(k.split("sub_")[1]))
        return graph["fingerprints"][best_key]
    return graph["fingerprints"].get(team_name)


def is_twin(graph, team_name, ref_team=None):
    """Check if a team is a twin of ref_team (or any known twin).

    Uses the most recent submission fingerprint when bot-level keys exist.
    """
    fp = _latest_fingerprint(graph, team_name)
    if not fp:
        return False, 0.0

    best_sim = 0.0

    # Compare against all known twins
    compare_to = graph["twins"] if not ref_team else [ref_team]
    for twin_name in compare_to:
        if twin_name == team_name:
            continue
        ref_fp = _latest_fingerprint(graph, twin_name)
        if not ref_fp:
            continue
        sim = compute_similarity(fp, ref_fp)
        best_sim = max(best_sim, sim)
        if sim >= TWIN_THRESHOLD:
            return True, sim

    return False, best_sim


def find_superior_twins(base_fingerprint, base_elo, lb_data, cluster_data=None,
                        freshness_hours=36, replay_dir=None):
    """Find twins of an arbitrary base agent that have higher Elo.

    Args:
        base_fingerprint: list of 144 JSON action strings (the base agent's fingerprint)
        base_elo: the base agent's Elo rating
        lb_data: leaderboard data (list of dicts with team_name, elo, submission_id)
        cluster_data: optional clusters.json data for cluster_id tagging
        freshness_hours: max age of cached replays
        replay_dir: where replays are cached

    Returns: list of dicts:
        [{name, elo, similarity, cluster_id, submission_id,
          replay_episode_ids, loss_episode_ids}]
    """
    rdir = Path(replay_dir) if replay_dir else REPLAY_DIR

    # Build cluster lookup: team_name -> cluster_id
    cluster_lookup = {}
    if cluster_data:
        for cid, members in cluster_data.items():
            if isinstance(members, list):
                for m in members:
                    name = m if isinstance(m, str) else m.get("team_name", "")
                    cluster_lookup[name] = cid

    results = []
    for entry in lb_data:
        team_name = entry.get("team_name", "")
        elo = float(entry.get("elo", 0))
        sub_id = entry.get("submission_id")

        if elo <= base_elo:
            continue

        # Get episodes for this submission to fingerprint
        if not sub_id:
            continue

        ep_ids = get_episode_ids(sub_id, MAX_EPISODES_PER_SUB)
        if not ep_ids:
            continue

        # Download first replay to get fingerprint
        best_fp = None
        all_episode_ids = []
        loss_episode_ids = []

        for ep_id in ep_ids:
            replay_path = download_replay(ep_id, freshness_hours=freshness_hours,
                                          replay_dir=str(rdir))
            if not replay_path:
                continue

            try:
                replay = json.load(open(replay_path))
            except Exception:
                continue

            teams_in_replay = replay.get("info", {}).get("TeamNames", [])
            rewards = replay.get("rewards", [0, 0])
            steps = replay.get("steps", [])

            if len(teams_in_replay) < 2 or len(steps) < 144:
                continue

            # Find which seat this team is in
            seat = None
            for s in [0, 1]:
                if teams_in_replay[s].strip() == team_name:
                    seat = s
                    break
            if seat is None:
                continue

            all_episode_ids.append(ep_id)

            # Track losses (reward < opponent reward)
            if rewards[seat] < rewards[1 - seat]:
                loss_episode_ids.append(ep_id)

            # Use first valid replay for fingerprint
            if best_fp is None:
                best_fp = fingerprint_from_replay(replay, seat)

        if best_fp is None:
            continue

        sim = compute_similarity(base_fingerprint, best_fp)
        if sim < TWIN_THRESHOLD:
            continue

        results.append({
            "name": team_name,
            "elo": elo,
            "similarity": round(sim, 4),
            "cluster_id": cluster_lookup.get(team_name),
            "submission_id": sub_id,
            "replay_episode_ids": all_episode_ids,
            "loss_episode_ids": loss_episode_ids,
        })

    # Sort by Elo descending
    results.sort(key=lambda x: x["elo"], reverse=True)
    return results


# ═══════════════════════════════════════════════════════════
# BFS EXPANSION
# ═══════════════════════════════════════════════════════════

def init_graph_with_us(graph, lb_data, our_team=None):
    """Initialize the graph with our team at Level 0."""
    team = our_team or OUR_TEAM
    if team not in graph["teams"]:
        our_lb = lb_data.get(team, {})
        graph["teams"][team] = {
            "level": 0,
            "team_id": our_lb.get("team_id"),
            "elo": our_lb.get("elo", 0),
            "submissions": [],
            "is_twin": True,
            "similarity": 1.0,
            "episodes_downloaded": 0,
            "discovered_at": datetime.now().isoformat(),
        }
        if team not in graph["twins"]:
            graph["twins"].append(team)

    # Get our submissions
    if graph["teams"][team].get("team_id"):
        subs = get_team_submissions(graph["teams"][team]["team_id"])
        graph["teams"][team]["submissions"] = [s[0] for s in subs]


def process_replay(graph, replay, episode_id, submission_id=None):
    """Process one replay: extract fingerprints, create edges, discover teams.

    When submission_id is provided, also stores a bot-level fingerprint keyed
    as 'team_name::sub_{submission_id}' in addition to the team-level key.
    """
    teams = replay.get("info", {}).get("TeamNames", [])
    rewards = replay.get("rewards", [0, 0])
    steps = replay.get("steps", [])

    if len(teams) < 2 or len(steps) < 144:
        return []

    discovered = []

    for seat in [0, 1]:
        team_name = teams[seat].strip()
        opp_name = teams[1 - seat].strip()

        # Fingerprint this team if not already done
        if team_name not in graph["fingerprints"]:
            fp = fingerprint_from_replay(replay, seat)
            graph["fingerprints"][team_name] = fp
            discovered.append(team_name)

        # Bot-level fingerprint keyed by submission_id
        if submission_id is not None:
            bot_key = f"{team_name}::sub_{submission_id}"
            if bot_key not in graph["fingerprints"]:
                fp = fingerprint_from_replay(replay, seat)
                graph["fingerprints"][bot_key] = fp

    # Create edge
    margin_0 = rewards[0] - rewards[1]
    result_0 = "W" if margin_0 > 0 else ("L" if margin_0 < 0 else "T")

    edge_key = f"{teams[0].strip()}:{teams[1].strip()}:{episode_id}"
    existing_keys = {f"{e['a']}:{e['b']}:{e['episode_id']}" for e in graph["edges"]}
    if edge_key not in existing_keys:
        graph["edges"].append({
            "a": teams[0].strip(),
            "b": teams[1].strip(),
            "episode_id": str(episode_id),
            "result_for_a": result_0,
        })

    return discovered


def bfs_expand(graph, max_depth=2, lb_data=None, our_team=None):
    """BFS expansion from known twins outward.

    At each level:
    1. Take all teams at current level
    2. For twins: download their episodes
    3. Process replays: fingerprint opponents, create edges
    4. New opponents become next level
    5. Check if new opponents are twins → promote to twin set
    """
    if lb_data is None:
        lb_data = {}
    team = our_team or OUR_TEAM

    # Queue: (team_name, current_depth)
    queue = deque()

    # Only expand from top_models or teams with Elo > our_elo (2771)
    # This focuses the download budget on high Elo-efficiency models
    # instead of expanding all 93+ twins which is too slow.
    our_elo = graph["teams"].get(team, {}).get("elo", 2771)
    top_set = set(graph.get("top_models", []))
    expand_candidates = set()
    for twin_name in list(graph["twins"]):
        if twin_name in top_set:
            expand_candidates.add(twin_name)
        else:
            twin_elo = graph["teams"].get(twin_name, {}).get("elo", 0)
            if twin_elo > our_elo:
                expand_candidates.add(twin_name)

    log(f"  BFS expand candidates: {len(expand_candidates)} of {len(graph['twins'])} twins")
    for twin_name in expand_candidates:
        team_data = graph["teams"].get(twin_name, {})
        level = team_data.get("level", 0)
        if level < max_depth:
            queue.append((twin_name, level))

    visited_for_expansion = set()
    new_twins_found = 0

    while queue:
        team_name, depth = queue.popleft()

        if team_name in visited_for_expansion:
            continue
        if depth >= max_depth:
            continue
        visited_for_expansion.add(team_name)

        team_data = graph["teams"].get(team_name, {})
        if not team_data.get("is_twin"):
            continue

        log(f"  BFS depth {depth}: expanding {team_name}")

        # Get this team's submissions
        team_id = team_data.get("team_id")
        if not team_id:
            # Try to find from leaderboard
            lb_entry = lb_data.get(team_name, {})
            team_id = lb_entry.get("team_id")
            if team_id:
                team_data["team_id"] = team_id
                team_data["elo"] = lb_entry.get("elo", team_data.get("elo", 0))

        if not team_id:
            log(f"    No team_id for {team_name}, skipping")
            continue

        subs = team_data.get("submissions")
        if not subs:
            subs_raw = get_team_submissions(team_id)
            subs = [s[0] for s in subs_raw]
            team_data["submissions"] = subs

        # Download episodes from each submission
        episodes_this_team = 0
        for sub_id in subs[:2]:  # Top 2 submissions per team
            ep_ids = get_episode_ids(sub_id, MAX_EPISODES_PER_SUB)
            log(f"    Sub {sub_id}: {len(ep_ids)} episodes")

            for ep_id in ep_ids:
                replay_path = download_replay(ep_id)
                if not replay_path:
                    continue
                episodes_this_team += 1

                try:
                    replay = json.load(open(replay_path))
                except Exception:
                    continue

                discovered = process_replay(graph, replay, ep_id, submission_id=sub_id)

                # Check newly discovered teams for twin status
                for new_team in discovered:
                    if new_team in graph["teams"]:
                        continue

                    twin_status, sim = is_twin(graph, new_team)
                    new_level = depth + 1

                    # Look up Elo
                    lb_entry = lb_data.get(new_team, {})
                    elo = lb_entry.get("elo", 0)
                    new_team_id = lb_entry.get("team_id")

                    graph["teams"][new_team] = {
                        "level": new_level,
                        "team_id": new_team_id,
                        "elo": elo,
                        "submissions": [],
                        "is_twin": twin_status,
                        "similarity": round(sim, 3),
                        "episodes_downloaded": 0,
                        "discovered_at": datetime.now().isoformat(),
                    }

                    if twin_status:
                        if new_team not in graph["twins"]:
                            graph["twins"].append(new_team)
                            new_twins_found += 1
                            log(f"    Twin found: {new_team} (sim={sim:.0%}, elo={elo:.0f})")
                        # Twins get promoted: add to queue for expansion
                        if new_level < max_depth:
                            queue.append((new_team, new_level))

        team_data["episodes_downloaded"] = team_data.get("episodes_downloaded", 0) + episodes_this_team
        graph["meta"]["total_episodes_downloaded"] += episodes_this_team

    graph["meta"]["bfs_depth_reached"] = max_depth
    log(f"  BFS complete: {new_twins_found} new twins found, "
        f"{len(graph['teams'])} total teams, {len(graph['twins'])} twins")
    return new_twins_found


# ═══════════════════════════════════════════════════════════
# TOP MODEL SELECTION + PRUNING
# ═══════════════════════════════════════════════════════════

def update_top_models(graph, top_n=None, our_team=None):
    """Select top N models to focus on. Mix of our twins + strong non-twins."""
    if top_n is None:
        top_n = TOP_N_MODELS
    team = our_team or OUR_TEAM

    # Score each team by Elo efficiency: (twin_elo - our_elo) / (1 - similarity)
    # Higher = more Elo per unit of divergence = densest improvement signal
    our_elo = graph["teams"].get(team, {}).get("elo", 2771)
    scored = []
    for name, data in graph["teams"].items():
        elo = data.get("elo", 0)
        is_twin = data.get("is_twin", False)
        sim = data.get("similarity", 0)
        if is_twin and elo > our_elo and sim < 1.0:
            # Elo efficiency: how much Elo per % divergence
            elo_efficiency = (elo - our_elo) / (1 - sim) if sim < 1.0 else 0
            score = elo_efficiency
        elif is_twin:
            score = elo  # twin but not better than us — rank by raw Elo
        else:
            score = elo * 0.01  # non-twins deprioritized
        scored.append((name, score, elo, is_twin))

    scored.sort(key=lambda x: x[1], reverse=True)
    graph["top_models"] = [name for name, _, _, _ in scored[:top_n]]

    log(f"  Top {top_n} models: {graph['top_models']}")


def prune_graph(graph, lb_data=None, our_team=None):
    """Remove teams below Elo floor and with no recent activity."""
    if lb_data is None:
        lb_data = {}
    team = our_team or OUR_TEAM

    removed = []
    for name in list(graph["teams"].keys()):
        if name == team:
            continue
        data = graph["teams"][name]

        # Update Elo from leaderboard
        if name in lb_data:
            data["elo"] = lb_data[name].get("elo", data.get("elo", 0))

        # Prune if below floor and not a twin
        if data.get("elo", 0) < PRUNE_ELO_FLOOR and not data.get("is_twin"):
            removed.append(name)
            del graph["teams"][name]
            if name in graph["fingerprints"]:
                del graph["fingerprints"][name]

    # Clean edges referencing removed teams
    graph["edges"] = [e for e in graph["edges"]
                      if e["a"] not in removed and e["b"] not in removed]

    if removed:
        log(f"  Pruned {len(removed)} teams below Elo {PRUNE_ELO_FLOOR}")


# ═══════════════════════════════════════════════════════════
# STATUS + REPORTING
# ═══════════════════════════════════════════════════════════

def show_status(graph):
    """Print graph status."""
    print("=" * 70)
    print("  TWIN GRAPH STATUS")
    print("=" * 70)
    print(f"  Teams: {len(graph['teams'])}")
    print(f"  Twins: {len(graph['twins'])}")
    print(f"  Edges (games): {len(graph['edges'])}")
    print(f"  Fingerprints: {len(graph['fingerprints'])}")
    print(f"  Episodes downloaded: {graph['meta']['total_episodes_downloaded']}")
    print(f"  BFS depth: {graph['meta']['bfs_depth_reached']}")
    print(f"  Last updated: {graph['meta']['last_updated']}")

    # Level distribution
    levels = defaultdict(int)
    twin_levels = defaultdict(int)
    for name, data in graph["teams"].items():
        level = data.get("level", 0)
        levels[level] += 1
        if data.get("is_twin"):
            twin_levels[level] += 1

    print(f"\n  Level distribution:")
    for level in sorted(levels.keys()):
        print(f"    Level {level}: {levels[level]} teams ({twin_levels.get(level, 0)} twins)")

    # Top models
    if graph.get("top_models"):
        print(f"\n  Top models:")
        for name in graph["top_models"][:10]:
            data = graph["teams"].get(name, {})
            twin_tag = "TWIN" if data.get("is_twin") else "    "
            print(f"    {twin_tag} {name:30s} elo={data.get('elo', 0):7.0f} "
                  f"level={data.get('level', '?')} sim={data.get('similarity', 0):.0%}")

    # Twin list with Elo
    twins_with_elo = [(name, graph["teams"].get(name, {}).get("elo", 0))
                       for name in graph["twins"]]
    twins_with_elo.sort(key=lambda x: x[1], reverse=True)
    print(f"\n  Twins by Elo (top 15):")
    for name, elo in twins_with_elo[:15]:
        sim = graph["teams"].get(name, {}).get("similarity", 0)
        print(f"    {name:30s} elo={elo:7.0f} sim={sim:.0%}")

    # Replay cache stats
    replay_count = len(list(REPLAY_DIR.glob("*.json")))
    replay_size = sum(f.stat().st_size for f in REPLAY_DIR.glob("*.json"))
    print(f"\n  Replay cache: {replay_count} files, {replay_size / 1024 / 1024:.0f} MB")

    print("=" * 70)


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Twin Graph: BFS twin discovery")
    parser.add_argument("--expand", type=int, metavar="DEPTH", help="BFS expand to this depth")
    parser.add_argument("--top", type=int, default=TOP_N_MODELS, help=f"Top N models to track (default {TOP_N_MODELS})")
    parser.add_argument("--status", action="store_true", help="Show graph status")
    parser.add_argument("--prune", action="store_true", help="Remove weak/old teams")
    parser.add_argument("--refresh", action="store_true", help="Full cycle: expand + prune + status")
    args = parser.parse_args()

    graph = load_graph()

    if args.status:
        show_status(graph)
        return

    # Always fetch leaderboard for Elo data
    log("Fetching leaderboard...")
    lb_data = get_leaderboard(500)
    log(f"  Leaderboard: {len(lb_data)} teams")

    # Initialize with us
    init_graph_with_us(graph, lb_data)

    if args.expand or args.refresh:
        depth = args.expand or 2
        log(f"BFS expanding to depth {depth}...")
        bfs_expand(graph, max_depth=depth, lb_data=lb_data)

    if args.prune or args.refresh:
        log("Pruning...")
        prune_graph(graph, lb_data)

    # Always update top models
    update_top_models(graph, args.top)

    save_graph(graph)
    show_status(graph)


if __name__ == "__main__":
    main()
