#!/usr/bin/env python3
"""Replay Miner: Pull replays from OUR submissions, extract profiles for BOTH
players per game, tag opponents with LB Elo, analyze by shop world.

Each replay gives us 2 profiles. We get opponent diversity for free since
Kaggle matches us against the full Elo spectrum.

Streams replays, extracts profiles, deletes raw replays after extraction.
Output: autoloop/diagnosis/miner_report.json + miner_summary.txt
"""
import csv
import json
import subprocess
import sys
import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
DIAGNOSIS_DIR = AUTOLOOP_DIR / "diagnosis"
REPLAY_TMP = AUTOLOOP_DIR / ".miner_tmp"
KAGGLE = "/Users/nathanjacob/Library/Python/3.14/bin/kaggle"
ENV = {"KAGGLE_API_TOKEN": "KGAT_REDACTED", "PATH": "/usr/bin:/bin:/usr/local/bin"}

# Time window: 4h to 24h ago
NOW = datetime.now(timezone.utc)
WINDOW_START = NOW - timedelta(hours=24)
WINDOW_END = NOW - timedelta(hours=4)

EPISODES_PER_SUB = 50  # max episodes per submission
MAX_TOTAL_EPISODES = 400

SHOP_PRODUCTS = {
    'BAKERY': ('EGG', 'WHEAT'),
    'PIZZA_SHOP': ('MILK', 'TOMATO', 'WHEAT'),
    'BRUNCH_SPOT': ('EGG', 'WHEAT', 'STRAWBERRY'),
    'YARN_STORE': ('WOOL',),
    'ICE_CREAM_SHOP': ('STRAWBERRY', 'MILK', 'WHEAT'),
    'PET_CAFE': ('CARROT',),
    'SMOOTHIE_SHOP': ('STRAWBERRY', 'MILK'),
    'FARMERS_MARKET': ('WHEAT', 'CARROT', 'TOMATO', 'STRAWBERRY'),
}


def log(msg):
    print(f"[miner] {msg}", flush=True)


# ── Step 1: Leaderboard ─────────────────────────────────

def pull_leaderboard():
    all_rows = []
    page_token = None
    for page in range(10):  # cap at 10 pages (~2000 players)
        cmd = [KAGGLE, "competitions", "leaderboard", "kaggriculture", "--show", "--csv"]
        if page_token:
            cmd += ["--page-token", page_token]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=60, env=ENV)
        lines = r.stdout.strip().split("\n")
        token_line = [l for l in lines if l.startswith("Next Page Token")]
        if token_line:
            page_token = token_line[0].split("=", 1)[1].strip()
            lines = [l for l in lines if not l.startswith("Next Page Token")]
        else:
            page_token = None
        reader = csv.DictReader(lines)
        rows = list(reader)
        all_rows.extend(rows)
        if not page_token or not rows:
            break

    lookup = {r['teamName']: float(r['score']) for r in all_rows}
    log(f"Leaderboard: {len(lookup)} players")
    return lookup


# ── Step 2: Get our submissions + episodes ───────────────

def get_our_submissions():
    """Get our submission IDs, pick those with enough games in the time window."""
    r = subprocess.run(
        [KAGGLE, "competitions", "submissions", "kaggriculture", "--format", "json"],
        capture_output=True, text=True, timeout=30, env=ENV
    )
    subs = json.loads(r.stdout)
    # Pick submissions with decent scores (>1400) that are recent enough to have games in window
    selected = []
    for s in subs:
        score = float(s.get('publicScore', 0) or 0)
        if score >= 1400:
            selected.append((int(s['ref']), score, s.get('description', '')))
    log(f"Our submissions: {len(selected)} with score >= 1400")
    return selected


def get_episodes(submission_id):
    """Get episode IDs for a submission, filter to time window."""
    try:
        r = subprocess.run(
            [KAGGLE, "competitions", "episodes", str(submission_id)],
            capture_output=True, text=True, timeout=30, env=ENV
        )
        if r.returncode != 0:
            return []

        episodes = []
        for line in r.stdout.strip().split("\n")[2:]:
            parts = line.split()
            if not parts or not parts[0].strip().isdigit():
                continue
            ep_id = int(parts[0].strip())
            # Try to parse the end time
            # Format: "115461968  2026-09-29 23:15:50.024000  2026-09-29 23:17:40.814000  ..."
            try:
                # endTime is the 3rd+4th whitespace-separated tokens
                date_str = parts[3] + " " + parts[4]
                end_time = datetime.fromisoformat(date_str).replace(tzinfo=timezone.utc)
                if WINDOW_START <= end_time <= WINDOW_END:
                    episodes.append(ep_id)
            except (IndexError, ValueError):
                episodes.append(ep_id)  # include if we can't parse time

        return episodes[:EPISODES_PER_SUB]
    except Exception as e:
        log(f"  Episode list error: {e}")
        return []


def download_replay(episode_id):
    """Download replay, return path or None."""
    REPLAY_TMP.mkdir(parents=True, exist_ok=True)
    cached = REPLAY_TMP / f"{episode_id}.json"
    if cached.exists():
        return cached
    try:
        r = subprocess.run(
            [KAGGLE, "competitions", "replay", str(episode_id), "-p", str(REPLAY_TMP), "-q"],
            capture_output=True, text=True, timeout=60, env=ENV, cwd=str(REPLAY_TMP)
        )
        downloaded = REPLAY_TMP / f"episode-{episode_id}-replay.json"
        if downloaded.exists():
            downloaded.rename(cached)
            return cached
        for f in REPLAY_TMP.glob(f"*{episode_id}*"):
            f.rename(cached)
            return cached
        return None
    except Exception:
        return None


# ── Step 3: Extract profiles ─────────────────────────────

def extract_profile(replay_path, lb_lookup):
    """Extract profiles for both players. Returns list of 2 profile dicts."""
    try:
        data = json.load(open(replay_path))
    except Exception:
        return None

    steps = data.get("steps", [])
    if len(steps) < 700:
        return None

    info = data.get("info", {})
    teams = info.get("TeamNames", [])
    if len(teams) < 2:
        return None

    def get_shops(day):
        s = min(day * 24 + 23, len(steps) - 1)
        return list(steps[s][0]["observation"].get("town", {}).get("unlocked_shops", []))

    shops_d3 = get_shops(3)
    shops_d6 = get_shops(6)
    shops_d9 = get_shops(9)
    shops_d12 = get_shops(12)
    shop_pair = tuple(shops_d6[:2]) if len(shops_d6) >= 2 else tuple(shops_d6)
    shop_trio = tuple(shops_d9[:3]) if len(shops_d9) >= 3 else tuple(shops_d9)

    profiles = []
    for seat in [0, 1]:
        name = teams[seat]
        elo = lb_lookup.get(name, 0)
        opp_seat = 1 - seat

        # Assign Elo band
        if elo >= 2600: band = "2600+"
        elif elo >= 2400: band = "2400-2600"
        elif elo >= 2200: band = "2200-2400"
        elif elo >= 2000: band = "2000-2200"
        elif elo > 0: band = "<2000"
        else: band = "unknown"

        final_score = steps[-1][0]["observation"]["farms"][seat]["money"]

        # Farm snapshots at key days
        farm_snapshots = {}
        for day in [10, 15, 20, 25]:
            s = min(day * 24 + 12, len(steps) - 1)
            obs = steps[s][0]["observation"]
            farm = obs["farms"][seat]
            crops = defaultdict(int)
            animals = defaultdict(int)
            for row in farm.get("tiles", []):
                for t in row:
                    if isinstance(t, dict):
                        if t.get("crop"): crops[t["crop"]] += 1
                        elif t.get("animal"): animals[t["animal"]] += 1
            farm_snapshots[day] = {
                "crops": dict(crops),
                "animals": dict(animals),
                "workers": 1 + len(farm.get("hands", [])),
                "money": farm["money"],
            }

        # Sell quantities and revenue
        sells = defaultdict(lambda: {"qty": 0, "revenue": 0})
        for s_idx, step_data in enumerate(steps):
            prices = step_data[0]["observation"]["market"]["prices"]
            for order in step_data[seat].get("action", {}).get("market", []):
                if order and len(order) >= 3 and order[0] == "SELL":
                    item, qty = order[1], int(order[2])
                    sells[item]["qty"] += qty
                    sells[item]["revenue"] += float(prices.get(item, 0)) * qty

        # Money at day boundaries (every 3 days)
        money_curve = {}
        for day in range(0, 30, 3):
            s = min(day * 24, len(steps) - 1)
            money_curve[day] = steps[s][0]["observation"]["farms"][seat]["money"]

        # Demand from shops at day 12
        demand = defaultdict(int)
        for shop in shops_d12:
            for product in SHOP_PRODUCTS.get(shop, ()):
                demand[product] += 1

        opp_score = steps[-1][0]["observation"]["farms"][opp_seat]["money"]

        profiles.append({
            "team": name,
            "elo": elo,
            "band": band,
            "seat": seat,
            "score": final_score,
            "won": final_score > opp_score,
            "margin": final_score - opp_score,
            "shop_pair": list(shop_pair),
            "shop_trio": list(shop_trio),
            "shops_d12": shops_d12,
            "demand": dict(demand),
            "farm": farm_snapshots,
            "sells": {k: dict(v) for k, v in sells.items()},
            "money_curve": money_curve,
        })

    return profiles


# ── Step 4: Analysis ─────────────────────────────────────

def analyze(all_profiles):
    """Run all analysis layers."""
    # Group by shop pair
    by_world = defaultdict(list)
    for p in all_profiles:
        by_world[tuple(p["shop_pair"])].append(p)

    results = {
        "world_stats": [],
        "elo_band_profiles": [],
        "action_diffs": [],
    }

    for shop_pair, profiles in sorted(by_world.items(), key=lambda x: -len(x[1])):
        n = len(profiles)
        if n < 4:
            continue

        winners = [p for p in profiles if p["won"]]
        losers = [p for p in profiles if not p["won"]]
        if not winners or not losers:
            continue

        # World stats
        avg_winner_elo = sum(p["elo"] for p in winners) / len(winners) if winners else 0
        avg_loser_elo = sum(p["elo"] for p in losers) / len(losers) if losers else 0

        # Money divergence: find first day where winners pull ahead by >5%
        days = list(range(0, 30, 3))
        diverge_day = None
        for day in days:
            w_money = [p["money_curve"].get(day, p["money_curve"].get(str(day), 0)) for p in winners]
            l_money = [p["money_curve"].get(day, p["money_curve"].get(str(day), 0)) for p in losers]
            w_avg = sum(w_money) / len(w_money) if w_money else 0
            l_avg = sum(l_money) / len(l_money) if l_money else 0
            total = w_avg + l_avg
            if total > 2000 and w_avg - l_avg > total * 0.025:
                diverge_day = day
                break

        # Farm diff at day 15 and 25
        farm_diffs = {}
        for day in [15, 25]:
            w_crops = defaultdict(float)
            w_animals = defaultdict(float)
            l_crops = defaultdict(float)
            l_animals = defaultdict(float)
            for p in winners:
                snap = p["farm"].get(day, p["farm"].get(str(day), {}))
                for c, n in snap.get("crops", {}).items(): w_crops[c] += n / len(winners)
                for a, n in snap.get("animals", {}).items(): w_animals[a] += n / len(winners)
            for p in losers:
                snap = p["farm"].get(day, p["farm"].get(str(day), {}))
                for c, n in snap.get("crops", {}).items(): l_crops[c] += n / len(losers)
                for a, n in snap.get("animals", {}).items(): l_animals[a] += n / len(losers)

            crop_d = {c: round(w_crops.get(c,0) - l_crops.get(c,0), 1)
                      for c in set(list(w_crops) + list(l_crops)) if abs(w_crops.get(c,0) - l_crops.get(c,0)) > 1}
            animal_d = {a: round(w_animals.get(a,0) - l_animals.get(a,0), 1)
                        for a in set(list(w_animals) + list(l_animals)) if abs(w_animals.get(a,0) - l_animals.get(a,0)) > 0.5}
            if crop_d or animal_d:
                farm_diffs[day] = {"crops": crop_d, "animals": animal_d}

        # Sell revenue diff
        w_sells = defaultdict(float)
        l_sells = defaultdict(float)
        for p in winners:
            for item, d in p["sells"].items(): w_sells[item] += d["revenue"] / len(winners)
        for p in losers:
            for item, d in p["sells"].items(): l_sells[item] += d["revenue"] / len(losers)
        sell_diffs = {item: round(w_sells.get(item,0) - l_sells.get(item,0))
                      for item in set(list(w_sells) + list(l_sells))
                      if abs(w_sells.get(item,0) - l_sells.get(item,0)) > 500}

        # Elo band breakdown
        band_profiles = defaultdict(list)
        for p in profiles:
            band_profiles[p["band"]].append(p)
        band_summary = {}
        for band, bps in sorted(band_profiles.items(), reverse=True):
            if len(bps) < 2:
                continue
            avg_score = sum(p["score"] for p in bps) / len(bps)
            wr = sum(1 for p in bps if p["won"]) / len(bps)
            # Avg farm at day 25
            crops25 = defaultdict(float)
            animals25 = defaultdict(float)
            for p in bps:
                snap = p["farm"].get(25, p["farm"].get("25", {}))
                for c, n in snap.get("crops", {}).items(): crops25[c] += n / len(bps)
                for a, n in snap.get("animals", {}).items(): animals25[a] += n / len(bps)
            band_summary[band] = {
                "n": len(bps), "avg_score": round(avg_score), "win_rate": round(wr, 2),
                "crops_d25": {k: round(v,1) for k,v in crops25.items() if v > 0.5},
                "animals_d25": {k: round(v,1) for k,v in animals25.items() if v > 0.3},
            }

        results["world_stats"].append({
            "shop_pair": list(shop_pair),
            "n_games": n // 2,
            "elo_separation": round(avg_winner_elo - avg_loser_elo),
            "diverge_day": diverge_day,
            "farm_diffs": farm_diffs,
            "sell_diffs": sell_diffs,
            "band_summary": band_summary,
        })

    # Sort by Elo separation (most interesting first)
    results["world_stats"].sort(key=lambda x: -abs(x["elo_separation"]))
    return results


# ── Step 5: Summary ──────────────────────────────────────

def generate_summary(results, all_profiles):
    lines = []
    n_players = len(set(p["team"] for p in all_profiles))
    n_games = len(all_profiles) // 2
    elo_range = f"{min((p['elo'] for p in all_profiles if p['elo']>0), default=0):.0f}-{max(p['elo'] for p in all_profiles):.0f}"
    bands = defaultdict(int)
    for p in all_profiles:
        bands[p["band"]] += 1

    lines.append(f"REPLAY MINER — {n_games} games, {n_players} unique players, Elo {elo_range}")
    lines.append(f"Band distribution: {dict(sorted(bands.items(), reverse=True))}")
    lines.append(f"Window: {WINDOW_START.strftime('%H:%M')}-{WINDOW_END.strftime('%H:%M')} UTC")
    lines.append("")

    for ws in results["world_stats"][:20]:
        sp = "+".join(ws["shop_pair"])
        lines.append(f"{'='*60}")
        lines.append(f"WORLD: {sp} ({ws['n_games']} games, elo_sep={ws['elo_separation']:+d})")
        if ws["diverge_day"] is not None:
            lines.append(f"  Gap opens: day {ws['diverge_day']}")

        # Farm diffs
        for day, diffs in sorted(ws.get("farm_diffs", {}).items()):
            if diffs["crops"] or diffs["animals"]:
                items = []
                for c, d in sorted(diffs["crops"].items(), key=lambda x: -abs(x[1])):
                    items.append(f"{c}:{d:+.1f}")
                for a, d in sorted(diffs["animals"].items(), key=lambda x: -abs(x[1])):
                    items.append(f"{a}:{d:+.1f}")
                lines.append(f"  Day {day} winners have: {', '.join(items)}")

        # Sell diffs
        if ws["sell_diffs"]:
            items = sorted(ws["sell_diffs"].items(), key=lambda x: -abs(x[1]))
            for item, rev in items[:5]:
                lines.append(f"  Sell {item}: winners earn ${rev:+,.0f} more")

        # Elo bands
        if ws["band_summary"]:
            lines.append(f"  By Elo band:")
            for band, bs in sorted(ws["band_summary"].items(), reverse=True):
                crops = ", ".join(f"{c}={v}" for c,v in sorted(bs["crops_d25"].items(), key=lambda x:-x[1])[:4])
                animals = ", ".join(f"{a}={v}" for a,v in sorted(bs["animals_d25"].items(), key=lambda x:-x[1])[:3])
                lines.append(f"    {band:12s} n={bs['n']:2d} WR={bs['win_rate']:.0%} ${bs['avg_score']:>8,}  {crops}  {animals}")
        lines.append("")

    return "\n".join(lines)


# ── Main ─────────────────────────────────────────────────

def main():
    log("=== REPLAY MINER START ===")
    REPLAY_TMP.mkdir(parents=True, exist_ok=True)
    DIAGNOSIS_DIR.mkdir(parents=True, exist_ok=True)

    # Step 1: Leaderboard
    log("Pulling leaderboard...")
    lb_lookup = pull_leaderboard()

    # Step 2: Our submissions
    log("Getting our submissions...")
    subs = get_our_submissions()

    # Step 3: Pull episodes + extract
    log("Pulling episodes and extracting profiles...")
    all_profiles = []
    seen_episodes = set()
    total_downloaded = 0

    for sub_id, score, desc in subs:
        if total_downloaded >= MAX_TOTAL_EPISODES:
            break
        log(f"  Sub {sub_id} (score={score:.0f}, {desc[:40]})...")
        episodes = get_episodes(sub_id)
        if not episodes:
            log(f"    No episodes in time window")
            continue

        new_eps = [e for e in episodes if e not in seen_episodes]
        log(f"    {len(new_eps)} new episodes (of {len(episodes)} total)")

        batch_extracted = 0
        for ep_id in new_eps:
            if total_downloaded >= MAX_TOTAL_EPISODES:
                break
            seen_episodes.add(ep_id)
            path = download_replay(ep_id)
            if not path:
                continue
            profiles = extract_profile(path, lb_lookup)
            if profiles:
                all_profiles.extend(profiles)
                batch_extracted += 1
                total_downloaded += 1
            # Cleanup
            try:
                path.unlink()
            except Exception:
                pass

        log(f"    Extracted {batch_extracted} games")

    log(f"\nTotal: {len(all_profiles)} profiles from {total_downloaded} games")

    if len(all_profiles) < 20:
        log("Not enough data. Check time window or submissions.")
        return

    # Step 4: Analyze
    log("Analyzing...")
    results = analyze(all_profiles)
    log(f"  {len(results['world_stats'])} worlds with enough data")

    # Step 5: Output
    summary = generate_summary(results, all_profiles)

    report = {
        "meta": {
            "total_games": total_downloaded,
            "total_profiles": len(all_profiles),
            "unique_players": len(set(p["team"] for p in all_profiles)),
            "timestamp": datetime.now().isoformat(),
        },
        "results": results,
    }

    with open(DIAGNOSIS_DIR / "miner_report.json", "w") as f:
        json.dump(report, f, indent=2, default=str)
    with open(DIAGNOSIS_DIR / "miner_summary.txt", "w") as f:
        f.write(summary)

    print("\n" + summary)

    # Cleanup
    try:
        for f in REPLAY_TMP.glob("*"):
            f.unlink()
        REPLAY_TMP.rmdir()
    except Exception:
        pass

    log("=== REPLAY MINER DONE ===")


if __name__ == "__main__":
    main()
