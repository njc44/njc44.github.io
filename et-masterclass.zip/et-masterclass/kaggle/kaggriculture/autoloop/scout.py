#!/usr/bin/env python3
"""Scout: Download & extract agents from top Kaggle notebooks.

Handles all known encoding formats:
  - %%writefile main.py (direct code in cell)
  - base85/base64 + zlib/lzma compressed
  - Raw .py files
  - AST-based extraction of encoded strings

Usage:
    python scout.py                  # Full scout run
    python scout.py --extract-only   # Only extract from already-downloaded notebooks
"""
import argparse
import ast
import base64
import json
import os
import re
import subprocess
import sys
import zlib
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"
STATE_FILE = AUTOLOOP_DIR / "state.json"
NOTEBOOK_CACHE = AUTOLOOP_DIR / ".notebook_cache"

AGENTS_DIR.mkdir(parents=True, exist_ok=True)
NOTEBOOK_CACHE.mkdir(parents=True, exist_ok=True)


def log(msg):
    print(f"[scout] {msg}", flush=True)


# ── Download ──────────────────────────────────────────────────

def download_notebooks():
    """Download top notebooks from Kaggle competition."""
    refs = set()

    for sort_by in ["voteCount", "dateCreated", "dateRun"]:
        try:
            result = subprocess.run(
                ["kaggle", "kernels", "list", "--competition", "kaggriculture",
                 "--sort-by", sort_by, "--page-size", "15"],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                for line in result.stdout.strip().split("\n")[1:]:  # skip header
                    parts = line.split()
                    if parts and "/" in parts[0]:
                        refs.add(parts[0])
        except Exception as e:
            log(f"  Warning: kaggle list --sort-by {sort_by} failed: {e}")

    log(f"  Found {len(refs)} unique notebook refs")

    new_count = 0
    for ref in refs:
        slug = ref.replace("/", "__")
        dest = NOTEBOOK_CACHE / slug

        if dest.exists() and any(dest.iterdir()):
            continue  # already downloaded

        log(f"  Downloading: {ref}")
        dest.mkdir(parents=True, exist_ok=True)
        try:
            result = subprocess.run(
                ["kaggle", "kernels", "pull", ref, "-p", str(dest)],
                capture_output=True, text=True, timeout=60
            )
            if result.returncode == 0:
                new_count += 1
            else:
                # Clean up empty dir on failure
                try:
                    dest.rmdir()
                except OSError:
                    pass
        except Exception as e:
            log(f"    Failed: {e}")

    log(f"  Downloaded {new_count} new notebooks")
    return new_count


# ── Extraction strategies ─────────────────────────────────────

def _try_writefile(cells):
    """Strategy: %%writefile main.py cell."""
    for cell in cells:
        src = "".join(cell.get("source", []))
        if "%%writefile main.py" in src or "%%writefile submission/main.py" in src:
            code = re.sub(r"%%writefile\s+\S+\s*\n?", "", src, count=1)
            if len(code) > 500 and ("def agent(" in code or "def my_agent(" in code
                                     or "class Policy" in code or "observation" in code):
                return code
    return None


def _try_base85_ast(cells):
    """Strategy: Find base85 encoded string via AST, decode safely."""
    for cell in cells:
        src = "".join(cell.get("source", []))
        if "b85" not in src.lower() and "base85" not in src.lower():
            continue
        try:
            tree = ast.parse(src)
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and "b85" in target.id.lower():
                            try:
                                b85_str = ast.literal_eval(node.value)
                                if isinstance(b85_str, str) and len(b85_str) > 1000:
                                    raw = base64.b85decode(b85_str)
                                    code = zlib.decompress(raw).decode("utf-8")
                                    if len(code) > 500:
                                        return code
                            except Exception:
                                pass
        except SyntaxError:
            pass
    return None


def _try_base64_ast(cells):
    """Strategy: Find base64 encoded string via AST, decode safely."""
    for cell in cells:
        src = "".join(cell.get("source", []))
        if "b64" not in src.lower() and "base64" not in src.lower():
            continue
        if "b85" in src.lower():
            continue  # handled by b85 strategy
        try:
            tree = ast.parse(src)
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and ("b64" in target.id.lower()
                                                              or "archive" in target.id.lower()
                                                              or "encoded" in target.id.lower()):
                            try:
                                val = ast.literal_eval(node.value)
                                if isinstance(val, str) and len(val) > 1000:
                                    raw = base64.b64decode(val)
                                    # Try zlib first
                                    try:
                                        code = zlib.decompress(raw).decode("utf-8")
                                    except zlib.error:
                                        # Try lzma
                                        import lzma
                                        try:
                                            code = lzma.decompress(raw).decode("utf-8")
                                        except Exception:
                                            code = raw.decode("utf-8", errors="ignore")
                                    if len(code) > 500:
                                        return code
                            except Exception:
                                pass
        except SyntaxError:
            pass
    return None


def _try_source_bytes(cells):
    """Strategy: SOURCE_BYTES = b''.join((...)) pattern (Ahmed v47+ encoding).

    The cell builds SOURCE_BYTES from byte literal concatenation and writes
    it to WORKDIR / 'main.py'. We run the extraction in a subprocess for
    isolation, then read the output file.
    """
    import shutil
    import subprocess as _sp
    import tempfile

    for cell in cells:
        src = "".join(cell.get("source", []))
        if "SOURCE_BYTES" not in src or "b''.join" not in src:
            continue
        workdir = None
        try:
            workdir = tempfile.mkdtemp()
            # Write cell source to a temp file, injecting WORKDIR
            cell_file = os.path.join(workdir, "_cell.py")
            with open(cell_file, "w") as f:
                f.write("from pathlib import Path\n")
                f.write(f"WORKDIR = Path({workdir!r})\n")
                f.write("WORKDIR.mkdir(parents=True, exist_ok=True)\n")
                f.write(src)

            # Execute in a subprocess with timeout for isolation
            _sp.run(
                [sys.executable, cell_file],
                capture_output=True, text=True, timeout=30,
            )

            main_py = os.path.join(workdir, "main.py")
            if os.path.exists(main_py):
                with open(main_py) as f:
                    code = f.read()
                if len(code) > 500 and ("def agent(" in code or "_ROUTES" in code):
                    return code
        except Exception as e:
            log(f"    source_bytes subprocess failed: {e}")
        finally:
            if workdir:
                shutil.rmtree(workdir, ignore_errors=True)
    return None


def _try_agent_function(cells):
    """Strategy: Find the largest code cell with 'def agent(' in it."""
    best = None
    best_len = 0
    for cell in reversed(cells):
        src = "".join(cell.get("source", []))
        if ("def agent(" in src or "def my_agent(" in src) and len(src) > best_len:
            # Make sure it's substantial
            if len(src) > 500:
                best = src
                best_len = len(src)
    return best


def extract_agent(nb_path):
    """Try all extraction strategies on a notebook. Returns code string or None."""
    if nb_path.suffix == ".py":
        code = nb_path.read_text()
        if len(code) > 500:
            return code
        return None

    if nb_path.suffix != ".ipynb":
        return None

    try:
        with open(nb_path) as f:
            nb = json.load(f)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None

    cells = nb.get("cells", [])
    if not cells:
        return None

    # Try strategies in order of reliability
    for strategy_name, strategy_fn in [
        ("writefile", _try_writefile),
        ("source_bytes", _try_source_bytes),
        ("base85", _try_base85_ast),
        ("base64", _try_base64_ast),
        ("agent_function", _try_agent_function),
    ]:
        try:
            code = strategy_fn(cells)
            if code:
                log(f"    Extracted via {strategy_name} ({len(code)} chars)")
                return code
        except Exception as e:
            log(f"    Strategy {strategy_name} failed: {e}")

    return None


# ── Smoke test ────────────────────────────────────────────────

def smoke_test(agent_dir):
    """Run a quick 1-game test to verify the agent doesn't crash."""
    main_py = agent_dir / "main.py"
    if not main_py.exists():
        return False

    python = "/Users/nathanjacob/opt/miniconda3/bin/python"
    try:
        result = subprocess.run(
            [python, "-c", f"""
from kaggle_environments import make
env = make('kaggriculture')  # LB-identical: no debug, no overrides
r = env.run(['{main_py}', '{main_py}'])
f = r[-1]
ok = f[0]['status'] == 'DONE' and f[1]['status'] == 'DONE'
print('OK' if ok else 'FAIL')
"""],
            capture_output=True, text=True, timeout=30,
            cwd=str(WORK_DIR)
        )
        return "OK" in result.stdout
    except Exception as e:
        log(f"    Smoke test error: {e}")
        return False


# ── Main extraction pipeline ──────────────────────────────────

def extract_all():
    """Extract agents from all downloaded notebooks."""
    new_agents = 0

    for nb_dir in sorted(NOTEBOOK_CACHE.iterdir()):
        if not nb_dir.is_dir():
            continue

        slug = nb_dir.name
        agent_dir = AGENTS_DIR / slug

        # Skip if already extracted and has main.py
        if (agent_dir / "main.py").exists():
            continue

        # Find notebook file
        nb_files = list(nb_dir.glob("*.ipynb")) + list(nb_dir.glob("*.py"))
        if not nb_files:
            continue

        nb_file = nb_files[0]
        log(f"  Extracting: {slug}")

        code = extract_agent(nb_file)
        if not code:
            log(f"    No agent code found")
            continue

        # Write agent
        agent_dir.mkdir(parents=True, exist_ok=True)
        (agent_dir / "main.py").write_text(code)

        # Smoke test
        log(f"    Smoke testing...")
        if smoke_test(agent_dir):
            log(f"    PASS — agent works")
            new_agents += 1

            # Save metadata
            meta = {
                "source_notebook": slug,
                "source_file": nb_file.name,
                "code_size": len(code),
                "code_lines": code.count("\n") + 1,
                "extracted_at": __import__("datetime").datetime.now().isoformat(),
                "smoke_test": "pass",
            }
            (agent_dir / "meta.json").write_text(json.dumps(meta, indent=2))
        else:
            log(f"    FAIL — agent crashes, removing")
            import shutil
            shutil.rmtree(agent_dir, ignore_errors=True)

    log(f"  Extracted {new_agents} new working agents")
    return new_agents


# ── Seed known agents ─────────────────────────────────────────

def seed_known_agents():
    """Copy already-known agents into the agents directory."""
    known = {
        "reyhanks_dynamic": "/tmp/kaggriculture_latest/reyhanks_dynamic/main.py",
        "flexon_powerful": "/tmp/kaggriculture_latest/flexon_powerful/main.py",
        "prvsiyan_moon": "/tmp/kaggriculture_test/prvsiyan_moon/main.py",
        "prvsiyan_soil": "/tmp/kaggriculture_test/prvsiyan_soil/main.py",
        "hybrid_v1": "/tmp/kaggriculture_latest/hybrid_v1/main.py",
    }

    # For multi-file agents, copy all files
    multi_file = {
        "hybrid_v1": "/tmp/kaggriculture_latest/hybrid_v1/",
    }

    import shutil
    for name, path in known.items():
        agent_dir = AGENTS_DIR / name
        if (agent_dir / "main.py").exists():
            continue

        src = Path(path)
        if not src.exists():
            continue

        agent_dir.mkdir(parents=True, exist_ok=True)

        if name in multi_file:
            src_dir = Path(multi_file[name])
            for f in src_dir.iterdir():
                if f.is_file() and not f.name.startswith(".") and f.name != "__pycache__":
                    shutil.copy2(f, agent_dir / f.name)
        else:
            shutil.copy2(src, agent_dir / "main.py")

        log(f"  Seeded: {name}")


# ── Entry point ───────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Scout: download & extract agents")
    parser.add_argument("--extract-only", action="store_true",
                        help="Skip downloading, only extract from cache")
    parser.add_argument("--seed", action="store_true",
                        help="Seed known agents into agents directory")
    args = parser.parse_args()

    log("=== SCOUT START ===")

    if args.seed:
        seed_known_agents()

    if not args.extract_only:
        log("Phase 1: Downloading notebooks...")
        download_notebooks()

    log("Phase 2: Extracting agents...")
    new = extract_all()

    # List all available agents
    agents = sorted([d.name for d in AGENTS_DIR.iterdir()
                     if d.is_dir() and (d / "main.py").exists()])
    log(f"Total agents available: {len(agents)}")
    for a in agents:
        log(f"  - {a}")

    log("=== SCOUT DONE ===")
    return agents


if __name__ == "__main__":
    main()
