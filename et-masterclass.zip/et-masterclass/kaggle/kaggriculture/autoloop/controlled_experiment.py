#!/usr/bin/env python3
"""Controlled Experiment Runner: Fixed-seed, seat-swapped testing.

Leoprovorov's methodology: N seeds × 2 seats = 2N games.
Same seed guarantees same world (shops, weeds, market params).

Usage:
    python controlled_experiment.py <agent_a> <agent_b> --seeds 42,123,456
    python controlled_experiment.py <agent_a> <agent_b> --worlds 6
    python controlled_experiment.py <agent_a> <agent_b> --lb-seeds replays/pipe26a_lb/
"""
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

DEFAULT_SEEDS = [42, 123, 456, 789, 1337, 2468]


def _resolve_agent_path(path_str):
    """Resolve agent path (directory -> main.py)."""
    p = Path(path_str)
    if p.is_dir():
        main = p / "main.py"
        if main.exists():
            return str(main)
    return str(p)


def _run_seeded_game(agent_a, agent_b, seed, seat_order=0):
    """Run one game with a fixed seed.

    seat_order=0: agent_a is player 0
    seat_order=1: agent_a is player 1
    """
    from kaggle_environments import make
    env = make("kaggriculture", configuration={"seed": seed})

    if seat_order == 0:
        agents = [agent_a, agent_b]
    else:
        agents = [agent_b, agent_a]

    t0 = time.time()
    env.run(agents)
    elapsed = time.time() - t0

    rewards = [env.state[i]["reward"] for i in range(2)]
    statuses = [env.state[i].get("status", "?") for i in range(2)]

    # Extract shop pair from replay
    shop1 = shop2 = "UNKNOWN"
    if len(env.steps) > 72:
        obs72 = env.steps[72][0].get("observation", {})
        unlocked = obs72.get("town", {}).get("unlocked_shops", [])
        if unlocked:
            shop1 = unlocked[0]
    if len(env.steps) > 144:
        obs144 = env.steps[144][0].get("observation", {})
        unlocked = obs144.get("town", {}).get("unlocked_shops", [])
        if len(unlocked) >= 2:
            shop2 = unlocked[1]

    # Orient results from agent_a's perspective
    a_seat = 0 if seat_order == 0 else 1
    b_seat = 1 - a_seat
    a_reward = rewards[a_seat] or 0
    b_reward = rewards[b_seat] or 0
    margin = a_reward - b_reward

    return {
        "seed": seed,
        "seat_order": seat_order,
        "a_seat": a_seat,
        "a_reward": a_reward,
        "b_reward": b_reward,
        "margin": margin,
        "outcome": "win" if margin > 0 else "loss" if margin < 0 else "tie",
        "shop1": shop1,
        "shop2": shop2,
        "world": f"{shop1}+{shop2}",
        "elapsed": round(elapsed, 1),
        "statuses": statuses,
    }


def run_seed_pair(agent_a, agent_b, seed):
    """Run TWO games with same seed: A-as-P0, then A-as-P1."""
    game0 = _run_seeded_game(agent_a, agent_b, seed, seat_order=0)
    game1 = _run_seeded_game(agent_a, agent_b, seed, seat_order=1)

    return {
        "seed": seed,
        "world": game0["world"],
        "game_as_p0": game0,
        "game_as_p1": game1,
        "a_wins_both": game0["outcome"] == "win" and game1["outcome"] == "win",
        "b_wins_both": game0["outcome"] == "loss" and game1["outcome"] == "loss",
        "seat_dependent": game0["outcome"] != game1["outcome"],
        "p0_margin": game0["margin"],
        "p1_margin": game1["margin"],
    }


def extract_lb_seeds(replay_dir, n=6):
    """Extract seed values from existing LB replays."""
    replay_dir = Path(replay_dir)
    seeds = set()
    for fpath in sorted(replay_dir.glob("*.json")):
        if fpath.name.startswith("_"):
            continue
        try:
            with open(fpath) as f:
                replay = json.load(f)
            seed = replay.get("info", {}).get("seed")
            if seed is not None:
                seeds.add(int(seed))
        except (json.JSONDecodeError, OSError):
            continue
    return sorted(seeds)[:n]


def run_controlled_experiment(agent_a, agent_b, seeds=None, parallel=1):
    """Run full controlled experiment: seeds × 2 seats."""
    if seeds is None:
        seeds = DEFAULT_SEEDS

    agent_a = _resolve_agent_path(agent_a)
    agent_b = _resolve_agent_path(agent_b)

    results = []
    a_wins = a_losses = a_ties = 0
    a_name = Path(agent_a).parent.name
    b_name = Path(agent_b).parent.name

    print(f"{'='*70}")
    print(f"CONTROLLED EXPERIMENT")
    print(f"  Agent A: {a_name}")
    print(f"  Agent B: {b_name}")
    print(f"  Seeds: {len(seeds)} × 2 seats = {len(seeds)*2} games")
    print(f"{'='*70}")

    for seed in seeds:
        pair = run_seed_pair(agent_a, agent_b, seed)
        results.append(pair)

        for game in [pair["game_as_p0"], pair["game_as_p1"]]:
            if game["outcome"] == "win":
                a_wins += 1
            elif game["outcome"] == "loss":
                a_losses += 1
            else:
                a_ties += 1

        sym = "BOTH" if pair["a_wins_both"] else "SEAT" if pair["seat_dependent"] else "LOST"
        print(f"  Seed {seed:>10d} [{pair['world']:40s}]: "
              f"P0=${pair['p0_margin']:+6.0f} P1=${pair['p1_margin']:+6.0f} → {sym}")

    total = a_wins + a_losses + a_ties
    print(f"\n{'='*70}")
    print(f"RESULTS: {a_wins}W {a_losses}L {a_ties}T ({total} games)")
    print(f"Win rate: {100*a_wins/total:.0f}%")

    both_wins = sum(1 for r in results if r["a_wins_both"])
    both_losses = sum(1 for r in results if r["b_wins_both"])
    seat_dep = sum(1 for r in results if r["seat_dependent"])
    print(f"A wins both seats: {both_wins}/{len(results)} worlds")
    print(f"B wins both seats: {both_losses}/{len(results)} worlds")
    print(f"Seat-dependent: {seat_dep}/{len(results)} worlds")
    print(f"{'='*70}")

    return {
        "a_name": a_name,
        "b_name": b_name,
        "seeds": seeds,
        "total_games": total,
        "a_wins": a_wins,
        "a_losses": a_losses,
        "a_ties": a_ties,
        "win_rate": a_wins / total if total else 0,
        "both_seat_wins": both_wins,
        "both_seat_losses": both_losses,
        "seat_dependent": seat_dep,
        "per_seed": results,
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Controlled experiment runner")
    parser.add_argument("agent_a", help="Path to agent A")
    parser.add_argument("agent_b", help="Path to agent B")
    parser.add_argument("--seeds", help="Comma-separated seeds")
    parser.add_argument("--worlds", type=int, default=6, help="Number of worlds (uses default seeds)")
    parser.add_argument("--lb-seeds", help="Extract seeds from LB replay dir")
    parser.add_argument("--parallel", type=int, default=1)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.seeds:
        seeds = [int(s.strip()) for s in args.seeds.split(",")]
    elif args.lb_seeds:
        seeds = extract_lb_seeds(args.lb_seeds, n=args.worlds)
        print(f"Extracted {len(seeds)} seeds from LB replays")
    else:
        seeds = DEFAULT_SEEDS[:args.worlds]

    results = run_controlled_experiment(args.agent_a, args.agent_b, seeds=seeds, parallel=args.parallel)

    if args.json:
        json.dump(results, sys.stdout, indent=2, default=str)
