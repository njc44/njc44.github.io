#!/usr/bin/env python3
"""Version Progression Study: H2H between consecutive Ahmed versions.

Runs 200-game matchups between each consecutive version pair to identify
which structural changes produce dominant (statistically significant) results.

Usage:
    python progression_study.py              # Run all pairs
    python progression_study.py --games 50   # Quick test
"""
import argparse
import json
import math
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"

# Chronological order of Ahmed's versions
VERSION_CHAIN = [
    ("v35", AGENTS_DIR / "ahmedberatozer__kaggriculture-v35-reactive-sales-sheep-expansi" / "main.py"),
    ("v36", AGENTS_DIR / "ahmedberatozer__kaggriculture-v36-guarded-four-turn-sales" / "main.py"),
    ("moreYield", AGENTS_DIR / "ahmedberatozer__more-yield-smarter-labor" / "main.py"),
    ("v38", AGENTS_DIR / "ahmedberatozer__kaggriculture-v38-smarter-feed-stronger-margins" / "main.py"),
    ("v39", AGENTS_DIR / "ahmedberatozer__kaggriculture-v39-ready-before-the-rush" / "main.py"),
    ("v40", AGENTS_DIR / "ahmedberatozer__kaggriculture-v40-plans-that-fit-the-shops" / "main.py"),
    ("v41", AGENTS_DIR / "ahmedberatozer__kaggriculture-v41-review-candidate" / "main.py"),
]

# Also test our candidate
CANDIDATE = ("_candidate", AGENTS_DIR / "_candidate" / "main.py")


def binomial_significance(wins, losses, ties):
    total = wins + losses + ties
    if total == 0:
        return 0.5, 1.0, False
    elo_points = wins + 0.5 * ties
    elo_rate = elo_points / total
    se = math.sqrt(0.25 / total)
    if se == 0:
        return elo_rate, 1.0, False
    z = (elo_rate - 0.5) / se
    p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))
    return round(elo_rate, 4), round(p_value, 4), p_value < 0.05


def run_single_game(args):
    """Run one game. Designed for ProcessPoolExecutor."""
    agent_a, agent_b, game_idx = args
    from kaggle_environments import make
    seat = game_idx % 2
    if seat == 0:
        p0, p1 = str(agent_a), str(agent_b)
    else:
        p0, p1 = str(agent_b), str(agent_a)
    try:
        env = make("kaggriculture")
        result = env.run([p0, p1])
        final = result[-1]
        r0, r1 = final[0]["reward"], final[1]["reward"]
        if final[0]["status"] != "DONE" or final[1]["status"] != "DONE":
            return None
        score_a = r0 if seat == 0 else r1
        score_b = r1 if seat == 0 else r0
        margin = score_a - score_b
        return "W" if margin > 0 else ("L" if margin < 0 else "T")
    except Exception:
        return None


def run_h2h(name_a, path_a, name_b, path_b, n_games, parallel=4):
    """Run H2H with parallel game execution."""
    args_list = [(str(path_a), str(path_b), i) for i in range(n_games)]

    results = []
    with ProcessPoolExecutor(max_workers=parallel) as executor:
        futures = [executor.submit(run_single_game, args) for args in args_list]
        for future in as_completed(futures):
            r = future.result()
            if r:
                results.append(r)

    wins = results.count("W")
    losses = results.count("L")
    ties = results.count("T")
    total = wins + losses + ties
    elo_rate, p_value, is_sig = binomial_significance(wins, losses, ties)

    return {
        "newer": name_a,
        "older": name_b,
        "wins": wins,
        "losses": losses,
        "ties": ties,
        "total": total,
        "elo_rate": elo_rate,
        "p_value": p_value,
        "is_significant": is_sig,
        "newer_wr": round(wins / total, 3) if total else 0,
    }


def format_result(r):
    sig = "***" if r["is_significant"] else "   "
    direction = "UPGRADE" if r["elo_rate"] > 0.5 and r["is_significant"] else (
        "DOWNGRADE" if r["elo_rate"] < 0.5 and r["is_significant"] else "NO CHANGE"
    )
    return (f"  {r['newer']:>12s} vs {r['older']:<12s}  "
            f"{r['wins']:>3d}W-{r['losses']:>3d}L-{r['ties']:>3d}T  "
            f"elo={r['elo_rate']:.1%}  p={r['p_value']:.4f} {sig}  {direction}")


def main():
    parser = argparse.ArgumentParser(description="Version Progression Study")
    parser.add_argument("--games", type=int, default=200, help="Games per matchup")
    parser.add_argument("--parallel", type=int, default=4, help="Parallel games")
    args = parser.parse_args()

    import os
    os.chdir(str(WORK_DIR))

    print("=" * 80)
    print("  VERSION PROGRESSION STUDY")
    print(f"  {args.games} games per matchup, {args.parallel} parallel workers")
    print("=" * 80)

    # Consecutive pairs
    pairs = []
    for i in range(len(VERSION_CHAIN) - 1):
        newer_name, newer_path = VERSION_CHAIN[i + 1]
        older_name, older_path = VERSION_CHAIN[i]
        if newer_path.exists() and older_path.exists():
            pairs.append((newer_name, newer_path, older_name, older_path))

    # Also test candidate vs v40 and candidate vs v41
    if CANDIDATE[1].exists():
        pairs.append((CANDIDATE[0], CANDIDATE[1], "v40", VERSION_CHAIN[5][1]))
        pairs.append((CANDIDATE[0], CANDIDATE[1], "v41", VERSION_CHAIN[6][1]))

    results = []
    for newer_name, newer_path, older_name, older_path in pairs:
        print(f"\n  Running: {newer_name} vs {older_name} ({args.games} games)...", flush=True)
        start = time.time()
        r = run_h2h(newer_name, newer_path, older_name, older_path, args.games, args.parallel)
        elapsed = time.time() - start
        print(format_result(r) + f"  ({elapsed:.0f}s)")
        results.append(r)

    # Summary
    print("\n" + "=" * 80)
    print("  PROGRESSION SUMMARY")
    print("=" * 80)
    print(f"\n  {'Newer':>12s} vs {'Older':<12s}  {'W':>3s}-{'L':>3s}-{'T':>3s}  "
          f"{'Elo Rate':>8s}  {'p-value':>8s}     {'Verdict':>10s}")
    print("-" * 80)
    for r in results:
        print(format_result(r))

    # Identify structural leaps
    print("\n  STRUCTURAL LEAPS (p<0.05, elo_rate>0.55):")
    leaps = [r for r in results if r["is_significant"] and r["elo_rate"] > 0.55]
    if leaps:
        for r in sorted(leaps, key=lambda x: x["elo_rate"], reverse=True):
            lines_newer = sum(1 for _ in open(
                next(p for n, p in VERSION_CHAIN + [CANDIDATE] if n == r["newer"])))
            lines_older = sum(1 for _ in open(
                next(p for n, p in VERSION_CHAIN + [CANDIDATE] if n == r["older"])))
            delta = lines_newer - lines_older
            print(f"    {r['newer']} -> {r['older']}: elo={r['elo_rate']:.1%}, "
                  f"delta={delta:+d} lines, p={r['p_value']:.4f}")
    else:
        print("    None found.")

    # Save
    output_file = AUTOLOOP_DIR / "corpus" / "progression_study.json"
    output_file.parent.mkdir(exist_ok=True)
    with open(output_file, "w") as f:
        json.dump({
            "results": results,
            "config": {"games": args.games, "parallel": args.parallel},
            "timestamp": datetime.now().isoformat(),
        }, f, indent=2, default=str)
    print(f"\n  Saved to {output_file}")


if __name__ == "__main__":
    main()
