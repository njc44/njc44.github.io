#!/usr/bin/env python3
"""Layer Diff: Extract and compare closure layers between Kaggriculture agents.

Ahmed's agents use a consistent pattern:
  _PREFIX_PARENT = agent    # captures current agent
  _PREFIX_CONST = ...       # layer constants
  def _prefix_helper(): ... # layer helpers
  def agent(): ...          # wrapper that calls _PREFIX_PARENT
  agent.telemetry = ...     # optional
  agent = globals().pop('agent')  # optional re-export

This module splits agents at _PREFIX_PARENT boundaries, extracts each layer,
and compares them between versions.

Usage:
    python layer_diff.py agents/v45/main.py agents/v46/main.py
    python layer_diff.py --three agents/v46/main.py agents/v47/main.py agents/v48/main.py
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

AUTOLOOP_DIR = Path(__file__).resolve().parent
AGENTS_DIR = AUTOLOOP_DIR / "agents"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"

# Pattern: _PREFIX_PARENT = agent OR _PREFIX_HOST = ... (with or without spaces)
LAYER_BOUNDARY = re.compile(r'^(_[A-Z][A-Z0-9_]*_PARENT)\s*=\s*agent\b', re.MULTILINE)
# Secondary pattern: _PREFIX_HOST=[v for v in list(globals().values()) if callable(v)][-1]
HOST_BOUNDARY = re.compile(r'^(_[A-Z][A-Z0-9_]*_HOST)\s*=\s*\[', re.MULTILINE)


def log(msg):
    print(f"[layer_diff] {msg}", flush=True)


# ═══════════════════════════════════════════════════════════
# LAYER EXTRACTION
# ═══════════════════════════════════════════════════════════

def extract_layers(agent_path):
    """Extract closure layers from an agent file.

    Returns list of dicts:
    [
        {
            'name': 'ADV',           # prefix without leading _ and trailing _PARENT
            'parent_var': '_ADV_PARENT',
            'start_line': 3536,
            'end_line': 3627,
            'code': '...',           # full layer code
            'constants': {'_ADV_LOOK': '3', ...},
            'helpers': ['_adv_apply', '_adv_frontload'],
            'has_agent_wrapper': True,
            'has_telemetry': True,
            'has_globals_pop': True,
            'content_hash': 'abc123...',
        },
        ...
    ]
    Also returns 'base_code' (everything before first layer).
    """
    code = Path(agent_path).read_text()
    lines = code.split('\n')

    # Find all layer boundaries (_PARENT pattern and _HOST pattern)
    boundaries = []
    for i, line in enumerate(lines):
        m = LAYER_BOUNDARY.match(line)
        if m:
            parent_var = m.group(1)
            prefix = parent_var[1:].rsplit('_PARENT', 1)[0]
            boundaries.append({
                'parent_var': parent_var,
                'name': prefix,
                'line': i,
                'pattern': 'PARENT',
            })
        else:
            m = HOST_BOUNDARY.match(line)
            if m:
                host_var = m.group(1)
                prefix = host_var[1:].rsplit('_HOST', 1)[0]
                boundaries.append({
                    'parent_var': host_var,
                    'name': prefix,
                    'line': i,
                    'pattern': 'HOST',
                })

    if not boundaries:
        return {'base_code': code, 'layers': []}

    # Extract each layer (from its _PARENT line to the next _PARENT or EOF)
    layers = []
    for idx, bd in enumerate(boundaries):
        start = bd['line']
        if idx + 1 < len(boundaries):
            end = boundaries[idx + 1]['line']
        else:
            end = len(lines)

        layer_code = '\n'.join(lines[start:end])

        # Extract constants: _PREFIX_* = ... (but not _PREFIX_PARENT/_PREFIX_HOST)
        prefix_upper = '_' + bd['name'] + '_'
        prefix_lower = '_' + bd['name'].lower() + '_'
        skip_vars = {bd['parent_var']}
        constants = {}
        for line in lines[start:end]:
            stripped = line.strip()
            if stripped.startswith(prefix_upper) and '=' in stripped:
                var_name = stripped.split('=')[0].strip()
                if var_name not in skip_vars:
                    val = stripped.split('=', 1)[1].strip()
                    constants[var_name] = val

        # Extract helper function names
        helpers = []
        for line in lines[start:end]:
            m = re.match(r'^def\s+(' + re.escape(prefix_lower) + r'\w+)\s*\(', line)
            if m:
                helpers.append(m.group(1))

        # Detect structural features
        has_agent_wrapper = any(
            re.match(r'^def\s+agent\s*\(', line.strip())
            for line in lines[start:end]
        )
        has_telemetry = any(
            'telemetry' in line and bd['name'] in line.upper()
            for line in lines[start:end]
        )
        has_globals_pop = any(
            "globals().pop('agent')" in line or 'globals().pop("agent")' in line
            for line in lines[start:end]
        )

        # Content hash (normalized: strip whitespace-only differences)
        normalized = re.sub(r'\s+', ' ', layer_code.strip())
        content_hash = hashlib.sha256(normalized.encode()).hexdigest()[:16]

        layers.append({
            'name': bd['name'],
            'parent_var': bd['parent_var'],
            'start_line': start + 1,  # 1-indexed
            'end_line': end,
            'code': layer_code,
            'constants': constants,
            'helpers': helpers,
            'has_agent_wrapper': has_agent_wrapper,
            'has_telemetry': has_telemetry,
            'has_globals_pop': has_globals_pop,
            'content_hash': content_hash,
        })

    base_code = '\n'.join(lines[:boundaries[0]['line']])

    return {
        'base_code': base_code,
        'base_hash': hashlib.sha256(
            re.sub(r'\s+', ' ', base_code.strip()).encode()
        ).hexdigest()[:16],
        'layers': layers,
    }


# ═══════════════════════════════════════════════════════════
# SETTINGS EXTRACTION
# ═══════════════════════════════════════════════════════════

def extract_settings(agent_path):
    """Extract DEFAULT_SETTINGS and any _SETTINGS overrides."""
    code = Path(agent_path).read_text()
    settings = {}

    # DEFAULT_SETTINGS dict
    m = re.search(r'DEFAULT_SETTINGS\s*=\s*\{([^}]+)\}', code, re.DOTALL)
    if m:
        for kv in re.finditer(r"['\"](\w+)['\"]\s*:\s*([^,}\n]+)", m.group(1)):
            settings[kv.group(1)] = kv.group(2).strip()

    return settings


# ═══════════════════════════════════════════════════════════
# DIFFING
# ═══════════════════════════════════════════════════════════

def diff_layers(extracted_a, extracted_b):
    """Compare two agents' layer stacks.

    Returns:
        identical:  [(name, hash)]
        modified:   [(name, {changed_constants, changed_helpers, hash_a, hash_b})]
        added:      [layer_dict]  (in B not in A)
        removed:    [name]        (in A not in B)
        base_changed: bool
    """
    layers_a = {l['name']: l for l in extracted_a['layers']}
    layers_b = {l['name']: l for l in extracted_b['layers']}

    names_a = set(layers_a.keys())
    names_b = set(layers_b.keys())

    identical = []
    modified = []

    for name in sorted(names_a & names_b):
        la, lb = layers_a[name], layers_b[name]
        if la['content_hash'] == lb['content_hash']:
            identical.append((name, la['content_hash']))
        else:
            # Detailed diff
            changed_constants = {}
            all_keys = set(la['constants'].keys()) | set(lb['constants'].keys())
            for k in all_keys:
                va = la['constants'].get(k)
                vb = lb['constants'].get(k)
                if va != vb:
                    changed_constants[k] = {'old': va, 'new': vb}

            changed_helpers = {
                'added': [h for h in lb['helpers'] if h not in la['helpers']],
                'removed': [h for h in la['helpers'] if h not in lb['helpers']],
            }

            modified.append((name, {
                'hash_a': la['content_hash'],
                'hash_b': lb['content_hash'],
                'changed_constants': changed_constants,
                'changed_helpers': changed_helpers,
                'lines_a': la['end_line'] - la['start_line'],
                'lines_b': lb['end_line'] - lb['start_line'],
            }))

    added = [layers_b[n] for n in sorted(names_b - names_a)]
    removed = sorted(names_a - names_b)

    base_changed = extracted_a.get('base_hash') != extracted_b.get('base_hash')

    return {
        'identical': identical,
        'modified': modified,
        'added': added,
        'removed': removed,
        'base_changed': base_changed,
        'layers_a_count': len(layers_a),
        'layers_b_count': len(layers_b),
    }


def extract_innovation_tail(agent_a_path, agent_b_path):
    """Extract code in agent_b that comes after where agent_a ends.

    Finds the last line in agent_b that matches agent_a's final
    `agent=globals().pop('agent')` or similar boundary, and returns
    everything after it. This captures ALL innovations regardless of
    their coding pattern (_PARENT, _HOST, direct reference, etc.).

    Returns: dict with 'code' (the tail), 'start_line', 'end_line'.
    """
    code_a = Path(agent_a_path).read_text()
    code_b = Path(agent_b_path).read_text()
    lines_b = code_b.split('\n')

    # Find the last globals().pop('agent') in agent_a
    lines_a = code_a.split('\n')
    last_pop_a = -1
    for i, line in enumerate(lines_a):
        if "globals().pop('agent')" in line or 'globals().pop("agent")' in line:
            last_pop_a = i

    if last_pop_a < 0:
        return None

    # Find the corresponding line in agent_b (should be at the same position
    # if the base is shared)
    target_line = lines_a[last_pop_a].strip()
    last_pop_b = -1
    for i, line in enumerate(lines_b):
        if line.strip() == target_line:
            last_pop_b = i

    if last_pop_b < 0:
        return None

    # Everything after this line in agent_b is the innovation tail
    tail_start = last_pop_b + 1
    tail_code = '\n'.join(lines_b[tail_start:]).strip()

    if not tail_code or len(tail_code) < 50:
        return None

    return {
        'code': tail_code,
        'start_line': tail_start + 1,  # 1-indexed
        'end_line': len(lines_b),
        'n_lines': len(lines_b) - tail_start,
    }


def diff_settings(agent_a_path, agent_b_path):
    """Compare DEFAULT_SETTINGS between two agents."""
    sa = extract_settings(agent_a_path)
    sb = extract_settings(agent_b_path)
    all_keys = sorted(set(sa.keys()) | set(sb.keys()))
    changes = {}
    for k in all_keys:
        if sa.get(k) != sb.get(k):
            changes[k] = {'old': sa.get(k), 'new': sb.get(k)}
    return changes


# ═══════════════════════════════════════════════════════════
# REPORTING
# ═══════════════════════════════════════════════════════════

def print_diff_report(diff, name_a, name_b, settings_diff=None):
    """Print human-readable diff report."""
    print(f"\n{'='*76}")
    print(f"LAYER DIFF: {name_a} → {name_b}")
    print(f"{'='*76}")
    print(f"Layers: {diff['layers_a_count']} → {diff['layers_b_count']}")
    print(f"Base code changed: {'YES' if diff['base_changed'] else 'no'}")
    print()

    if diff['identical']:
        print(f"IDENTICAL ({len(diff['identical'])} layers):")
        for name, h in diff['identical']:
            print(f"  {name}")
        print()

    if diff['modified']:
        print(f"MODIFIED ({len(diff['modified'])} layers):")
        for name, info in diff['modified']:
            print(f"  {name}  ({info['lines_a']} → {info['lines_b']} lines)")
            if info['changed_constants']:
                for k, v in info['changed_constants'].items():
                    old = v['old'] or '(absent)'
                    new = v['new'] or '(absent)'
                    print(f"    {k}: {old} → {new}")
            if info['changed_helpers']['added']:
                print(f"    + helpers: {', '.join(info['changed_helpers']['added'])}")
            if info['changed_helpers']['removed']:
                print(f"    - helpers: {', '.join(info['changed_helpers']['removed'])}")
        print()

    if diff['added']:
        print(f"ADDED ({len(diff['added'])} layers):")
        for layer in diff['added']:
            n_lines = layer['end_line'] - layer['start_line']
            print(f"  {layer['name']}  ({n_lines} lines, {len(layer['helpers'])} helpers)")
            if layer['constants']:
                for k, v in list(layer['constants'].items())[:5]:
                    print(f"    {k} = {v[:60]}")
            if layer['helpers']:
                print(f"    helpers: {', '.join(layer['helpers'][:8])}")
        print()

    if diff['removed']:
        print(f"REMOVED ({len(diff['removed'])} layers):")
        for name in diff['removed']:
            print(f"  {name}")
        print()

    if settings_diff:
        print("SETTINGS CHANGES:")
        for k, v in settings_diff.items():
            print(f"  {k}: {v['old']} → {v['new']}")
        print()


def full_diff(agent_a_path, agent_b_path, save=True):
    """Run complete layer + settings diff between two agents.

    Returns: dict with all diff results and extracted layers.
    """
    agent_a_path = str(agent_a_path)
    agent_b_path = str(agent_b_path)
    name_a = Path(agent_a_path).parent.name
    name_b = Path(agent_b_path).parent.name

    log(f"Extracting layers from {name_a}...")
    ext_a = extract_layers(agent_a_path)
    log(f"  {len(ext_a['layers'])} layers")

    log(f"Extracting layers from {name_b}...")
    ext_b = extract_layers(agent_b_path)
    log(f"  {len(ext_b['layers'])} layers")

    diff = diff_layers(ext_a, ext_b)
    sdiff = diff_settings(agent_a_path, agent_b_path)
    tail = extract_innovation_tail(agent_a_path, agent_b_path)

    print_diff_report(diff, name_a, name_b, sdiff)

    if tail:
        log(f"Innovation tail: {tail['n_lines']} lines (after line {tail['start_line']})")

    result = {
        'agent_a': name_a,
        'agent_b': name_b,
        'agent_a_path': agent_a_path,
        'agent_b_path': agent_b_path,
        'extracted_a': {
            'base_hash': ext_a['base_hash'],
            'layer_count': len(ext_a['layers']),
            'layer_names': [l['name'] for l in ext_a['layers']],
        },
        'extracted_b': {
            'base_hash': ext_b['base_hash'],
            'layer_count': len(ext_b['layers']),
            'layer_names': [l['name'] for l in ext_b['layers']],
        },
        'diff': {
            'identical': diff['identical'],
            'modified': [(n, info) for n, info in diff['modified']],
            'added_names': [l['name'] for l in diff['added']],
            'removed': diff['removed'],
            'base_changed': diff['base_changed'],
        },
        'settings_diff': sdiff,
        # Keep full layer data for code gen
        'added_layers': diff['added'],
        'modified_layers': diff['modified'],
        # Innovation tail: all code in B after A's last shared boundary
        'innovation_tail': tail,
    }

    if save:
        CORPUS_DIR.mkdir(parents=True, exist_ok=True)
        out_path = CORPUS_DIR / f"layer_diff_{name_a}_vs_{name_b}.json"
        serializable = json.loads(json.dumps(result, default=str))
        with open(out_path, "w") as f:
            json.dump(serializable, f, indent=2)
        log(f"Saved to {out_path}")

    return result


def three_way_diff(path_a, path_b, path_c):
    """Run diffs: A→B, B→C, A→C."""
    log("=== THREE-WAY DIFF ===")
    diff_ab = full_diff(path_a, path_b)
    diff_bc = full_diff(path_b, path_c)
    diff_ac = full_diff(path_a, path_c)

    # Summary
    print(f"\n{'='*76}")
    print("THREE-WAY SUMMARY")
    print(f"{'='*76}")
    na = Path(path_a).parent.name
    nb = Path(path_b).parent.name
    nc = Path(path_c).parent.name

    print(f"{na} → {nb}: +{len(diff_ab['diff']['added_names'])} layers, "
          f"~{len(diff_ab['diff']['modified'])} modified, "
          f"-{len(diff_ab['diff']['removed'])} removed")
    print(f"{nb} → {nc}: +{len(diff_bc['diff']['added_names'])} layers, "
          f"~{len(diff_bc['diff']['modified'])} modified, "
          f"-{len(diff_bc['diff']['removed'])} removed")
    print(f"{na} → {nc}: +{len(diff_ac['diff']['added_names'])} layers, "
          f"~{len(diff_ac['diff']['modified'])} modified, "
          f"-{len(diff_ac['diff']['removed'])} removed")

    # Identify independent vs dependent innovations
    added_in_b = set(diff_ab['diff']['added_names'])
    added_in_c_from_b = set(diff_bc['diff']['added_names'])
    added_in_c_total = set(diff_ac['diff']['added_names'])

    print(f"\nInnovations in {nb} (vs {na}): {sorted(added_in_b) or 'none'}")
    print(f"Additional innovations in {nc} (vs {nb}): {sorted(added_in_c_from_b) or 'none'}")
    print(f"Total innovations in {nc} (vs {na}): {sorted(added_in_c_total) or 'none'}")

    return {'ab': diff_ab, 'bc': diff_bc, 'ac': diff_ac}


# ═══════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════

def resolve_agent_path(arg):
    """Resolve agent path from name or path."""
    p = Path(arg)
    if p.exists():
        return str(p)
    # Try as agent directory name
    candidate = AGENTS_DIR / arg / "main.py"
    if candidate.exists():
        return str(candidate)
    # Try glob
    matches = list(AGENTS_DIR.glob(f"*{arg}*"))
    if matches:
        mp = matches[0] / "main.py"
        if mp.exists():
            return str(mp)
    raise FileNotFoundError(f"Agent not found: {arg}")


def main():
    parser = argparse.ArgumentParser(description="Layer Diff: compare agent closure layers")
    parser.add_argument("agent_a", help="First agent (path or name)")
    parser.add_argument("agent_b", help="Second agent (path or name)")
    parser.add_argument("agent_c", nargs="?", help="Third agent for 3-way diff")
    parser.add_argument("--three", action="store_true", help="Run three-way diff (A→B, B→C, A→C)")
    args = parser.parse_args()

    path_a = resolve_agent_path(args.agent_a)
    path_b = resolve_agent_path(args.agent_b)

    if args.agent_c or args.three:
        if not args.agent_c:
            print("ERROR: --three requires 3 agents")
            return
        path_c = resolve_agent_path(args.agent_c)
        three_way_diff(path_a, path_b, path_c)
    else:
        full_diff(path_a, path_b)


if __name__ == "__main__":
    main()
