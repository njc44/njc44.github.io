#!/usr/bin/env python3
"""Autoloop v3: End-to-end pipeline from base agent to improved agent.

Steps:
1. COLOSSEUM: Run base vs top opponents, save losses
2. TRACER V3: Analyze losses — find opening + sell timing signals
3. FIX SEARCH: Sweep openings with market simulator, find optimal config
4. CODE GEN: Generate improved agent (base + opening wrapper)
5. VALIDATE: Run improved agent vs all opponents in colosseum

Usage:
    python autoloop_v3.py --base v45 --name pipe9
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"
PYTHON = sys.executable
COLOSSEUM = str(AUTOLOOP_DIR / "colosseum.py")

# Top opponents for testing
TOP_OPPONENTS = [
    ("jaxa623", "jaxa623__2842-two-identical-agents-90-points-apart"),
    ("ahmed_v46", "ahmedberatozer__kaggriculture-v46-first-turn-microstructure-and-s"),
    ("tetsutani_new", "tetsutani__market-smart-farming-kaggriculture"),
    ("ahmed_v45", "ahmedberatozer__kaggriculture-v45-first-turn-wheat-round-trip"),
    ("ahmed_v44", "ahmedberatozer__kaggriculture-v44-winning-the-same-turn-sale-race"),
    ("ahmed_v43", "ahmedberatozer__kaggriculture-v43-recovering-lost-harvests"),
    ("ahmed_v42", "ahmedberatozer__kaggriculture-v42-production-that-fits-the-marke"),
    ("ahmed_v40", "ahmedberatozer__kaggriculture-v40-plans-that-fit-the-shops"),
    ("ahmed_v38", "ahmedberatozer__kaggriculture-v38-smarter-feed-stronger-margins"),
    ("degnonguidi_best", "degnonguidi__best-agent-ranking"),
    ("aurax7_v6", "aurax7__kaggriculture-shop-router-reactive-v6"),
    ("evgendvorkin", "evgendvorkin__kaggriculture"),
    ("flexonafft", "flexonafft__kaggriculture-multi-route-farming-agent"),
    ("pipe7", "_pipe7_candidate"),
    ("pipe8", "_pipe8_candidate"),
]


def run_h2h(agent_a, agent_b, games=10, parallel=10, save_losses=None):
    """Run colosseum H2H and return parsed results."""
    with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as f:
        outpath = f.name
    try:
        cmd = [PYTHON, COLOSSEUM, agent_a, agent_b,
               '--games', str(games), '--parallel', str(parallel), '--output', outpath]
        if save_losses:
            cmd += ['--save-losses', save_losses]
        subprocess.run(cmd, capture_output=True, text=True, timeout=300, cwd=str(WORK_DIR))
        if os.path.exists(outpath) and os.path.getsize(outpath) > 0:
            with open(outpath) as f:
                return json.load(f)
        return {"error": True}
    except Exception as e:
        return {"error": True, "detail": str(e)}
    finally:
        if os.path.exists(outpath):
            os.unlink(outpath)


def step1_colosseum(base_path, name, games=30, parallel=10):
    """Step 1: Run base vs top opponents, save losses."""
    print(f"\n{'='*80}")
    print(f"  STEP 1: COLOSSEUM — {name} vs top opponents ({games} games each)")
    print(f"{'='*80}")

    losses_dir = str(CORPUS_DIR / f"{name}_losses")
    os.makedirs(losses_dir, exist_ok=True)

    results = {}
    for opp_name, opp_dir in TOP_OPPONENTS[:5]:  # top 5 for diagnosis
        opp_path = str(AGENTS_DIR / opp_dir / "main.py")
        if not os.path.exists(opp_path):
            print(f"  SKIP {opp_name}: not found")
            continue

        print(f"  Running vs {opp_name}...", end=" ", flush=True)
        opp_losses = str(CORPUS_DIR / f"{name}_vs_{opp_name}_losses")
        os.makedirs(opp_losses, exist_ok=True)
        r = run_h2h(base_path, opp_path, games, parallel, opp_losses)
        if r.get("error"):
            print("ERROR")
        else:
            wlt = f"{r['wins']}-{r['losses']}-{r['ties']}"
            print(f"{wlt} ({r['elo_rate']:.0%})")
            results[opp_name] = r

    # Save summary
    summary_path = str(CORPUS_DIR / f"{name}_step1_results.json")
    with open(summary_path, "w") as f:
        json.dump(results, f, indent=2, default=str)

    return results


def step2_tracer(name):
    """Step 2: Run v3 mechanism tracer on losses."""
    print(f"\n{'='*80}")
    print(f"  STEP 2: V3 TRACER — analyzing {name} losses")
    print(f"{'='*80}")

    # Import tracer
    sys.path.insert(0, str(AUTOLOOP_DIR))
    from mechanism_tracer_v3 import analyze_losses_v3

    # Find all loss directories
    all_traces = []
    for d in CORPUS_DIR.iterdir():
        if d.is_dir() and d.name.startswith(f"{name}_vs_") and d.name.endswith("_losses"):
            opp_name = d.name.replace(f"{name}_vs_", "").replace("_losses", "")
            print(f"\n  --- vs {opp_name} ---")
            traces = analyze_losses_v3(str(d))
            if traces:
                for t in traces:
                    t["opponent"] = opp_name
                all_traces.extend(traces)

    # Save all traces
    traces_path = str(CORPUS_DIR / f"{name}_v3_traces.json")
    with open(traces_path, "w") as f:
        json.dump(all_traces, f, indent=2, default=str)
    print(f"\n  Saved {len(all_traces)} traces to {traces_path}")

    return all_traces


def step3_fix_search(name, tracer_results=None):
    """Step 3: Run fix search (opening + sell timing)."""
    print(f"\n{'='*80}")
    print(f"  STEP 3: FIX SEARCH — finding optimal opening + sell timing for {name}")
    print(f"{'='*80}")

    from fix_search import run_fix_search

    output_dir = str(CORPUS_DIR / f"{name}_fix_search")
    result = run_fix_search(tracer_results=tracer_results, output_dir=output_dir)
    return result


def step4_codegen(name, base_path, fix_result):
    """Step 4: Generate improved agent."""
    print(f"\n{'='*80}")
    print(f"  STEP 4: CODE GEN — building {name} agent")
    print(f"{'='*80}")

    output_dir = AGENTS_DIR / f"_{name}"
    os.makedirs(output_dir, exist_ok=True)

    # Copy base agent
    shutil.copy2(base_path, output_dir / "main.py")

    # Append opening wrapper
    wrapper_code = fix_result["wrapper_code"]
    with open(output_dir / "main.py", "a") as f:
        f.write("\n\n")
        f.write(wrapper_code)

    agent_path = str(output_dir / "main.py")
    lines = sum(1 for _ in open(agent_path))
    print(f"  Generated: {agent_path} ({lines} lines)")

    # Smoke test
    print("  Smoke testing...", end=" ", flush=True)
    test_opp = str(AGENTS_DIR / "ahmedberatozer__kaggriculture-v38-smarter-feed-stronger-margins" / "main.py")
    r = run_h2h(agent_path, test_opp, games=2, parallel=2)
    if r.get("error"):
        print("FAILED!")
        return None
    print(f"OK ({r['wins']}-{r['losses']}-{r['ties']})")

    return agent_path


def step5_validate(name, agent_path, games=10, parallel=10):
    """Step 5: Full validation against all opponents."""
    print(f"\n{'='*80}")
    print(f"  STEP 5: VALIDATION — {name} vs all {len(TOP_OPPONENTS)} opponents ({games} games each)")
    print(f"{'='*80}")

    print(f"{'Opponent':<25} {'W/L/T':>10} {'Rate':>7} {'Margin':>10}")
    print("-" * 60)

    total_w, total_l, total_t = 0, 0, 0
    results = {}

    for opp_name, opp_dir in TOP_OPPONENTS:
        opp_path = str(AGENTS_DIR / opp_dir / "main.py")
        if not os.path.exists(opp_path):
            continue
        r = run_h2h(agent_path, opp_path, games, parallel)
        if r.get("error"):
            print(f"{opp_name:<25} {'ERROR':>10}")
            continue
        wlt = f"{r['wins']}-{r['losses']}-{r['ties']}"
        total_w += r["wins"]; total_l += r["losses"]; total_t += r["ties"]
        print(f"{opp_name:<25} {wlt:>10} {r['elo_rate']:>6.0%} {r.get('avg_margin', 0):>+10.0f}")
        results[opp_name] = r

    total = total_w + total_l + total_t
    elo_rate = (total_w + 0.5 * total_t) / total if total else 0
    print("-" * 60)
    print(f"{'TOTAL':<25} {f'{total_w}-{total_l}-{total_t}':>10} {elo_rate:>6.0%}")

    # Self-play
    print(f"\n  Self-play (20 games)...", end=" ", flush=True)
    sp = run_h2h(agent_path, agent_path, 20, parallel)
    if not sp.get("error"):
        print(f"{sp['wins']}-{sp['losses']}-{sp['ties']}")
    else:
        print("ERROR")

    # Save
    val_path = str(CORPUS_DIR / f"{name}_validation.json")
    with open(val_path, "w") as f:
        json.dump({"results": results, "total_w": total_w, "total_l": total_l,
                    "total_t": total_t, "elo_rate": elo_rate}, f, indent=2, default=str)
    print(f"\n  Saved to {val_path}")

    return elo_rate


def main():
    parser = argparse.ArgumentParser(description="Autoloop v3: base agent → improved agent")
    parser.add_argument("--base", required=True, help="Base agent directory name (in autoloop/agents/)")
    parser.add_argument("--name", required=True, help="Name for the output (e.g., pipe9)")
    parser.add_argument("--games-diagnose", type=int, default=30, help="Games per opponent for diagnosis")
    parser.add_argument("--games-validate", type=int, default=10, help="Games per opponent for validation")
    parser.add_argument("--parallel", type=int, default=10, help="Parallel workers")
    args = parser.parse_args()

    base_path = str(AGENTS_DIR / args.base / "main.py")
    if not os.path.exists(base_path):
        print(f"ERROR: Base agent not found: {base_path}")
        return

    os.chdir(str(WORK_DIR))
    t0 = time.time()

    print(f"\n{'#'*80}")
    print(f"  AUTOLOOP V3: {args.base} → {args.name}")
    print(f"{'#'*80}")

    # Step 1: Colosseum
    step1_results = step1_colosseum(base_path, args.name, args.games_diagnose, args.parallel)

    # Step 2: Tracer
    traces = step2_tracer(args.name)

    # Step 3: Fix search (passes tracer results for sell timing analysis)
    fix_result = step3_fix_search(args.name, traces)
    if fix_result is None:
        print("ABORT: Fix search failed")
        return

    # Step 4: Code gen
    agent_path = step4_codegen(args.name, base_path, fix_result)
    if agent_path is None:
        print("ABORT: Code gen failed")
        return

    # Step 5: Validate
    elo_rate = step5_validate(args.name, agent_path, args.games_validate, args.parallel)

    elapsed = time.time() - t0
    print(f"\n{'#'*80}")
    print(f"  AUTOLOOP V3 COMPLETE: {args.name}")
    print(f"  Elo rate: {elo_rate:.0%}")
    print(f"  Agent: {agent_path}")
    print(f"  Time: {elapsed:.0f}s")
    print(f"{'#'*80}")


if __name__ == "__main__":
    main()
