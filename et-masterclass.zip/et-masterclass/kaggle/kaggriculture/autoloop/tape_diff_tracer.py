#!/usr/bin/env python3
"""Tape Diff Tracer v2 — finds actionable tape edits by diffing agent tapes.

Primary mode (tape-to-tape): Import two agents, compare their _ROUTES directly.
No replay noise, no reactive layer artifacts, exact tape entries.

Fallback mode (--replay): Compare our tape against replay actions from high-Elo
twins. Noisier due to reactive layers (sell_lead, etc.) but works for twins
whose code we don't have locally.

Fits into the autoloop DAG as Step 4 (replacing mechanism_tracer):
  Step 3 (TWIN_GRAPH) → Step 4 (TAPE_DIFF_TRACER) → Step 5 (COLOSSEUM)
Output is concrete tape edits that can be directly tested by the colosseum.
"""

import argparse
import csv
import importlib.util
import json
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

AUTOLOOP_DIR = Path(__file__).resolve().parent
AGENTS_DIR = AUTOLOOP_DIR / "agents"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"
REPLAYS_DIR = AUTOLOOP_DIR / "replays"
TEAM_INDEX_PATH = REPLAYS_DIR / "_team_index.json"
OUR_TEAM = "Nathan Jacob"
MAX_STEP = 719

# Default target: Ahmed's v45 (the base most high-Elo agents fork from)
DEFAULT_TARGET = "ahmedberatozer__kaggriculture-v45-first-turn-wheat-round-trip"


def log(msg):
    print(f"[tape_diff] {msg}", flush=True)


# ── Shared: extract tape from agent ───────────────────────────────────

def extract_routes(agent_path):
    """Import agent module, return (routes_dict, shop_routes_dict).
    Raises ValueError if agent doesn't have compatible _ROUTES structure."""
    spec = importlib.util.spec_from_file_location("_agent_mod", str(agent_path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    raw = getattr(mod, "_ROUTES", None)
    if raw is None or not isinstance(raw, dict):
        raise ValueError(f"Agent has no compatible _ROUTES dict (got {type(raw).__name__})")
    routes = {}
    for rid, steps in raw.items():
        routes[int(rid)] = [
            {"market": s.get("market", []), "farmer": s.get("farmer", ["PASS"]),
             "hands": s.get("hands", [])}
            for s in steps
        ]
    shop_raw = getattr(mod, "_R108_SHOP_ROUTES", {})
    shop_routes = {tuple(sorted(k)): v for k, v in shop_raw.items()} if shop_raw else {}
    return routes, shop_routes


def fmt_action(action):
    """Compact action display."""
    if not action:
        return "[]"
    parts = []
    for op in action:
        cmd = op[0] if op else "?"
        if cmd == "BUY_PRODUCT" and len(op) >= 3:
            parts.append(f"BUY {op[2]}")
        elif cmd == "SELL" and len(op) >= 3:
            parts.append(f"SELL {op[2]}")
        elif cmd == "SELL_PRODUCT" and len(op) >= 3:
            parts.append(f"SELLP {op[2]}")
        elif cmd == "HIRE":
            parts.append("HIRE")
        elif cmd == "BUY_ANIMAL" and len(op) >= 3:
            parts.append(f"{op[1]} {op[2]}")
        elif cmd == "BUY_SEED" and len(op) >= 3:
            parts.append(f"SEED_{op[1]} {op[2]}")
        elif cmd == "BUY_STRUCTURE" and len(op) >= 2:
            parts.append(f"BUILD_{op[1]}")
        elif len(op) >= 3:
            parts.append(f"{cmd} {op[2]}")
        elif len(op) >= 2:
            parts.append(f"{cmd} {op[1]}")
        else:
            parts.append(cmd)
    return "[" + ",".join(parts) + "]"


def fmt_route(rid):
    return "ALL(r0)" if rid == 0 else f"r{rid}"


# ══════════════════════════════════════════════════════════════════════
# MODE 1: TAPE-TO-TAPE (primary)
# ══════════════════════════════════════════════════════════════════════

def diff_tapes(our_routes, target_routes):
    """Compare two agents' tapes route-by-route, step-by-step.
    Returns list of diff dicts with exact tape entries."""
    diffs = []
    common_rids = sorted(set(our_routes) & set(target_routes))
    for rid in common_rids:
        our_tape = our_routes[rid]
        tgt_tape = target_routes[rid]
        for step in range(min(len(our_tape), len(tgt_tape))):
            our_m = our_tape[step].get("market", [])
            tgt_m = tgt_tape[step].get("market", [])
            if json.dumps(our_m, sort_keys=True) != json.dumps(tgt_m, sort_keys=True):
                diffs.append({
                    "route_id": rid,
                    "step": step,
                    "day": step // 24,
                    "hour": step % 24,
                    "our_action": our_m,
                    "target_action": tgt_m,
                })
    return diffs


def tape_report(diffs, our_name, target_name, our_routes, target_routes):
    """Print tape-to-tape diff report and save JSON."""
    # Group by route
    by_route = defaultdict(list)
    for d in diffs:
        by_route[d["route_id"]].append(d)

    common_rids = sorted(set(our_routes) & set(target_routes))
    our_only = sorted(set(our_routes) - set(target_routes))
    tgt_only = sorted(set(target_routes) - set(our_routes))

    print()
    print(f"TAPE DIFF: {our_name} vs {target_name}")
    print("=" * 76)
    print(f"Routes in common: {len(common_rids)}  "
          f"(ours only: {len(our_only)}, target only: {len(tgt_only)})")
    print(f"Total diffs: {len(diffs)}")
    print()

    if not diffs:
        print("Tapes are IDENTICAL. No changes needed.")
    else:
        # Summary by route
        print("DIFFS BY ROUTE:")
        for rid in common_rids:
            rd = by_route.get(rid, [])
            if rd:
                steps = [d["step"] for d in rd]
                step_range = f"steps {min(steps)}-{max(steps)}" if len(steps) > 1 else f"step {steps[0]}"
                print(f"  {fmt_route(rid):12} {len(rd):>3} diffs ({step_range})")
        print()

        # Detail: every diff (there should be few for tape-to-tape)
        print("ALL DIFFS:")
        for d in sorted(diffs, key=lambda x: (x["route_id"], x["step"])):
            r = fmt_route(d["route_id"])
            print(f"  {r:12} step {d['step']:>3} (D{d['day']}/H{d['hour']})")
            print(f"    ours:   {fmt_action(d['our_action'])}")
            print(f"    target: {fmt_action(d['target_action'])}")

    # Save JSON
    output = {
        "mode": "tape",
        "our_agent": our_name,
        "target_agent": target_name,
        "routes_in_common": len(common_rids),
        "total_diffs": len(diffs),
        "diffs": diffs,
    }
    out_path = CORPUS_DIR / "tape_diff_proposals.json"
    with open(out_path, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nSaved to {out_path}")


def run_tape_mode(args):
    """Primary mode: tape-to-tape comparison."""
    t0 = time.time()

    # Resolve target agent path
    target = args.target
    target_path = Path(target)
    if not target_path.exists():
        target_path = AGENTS_DIR / target / "main.py"
    if not target_path.exists():
        # Try glob match
        matches = list(AGENTS_DIR.glob(f"*{target}*"))
        if matches:
            target_path = matches[0] / "main.py"
    if not target_path.exists():
        log(f"ERROR: Target agent not found: {target}")
        log(f"  Tried: {target}, {AGENTS_DIR / target / 'main.py'}")
        sys.exit(1)

    our_path = Path(args.agent)
    our_name = our_path.parent.name
    target_name = target_path.parent.name

    log(f"Ours:   {our_path}")
    log(f"Target: {target_path}")

    log(f"Loading {our_name}...")
    our_routes, our_shops = extract_routes(our_path)
    log(f"  {len(our_routes)} routes, {len(our_shops)} shop mappings")

    log(f"Loading {target_name}...")
    try:
        tgt_routes, tgt_shops = extract_routes(target_path)
    except (ValueError, Exception) as e:
        log(f"ERROR: Cannot load target: {e}")
        sys.exit(1)
    log(f"  {len(tgt_routes)} routes, {len(tgt_shops)} shop mappings")

    # Diff
    diffs = diff_tapes(our_routes, tgt_routes)
    log(f"Diffs: {len(diffs)}")

    # Shop routing diffs
    shop_diffs = []
    for k in sorted(set(our_shops) | set(tgt_shops)):
        our_v = our_shops.get(k)
        tgt_v = tgt_shops.get(k)
        if our_v != tgt_v:
            shop_diffs.append({"shops": k, "ours": our_v, "target": tgt_v})
    if shop_diffs:
        log(f"Shop routing diffs: {len(shop_diffs)}")
        for sd in shop_diffs:
            log(f"  {sd['shops']}: ours=r{sd['ours']} target=r{sd['target']}")

    tape_report(diffs, our_name, target_name, our_routes, tgt_routes)

    elapsed = time.time() - t0
    log(f"Done in {elapsed:.1f}s")


# ══════════════════════════════════════════════════════════════════════
# MODE 2: REPLAY-BASED (fallback for twins without local code)
# ══════════════════════════════════════════════════════════════════════

def _acts_eq(a, b):
    """Order-insensitive action comparison (same ops, any order)."""
    if len(a) != len(b):
        return False
    sa = sorted(json.dumps(op, sort_keys=True) for op in a)
    sb = sorted(json.dumps(op, sort_keys=True) for op in b)
    return sa == sb


def run_replay_mode(args):
    """Fallback mode: compare our tape against replay actions.

    Noisier than tape-to-tape due to reactive layers (sell_lead reorders ops,
    adjusts quantities). Use only for twins whose agent code is not available.

    Key corrections applied:
    - Replay offset +1 (replay step 0 is always a no-op init step)
    - Order-insensitive comparison (sell_lead reorders operations at runtime)
    - Timing shift detection (adjacent swaps and cascading delays)
    """
    t0 = time.time()

    # Extract our tape
    if args.from_cache:
        path = CORPUS_DIR / "our_tape.json"
        with open(path) as f:
            data = json.load(f)
        routes = {int(k): v for k, v in data["tape"].items()}
        shop_routes = {tuple(k.split("|")): v for k, v in data["shop_routes"].items()}
        log(f"Loaded cached tape: {len(routes)} routes")
    else:
        log(f"Loading agent from {args.agent}")
        routes, shop_routes = extract_routes(args.agent)
        log(f"Extracted {len(routes)} routes, {len(shop_routes)} shop mappings")
        data = {
            "tape": {str(k): v for k, v in routes.items()},
            "shop_routes": {"|".join(k): v for k, v in shop_routes.items()},
        }
        with open(CORPUS_DIR / "our_tape.json", "w") as f:
            json.dump(data, f)

    # Load twins
    with open(CORPUS_DIR / "fingerprints.json") as f:
        fingerprints = json.load(f)
    lb_files = sorted(Path("/tmp").glob("kaggriculture-publicleaderboard-*.csv"), reverse=True)
    if not lb_files:
        raise FileNotFoundError("No leaderboard CSV in /tmp/")
    log(f"Leaderboard: {lb_files[0].name}")
    leaderboard = {}
    with open(lb_files[0]) as f:
        for row in csv.DictReader(f):
            leaderboard[row["TeamName"]] = float(row["Score"])

    our_fp = fingerprints.get(OUR_TEAM)
    our_elo = leaderboard.get(OUR_TEAM)
    if not our_fp or our_elo is None:
        raise ValueError(f"'{OUR_TEAM}' not in fingerprints/leaderboard")

    twins = []
    for team, fp in fingerprints.items():
        if team == OUR_TEAM:
            continue
        elo = leaderboard.get(team)
        if elo is None or elo <= our_elo:
            continue
        sim = sum(1 for a, b in zip(our_fp, fp) if a == b) / len(our_fp)
        twins.append({"name": team, "elo": elo, "similarity": sim,
                       "score": (elo - our_elo) * sim})
    twins.sort(key=lambda x: (-x["score"], x["name"]))
    twins = twins[:args.top_n]
    log(f"Our Elo: {our_elo:.1f} | Top {len(twins)} twins")

    # Build replay lookup
    now = time.time()
    cutoff = now - args.freshness_hours * 3600
    if TEAM_INDEX_PATH.exists():
        with open(TEAM_INDEX_PATH) as f:
            index = json.load(f)
    else:
        index = {}
    dirty = False
    team_to_files = defaultdict(list)
    for rf in sorted(REPLAYS_DIR.glob("*.json")):
        if rf.name.startswith("_") or rf.stat().st_mtime < cutoff:
            continue
        fname = rf.name
        if fname in index and len(index[fname]) >= 2:
            teams = index[fname]
        else:
            with open(rf, "r", encoding="utf-8") as f:
                header = f.read(2000)
            m = re.search(r'"TeamNames"\s*:\s*\[([^\]]*)\]', header)
            teams = re.findall(r'"([^"]*)"', m.group(1)) if m else []
            index[fname] = teams
            dirty = True
        for t in teams:
            team_to_files[t].append(rf)
    if dirty:
        with open(TEAM_INDEX_PATH, "w") as f:
            json.dump(index, f)

    # Diff replays (with +1 offset and order-insensitive comparison)
    all_diffs = []
    replays_processed = 0
    for twin in twins:
        rfiles = team_to_files.get(twin["name"], [])
        if not rfiles:
            continue
        log(f"  {twin['name']} (Elo {twin['elo']:.0f}): {len(rfiles)} replays")
        for rf in rfiles:
            try:
                with open(rf) as f:
                    replay = json.load(f)
            except Exception:
                continue
            info = replay["info"]
            steps = replay["steps"]
            twin_seat = next((i for i, n in enumerate(info["TeamNames"])
                              if n == twin["name"]), None)
            if twin_seat is None:
                continue
            opp_seat = 1 - twin_seat
            margin = replay["rewards"][twin_seat] - replay["rewards"][opp_seat]
            outcome = "win" if margin > 0 else ("loss" if margin < 0 else "tie")

            # Shop route
            shop_route_id = 0
            for i in range(len(steps)):
                obs = steps[i][0].get("observation", steps[i][0])
                sl = (obs.get("town") or {}).get("unlocked_shops") or []
                unique = sorted(set(sl))
                if len(unique) >= 2:
                    shop_route_id = shop_routes.get(tuple(unique), 100)
                    break

            # Diff with offset +1
            for ts in range(min(MAX_STEP, len(steps) - 1)):
                rs = ts + 1
                obs = steps[rs][0].get("observation", steps[rs][0])
                sl = (obs.get("town") or {}).get("unlocked_shops") or []
                cur_route = shop_route_id if len(set(sl)) >= 2 else 0
                tape = routes.get(cur_route)
                if not tape or ts >= len(tape):
                    continue
                our_action = tape[ts].get("market", [])
                twin_action = ((steps[rs][twin_seat].get("action") or {}).get("market")) or []
                if not _acts_eq(our_action, twin_action):
                    all_diffs.append({
                        "step": ts, "day": ts // 24, "hour": ts % 24,
                        "route_id": cur_route,
                        "our_action": our_action, "twin_action": twin_action,
                        "twin_name": twin["name"], "twin_elo": twin["elo"],
                        "opponent_name": info["TeamNames"][opp_seat],
                        "game_outcome": outcome, "margin": margin,
                    })
            replays_processed += 1

    log(f"Diffs: {len(all_diffs)} from {replays_processed} replays")

    # Classify, rank, report (simplified)
    groups = defaultdict(list)
    for d in all_diffs:
        groups[(d["twin_name"], d["route_id"], d["step"])].append(d)

    proposals = []
    for (twin, rid, step), ds in groups.items():
        n = len(ds)
        if n < args.min_replays:
            continue
        buckets = defaultdict(list)
        for d in ds:
            buckets[json.dumps(d["twin_action"], sort_keys=True)].append(d)
        best_key = max(buckets, key=lambda k: (len(buckets[k]), k))
        k = len(buckets[best_key])
        if k / n < 0.7:
            continue
        sample = buckets[best_key][0]
        w = sum(1 for d in buckets[best_key] if d["game_outcome"] == "win")
        l = sum(1 for d in buckets[best_key] if d["game_outcome"] == "loss")
        proposals.append({
            "route_id": rid, "step": step,
            "day": step // 24, "hour": step % 24,
            "our_action": sample["our_action"],
            "proposed_action": sample["twin_action"],
            "twin": twin, "twin_elo": sample["twin_elo"],
            "consistent": k, "total": n,
            "win_rate": w / (w + l) if (w + l) else 0,
        })

    proposals.sort(key=lambda x: (-x["twin_elo"], x["route_id"], x["step"]))
    log(f"Proposals: {len(proposals)}")

    print(f"\nREPLAY-BASED PROPOSALS ({len(proposals)} total)")
    print("=" * 76)
    print(f"{'#':>3}  {'Route':<10} {'Step':>4}  {'Day/Hr':<6}  {'Twin':<20} {'WR':>4}  Action Change")
    for i, p in enumerate(proposals[:30]):
        act = f"{fmt_action(p['our_action'])} \u2192 {fmt_action(p['proposed_action'])}"
        print(f" {i+1:>3}  {fmt_route(p['route_id']):<10} {p['step']:>4}  "
              f"D{p['day']}/H{p['hour']:<4}  {p['twin'][:20]:<20} "
              f"{p['win_rate']:>3.0%}  {act}")

    output = {"mode": "replay", "proposals": proposals}
    out_path = CORPUS_DIR / "tape_diff_proposals.json"
    with open(out_path, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nSaved to {out_path}")
    log(f"Done in {time.time() - t0:.1f}s")


# ══════════════════════════════════════════════════════════════════════
# MODE 3: FULL DIFF (tape + layers + settings)
# ══════════════════════════════════════════════════════════════════════

def run_full_diff(our_path, target_path, save=True):
    """Combined tape diff + layer diff + settings diff.

    Returns dict with all diff results for use by autoloop_v4.
    """
    our_name = Path(our_path).parent.name
    target_name = Path(target_path).parent.name
    log(f"Full diff: {our_name} vs {target_name}")

    # Tape diff
    try:
        our_routes, our_shops = extract_routes(our_path)
        tgt_routes, tgt_shops = extract_routes(target_path)
        tape_diffs = diff_tapes(our_routes, tgt_routes)
    except Exception as e:
        log(f"  Tape diff error: {e}")
        tape_diffs = []

    # Layer diff (import from layer_diff module)
    layer_result = None
    try:
        from layer_diff import full_diff as layer_full_diff
        layer_result = layer_full_diff(our_path, target_path, save=save)
    except Exception as e:
        log(f"  Layer diff error: {e}")

    result = {
        'our_agent': our_name,
        'target_agent': target_name,
        'tape_diffs': len(tape_diffs),
        'tape_diff_details': tape_diffs[:50],  # cap for JSON size
        'layer_diff': layer_result,
    }

    if save:
        out_path = CORPUS_DIR / f"full_diff_{our_name}_vs_{target_name}.json"
        with open(out_path, "w") as f:
            json.dump(result, f, indent=2, default=str)
        log(f"  Saved to {out_path}")

    return result


# ══════════════════════════════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Tape Diff Tracer — find actionable tape edits")
    parser.add_argument("--agent", default=str(AGENTS_DIR / "_pipe6_candidate" / "main.py"),
                        help="Our agent (default: _pipe6_candidate)")
    parser.add_argument("--target", default=DEFAULT_TARGET,
                        help="Target agent to diff against (default: v45)")
    parser.add_argument("--replay", action="store_true",
                        help="Use replay-based comparison (fallback mode)")
    parser.add_argument("--full", action="store_true",
                        help="Combined tape + layer + settings diff")
    # Replay-mode options
    parser.add_argument("--top-n", type=int, default=20)
    parser.add_argument("--min-replays", type=int, default=3)
    parser.add_argument("--freshness-hours", type=float, default=36)
    parser.add_argument("--from-cache", action="store_true")
    args = parser.parse_args()

    if args.full:
        our_path = Path(args.agent)
        if not our_path.exists():
            our_path = AGENTS_DIR / args.agent / "main.py"
        target_path = Path(args.target)
        if not target_path.exists():
            target_path = AGENTS_DIR / args.target / "main.py"
            if not target_path.exists():
                matches = list(AGENTS_DIR.glob(f"*{args.target}*"))
                if matches:
                    target_path = matches[0] / "main.py"
        run_full_diff(str(our_path), str(target_path))
    elif args.replay:
        run_replay_mode(args)
    else:
        run_tape_mode(args)


if __name__ == "__main__":
    main()
