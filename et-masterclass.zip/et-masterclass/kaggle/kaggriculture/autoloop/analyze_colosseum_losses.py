#!/usr/bin/env python3
"""Analyze colosseum loss replays using the mechanism tracer's trace_game function."""
import json
import sys
from pathlib import Path
from collections import defaultdict

# Import from mechanism_tracer
sys.path.insert(0, str(Path(__file__).parent))
from mechanism_tracer import trace_game, aggregate_mechanisms, format_report

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("loss_dir", help="Directory of colosseum loss replays")
    parser.add_argument("--top", type=int, default=10)
    args = parser.parse_args()

    loss_dir = Path(args.loss_dir)
    loss_files = sorted(loss_dir.glob("loss_*.json"))
    print(f"[analyze] Loading {len(loss_files)} loss replays from {loss_dir}")

    traces = []
    for lf in loss_files:
        try:
            replay = json.load(open(lf))
        except Exception as e:
            print(f"  skip {lf.name}: {e}")
            continue

        # Colosseum format: our_seat tells us which seat we played
        # trace_game uses target_team to find our seat; agent_a = us
        trace = trace_game(replay, target_team="agent_a")
        if trace:
            traces.append(trace)

    print(f"[analyze] Traced {len(traces)} losses")
    if not traces:
        print("No losses to analyze")
        return

    candidates = aggregate_mechanisms(traces)
    report = format_report(candidates, traces, "agent_a (pipe-4)")
    print(report)

    # Also dump detailed divergence analysis
    print("\n" + "=" * 80)
    print("  DETAILED DIVERGENCE BREAKDOWN")
    print("=" * 80)

    # Day distribution
    day_counts = defaultdict(int)
    for t in traces:
        day_counts[t["divergence"]["day"]] += 1
    print("\n  Divergence day distribution:")
    for day in sorted(day_counts.keys()):
        bar = "#" * day_counts[day]
        print(f"    Day {day:2d}: {day_counts[day]:3d} losses {bar}")

    # Checkpoint analysis: where does v40 pull ahead?
    print("\n  Average checkpoint deltas (opponent - us, positive = opponent ahead):")
    delta_sums = defaultdict(lambda: defaultdict(float))
    delta_counts = defaultdict(int)
    for t in traces:
        for day_str, d in t.get("deltas", {}).items():
            day = int(day_str)
            delta_counts[day] += 1
            delta_sums[day]["cash"] += d.get("cash", 0)
            delta_sums[day]["workers"] += d.get("workers", 0)
            delta_sums[day]["sell_revenue"] += d.get("sell_revenue", 0)
            for animal, count in d.get("animals", {}).items():
                delta_sums[day][f"animal_{animal}"] += count
            for crop, count in d.get("crops", {}).items():
                delta_sums[day][f"crop_{crop}"] += count
            for struct, count in d.get("structures", {}).items():
                delta_sums[day][f"struct_{struct}"] += count

    for day in sorted(delta_sums.keys()):
        n = delta_counts[day]
        print(f"\n    Day {day} (n={n}):")
        for metric, total in sorted(delta_sums[day].items(), key=lambda x: abs(x[1]), reverse=True):
            avg = total / n
            if abs(avg) > 0.01:
                direction = "opponent leads" if avg > 0 else "we lead"
                print(f"      {metric:25s}: {avg:+8.1f} ({direction})")

    # Top mechanism actions with full detail
    print("\n" + "-" * 80)
    print("  TOP 5 MECHANISM ACTIONS (with full opponent action examples)")
    print("-" * 80)
    for i, cand in enumerate(candidates[:5]):
        if cand["count"] == 0:
            continue
        print(f"\n  #{i+1} {cand['mechanism']} — in {cand['count']}/{len(traces)} losses ({cand['frequency']:.0%})")
        if cand.get("top_specific_action"):
            print(f"      Most common: {cand['top_specific_action'][0]} ({cand['top_specific_action'][1]}x)")
        for j, ex in enumerate(cand["examples"][:3]):
            print(f"      Example {j+1}: day {ex['day']} step {ex['step']} ({ex['shop_combo']})")
            print(f"        Us:  {json.dumps(ex.get('our_action', '?'))[:120]}")
            print(f"        Opp: {json.dumps(ex.get('opp_action', '?'))[:120]}")

    # Save
    out = loss_dir.parent / "pipe4_vs_v40_mechanisms.json"
    with open(out, "w") as f:
        json.dump({"traces": [{k:v for k,v in t.items() if k != "checkpoints"} for t in traces],
                   "candidates": candidates}, f, indent=2, default=str)
    print(f"\n[analyze] Saved to {out}")


if __name__ == "__main__":
    main()
