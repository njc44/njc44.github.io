#!/usr/bin/env python3
"""Autoloop v5: Measurement-first pipeline.

Philosophy shift from v4:
  v4: "What did the opponent change? → Take it → Test in gauntlet"
  v5: "What game mechanic is suboptimal? → Design a fix → Measure on panel → Ship or reject"

Three new capabilities:
  A. Panel Evaluator — +a/-b on 1,000+ recorded games (replaces unpredictive gauntlet)
  B. Mechanic Analyzer — originate candidates from game rules (not just absorption)
  C. Experiment Registry — track all candidates, prevent retrying failures

Pipeline:
  1. PANEL BUILD    — index cached replays → extract tapes → panel/index.json
  2. BASELINE       — run current agent vs panel → baseline outcomes
  3. ORIGINATE      — run mechanic auditors → candidate specs
  4. ABSORB         — (optional) run v4 absorption → more candidate specs
  5. REGISTRY CHECK — filter out candidates similar to known failures
  6. PANEL EVAL     — for each candidate: run vs panel → count flips (+a/-b)
  7. COLOSSEUM      — live H2H for panel survivors only (200 games vs predecessor)
  8. GATE           — elo_rate check + regression check
  9. SHIP or LOG    — accepted → submit, rejected → registry with reason

Usage:
    python autoloop_v5.py --base pipe11 --name pipe12
    python autoloop_v5.py --base pipe11 --name pipe12 --originate-only
    python autoloop_v5.py --base pipe11 --name pipe12 --absorb-from thomastschinkel
    python autoloop_v5.py --rebuild-panel
    python autoloop_v5.py --status  # show registry + panel status
"""
import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"
PANEL_DIR = CORPUS_DIR / "panel"
PYTHON = sys.executable
COLOSSEUM = str(AUTOLOOP_DIR / "colosseum.py")

sys.path.insert(0, str(AUTOLOOP_DIR))


def log(msg):
    print(f"[v5] {msg}", flush=True)


def banner(step, title):
    print(f"\n{'='*70}")
    print(f"  STEP {step}: {title}")
    print(f"{'='*70}", flush=True)


def resolve_agent(name_or_path):
    """Resolve to agent main.py path."""
    p = Path(name_or_path)
    if p.is_file():
        return str(p)
    candidate = AGENTS_DIR / name_or_path / "main.py"
    if candidate.exists():
        return str(candidate)
    matches = list(AGENTS_DIR.glob(f"*{name_or_path}*"))
    for m in matches:
        if (m / "main.py").exists():
            return str(m / "main.py")
    return None


def run_h2h(agent_a, agent_b, games=10, parallel=10):
    """Run colosseum H2H and return parsed results."""
    import tempfile
    with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as f:
        outpath = f.name
    try:
        cmd = [PYTHON, COLOSSEUM, agent_a, agent_b,
               '--games', str(games), '--parallel', str(parallel), '--output', outpath]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600, cwd=str(WORK_DIR))
        if os.path.exists(outpath) and os.path.getsize(outpath) > 0:
            with open(outpath) as f:
                return json.load(f)
        return {"error": True, "detail": result.stderr[-300:] if result.stderr else "no output"}
    except Exception as e:
        return {"error": True, "detail": str(e)}
    finally:
        if os.path.exists(outpath):
            os.unlink(outpath)


# ═══════════════════════════════════════════════════════════
# STEP 1: PANEL BUILD
# ═══════════════════════════════════════════════════════════

def step1_panel_build(max_games=2000, force=False):
    banner(1, "PANEL BUILD")
    from panel_evaluator import build_panel, load_panel_index

    index = load_panel_index()
    if index and index.get("total_games", 0) >= 500 and not force:
        log(f"Panel exists: {index['total_games']} games (use --rebuild-panel to rebuild)")
        return index

    log("Building panel from cached replays...")
    index = build_panel(max_games=max_games)
    return index


# ═══════════════════════════════════════════════════════════
# STEP 2: BASELINE
# ═══════════════════════════════════════════════════════════

def step2_baseline(base_path, panel_dir, parallel=10, max_games=None):
    banner(2, "BASELINE — running base agent vs panel")
    from panel_evaluator import run_panel, save_panel_results, load_panel_results

    # Check cache
    base_name = Path(base_path).parent.name
    cache_path = PANEL_DIR / "baselines" / f"{base_name}_results.json"
    if cache_path.exists():
        log(f"Loading cached baseline from {cache_path}")
        return load_panel_results(str(cache_path))

    results = run_panel(base_path, panel_dir, parallel, max_games)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    save_panel_results(results, str(cache_path))
    log(f"Cached baseline to {cache_path}")

    # Summary
    wins = sum(1 for r in results.values() if r.get("outcome") == "WIN")
    losses = sum(1 for r in results.values() if r.get("outcome") == "LOSS")
    ties = sum(1 for r in results.values() if r.get("outcome") == "TIE")
    total = wins + losses + ties
    rate = (wins + 0.5 * ties) / total if total else 0
    log(f"Baseline: {wins}W-{losses}L-{ties}T ({rate:.1%} elo rate)")

    return results


# ═══════════════════════════════════════════════════════════
# STEP 3: ORIGINATE
# ═══════════════════════════════════════════════════════════

def step3_originate(base_path, replays=None):
    banner(3, "ORIGINATE — generating candidates from game mechanics")
    from mechanic_analyzer import run_all_auditors
    candidates = run_all_auditors(base_path, replays)
    log(f"Generated {len(candidates)} candidates")
    return candidates


# ═══════════════════════════════════════════════════════════
# STEP 4: ABSORB (optional, from v4)
# ═══════════════════════════════════════════════════════════

def step4_absorb(base_path, absorb_from=None, patterns=None):
    if not absorb_from:
        log("Skipping absorption (--absorb-from not specified)")
        return []

    banner(4, f"ABSORB — from {absorb_from}")
    from mechanic_analyzer import CandidateSpec

    # Use v4's scout + layer_diff to find innovations
    try:
        from autoloop_v4 import step1_scout, find_target_agents
        target_agents = find_target_agents(absorb_from, patterns or ["v9"])
        if not target_agents:
            target_agents = step1_scout(absorb_from, patterns or ["v9"])
        if not target_agents:
            log("No target agents found for absorption")
            return []

        # Convert to CandidateSpecs
        candidates = []
        for pattern, info in target_agents.items():
            candidates.append(CandidateSpec(
                id=f"ABSORB_{absorb_from}_{pattern}",
                domain="absorb",
                description=f"Absorb {pattern} from {absorb_from}: {info.get('name', '?')}",
                estimated_impact="Unknown — needs panel evaluation",
                source=f"absorb:{absorb_from}_{pattern}",
                details={"target_user": absorb_from, "pattern": pattern,
                         "agent_path": info.get("path")},
            ))
        log(f"Generated {len(candidates)} absorption candidates")
        return candidates

    except Exception as e:
        log(f"Absorption error: {e}")
        return []


# ═══════════════════════════════════════════════════════════
# STEP 5: REGISTRY CHECK
# ═══════════════════════════════════════════════════════════

def step5_registry_check(candidates):
    banner(5, "REGISTRY CHECK — filtering known failures")
    from registry import ExperimentRegistry

    reg = ExperimentRegistry()
    filtered = []
    skipped = 0

    for c in candidates:
        rejected = reg.check_rejected(c.description, c.domain)
        if rejected:
            log(f"  SKIP {c.id}: similar to rejected {rejected[0].id} "
                f"({rejected[0].rejection_reason})")
            skipped += 1
            continue
        filtered.append(c)

    log(f"Registry filter: {len(candidates)} → {len(filtered)} candidates ({skipped} skipped)")
    return filtered


# ═══════════════════════════════════════════════════════════
# STEP 6: PANEL EVAL
# ═══════════════════════════════════════════════════════════

def step6_panel_eval(base_path, baseline_results, candidates, panel_dir,
                     parallel=10, max_games=None):
    banner(6, f"PANEL EVAL — testing {len(candidates)} candidates")
    from panel_evaluator import run_panel, count_flips, load_panel_index, save_panel_results
    from registry import ExperimentRegistry

    reg = ExperimentRegistry()
    index = load_panel_index(panel_dir)
    survivors = []

    for i, candidate in enumerate(candidates):
        log(f"\n  --- [{i+1}/{len(candidates)}] {candidate.id} ---")
        log(f"  {candidate.description[:80]}")

        # For now, candidates without code_template can't be auto-applied.
        # Log them as "needs manual implementation" and pass them through
        # if they have strong enough expected impact.
        if not candidate.code_template and candidate.domain != "absorb":
            # Check if this is a Tschinkel-verified candidate
            is_verified = "Tschinkel" in candidate.estimated_impact or "verified" in candidate.estimated_impact
            if is_verified:
                log(f"  PASS (Tschinkel-verified, needs implementation)")
                exp_id = reg.log(
                    description=candidate.description,
                    domain=candidate.domain,
                    source=candidate.source,
                    status="panel_pass",
                    candidate_spec=candidate.to_dict(),
                )
                candidate.details["experiment_id"] = exp_id
                survivors.append(candidate)
            else:
                log(f"  SKIP (no code template, unverified)")
                reg.log(
                    description=candidate.description,
                    domain=candidate.domain,
                    source=candidate.source,
                    status="pending",
                    candidate_spec=candidate.to_dict(),
                )
            continue

        # TODO: For candidates WITH code_template, we would:
        # 1. Apply the template to the base agent
        # 2. Run panel evaluation
        # 3. Count flips
        # 4. Accept/reject based on net flips
        #
        # For absorption candidates with an agent_path, we'd:
        # 1. Run panel with the absorbed agent
        # 2. Count flips vs baseline
        #
        # This will be implemented once we have working panel runs.
        log(f"  QUEUED for panel eval (code_template available)")
        exp_id = reg.log(
            description=candidate.description,
            domain=candidate.domain,
            source=candidate.source,
            status="pending",
            candidate_spec=candidate.to_dict(),
        )
        candidate.details["experiment_id"] = exp_id
        survivors.append(candidate)

    log(f"\nPanel eval: {len(survivors)} survivors from {len(candidates)} candidates")
    return survivors


# ═══════════════════════════════════════════════════════════
# STEP 7: COLOSSEUM (live validation)
# ═══════════════════════════════════════════════════════════

def step7_colosseum(base_path, survivors, games=200, parallel=10):
    banner(7, f"COLOSSEUM — live validation ({len(survivors)} candidates)")

    if not survivors:
        log("No survivors to validate")
        return []

    # For candidates that have an agent path (absorption), run live H2H
    validated = []
    for candidate in survivors:
        agent_path = candidate.details.get("agent_path")
        if not agent_path or not os.path.exists(agent_path):
            log(f"  {candidate.id}: no agent path, passing through")
            validated.append(candidate)
            continue

        log(f"  {candidate.id} vs base ({games} games)...")
        r = run_h2h(agent_path, base_path, games, parallel)
        if r.get("error"):
            log(f"    ERROR: {r.get('detail', '')[:100]}")
            continue

        wlt = f"{r['wins']}-{r['losses']}-{r['ties']}"
        log(f"    {wlt} (elo_rate={r['elo_rate']:.0%})")

        if r['elo_rate'] > 0.5:
            validated.append(candidate)
            candidate.details["colosseum_result"] = {
                "wins": r["wins"], "losses": r["losses"], "ties": r["ties"],
                "elo_rate": r["elo_rate"],
            }

    log(f"Colosseum: {len(validated)} validated from {len(survivors)} survivors")
    return validated


# ═══════════════════════════════════════════════════════════
# STEP 8: GATE
# ═══════════════════════════════════════════════════════════

def step8_gate(validated):
    banner(8, "GATE — final checks")
    # For now, all validated candidates pass the gate
    # In the future, this would run regression checks against a broader gauntlet
    log(f"Passing {len(validated)} candidates through gate")
    return validated


# ═══════════════════════════════════════════════════════════
# STEP 9: SHIP or LOG
# ═══════════════════════════════════════════════════════════

def step9_ship_or_log(passed, failed_candidates=None):
    banner(9, "RESULTS")
    from registry import ExperimentRegistry
    reg = ExperimentRegistry()

    if passed:
        print(f"\n  ACCEPTED CANDIDATES ({len(passed)}):")
        for c in passed:
            print(f"    [{c.id}] {c.description[:70]}")
            print(f"      Impact: {c.estimated_impact}")
            exp_id = c.details.get("experiment_id")
            if exp_id:
                reg.update(exp_id, status="accepted")
    else:
        print("\n  No candidates accepted.")

    # Summary
    print(f"\n  Registry status:")
    reg.summary()


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Autoloop v5: Measurement-first pipeline")
    parser.add_argument("--base", help="Base agent directory name (e.g. pipe11)")
    parser.add_argument("--name", default="pipe12", help="Output agent name")
    parser.add_argument("--absorb-from", help="Target user for absorption (e.g. thomastschinkel)")
    parser.add_argument("--absorb-patterns", nargs="+", help="Version patterns for absorption")
    parser.add_argument("--originate-only", action="store_true", help="Skip absorption step")
    parser.add_argument("--max-panel-games", type=int, default=2000)
    parser.add_argument("--max-eval-games", type=int, help="Limit panel games for eval (faster testing)")
    parser.add_argument("--games-colosseum", type=int, default=200)
    parser.add_argument("--parallel", type=int, default=10)
    parser.add_argument("--rebuild-panel", action="store_true", help="Rebuild panel from scratch")
    parser.add_argument("--status", action="store_true", help="Show system status")
    parser.add_argument("--skip-panel-eval", action="store_true", help="Skip panel eval (registry check only)")
    args = parser.parse_args()

    if args.status:
        _show_status()
        return

    if args.rebuild_panel:
        step1_panel_build(max_games=args.max_panel_games, force=True)
        return

    if not args.base:
        parser.print_help()
        return

    base_path = resolve_agent(args.base)
    if not base_path:
        log(f"ERROR: Base agent not found: {args.base}")
        return

    t0 = time.time()
    print(f"\n{'#'*70}")
    print(f"  AUTOLOOP V5: {args.base} → {args.name}")
    print(f"{'#'*70}")
    log(f"Base: {base_path}")

    # Step 1: Panel Build
    panel_index = step1_panel_build(args.max_panel_games)

    # Step 2: Baseline (skip if no panel eval needed)
    baseline_results = None
    if not args.skip_panel_eval and panel_index:
        baseline_results = step2_baseline(
            base_path, str(PANEL_DIR), args.parallel, args.max_eval_games)

    # Step 3: Originate
    candidates = step3_originate(base_path)

    # Step 4: Absorb (optional)
    if not args.originate_only:
        absorb_candidates = step4_absorb(
            base_path, args.absorb_from, args.absorb_patterns)
        candidates.extend(absorb_candidates)

    # Step 5: Registry Check
    candidates = step5_registry_check(candidates)

    # Step 6: Panel Eval
    if not args.skip_panel_eval and baseline_results:
        survivors = step6_panel_eval(
            base_path, baseline_results, candidates,
            str(PANEL_DIR), args.parallel, args.max_eval_games)
    else:
        survivors = candidates

    # Step 7: Colosseum (for absorption candidates with agent paths)
    validated = step7_colosseum(base_path, survivors, args.games_colosseum, args.parallel)

    # Step 8: Gate
    passed = step8_gate(validated)

    # Step 9: Ship or Log
    step9_ship_or_log(passed)

    elapsed = time.time() - t0
    print(f"\n{'#'*70}")
    print(f"  AUTOLOOP V5 COMPLETE: {elapsed:.0f}s ({elapsed/60:.1f}m)")
    print(f"{'#'*70}")


def _show_status():
    """Show system status: panel, registry, available agents."""
    from panel_evaluator import load_panel_index
    from registry import ExperimentRegistry

    print("=== AUTOLOOP V5 STATUS ===\n")

    # Panel
    index = load_panel_index()
    if index:
        print(f"Panel: {index['total_games']} games, built {index.get('built_at', '?')}")
        # Count unique teams
        teams = set()
        for g in index["games"]:
            teams.add(g.get("team_0", "?"))
            teams.add(g.get("team_1", "?"))
        print(f"  Teams: {len(teams)} unique")

        # Check baselines
        baselines_dir = PANEL_DIR / "baselines"
        if baselines_dir.exists():
            baselines = list(baselines_dir.glob("*_results.json"))
            print(f"  Cached baselines: {len(baselines)}")
            for b in baselines:
                print(f"    {b.stem}")
    else:
        print("Panel: NOT BUILT (run --rebuild-panel)")

    # Registry
    print()
    reg = ExperimentRegistry()
    reg.summary()

    # Agents
    print(f"\nAgents: {len(list(AGENTS_DIR.iterdir()))} in {AGENTS_DIR}")


if __name__ == "__main__":
    main()
