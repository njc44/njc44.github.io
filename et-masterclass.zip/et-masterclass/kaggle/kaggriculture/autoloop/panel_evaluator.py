#!/usr/bin/env python3
"""Panel Evaluator: Measurement-first evaluation using recorded games.

Replaces the ~15-agent gauntlet with a diverse panel of 1,000+ recorded games.
Each change is measured by "games flipped" (+a/-b), not just aggregate win rate.

Three components:
  PanelBuilder — index cached replays, extract action tapes
  PanelRunner  — run candidate vs frozen tapes in parallel
  FlipCounter  — compare baseline vs candidate outcomes, count flips

Usage:
    python panel_evaluator.py --build                              # Build panel from cached replays
    python panel_evaluator.py --build --max-games 500              # Limit panel size
    python panel_evaluator.py --run agents/pipe11/main.py          # Run agent vs panel
    python panel_evaluator.py --compare baseline.json candidate.json  # Count flips
    python panel_evaluator.py --eval agents/pipe11/main.py agents/pipe12/main.py  # Full eval
"""
import argparse
import json
import math
import os
import sys
import tempfile
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
REPLAY_DIR = AUTOLOOP_DIR / "replays"
PANEL_DIR = AUTOLOOP_DIR / "corpus" / "panel"
TAPES_DIR = PANEL_DIR / "tapes"
INDEX_PATH = PANEL_DIR / "index.json"

# Import replay_agent for frozen playback
sys.path.insert(0, str(WORK_DIR))


def log(msg):
    print(f"[panel] {msg}", flush=True)


# ═══════════════════════════════════════════════════════════
# PANEL BUILDER
# ═══════════════════════════════════════════════════════════

def extract_tape(replay, seat):
    """Extract action tape for one player from a full replay.

    Returns a list of 720 action dicts, each with {farmer, hands, market}.
    Compatible with replay_agent.make_replay_agent().
    """
    tape = []
    for step_data in replay["steps"]:
        action = step_data[seat].get("action")
        if action and isinstance(action, dict):
            tape.append(action)
        else:
            tape.append({"farmer": ["PASS"], "hands": [], "market": []})
    return tape


def extract_metadata(replay):
    """Extract game metadata from a replay."""
    info = replay.get("info", {})
    teams = info.get("TeamNames", ["unknown", "unknown"])
    rewards = replay.get("rewards", [0, 0])
    episode_id = info.get("EpisodeId", 0)

    # Determine winner
    if rewards[0] > rewards[1]:
        winner = 0
    elif rewards[1] > rewards[0]:
        winner = 1
    else:
        winner = -1  # tie

    # Extract shops from first shop unlock (step 72 = day 3)
    shops = []
    try:
        for step_idx in [72, 144, 216]:
            if step_idx < len(replay["steps"]):
                obs = replay["steps"][step_idx][0].get("observation", {})
                shops = obs.get("town", {}).get("unlocked_shops", [])
                if shops:
                    break
    except (KeyError, IndexError):
        pass

    return {
        "episode_id": episode_id,
        "team_0": teams[0] if len(teams) > 0 else "unknown",
        "team_1": teams[1] if len(teams) > 1 else "unknown",
        "reward_0": rewards[0],
        "reward_1": rewards[1],
        "winner": winner,
        "shops": shops[:3],
    }


def build_panel(replay_dir=None, panel_dir=None, max_games=2000):
    """Build panel from cached replays: extract tapes + build index.

    Reads full replay JSONs, extracts both players' action tapes as lightweight
    JSON files, and builds an index with metadata.
    """
    replay_dir = Path(replay_dir or REPLAY_DIR)
    panel_dir = Path(panel_dir or PANEL_DIR)
    tapes_dir = panel_dir / "tapes"
    tapes_dir.mkdir(parents=True, exist_ok=True)

    replay_files = sorted(replay_dir.glob("*.json"))
    log(f"Found {len(replay_files)} replays in {replay_dir}")

    games = []
    skipped = 0
    errors = 0

    for i, rpath in enumerate(replay_files):
        if len(games) >= max_games:
            break

        if (i + 1) % 100 == 0:
            log(f"  Processing {i + 1}/{len(replay_files)} ({len(games)} games built)...")

        try:
            with open(rpath) as f:
                replay = json.load(f)

            # Validate: must have 720 steps with valid actions
            steps = replay.get("steps", [])
            if len(steps) < 700:
                skipped += 1
                continue

            meta = extract_metadata(replay)
            ep_id = meta["episode_id"] or rpath.stem

            # Check if tapes already extracted
            tape_0_path = tapes_dir / f"ep_{ep_id}_p0.json"
            tape_1_path = tapes_dir / f"ep_{ep_id}_p1.json"

            if not tape_0_path.exists():
                tape_0 = extract_tape(replay, 0)
                with open(tape_0_path, "w") as f:
                    json.dump(tape_0, f)

            if not tape_1_path.exists():
                tape_1 = extract_tape(replay, 1)
                with open(tape_1_path, "w") as f:
                    json.dump(tape_1, f)

            game_entry = {
                **meta,
                "tape_0": str(tape_0_path.relative_to(panel_dir)),
                "tape_1": str(tape_1_path.relative_to(panel_dir)),
                "replay_file": rpath.name,
            }
            games.append(game_entry)

        except Exception as e:
            errors += 1
            if errors <= 5:
                log(f"  Error processing {rpath.name}: {e}")

    # Build index
    index = {
        "version": 1,
        "built_at": datetime.now(timezone.utc).isoformat(),
        "source": str(replay_dir),
        "total_games": len(games),
        "games": games,
    }

    index_path = panel_dir / "index.json"
    with open(index_path, "w") as f:
        json.dump(index, f, indent=2)

    log(f"Panel built: {len(games)} games, {skipped} skipped, {errors} errors")
    log(f"Index: {index_path}")
    log(f"Tapes: {tapes_dir}")

    return index


def load_panel_index(panel_dir=None):
    """Load panel index from disk."""
    panel_dir = Path(panel_dir or PANEL_DIR)
    index_path = panel_dir / "index.json"
    if not index_path.exists():
        return None
    with open(index_path) as f:
        return json.load(f)


# ═══════════════════════════════════════════════════════════
# PANEL RUNNER
# ═══════════════════════════════════════════════════════════

def _run_panel_game(args):
    """Run one panel game: candidate agent vs frozen tape opponent.

    Module-level function for ProcessPoolExecutor pickling.
    """
    candidate_path, tape_path, candidate_seat, game_idx = args
    from kaggle_environments import make

    # Build frozen replay agent from tape
    tape_agent_path = _make_tape_agent_file(tape_path)

    try:
        if candidate_seat == 0:
            p0, p1 = str(candidate_path), tape_agent_path
        else:
            p0, p1 = tape_agent_path, str(candidate_path)

        env = make("kaggriculture")
        result = env.run([p0, p1])

        final = result[-1]
        r0, r1 = final[0]["reward"], final[1]["reward"]
        s0, s1 = final[0]["status"], final[1]["status"]

        if s0 != "DONE" or s1 != "DONE":
            return {"game_idx": game_idx, "error": True, "detail": f"status: {s0}/{s1}"}

        if candidate_seat == 0:
            our_score, opp_score = r0, r1
        else:
            our_score, opp_score = r1, r0

        outcome = "WIN" if our_score > opp_score else ("LOSS" if our_score < opp_score else "TIE")

        return {
            "game_idx": game_idx,
            "error": False,
            "outcome": outcome,
            "our_score": our_score,
            "opp_score": opp_score,
            "margin": our_score - opp_score,
        }

    except Exception as e:
        return {"game_idx": game_idx, "error": True, "detail": str(e)[:200]}
    finally:
        # Clean up temp file
        try:
            os.unlink(tape_agent_path)
        except OSError:
            pass


def _make_tape_agent_file(tape_path):
    """Create a temporary agent .py file that replays a tape.

    The colosseum engine loads agents from file paths, so we write a small
    Python file that loads the tape and replays it.
    """
    code = f'''import json

with open({tape_path!r}) as _f:
    _TAPE = json.load(_f)

def agent(observation, configuration=None):
    step = int(observation["step"])
    if step < len(_TAPE):
        return _TAPE[step]
    return {{"farmer": ["PASS"], "hands": [], "market": []}}
'''
    fd, path = tempfile.mkstemp(suffix=".py", prefix="tape_agent_")
    with os.fdopen(fd, "w") as f:
        f.write(code)
    return path


def run_panel(candidate_path, panel_dir=None, parallel=10, max_games=None,
              seat_balance=True):
    """Run candidate agent vs all frozen opponents in the panel.

    For each game in the panel, the candidate plays against the frozen tape
    of one of the original players. If seat_balance=True (default), we play
    the candidate from both seats where possible.

    Returns dict mapping game_idx -> result.
    """
    panel_dir = Path(panel_dir or PANEL_DIR)
    index = load_panel_index(panel_dir)
    if not index:
        log("ERROR: No panel index found. Run --build first.")
        return {}

    games = index["games"]
    if max_games:
        games = games[:max_games]

    # Build task list: for each game, candidate plays against BOTH players' tapes
    tasks = []
    for i, game in enumerate(games):
        # Candidate plays from seat 0 against player 1's tape
        tape_1 = str(panel_dir / game["tape_1"])
        if os.path.exists(tape_1):
            tasks.append((str(candidate_path), tape_1, 0, f"{i}_s0"))

        # Candidate plays from seat 1 against player 0's tape
        if seat_balance:
            tape_0 = str(panel_dir / game["tape_0"])
            if os.path.exists(tape_0):
                tasks.append((str(candidate_path), tape_0, 1, f"{i}_s1"))

    log(f"Running {len(tasks)} panel games ({len(games)} entries × {'2 seats' if seat_balance else '1 seat'})...")
    log(f"Parallel workers: {parallel}")

    results = {}
    t0 = time.time()
    completed = 0

    with ProcessPoolExecutor(max_workers=parallel) as pool:
        futures = {pool.submit(_run_panel_game, t): t for t in tasks}
        for future in as_completed(futures):
            try:
                r = future.result(timeout=120)
                results[r["game_idx"]] = r
            except Exception as e:
                task = futures[future]
                results[task[3]] = {"game_idx": task[3], "error": True, "detail": str(e)[:200]}

            completed += 1
            if completed % 50 == 0:
                elapsed = time.time() - t0
                rate = completed / elapsed if elapsed > 0 else 0
                eta = (len(tasks) - completed) / rate if rate > 0 else 0
                log(f"  {completed}/{len(tasks)} ({rate:.1f} games/s, ETA {eta:.0f}s)")

    elapsed = time.time() - t0
    errors = sum(1 for r in results.values() if r.get("error"))
    log(f"Panel run complete: {len(results)} games in {elapsed:.0f}s ({errors} errors)")

    return results


def save_panel_results(results, output_path):
    """Save panel run results to JSON."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "total_games": len(results),
            "results": results,
        }, f, indent=2)


def load_panel_results(path):
    """Load panel run results from JSON."""
    with open(path) as f:
        return json.load(f).get("results", {})


# ═══════════════════════════════════════════════════════════
# FLIP COUNTER
# ═══════════════════════════════════════════════════════════

@dataclass
class FlipReport:
    plus_a: int = 0        # baseline lost, candidate wins (IMPROVEMENT)
    minus_b: int = 0       # baseline won, candidate loses (REGRESSION)
    holds_win: int = 0     # both win
    holds_loss: int = 0    # both lose
    total_valid: int = 0   # games with valid results from both runs
    filtered_out: int = 0  # games excluded by score filter
    errors: int = 0        # games with errors in either run
    details: list = None   # per-game flip details

    @property
    def net(self):
        return self.plus_a - self.minus_b

    @property
    def flip_rate(self):
        if self.total_valid == 0:
            return 0.0
        return self.net / self.total_valid

    def summary(self):
        return (f"+{self.plus_a}/-{self.minus_b} (net {self.net:+d}) "
                f"on {self.total_valid} valid games "
                f"({self.filtered_out} filtered, {self.errors} errors)")

    def to_dict(self):
        d = asdict(self)
        d["net"] = self.net
        d["flip_rate"] = self.flip_rate
        if d.get("details"):
            d["details"] = d["details"][:20]  # truncate for storage
        return d


def count_flips(baseline_results, candidate_results, panel_index=None,
                score_threshold=0.95, panel_dir=None):
    """Compare baseline vs candidate panel runs, count games flipped.

    score_threshold: exclude games where the frozen opponent's score in the
    candidate run is <threshold of its recorded score. This catches games
    where the frozen replay isn't behaving realistically.

    Returns a FlipReport.
    """
    report = FlipReport(details=[])

    # Load panel index for original scores if available
    original_scores = {}
    if panel_index:
        for i, game in enumerate(panel_index.get("games", [])):
            original_scores[f"{i}_s0"] = game.get("reward_1", 0)  # opp for seat 0 = player 1
            original_scores[f"{i}_s1"] = game.get("reward_0", 0)  # opp for seat 1 = player 0

    # Find common game indices
    common = set(baseline_results.keys()) & set(candidate_results.keys())

    for game_idx in sorted(common):
        br = baseline_results[game_idx]
        cr = candidate_results[game_idx]

        # Skip errors
        if br.get("error") or cr.get("error"):
            report.errors += 1
            continue

        # Score filter: check if frozen opponent's score is realistic
        if score_threshold < 1.0 and game_idx in original_scores:
            original_opp_score = original_scores[game_idx]
            candidate_opp_score = cr.get("opp_score", 0)
            if original_opp_score > 0 and candidate_opp_score < score_threshold * original_opp_score:
                report.filtered_out += 1
                continue

        report.total_valid += 1
        b_outcome = br.get("outcome", "")
        c_outcome = cr.get("outcome", "")

        if b_outcome in ("LOSS", "TIE") and c_outcome == "WIN":
            report.plus_a += 1
            report.details.append({"game_idx": game_idx, "flip": "+a",
                                   "baseline": b_outcome, "candidate": c_outcome})
        elif b_outcome == "WIN" and c_outcome in ("LOSS", "TIE"):
            report.minus_b += 1
            report.details.append({"game_idx": game_idx, "flip": "-b",
                                   "baseline": b_outcome, "candidate": c_outcome})
        elif b_outcome == "WIN" and c_outcome == "WIN":
            report.holds_win += 1
        else:
            report.holds_loss += 1

    return report


# ═══════════════════════════════════════════════════════════
# FULL EVALUATION: baseline + candidate + flips in one call
# ═══════════════════════════════════════════════════════════

def evaluate(baseline_path, candidate_path, panel_dir=None, parallel=10,
             max_games=None, score_threshold=0.95):
    """Full panel evaluation: run baseline, run candidate, count flips.

    Returns (FlipReport, baseline_results, candidate_results).
    """
    panel_dir = Path(panel_dir or PANEL_DIR)
    index = load_panel_index(panel_dir)
    if not index:
        log("ERROR: No panel index found")
        return None, {}, {}

    log(f"=== PANEL EVALUATION ===")
    log(f"Baseline:  {baseline_path}")
    log(f"Candidate: {candidate_path}")
    log(f"Panel:     {index['total_games']} games")

    # Check if baseline results already cached
    baseline_cache = panel_dir / "baselines" / f"{Path(baseline_path).parent.name}_results.json"
    if baseline_cache.exists():
        log(f"Loading cached baseline from {baseline_cache}")
        baseline_results = load_panel_results(baseline_cache)
    else:
        log(f"\n--- Running baseline ---")
        baseline_results = run_panel(baseline_path, panel_dir, parallel, max_games)
        baseline_cache.parent.mkdir(parents=True, exist_ok=True)
        save_panel_results(baseline_results, baseline_cache)
        log(f"Cached baseline to {baseline_cache}")

    log(f"\n--- Running candidate ---")
    candidate_results = run_panel(candidate_path, panel_dir, parallel, max_games)

    log(f"\n--- Counting flips ---")
    report = count_flips(baseline_results, candidate_results, index, score_threshold)

    log(f"\n{'='*60}")
    log(f"RESULT: {report.summary()}")
    log(f"{'='*60}")

    return report, baseline_results, candidate_results


# ═══════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Panel Evaluator")
    parser.add_argument("--build", action="store_true", help="Build panel from cached replays")
    parser.add_argument("--max-games", type=int, default=2000, help="Max games in panel")
    parser.add_argument("--run", help="Run agent vs panel, save results")
    parser.add_argument("--output", help="Output path for results")
    parser.add_argument("--compare", nargs=2, metavar=("BASELINE", "CANDIDATE"),
                        help="Compare two result files")
    parser.add_argument("--eval", nargs=2, metavar=("BASELINE_AGENT", "CANDIDATE_AGENT"),
                        help="Full evaluation: run both agents, count flips")
    parser.add_argument("--parallel", type=int, default=10)
    parser.add_argument("--panel-dir", help="Override panel directory")
    parser.add_argument("--score-threshold", type=float, default=0.95,
                        help="Frozen replay score filter (0.95 = exclude if opp drops below 95%%)")
    parser.add_argument("--info", action="store_true", help="Show panel info")
    args = parser.parse_args()

    panel_dir = Path(args.panel_dir) if args.panel_dir else PANEL_DIR

    if args.build:
        build_panel(panel_dir=panel_dir, max_games=args.max_games)

    elif args.run:
        results = run_panel(args.run, panel_dir, args.parallel, args.max_games)
        out = args.output or str(panel_dir / "latest_results.json")
        save_panel_results(results, out)
        log(f"Saved to {out}")

        # Quick summary
        wins = sum(1 for r in results.values() if r.get("outcome") == "WIN")
        losses = sum(1 for r in results.values() if r.get("outcome") == "LOSS")
        ties = sum(1 for r in results.values() if r.get("outcome") == "TIE")
        errors = sum(1 for r in results.values() if r.get("error"))
        total = wins + losses + ties
        rate = (wins + 0.5 * ties) / total if total else 0
        log(f"Summary: {wins}W-{losses}L-{ties}T ({rate:.1%} elo rate, {errors} errors)")

    elif args.compare:
        baseline_results = load_panel_results(args.compare[0])
        candidate_results = load_panel_results(args.compare[1])
        index = load_panel_index(panel_dir)
        report = count_flips(baseline_results, candidate_results, index, args.score_threshold)
        log(f"Flip report: {report.summary()}")

    elif args.eval:
        report, _, _ = evaluate(
            args.eval[0], args.eval[1],
            panel_dir=panel_dir, parallel=args.parallel,
            max_games=args.max_games, score_threshold=args.score_threshold,
        )

    elif args.info:
        index = load_panel_index(panel_dir)
        if index:
            log(f"Panel: {index['total_games']} games, built {index.get('built_at', '?')}")
            teams = set()
            for g in index["games"]:
                teams.add(g.get("team_0", "?"))
                teams.add(g.get("team_1", "?"))
            log(f"Teams: {len(teams)} unique")
            log(f"Source: {index.get('source', '?')}")
        else:
            log("No panel found. Run --build first.")

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
