#!/usr/bin/env python3
"""Step-Level Money Tracer: Per-step money attribution and divergence detection.

Tracks money at every step (720 per game), finds the exact step where
value leaks, and attributes the cause to specific sell/buy actions.

Usage:
    python step_money_tracer.py <replay_file> --seat 0
    python step_money_tracer.py <losses_dir> --seats _seats.json
    python step_money_tracer.py <replay_file> --step 553  # detail one step
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

PRODUCTS = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON",
            "EGG", "MILK", "WOOL", "FERTILIZER")


def trace_money_per_step(replay, our_seat=0):
    """Extract money for both players at every step.

    Returns dict with:
      - our_money: list of 720 money values
      - opp_money: list of 720 money values
      - gap: list of 720 (opp - our) values
      - our_deltas: list of 720 per-step changes
      - opp_deltas: list of 720 per-step changes
    """
    steps = replay.get("steps", [])
    opp_seat = 1 - our_seat
    our_money = []
    opp_money = []

    for step_data in steps:
        obs = step_data[0].get("observation", {})
        farms = obs.get("farms", [{}, {}])
        our_money.append(float(farms[our_seat].get("money", 0)))
        opp_money.append(float(farms[opp_seat].get("money", 0)))

    gap = [opp_money[i] - our_money[i] for i in range(len(our_money))]
    our_deltas = [0] + [our_money[i] - our_money[i-1] for i in range(1, len(our_money))]
    opp_deltas = [0] + [opp_money[i] - opp_money[i-1] for i in range(1, len(opp_money))]

    return {
        "our_money": our_money,
        "opp_money": opp_money,
        "gap": gap,
        "our_deltas": our_deltas,
        "opp_deltas": opp_deltas,
    }


def find_permanent_divergence(gap, window=24):
    """Find the first step where one player pulls ahead and stays ahead.

    A divergence is "permanent" if the gap stays consistently positive
    (or negative) for `window` consecutive steps.

    Returns (step_index, direction) where direction is +1 (opp ahead)
    or -1 (we ahead), or (None, 0) if no permanent divergence.
    """
    n = len(gap)
    for i in range(n - window):
        if gap[i] == 0:
            continue
        direction = 1 if gap[i] > 0 else -1
        permanent = True
        for j in range(i, min(i + window, n)):
            if direction > 0 and gap[j] <= 0:
                permanent = False
                break
            if direction < 0 and gap[j] >= 0:
                permanent = False
                break
        if permanent:
            return (i, direction)
    return (None, 0)


def attribute_step(replay, seat, step_idx):
    """Attribute money change at a specific step to actions.

    Returns dict with action details and estimated revenue/cost.
    """
    steps = replay.get("steps", [])
    if step_idx >= len(steps):
        return {}

    action = steps[step_idx][seat].get("action", {}) or {}
    obs = steps[step_idx][0].get("observation", {})
    farms = obs.get("farms", [{}, {}])
    market_obs = obs.get("market", {})
    prices = market_obs.get("prices", {})
    inventory = market_obs.get("inventory", {})

    sells = []
    buys = []
    hires = 0
    for order in action.get("market", []):
        if not isinstance(order, list) or len(order) < 2:
            continue
        if order[0] == "SELL" and len(order) >= 3:
            item, qty = order[1], int(order[2])
            price = prices.get(item, 0)
            sells.append({"item": item, "qty": qty, "price": price,
                          "est_revenue": price * qty})
        elif order[0] in ("BUY_PRODUCT", "BUY_ANIMAL", "BUY_SEED") and len(order) >= 3:
            item, qty = order[1], int(order[2])
            price = prices.get(item, 0)
            buys.append({"item": item, "qty": qty, "price": price})
        elif order[0] == "HIRE":
            hires += 1
        elif order[0] == "BUY_LAND":
            buys.append({"item": "LAND", "qty": 1, "price": 0})

    return {
        "step": step_idx,
        "day": step_idx // 24,
        "hour": step_idx % 24,
        "sells": sells,
        "buys": buys,
        "hires": hires,
        "total_sell_revenue": sum(s["est_revenue"] for s in sells),
        "money_before": farms[seat].get("money", 0),
    }


def find_top_leak_steps(trace, n=10):
    """Find the N steps where the gap grows most (in opponent's favor)."""
    gap = trace["gap"]
    gap_deltas = [0] + [gap[i] - gap[i-1] for i in range(1, len(gap))]
    indexed = [(abs(d), i, d) for i, d in enumerate(gap_deltas) if d > 0]
    indexed.sort(reverse=True)
    return [(step, delta) for _, step, delta in indexed[:n]]


def analyze_game_step_level(replay, our_seat=0):
    """Full step-level analysis for one game."""
    trace = trace_money_per_step(replay, our_seat)
    div_step, div_dir = find_permanent_divergence(trace["gap"])
    top_leaks = find_top_leak_steps(trace)

    # GROUND TRUTH sanity check: trace money must match rewards
    rewards = replay.get("rewards", [0, 0])
    our_reward = rewards[our_seat] if rewards[our_seat] else 0
    opp_reward = rewards[1 - our_seat] if rewards[1 - our_seat] else 0
    trace_final_us = trace["our_money"][-1] if trace["our_money"] else 0
    trace_final_opp = trace["opp_money"][-1] if trace["opp_money"] else 0
    if our_reward and abs(trace_final_us - our_reward) > our_reward * 0.01:
        import sys
        sys.stderr.write(f"WARNING: trace money ${trace_final_us:.0f} != reward ${our_reward:.0f}\n")

    result = {
        "our_final": trace["our_money"][-1] if trace["our_money"] else 0,
        "opp_final": trace["opp_money"][-1] if trace["opp_money"] else 0,
        "margin": (trace["our_money"][-1] - trace["opp_money"][-1]) if trace["our_money"] else 0,
        "divergence_step": div_step,
        "divergence_day": div_step // 24 if div_step else None,
        "divergence_direction": "opp_ahead" if div_dir > 0 else "us_ahead" if div_dir < 0 else "none",
        "top_leak_steps": top_leaks,
    }

    if div_step is not None:
        result["divergence_detail"] = {
            "our_action": attribute_step(replay, our_seat, div_step),
            "opp_action": attribute_step(replay, 1 - our_seat, div_step),
            "gap_at_divergence": trace["gap"][div_step],
        }

    return result


def print_step_analysis(replay, our_seat=0, detail_step=None):
    """Print step-level analysis for one game."""
    trace = trace_money_per_step(replay, our_seat)
    analysis = analyze_game_step_level(replay, our_seat)

    print(f"{'='*70}")
    print(f"STEP-LEVEL MONEY TRACE")
    print(f"Final: us=${analysis['our_final']:.0f} opp=${analysis['opp_final']:.0f} "
          f"margin=${analysis['margin']:+.0f}")
    print(f"{'='*70}")

    if analysis["divergence_step"] is not None:
        ds = analysis["divergence_step"]
        print(f"\nPermanent divergence at step {ds} (day {ds//24}, hour {ds%24})")
        print(f"  Direction: {analysis['divergence_direction']}")
        print(f"  Gap: ${trace['gap'][ds]:+.0f}")
        dd = analysis.get("divergence_detail", {})
        our_a = dd.get("our_action", {})
        opp_a = dd.get("opp_action", {})
        if our_a.get("sells"):
            print(f"  Our sells: {[(s['item'], s['qty'], f'${s['price']}') for s in our_a['sells']]}")
        if opp_a.get("sells"):
            print(f"  Opp sells: {[(s['item'], s['qty'], f'${s['price']}') for s in opp_a['sells']]}")

    print(f"\nTop leak steps (where gap grows most):")
    for step, delta in analysis["top_leak_steps"][:10]:
        day, hour = step // 24, step % 24
        print(f"  Step {step:3d} (d{day:2d}h{hour:2d}): gap grows ${delta:+.0f}")

    # Print per-day summary
    print(f"\n{'Day':>4} {'Us$':>10} {'Opp$':>10} {'Gap':>8} {'DayΔ':>8}")
    print("-" * 45)
    prev_gap = 0
    for d in range(30):
        step = d * 24 + 23
        if step >= len(trace["our_money"]):
            break
        um = trace["our_money"][step]
        om = trace["opp_money"][step]
        gap = trace["gap"][step]
        gap_delta = gap - prev_gap
        if abs(gap) > 50 or abs(gap_delta) > 50 or d in [0, 10, 20, 29]:
            print(f"{d:4d} ${um:9.0f} ${om:9.0f} ${gap:+7.0f} ${gap_delta:+7.0f}")
        prev_gap = gap

    if detail_step is not None:
        print(f"\n{'='*70}")
        print(f"DETAIL: Step {detail_step} (day {detail_step//24}, hour {detail_step%24})")
        for label, seat in [("US", our_seat), ("OPP", 1 - our_seat)]:
            attr = attribute_step(replay, seat, detail_step)
            print(f"  {label}: money=${attr['money_before']:.0f}")
            if attr["sells"]:
                for s in attr["sells"]:
                    print(f"    SELL {s['item']} x{s['qty']} @${s['price']} = ${s['est_revenue']:.0f}")
            if attr["buys"]:
                for b in attr["buys"]:
                    print(f"    BUY {b['item']} x{b['qty']}")
            if attr["hires"]:
                print(f"    HIRE x{attr['hires']}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Step-level money tracer")
    parser.add_argument("path", help="Replay file or directory")
    parser.add_argument("--seat", type=int, default=0, help="Our seat (0 or 1)")
    parser.add_argument("--seats", help="Path to _seats.json")
    parser.add_argument("--step", type=int, help="Detail a specific step")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    path = Path(args.path)
    if path.is_file():
        with open(path) as f:
            replay = json.load(f)
        if args.json:
            result = analyze_game_step_level(replay, args.seat)
            json.dump(result, sys.stdout, indent=2)
        else:
            print_step_analysis(replay, args.seat, detail_step=args.step)
    elif path.is_dir():
        seats = {}
        if args.seats:
            seats_path = path / args.seats if not Path(args.seats).is_absolute() else Path(args.seats)
            if seats_path.exists():
                with open(seats_path) as f:
                    seats = json.load(f)

        all_results = []
        for fpath in sorted(path.glob("*.json")):
            if fpath.name.startswith("_"):
                continue
            with open(fpath) as f:
                replay = json.load(f)
            ep_id = fpath.stem
            our_seat = int(seats.get(ep_id, args.seat))
            result = analyze_game_step_level(replay, our_seat)
            result["ep_id"] = ep_id
            all_results.append(result)

        losses = [r for r in all_results if r["margin"] < 0]
        if losses:
            print(f"{'='*70}")
            print(f"STEP-LEVEL ANALYSIS: {len(losses)} losses")
            print(f"{'='*70}")
            for r in sorted(losses, key=lambda x: x["margin"]):
                ds = r["divergence_step"]
                ds_str = f"step {ds} (d{ds//24})" if ds else "none"
                print(f"  EP {r['ep_id']}: margin=${r['margin']:+.0f}, "
                      f"diverge={ds_str}")
