#!/usr/bin/env python3
"""
LB Mechanic Miner: Extract game mechanics from LB replays and find
which mechanics are statistically associated with winning.

Uses Fisher's exact test for binary features and Mann-Whitney U for
continuous features. Benjamini-Hochberg correction for multiple testing.
"""
import json, sys
from pathlib import Path
from collections import defaultdict
from scipy import stats
import numpy as np

STEPS_PER_DAY = 24

def detect_seat(steps):
    """Detect which player we are from step-0 market orders.
    Our arsgorynich/V39 base does BUY_PRODUCT WHEAT 13 + BUY_PRODUCT WHEAT 30 + SELL WHEAT at step 0.
    If P0's step-0 action matches, we're P0. Otherwise P1."""
    try:
        # Check step 1 observation — both players' money after step 0
        obs = steps[1][0].get("observation", {})
        farms = obs.get("farms", [{}, {}])
        m0 = float(farms[0].get("money", 0))
        m1 = float(farms[1].get("money", 0))
        
        # Also check step 0 actions
        a0 = steps[0][0].get("action", {})
        a1 = steps[0][1].get("action", {})
        
        # Our V39 base opening: BUY 13 + BUY 30 + SELL 30 wheat
        # After step 0, our money should be very low (spent on wheat buys)
        # Check market orders for our distinctive pattern
        def has_v39_opening(action):
            market = action.get("market", []) if isinstance(action, dict) else []
            if not market or len(market) < 2:
                return False
            buys = [o for o in market if isinstance(o, (list, tuple)) and len(o) >= 3 and o[0] == "BUY_PRODUCT" and o[1] == "WHEAT"]
            return len(buys) >= 2
        
        if has_v39_opening(a0) and not has_v39_opening(a1):
            return 0
        elif has_v39_opening(a1) and not has_v39_opening(a0):
            return 1
        
        # Fallback: check if both have same opening (mirror) or use money
        # In V39, step-1 money is typically very low ($1-$30)
        if m0 < 50 and m1 > 100:
            return 0
        elif m1 < 50 and m0 > 100:
            return 1
        
        # If both low (mirror), default to 0 (coin flip anyway)
        return 0
    except Exception:
        return 0


def extract_features(steps, our_seat):
    """Extract mechanic features from a single game replay."""
    opp_seat = 1 - our_seat
    final = steps[-1]
    our_reward = final[our_seat].get("reward", 0) or 0
    opp_reward = final[opp_seat].get("reward", 0) or 0
    won = our_reward > opp_reward
    
    features = {"won": won, "margin": our_reward - opp_reward}
    
    # Extract per-day sell counts by item for both players
    # We track by reading money changes and market actions
    our_sells = defaultdict(int)
    opp_sells = defaultdict(int)
    our_buys = defaultdict(int)
    opp_buys = defaultdict(int)
    our_hires = 0
    opp_hires = 0
    
    for step_idx in range(min(720, len(steps))):
        step_data = steps[step_idx]
        day = step_idx // STEPS_PER_DAY
        
        for seat, sells_dict, buys_dict in [(our_seat, our_sells, our_buys), 
                                              (opp_seat, opp_sells, opp_buys)]:
            action = step_data[seat].get("action", {})
            if not isinstance(action, dict):
                continue
            market = action.get("market", [])
            if not isinstance(market, list):
                continue
            for order in market:
                if not isinstance(order, (list, tuple)) or len(order) < 1:
                    continue
                op = order[0]
                if op == "SELL" and len(order) >= 3:
                    item = order[1]
                    qty = max(0, int(order[2]))
                    sells_dict[f"{item}_d{day//5*5}-{day//5*5+4}"] += qty
                    sells_dict[f"{item}_total"] += qty
                elif op == "BUY_PRODUCT" and len(order) >= 3:
                    item = order[1]
                    qty = max(0, int(order[2]))
                    buys_dict[f"{item}_total"] += qty
                elif op == "HIRE":
                    if seat == our_seat:
                        our_hires += 1
                    else:
                        opp_hires += 1
    
    # Mechanic features: DIFFERENCE between us and opponent
    all_items = set(list(our_sells.keys()) + list(opp_sells.keys()))
    for key in all_items:
        features[f"sell_gap_{key}"] = our_sells.get(key, 0) - opp_sells.get(key, 0)
    
    features["hire_gap"] = our_hires - opp_hires
    features["buy_WHEAT_gap"] = our_buys.get("WHEAT_total", 0) - opp_buys.get("WHEAT_total", 0)
    features["buy_FERTILIZER_gap"] = our_buys.get("FERTILIZER_total", 0) - opp_buys.get("FERTILIZER_total", 0)
    
    # Animal counts at day 15
    try:
        obs = steps[360][0].get("observation", {})
        farms = obs.get("farms", [{}, {}])
        for seat_idx, prefix in [(our_seat, "our"), (opp_seat, "opp")]:
            tiles = farms[seat_idx].get("tiles", [])
            animals = defaultdict(int)
            for row in tiles:
                for tile in row:
                    if isinstance(tile, dict) and "animal" in tile:
                        animals[tile["animal"]] += 1
            for animal in ["GOOSE", "COW", "SHEEP"]:
                features[f"{prefix}_animal_{animal}_d15"] = animals.get(animal, 0)
        
        for animal in ["GOOSE", "COW", "SHEEP"]:
            features[f"animal_gap_{animal}_d15"] = features.get(f"our_animal_{animal}_d15", 0) - features.get(f"opp_animal_{animal}_d15", 0)
    except Exception:
        pass
    
    # Day 6 money gap (mirror detection)
    try:
        obs6 = steps[144][0].get("observation", {})
        farms6 = obs6.get("farms", [{}, {}])
        our_m6 = float(farms6[our_seat].get("money", 0))
        opp_m6 = float(farms6[opp_seat].get("money", 0))
        features["d6_money_gap"] = our_m6 - opp_m6
        features["is_mirror"] = abs(our_m6 - opp_m6) < 5
    except Exception:
        features["is_mirror"] = False
    
    # Endgame sells (days 27-29)
    for item in ["WHEAT", "FERTILIZER", "CARROT", "STRAWBERRY", "WOOL", "MILK", "EGG", "MELON", "TOMATO"]:
        our_late = sum(our_sells.get(f"{item}_d{d}-{d+4}", 0) for d in [25])
        opp_late = sum(opp_sells.get(f"{item}_d{d}-{d+4}", 0) for d in [25])
        features[f"late_sell_gap_{item}"] = our_late - opp_late
    
    # FEED count days 25-29 (sheep death mechanic)
    our_feeds_late = 0
    opp_feeds_late = 0
    for step_idx in range(600, min(720, len(steps))):
        for seat, counter_name in [(our_seat, "our"), (opp_seat, "opp")]:
            action = steps[step_idx][seat].get("action", {})
            if not isinstance(action, dict):
                continue
            cmds = [action.get("farmer", ["PASS"])] + list(action.get("hands", []))
            for cmd in cmds:
                if isinstance(cmd, (list, tuple)) and cmd and cmd[0] == "FEED":
                    if counter_name == "our":
                        our_feeds_late += 1
                    else:
                        opp_feeds_late += 1
    features["late_feed_gap"] = our_feeds_late - opp_feeds_late
    features["our_late_feeds"] = our_feeds_late
    features["opp_late_feeds"] = opp_feeds_late
    
    # Shops
    try:
        obs144 = steps[144][0].get("observation", {})
        features["shops"] = tuple(obs144.get("town", {}).get("unlocked_shops", [])[:2])
    except Exception:
        features["shops"] = ()
    
    return features


def run_fisher(games, feature_name, threshold=0):
    """Run Fisher's exact test: is feature > threshold associated with winning?"""
    a = b = c = d = 0  # a=win+present, b=win+absent, c=loss+present, d=loss+absent
    for g in games:
        val = g.get(feature_name, 0)
        won = g["won"]
        present = val > threshold
        if won and present: a += 1
        elif won and not present: b += 1
        elif not won and present: c += 1
        else: d += 1
    
    table = [[a, b], [c, d]]
    try:
        odds, p = stats.fisher_exact(table, alternative="two-sided")
    except Exception:
        odds, p = 1.0, 1.0
    
    return {"table": table, "odds_ratio": odds, "p_value": p, 
            "n_present": a + c, "n_absent": b + d,
            "win_rate_present": a / (a + c) if (a + c) > 0 else 0,
            "win_rate_absent": b / (b + d) if (b + d) > 0 else 0}


def run_mannwhitney(games, feature_name):
    """Mann-Whitney U test: is feature value different between wins and losses?"""
    wins = [g[feature_name] for g in games if g["won"] and feature_name in g]
    losses = [g[feature_name] for g in games if not g["won"] and feature_name in g]
    
    if len(wins) < 3 or len(losses) < 3:
        return None
    
    try:
        stat, p = stats.mannwhitneyu(wins, losses, alternative="two-sided")
    except Exception:
        return None
    
    return {"p_value": p, "win_mean": np.mean(wins), "loss_mean": np.mean(losses),
            "win_median": np.median(wins), "loss_median": np.median(losses),
            "effect": np.mean(wins) - np.mean(losses), "n_wins": len(wins), "n_losses": len(losses)}


def benjamini_hochberg(p_values, alpha=0.1):
    """BH correction for multiple testing. Returns which are significant."""
    n = len(p_values)
    sorted_idx = np.argsort(p_values)
    significant = [False] * n
    for rank, idx in enumerate(sorted_idx, 1):
        if p_values[idx] <= alpha * rank / n:
            significant[idx] = True
        else:
            break
    return significant


def main():
    replay_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("autoloop/replays/pipe25a_lb")
    
    print(f"Loading replays from {replay_dir}...")
    files = sorted(replay_dir.glob("*.json"))
    files = [f for f in files if f.stat().st_size > 1000]
    print(f"Found {len(files)} replay files")
    
    # Extract features from all games
    games = []
    seat_checks = {}  # for validation
    for f in files:
        try:
            data = json.loads(f.read_text())
            steps = data["steps"]
            seat = detect_seat(steps)
            features = extract_features(steps, seat)
            features["episode"] = f.stem
            features["seat"] = seat
            games.append(features)
        except Exception as e:
            print(f"  Skip {f.stem}: {e}")
    
    wins = sum(1 for g in games if g["won"])
    losses = len(games) - wins
    mirrors = sum(1 for g in games if g.get("is_mirror", False))
    
    print(f"\n{'='*70}")
    print(f"  STEP 1: Feature Extraction ({len(games)} games)")
    print(f"{'='*70}")
    print(f"  Record: {wins}W-{losses}L ({wins/len(games)*100:.1f}% win rate)")
    print(f"  Mirrors: {mirrors} ({mirrors/len(games)*100:.0f}%)")
    
    # Print 3 sample games for validation
    print(f"\n  Sample games for validation:")
    for g in games[:3]:
        print(f"    {g['episode']}: seat=P{g['seat']} won={g['won']} margin={g['margin']:+,.0f} mirror={g.get('is_mirror')} shops={g.get('shops')}")
        print(f"      sell_gap_WHEAT_total={g.get('sell_gap_WHEAT_total',0):+.0f} sell_gap_FERTILIZER_total={g.get('sell_gap_FERTILIZER_total',0):+.0f}")
        print(f"      late_feed_gap={g.get('late_feed_gap',0):+.0f} hire_gap={g.get('hire_gap',0):+.0f}")
    
    # STEP 2: Statistical testing
    print(f"\n{'='*70}")
    print(f"  STEP 2: Statistical Testing (Mann-Whitney U)")
    print(f"{'='*70}")
    
    # Non-mirror games only (mirrors are coin flips, not mechanics)
    non_mirror = [g for g in games if not g.get("is_mirror", False)]
    print(f"  Testing on {len(non_mirror)} non-mirror games ({sum(1 for g in non_mirror if g['won'])}W-{sum(1 for g in non_mirror if not g['won'])}L)")
    
    # Collect all numeric features
    feature_names = set()
    for g in non_mirror:
        for k, v in g.items():
            if isinstance(v, (int, float)) and k not in ("won", "margin", "seat", "is_mirror"):
                feature_names.add(k)
    
    # Run Mann-Whitney on each feature
    results = []
    for feat in sorted(feature_names):
        mw = run_mannwhitney(non_mirror, feat)
        if mw and mw["p_value"] < 0.2:  # Pre-filter for reporting
            results.append((feat, mw))
    
    # BH correction
    p_values = np.array([r[1]["p_value"] for r in results])
    significant = benjamini_hochberg(p_values, alpha=0.1)
    
    print(f"\n  {'Feature':<40} {'p-value':>8} {'Sig':>4} {'Win Mean':>10} {'Loss Mean':>10} {'Effect':>10}")
    print(f"  {'-'*86}")
    
    for i, (feat, mw) in enumerate(sorted(results, key=lambda x: x[1]["p_value"])):
        sig = "***" if significant[i] else ""
        print(f"  {feat:<40} {mw['p_value']:>8.4f} {sig:>4} {mw['win_mean']:>+10.1f} {mw['loss_mean']:>+10.1f} {mw['effect']:>+10.1f}")
    
    # STEP 3: Net benefit estimation for significant features
    sig_features = [(feat, mw) for i, (feat, mw) in enumerate(results) if significant[i]]
    
    if sig_features:
        print(f"\n{'='*70}")
        print(f"  STEP 3: Net Benefit Estimation ({len(sig_features)} significant mechanics)")
        print(f"{'='*70}")
        
        for feat, mw in sig_features:
            direction = "higher" if mw["effect"] > 0 else "lower"
            print(f"\n  {feat}:")
            print(f"    Winners have {direction} values (effect={mw['effect']:+.1f})")
            print(f"    Win mean={mw['win_mean']:+.1f}, Loss mean={mw['loss_mean']:+.1f}")
            print(f"    p={mw['p_value']:.4f}, n={mw['n_wins']}W/{mw['n_losses']}L")
            
            # Show specific games where this feature is extreme
            threshold = mw["loss_mean"]  # Games where we're at "loss level" 
            at_risk = [g for g in non_mirror if not g["won"] and feat in g and 
                       ((mw["effect"] > 0 and g[feat] < threshold) or 
                        (mw["effect"] < 0 and g[feat] > threshold))]
            print(f"    Losses at 'bad' level: {len(at_risk)}/{sum(1 for g in non_mirror if not g['won'])}")
    
    print(f"\n{'='*70}")
    print(f"  SANITY CHECK: Sheep death mechanic")
    print(f"{'='*70}")
    mw_feed = run_mannwhitney(non_mirror, "late_feed_gap")
    if mw_feed:
        print(f"  late_feed_gap: p={mw_feed['p_value']:.4f} win_mean={mw_feed['win_mean']:+.1f} loss_mean={mw_feed['loss_mean']:+.1f}")
        print(f"  (Positive = we feed more than opponent in late game)")
        print(f"  {'PASS' if mw_feed['p_value'] < 0.1 or mw_feed['effect'] > 0 else 'INVESTIGATE'}: sheep death already fixed, expect positive effect")
    
    print(f"\nDone.")


if __name__ == "__main__":
    main()
