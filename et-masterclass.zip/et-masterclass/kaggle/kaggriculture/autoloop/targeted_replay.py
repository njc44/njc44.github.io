#!/usr/bin/env python3
"""Targeted Replay Validator: Fast pre-screen for fix candidates.

Loads losing replay metadata from mechanism_traces.json, identifies which
opponents we have agent code for locally, and runs candidate vs baseline
against those specific opponents to measure improvement.

Opponent matching strategy (in priority order):
  1. Manual mapping file: autoloop/corpus/opponent_agent_map.json
     Format: {"Display Name": "agent_dir_name", ...}
  2. Fuzzy name matching: normalize display name and compare to username
     portion of agent dirs (works when display name == username)
  3. --use-all-agents: Skip trace matching entirely. Test candidate vs
     baseline against ALL local agents in autoloop/agents/.

This is a fast pre-screen (~N opponents x 10 games x 2 agents) before
committing to a full 200-game colosseum run.

Usage:
    # Trace-based (test only against opponents we lost to):
    python -m autoloop.targeted_replay \\
        --candidate main_fixed.py \\
        --baseline  autoloop/agents/_candidate/main.py

    # All agents (comprehensive pre-screen):
    python -m autoloop.targeted_replay \\
        --candidate main_fixed.py \\
        --baseline  autoloop/agents/_candidate/main.py \\
        --use-all-agents

    # Quick sanity check (fewer games):
    python -m autoloop.targeted_replay \\
        --candidate main_fixed.py \\
        --baseline  autoloop/agents/_candidate/main.py \\
        --use-all-agents --games-per-opponent 4
"""
import argparse
import json
import math
import os
import re
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"
TRACES_FILE = CORPUS_DIR / "mechanism_traces.json"
OPPONENT_MAP_FILE = CORPUS_DIR / "opponent_agent_map.json"


# ── Utility functions ─────────────────────────────────────────

def wilson_ci(wins, total, z=1.96):
    """Wilson score confidence interval for win rate."""
    if total == 0:
        return (0.0, 0.0)
    p = wins / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    spread = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denom
    return (max(0, center - spread), min(1, center + spread))


def _normal_cdf(x):
    """Approximation of the standard normal CDF."""
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def binomial_significance(wins, losses, ties):
    """Test if win rate is significantly different from 50%.

    Uses Elo-correct scoring: ties count as 0.5.
    Returns: (elo_rate, p_value, is_significant_at_05)
    """
    total = wins + losses + ties
    if total == 0:
        return 0.5, 1.0, False

    elo_points = wins + 0.5 * ties
    elo_rate = elo_points / total

    se = math.sqrt(0.25 / total)
    if se == 0:
        return elo_rate, 1.0, False

    z = (elo_rate - 0.5) / se
    p_value = 2 * (1 - _normal_cdf(abs(z)))

    return round(elo_rate, 4), round(p_value, 4), p_value < 0.05


# ── Opponent matching ─────────────────────────────────────────

def _normalize_name(name):
    """Normalize a display name for fuzzy matching.

    Strips spaces, punctuation, lowercases. E.g.:
        "Rayk Kretzschmar" -> "raykkretzschmar"
        "Vanshika #2"      -> "vanshika2"
    """
    name = name.lower()
    name = re.sub(r"[^a-z0-9]", "", name)
    return name


def _load_manual_map():
    """Load manual display-name -> agent-dir mapping if it exists.

    File format: {"Display Name": "agent_dir_name", ...}
    where agent_dir_name is the directory under autoloop/agents/.
    """
    if not OPPONENT_MAP_FILE.exists():
        return {}

    try:
        with open(OPPONENT_MAP_FILE) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def get_all_local_agents():
    """Get all local agent directories (excluding our own candidates).

    Returns: dict[agent_dir_name] -> path to main.py
    """
    agents = {}
    if not AGENTS_DIR.exists():
        return agents

    for agent_dir in AGENTS_DIR.iterdir():
        if not agent_dir.is_dir():
            continue

        main_py = agent_dir / "main.py"
        if not main_py.exists():
            continue

        dir_name = agent_dir.name

        # Skip our own candidate agents (any dir starting with _)
        if dir_name.startswith("_"):
            continue

        agents[dir_name] = str(main_py)

    return agents


def build_opponent_map():
    """Build a mapping from normalized opponent display names to agent paths.

    Uses both manual mapping and fuzzy name matching.
    Returns: dict[normalized_display_name] -> path to main.py
    """
    all_agents = get_all_local_agents()
    opponent_map = {}

    # Layer 1: Manual mapping (display name -> agent dir name)
    manual = _load_manual_map()
    for display_name, agent_dir_name in manual.items():
        if agent_dir_name in all_agents:
            normalized = _normalize_name(display_name)
            if normalized:
                opponent_map[normalized] = all_agents[agent_dir_name]

    # Layer 2: Fuzzy matching on username portion of agent dir
    for dir_name, path in all_agents.items():
        if "__" in dir_name:
            username = dir_name.split("__")[0]
        else:
            username = dir_name

        normalized = _normalize_name(username)
        if normalized and normalized not in opponent_map:
            opponent_map[normalized] = path

    return opponent_map


def match_opponents(traces, opponent_map):
    """Match trace opponent display names to local agent paths.

    Returns:
        matched: dict[opponent_name] -> (agent_path, [traces])
        unmatched: dict[opponent_name] -> [traces]
    """
    matched = {}
    unmatched = {}

    for trace in traces:
        opp_name = trace.get("opponent", "")
        normalized = _normalize_name(opp_name)

        if normalized in opponent_map:
            if opp_name not in matched:
                matched[opp_name] = (opponent_map[normalized], [])
            matched[opp_name][1].append(trace)
        else:
            if opp_name not in unmatched:
                unmatched[opp_name] = []
            unmatched[opp_name].append(trace)

    return matched, unmatched


# ── Game execution (module-level for pickling) ────────────────

def _run_single_game(agent_a_path, agent_b_path, seat, game_idx):
    """Run one game. Module-level function for ProcessPoolExecutor.

    Args:
        agent_a_path: Path to "our" agent (candidate or baseline).
        agent_b_path: Path to opponent agent.
        seat: 0 = our agent is player 0, 1 = our agent is player 1.
        game_idx: Index of this game (for reporting).

    Returns: dict with game result or error info.
    """
    os.chdir(str(WORK_DIR))

    if seat == 0:
        p0, p1 = agent_a_path, agent_b_path
    else:
        p0, p1 = agent_b_path, agent_a_path

    game_start = time.time()
    try:
        from kaggle_environments import make
        env = make("kaggriculture")
        result = env.run([p0, p1])
        elapsed = time.time() - game_start

        final = result[-1]
        r0, r1 = final[0]["reward"], final[1]["reward"]
        s0, s1 = final[0]["status"], final[1]["status"]

        if s0 != "DONE" or s1 != "DONE":
            return {
                "game": game_idx, "seat": seat, "elapsed": round(elapsed, 1),
                "error": f"Non-DONE status: {s0}, {s1}",
            }

        score_a = r0 if seat == 0 else r1
        score_b = r1 if seat == 0 else r0
        margin = score_a - score_b

        return {
            "game": game_idx,
            "seat": seat,
            "score_a": score_a,
            "score_b": score_b,
            "margin": margin,
            "result": "WIN" if margin > 0 else ("LOSE" if margin < 0 else "TIE"),
            "elapsed": round(elapsed, 1),
        }

    except Exception as e:
        elapsed = time.time() - game_start
        return {
            "game": game_idx, "seat": seat, "elapsed": round(elapsed, 1),
            "error": str(e),
        }


def run_matchup(agent_path, opponent_path, games_per_opponent, parallel):
    """Run agent vs one opponent for N games (split across seats).

    Returns: dict with W/L/T and game details.
    """
    games_per_seat = games_per_opponent // 2
    remainder = games_per_opponent % 2

    tasks = []
    for i in range(games_per_opponent):
        seat = 0 if i < (games_per_seat + remainder) else 1
        tasks.append((agent_path, opponent_path, seat, i))

    games = []
    errors = []

    with ProcessPoolExecutor(max_workers=parallel) as executor:
        futures = {
            executor.submit(_run_single_game, *task): task
            for task in tasks
        }
        for future in as_completed(futures):
            result = future.result()
            if "error" in result:
                errors.append(result)
            else:
                games.append(result)

    wins = sum(1 for g in games if g["result"] == "WIN")
    losses = sum(1 for g in games if g["result"] == "LOSE")
    ties = sum(1 for g in games if g["result"] == "TIE")

    return {
        "wins": wins,
        "losses": losses,
        "ties": ties,
        "total_played": wins + losses + ties,
        "errors": len(errors),
        "games": sorted(games, key=lambda g: g["game"]),
        "error_details": errors,
    }


# ── Main orchestration ────────────────────────────────────────

def load_traces():
    """Load mechanism traces from corpus."""
    if not TRACES_FILE.exists():
        print(f"ERROR: {TRACES_FILE} not found")
        sys.exit(1)

    with open(TRACES_FILE) as f:
        traces = json.load(f)

    return traces


def run_targeted_replay(candidate_path, baseline_path, games_per_opponent,
                        parallel, use_all_agents=False,
                        anti_targets=None, anti_target_threshold=0.80):
    """Run the full targeted replay validation.

    Two modes:
    - Trace-based (default): Only test against opponents from mechanism_traces.json
      that we can match to local agents.
    - All-agents (--use-all-agents): Test against every local agent in agents/.
      Faster to get signal when trace matching yields few opponents.

    Args:
        anti_targets: list of (name, path) tuples for agents we currently dominate.
            After main matchups, candidate is tested against each anti-target.
            If elo_rate falls below anti_target_threshold, a regression warning is issued.
        anti_target_threshold: minimum elo_rate vs anti-targets (default 0.80).

    Returns: full results dict (includes 'regressions' list if anti_targets provided).
    """
    print(f"\n{'='*70}")
    print(f"  TARGETED REPLAY VALIDATOR")
    print(f"  Candidate: {candidate_path}")
    print(f"  Baseline:  {baseline_path}")
    print(f"  Games per opponent: {games_per_opponent}")
    print(f"  Parallel workers: {parallel}")
    print(f"  Mode: {'all-agents' if use_all_agents else 'trace-matched'}")
    print(f"{'='*70}")

    if use_all_agents:
        # Test against ALL local agents
        all_agents = get_all_local_agents()
        print(f"\n  Local agents available: {len(all_agents)}")

        if not all_agents:
            print("  No local agents found in autoloop/agents/.")
            return None

        # Build matchup list: each agent dir -> (path, trace_context)
        # trace_context is empty since we're not matching to specific traces
        matchup_list = {
            dir_name: (path, [])
            for dir_name, path in sorted(all_agents.items())
        }
        unmatched = {}
    else:
        # Trace-based matching
        traces = load_traces()
        opponent_map = build_opponent_map()

        print(f"\n  Traces loaded: {len(traces)} losses")
        print(f"  Local agents:  {len(get_all_local_agents())} available")

        matched, unmatched = match_opponents(traces, opponent_map)

        print(f"\n  Matched opponents: {len(matched)}")
        for name, (path, opp_traces) in sorted(matched.items()):
            print(f"    {name} ({len(opp_traces)} losses) "
                  f"-> {Path(path).parent.name}")

        if unmatched:
            print(f"\n  Unmatched opponents: {len(unmatched)}")
            for name, opp_traces in sorted(unmatched.items()):
                print(f"    {name} ({len(opp_traces)} losses) -- no local agent")
            print(f"\n  TIP: Create {OPPONENT_MAP_FILE.name} to map display "
                  f"names to agent dirs.")
            print(f"  Format: {{\"Display Name\": \"agent_dir_name\", ...}}")

        if not matched:
            print("\n  No opponents matched. Consider --use-all-agents mode.")
            return None

        matchup_list = matched

    # Run games
    total_games = len(matchup_list) * games_per_opponent * 2
    print(f"\n  Total games to run: {total_games} "
          f"({len(matchup_list)} opponents x {games_per_opponent} games x 2 agents)")
    print(f"  Estimated time: ~{total_games * 0.3 / parallel:.0f}s at {parallel} workers")
    print()

    results = {}
    overall_start = time.time()

    for opp_label, (opp_path, opp_traces) in sorted(matchup_list.items()):
        agent_dir_name = Path(opp_path).parent.name
        trace_info = f", {len(opp_traces)} traced losses" if opp_traces else ""
        print(f"  --- vs {opp_label} ({agent_dir_name}{trace_info}) ---",
              flush=True)

        # Candidate vs opponent
        t0 = time.time()
        cand_result = run_matchup(
            str(candidate_path), opp_path, games_per_opponent, parallel
        )
        cand_time = time.time() - t0
        print(f"    Candidate: {cand_result['wins']}W-{cand_result['losses']}L-"
              f"{cand_result['ties']}T ({cand_result['errors']} err) "
              f"[{cand_time:.0f}s]", flush=True)

        # Baseline vs opponent
        t0 = time.time()
        base_result = run_matchup(
            str(baseline_path), opp_path, games_per_opponent, parallel
        )
        base_time = time.time() - t0
        print(f"    Baseline:  {base_result['wins']}W-{base_result['losses']}L-"
              f"{base_result['ties']}T ({base_result['errors']} err) "
              f"[{base_time:.0f}s]", flush=True)

        # Compute deltas
        cand_elo_pts = cand_result["wins"] + 0.5 * cand_result["ties"]
        base_elo_pts = base_result["wins"] + 0.5 * base_result["ties"]
        cand_total = cand_result["total_played"]
        base_total = base_result["total_played"]
        cand_rate = cand_elo_pts / cand_total if cand_total else 0
        base_rate = base_elo_pts / base_total if base_total else 0
        delta = cand_rate - base_rate

        verdict = ("IMPROVED" if delta > 0.05
                   else ("REGRESSED" if delta < -0.05 else "NEUTRAL"))
        print(f"    Delta: {delta:+.3f} elo-rate ({verdict})")
        print()

        results[opp_label] = {
            "agent_dir": agent_dir_name,
            "agent_path": opp_path,
            "loss_count": len(opp_traces),
            "loss_margins": [t["margin"] for t in opp_traces],
            "primary_mechanisms": [
                t.get("primary_mechanism", "") for t in opp_traces
            ],
            "candidate": cand_result,
            "baseline": base_result,
            "candidate_elo_rate": round(cand_rate, 4),
            "baseline_elo_rate": round(base_rate, 4),
            "delta_elo_rate": round(delta, 4),
            "verdict": verdict,
        }

    # Anti-target regression check
    regressions = []
    if anti_targets:
        print(f"  --- Anti-target regression check (threshold={anti_target_threshold:.0%}) ---")
        for at_name, at_path in anti_targets:
            t0 = time.time()
            at_result = run_matchup(
                str(candidate_path), str(at_path), games_per_opponent, parallel
            )
            at_time = time.time() - t0

            at_elo_pts = at_result["wins"] + 0.5 * at_result["ties"]
            at_total = at_result["total_played"]
            at_rate = at_elo_pts / at_total if at_total else 0

            status = "OK" if at_rate >= anti_target_threshold else "REGRESSION"
            print(f"    vs {at_name}: {at_result['wins']}W-{at_result['losses']}L-"
                  f"{at_result['ties']}T  elo_rate={at_rate:.2f}  "
                  f"[{at_time:.0f}s]  {status}", flush=True)

            if at_rate < anti_target_threshold:
                regression_entry = {
                    "anti_target": at_name,
                    "anti_target_path": str(at_path),
                    "elo_rate": round(at_rate, 4),
                    "threshold": anti_target_threshold,
                    "result": at_result,
                }
                regressions.append(regression_entry)
                print(f"    WARNING: Candidate elo_rate {at_rate:.2f} vs {at_name} "
                      f"is below threshold {anti_target_threshold:.2f}")

        if not regressions:
            print(f"    All anti-targets passed.\n")
        else:
            print(f"    {len(regressions)} regression(s) detected.\n")

    total_elapsed = time.time() - overall_start

    # Aggregate
    agg = _aggregate_results(results)

    # Print summary
    _print_summary(results, agg, candidate_path, baseline_path,
                   games_per_opponent, total_elapsed,
                   use_all_agents, len(unmatched))

    return {
        "candidate": str(candidate_path),
        "baseline": str(baseline_path),
        "games_per_opponent": games_per_opponent,
        "parallel": parallel,
        "mode": "all-agents" if use_all_agents else "trace-matched",
        "total_elapsed": round(total_elapsed, 1),
        "opponents_tested": len(results),
        "opponents_unmatched": len(unmatched),
        "per_opponent": results,
        "aggregate": agg,
        "regressions": regressions,
        "timestamp": datetime.now().isoformat(),
    }


def _aggregate_results(results):
    """Compute aggregate stats across all opponents."""
    cand_w, cand_l, cand_t = 0, 0, 0
    base_w, base_l, base_t = 0, 0, 0
    improved, regressed, neutral = 0, 0, 0

    for opp_name, r in results.items():
        cand_w += r["candidate"]["wins"]
        cand_l += r["candidate"]["losses"]
        cand_t += r["candidate"]["ties"]
        base_w += r["baseline"]["wins"]
        base_l += r["baseline"]["losses"]
        base_t += r["baseline"]["ties"]

        if r["verdict"] == "IMPROVED":
            improved += 1
        elif r["verdict"] == "REGRESSED":
            regressed += 1
        else:
            neutral += 1

    cand_elo_rate, cand_p, cand_sig = binomial_significance(
        cand_w, cand_l, cand_t)
    base_elo_rate, base_p, base_sig = binomial_significance(
        base_w, base_l, base_t)

    return {
        "candidate_total": {
            "wins": cand_w, "losses": cand_l, "ties": cand_t},
        "baseline_total": {
            "wins": base_w, "losses": base_l, "ties": base_t},
        "candidate_elo_rate": cand_elo_rate,
        "candidate_p_value": cand_p,
        "candidate_significant": cand_sig,
        "baseline_elo_rate": base_elo_rate,
        "baseline_p_value": base_p,
        "baseline_significant": base_sig,
        "delta_elo_rate": round(cand_elo_rate - base_elo_rate, 4),
        "opponents_improved": improved,
        "opponents_regressed": regressed,
        "opponents_neutral": neutral,
    }


def _print_summary(results, agg, candidate_path, baseline_path,
                    games_per_opponent, elapsed, use_all_agents,
                    unmatched_count):
    """Print the final summary report."""
    print(f"\n{'#'*70}")
    print(f"  TARGETED REPLAY SUMMARY")
    print(f"{'#'*70}")
    print(f"  Candidate: {candidate_path}")
    print(f"  Baseline:  {baseline_path}")
    mode_label = "all-agents" if use_all_agents else "trace-matched"
    print(f"  Mode: {mode_label}")
    print(f"  Opponents tested: {len(results)} "
          f"({games_per_opponent} games each)")
    if not use_all_agents and unmatched_count > 0:
        print(f"  Opponents unmatched: {unmatched_count}")
    print(f"  Total time: {elapsed:.0f}s")

    ct = agg["candidate_total"]
    bt = agg["baseline_total"]

    print(f"\n  CANDIDATE overall: "
          f"{ct['wins']}W-{ct['losses']}L-{ct['ties']}T")
    sig_c = "***" if agg["candidate_significant"] else "(ns)"
    print(f"    Elo rate: {agg['candidate_elo_rate']*100:.1f}% "
          f"(p={agg['candidate_p_value']:.3f}) {sig_c}")

    print(f"\n  BASELINE overall:  "
          f"{bt['wins']}W-{bt['losses']}L-{bt['ties']}T")
    sig_b = "***" if agg["baseline_significant"] else "(ns)"
    print(f"    Elo rate: {agg['baseline_elo_rate']*100:.1f}% "
          f"(p={agg['baseline_p_value']:.3f}) {sig_b}")

    delta = agg["delta_elo_rate"]
    direction = "BETTER" if delta > 0 else ("WORSE" if delta < 0 else "SAME")
    print(f"\n  DELTA: {delta:+.4f} elo-rate ({direction})")
    print(f"  Opponents improved:  {agg['opponents_improved']}")
    print(f"  Opponents regressed: {agg['opponents_regressed']}")
    print(f"  Opponents neutral:   {agg['opponents_neutral']}")

    # Per-opponent table
    print(f"\n  {'Opponent':<40s} {'CandW/L/T':>10s} {'BaseW/L/T':>10s} "
          f"{'CandElo':>8s} {'BaseElo':>8s} {'Delta':>8s} {'Verdict':>10s}")
    print(f"  {'-'*38:40s} {'-'*10:>10s} {'-'*10:>10s} "
          f"{'-'*8:>8s} {'-'*8:>8s} {'-'*8:>8s} {'-'*10:>10s}")

    for opp_name in sorted(results.keys()):
        r = results[opp_name]
        c = r["candidate"]
        b = r["baseline"]
        cw = f"{c['wins']}/{c['losses']}/{c['ties']}"
        bw = f"{b['wins']}/{b['losses']}/{b['ties']}"
        name_trunc = opp_name[:38]
        print(f"  {name_trunc:<40s} {cw:>10s} {bw:>10s} "
              f"{r['candidate_elo_rate']:>7.1%} "
              f"{r['baseline_elo_rate']:>7.1%} "
              f"{r['delta_elo_rate']:>+7.3f} {r['verdict']:>10s}")

    # Gate decision
    print(f"\n  {'='*70}")
    if delta > 0.03:
        print(f"  GATE: PASS -- Candidate shows improvement on "
              f"loss-causing opponents.")
        print(f"  Recommendation: Proceed to full colosseum run.")
    elif delta < -0.03:
        print(f"  GATE: FAIL -- Candidate performs WORSE on "
              f"loss-causing opponents.")
        print(f"  Recommendation: Do NOT proceed. Fix regressed "
              f"matchups first.")
    else:
        print(f"  GATE: INCONCLUSIVE -- Delta too small to judge "
              f"from targeted replay.")
        print(f"  Recommendation: Run full colosseum if other "
              f"signals are positive.")
    print(f"{'#'*70}\n")


# ── CLI ───────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Targeted Replay Validator: fast pre-screen for "
                    "fix candidates.")
    parser.add_argument(
        "--candidate", required=True,
        help="Path to candidate agent (modified main.py)")
    parser.add_argument(
        "--baseline", required=True,
        help="Path to baseline agent")
    parser.add_argument(
        "--games-per-opponent", type=int, default=10,
        help="Games per opponent (split across seats, default 10)")
    parser.add_argument(
        "--parallel", type=int, default=10,
        help="Max parallel workers (default 10)")
    parser.add_argument(
        "--use-all-agents", action="store_true",
        help="Test against ALL local agents instead of only trace-matched "
             "opponents. Useful when display-name-to-username matching "
             "yields few results.")
    parser.add_argument(
        "--output", type=str,
        help="Save full results to JSON file")

    args = parser.parse_args()

    candidate = Path(args.candidate).resolve()
    baseline = Path(args.baseline).resolve()

    if not candidate.exists():
        print(f"ERROR: Candidate not found: {candidate}")
        sys.exit(1)
    if not baseline.exists():
        print(f"ERROR: Baseline not found: {baseline}")
        sys.exit(1)

    os.chdir(str(WORK_DIR))

    results = run_targeted_replay(
        candidate, baseline,
        args.games_per_opponent, args.parallel,
        use_all_agents=args.use_all_agents,
    )

    if results and args.output:
        output_path = Path(args.output)
        with open(output_path, "w") as f:
            json.dump(results, f, indent=2, default=str)
        print(f"  Results saved to: {output_path}")


if __name__ == "__main__":
    main()
