#!/usr/bin/env python3
"""Run pipe-10 and hero_from_v46 against top opponents."""

import subprocess
import json
import time
import os
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed

AGENTS_DIR = Path("autoloop/agents")
CORPUS_DIR = Path("autoloop/corpus")

OUR_AGENTS = {
    "pipe10": AGENTS_DIR / "_pipe10_v45_full/main.py",
    "hero_v46": AGENTS_DIR / "_hero_from_v46/main.py",
}

OPPONENTS = {
    "ahmed_v46": AGENTS_DIR / "ahmedberatozer__kaggriculture-v46-first-turn-microstructure-and-s/main.py",
    "ahmed_v45": AGENTS_DIR / "ahmedberatozer__kaggriculture-v45-first-turn-wheat-round-trip/main.py",
    "ahmed_v44": AGENTS_DIR / "ahmedberatozer__kaggriculture-v44-winning-the-same-turn-sale-race/main.py",
    "jaxa623": AGENTS_DIR / "jaxa623__2842-two-identical-agents-90-points-apart/main.py",
    "tetsutani": AGENTS_DIR / "tetsutani__market-smart-farming-kaggriculture/main.py",
    "alperen_v62": AGENTS_DIR / "alperen5252525__v62-metabalance-kaggriculture/main.py",
    "thomastschinkel": AGENTS_DIR / "thomastschinkel__kaggriculture-93-8-win-rate-public-state-router/main.py",
    "degnonguidi": AGENTS_DIR / "degnonguidi__kaggriculture-utils-v1/main.py",
}

# Auto-detect Ahmed's latest versions for gauntlet
for _v in ["v47", "v48", "v49", "v50"]:
    _matches = list(AGENTS_DIR.glob(f"ahmedberatozer__*{_v}*"))
    for _m in _matches:
        if (_m / "main.py").exists():
            _key = f"ahmed_{_v}"
            if _key not in OPPONENTS:
                OPPONENTS[_key] = _m / "main.py"

GAMES = 200
PARALLEL_PER_MATCH = 5  # conservative to avoid overloading with concurrent matches
MAX_CONCURRENT_MATCHES = 3


def run_match(our_name, our_path, opp_name, opp_path):
    output_file = CORPUS_DIR / f"gauntlet_{our_name}_vs_{opp_name}.json"
    if output_file.exists():
        print(f"  SKIP {our_name} vs {opp_name} (already exists)")
        with open(output_file) as f:
            return our_name, opp_name, json.load(f)

    print(f"  START {our_name} vs {opp_name} ({GAMES} games)")
    t0 = time.time()
    result = subprocess.run(
        [
            "/Users/nathanjacob/opt/miniconda3/bin/python", "autoloop/colosseum.py",
            str(our_path), str(opp_path),
            "--games", str(GAMES),
            "--parallel", str(PARALLEL_PER_MATCH),
            "--output", str(output_file),
        ],
        capture_output=True, text=True, timeout=1200,
    )
    elapsed = time.time() - t0

    if result.returncode != 0:
        print(f"  ERROR {our_name} vs {opp_name}: {result.stderr[-200:]}")
        return our_name, opp_name, {"error": result.stderr[-500:]}

    with open(output_file) as f:
        data = json.load(f)

    elo = data.get("elo_rate", "?")
    w, l, t = data["wins"], data["losses"], data["ties"]
    print(f"  DONE  {our_name} vs {opp_name}: {w}W-{l}L-{t}T  elo={elo:.1%}  ({elapsed:.0f}s)")
    return our_name, opp_name, data


def main():
    os.chdir("/Users/nathanjacob/Documents/kaggle/kaggriculture")
    CORPUS_DIR.mkdir(exist_ok=True)

    matchups = []
    for our_name, our_path in OUR_AGENTS.items():
        for opp_name, opp_path in OPPONENTS.items():
            matchups.append((our_name, our_path, opp_name, opp_path))

    print(f"Running {len(matchups)} matchups ({GAMES} games each, {MAX_CONCURRENT_MATCHES} concurrent)\n")

    results = {}
    with ProcessPoolExecutor(max_workers=MAX_CONCURRENT_MATCHES) as pool:
        futures = {
            pool.submit(run_match, *m): (m[0], m[2]) for m in matchups
        }
        for future in as_completed(futures):
            our_name, opp_name = futures[future]
            try:
                _, _, data = future.result()
                results[(our_name, opp_name)] = data
            except Exception as e:
                print(f"  EXCEPTION {our_name} vs {opp_name}: {e}")
                results[(our_name, opp_name)] = {"error": str(e)}

    # Print summary table
    print("\n" + "=" * 90)
    print("GAUNTLET SUMMARY")
    print("=" * 90)
    print(f"{'Matchup':40s} {'Record':>12s} {'Elo Rate':>10s} {'p-value':>10s} {'Cohen h':>10s}")
    print("-" * 90)

    for our_name in OUR_AGENTS:
        for opp_name in OPPONENTS:
            d = results.get((our_name, opp_name), {})
            if "error" in d:
                print(f"{our_name} vs {opp_name:20s} {'ERROR':>12s}")
                continue
            w, l, t = d["wins"], d["losses"], d["ties"]
            rec = f"{w}W-{l}L-{t}T"
            elo = f"{d['elo_rate']:.1%}"
            p = f"{d['p_value']:.4f}"
            h = f"{d['cohens_h']:.3f}"
            print(f"{our_name:8s} vs {opp_name:20s} {rec:>12s} {elo:>10s} {p:>10s} {h:>10s}")
        print()

    # Save combined report
    report = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "games_per_matchup": GAMES,
        "matchups": {},
    }
    for (our_name, opp_name), d in results.items():
        key = f"{our_name}_vs_{opp_name}"
        if "error" not in d:
            report["matchups"][key] = {
                "agent_a": our_name,
                "agent_b": opp_name,
                "wins": d["wins"], "losses": d["losses"], "ties": d["ties"],
                "elo_rate": d["elo_rate"],
                "p_value": d["p_value"],
                "cohens_h": d["cohens_h"],
                "avg_margin": d["avg_margin"],
            }
        else:
            report["matchups"][key] = {"error": d["error"]}

    report_path = CORPUS_DIR / "gauntlet_report.json"
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\nFull report saved to {report_path}")


if __name__ == "__main__":
    main()
