#!/usr/bin/env python3
"""Value Leak Diagnosis: Integrated per-world, per-step loss analysis.

Combines shop world classification + step-level money tracing to produce
actionable diagnosis: "In world X, at step Y, we lost $Z because..."

Usage:
    python value_leak_diagnosis.py <replay_dir> --seats _seats.json
    python value_leak_diagnosis.py <replay_file> --seat 1 --single
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

from shop_world_classifier import extract_shop_pair, world_id
from step_money_tracer import (trace_money_per_step, find_permanent_divergence,
                                attribute_step, find_top_leak_steps)


def diagnose_replay(replay, our_seat=0):
    """Full diagnosis for one replay: world + step-level divergence + attribution."""
    shop1, shop2 = extract_shop_pair(replay)
    wid = world_id(shop1, shop2)
    trace = trace_money_per_step(replay, our_seat)
    div_step, div_dir = find_permanent_divergence(trace["gap"])
    top_leaks = find_top_leak_steps(trace)
    rewards = replay.get("rewards", [0, 0])
    our_reward = rewards[our_seat] if rewards[our_seat] else 0
    opp_reward = rewards[1 - our_seat] if rewards[1 - our_seat] else 0
    margin = our_reward - opp_reward
    seed = replay.get("info", {}).get("seed")
    teams = replay.get("info", {}).get("TeamNames", [])
    opponent = teams[1 - our_seat] if len(teams) > 1 - our_seat else "unknown"

    result = {
        "world": wid,
        "shop1": shop1,
        "shop2": shop2,
        "seed": seed,
        "opponent": opponent,
        "our_reward": our_reward,
        "opp_reward": opp_reward,
        "margin": margin,
        "outcome": "win" if margin > 0 else "loss" if margin < 0 else "tie",
        "divergence_step": div_step,
        "divergence_day": div_step // 24 if div_step else None,
        "divergence_direction": "opp_ahead" if div_dir > 0 else "us_ahead" if div_dir < 0 else "none",
        "top_leak_steps": top_leaks[:5],
    }

    if div_step is not None:
        result["divergence_detail"] = {
            "our_action": attribute_step(replay, our_seat, div_step),
            "opp_action": attribute_step(replay, 1 - our_seat, div_step),
            "gap_at_step": trace["gap"][div_step],
        }

    # Classify the loss type
    if margin < 0:
        abs_margin = abs(margin)
        if abs_margin < 200:
            result["loss_type"] = "lockstep_mirror"
        elif abs_margin < 2000:
            result["loss_type"] = "tactical_edge"
        else:
            result["loss_type"] = "structural_difference"

        # Check if this is a mirror by checking action identity in first 100 steps
        steps = replay.get("steps", [])
        identical = sum(1 for s in steps[:100]
                        if s[0].get("action") == s[1].get("action"))
        result["mirror_pct"] = identical / min(100, len(steps))
    else:
        result["loss_type"] = "not_a_loss"
        result["mirror_pct"] = 0

    return result


def diagnose_losses(replay_dir, seats_file=None, max_games=100):
    """Batch diagnosis of all losses in a directory."""
    replay_dir = Path(replay_dir)
    seats = {}
    if seats_file:
        sp = Path(seats_file)
        if not sp.exists() and not sp.is_absolute():
            sp = replay_dir / Path(seats_file).name
        if sp.exists():
            with open(sp) as f:
                seats = json.load(f)

    diagnoses = []
    for fpath in sorted(replay_dir.glob("*.json"))[:max_games]:
        if fpath.name.startswith("_"):
            continue
        with open(fpath) as f:
            replay = json.load(f)
        ep_id = fpath.stem
        our_seat = int(seats.get(ep_id, 0))
        d = diagnose_replay(replay, our_seat)
        d["ep_id"] = ep_id
        diagnoses.append(d)

    losses = [d for d in diagnoses if d["outcome"] == "loss"]

    # Group by world
    by_world = defaultdict(list)
    for d in losses:
        by_world[d["world"]].append(d)

    # Group by loss type
    by_type = defaultdict(list)
    for d in losses:
        by_type[d["loss_type"]].append(d)

    # Find common divergence days
    div_days = [d["divergence_day"] for d in losses if d["divergence_day"] is not None]
    day_counts = defaultdict(int)
    for dd in div_days:
        day_counts[dd] += 1

    # Find common leak steps across losses
    all_leaks = defaultdict(float)
    for d in losses:
        for step, delta in d["top_leak_steps"]:
            all_leaks[step // 24] += delta  # aggregate by day

    return {
        "total_games": len(diagnoses),
        "total_losses": len(losses),
        "losses_by_world": {k: len(v) for k, v in sorted(by_world.items(), key=lambda x: -len(x[1]))},
        "losses_by_type": {k: len(v) for k, v in by_type.items()},
        "common_divergence_days": dict(sorted(day_counts.items(), key=lambda x: -x[1])),
        "leak_by_day": dict(sorted(all_leaks.items(), key=lambda x: -x[1])[:10]),
        "per_world": {k: v for k, v in by_world.items()},
        "per_type": by_type,
        "all_diagnoses": diagnoses,
    }


def format_diagnosis(d):
    """Format one game's diagnosis as human-readable text."""
    ds = d.get("divergence_step")
    ds_str = f"step {ds} (day {ds//24}, hour {ds%24})" if ds else "none"
    lines = [
        f"EP {d.get('ep_id', '?')} | World: {d['world']} | vs {d['opponent']}",
        f"  Result: ${d['our_reward']:.0f} vs ${d['opp_reward']:.0f} (margin ${d['margin']:+.0f})",
        f"  Type: {d['loss_type']} | Mirror: {d['mirror_pct']:.0%}",
        f"  Divergence: {ds_str}",
    ]
    dd = d.get("divergence_detail", {})
    if dd:
        our_a = dd.get("our_action", {})
        opp_a = dd.get("opp_action", {})
        if our_a.get("sells") or opp_a.get("sells"):
            lines.append(f"  At divergence:")
            if our_a.get("sells"):
                for s in our_a["sells"]:
                    lines.append(f"    Us: SELL {s['item']} x{s['qty']} @${s['price']}")
            if opp_a.get("sells"):
                for s in opp_a["sells"]:
                    lines.append(f"    Opp: SELL {s['item']} x{s['qty']} @${s['price']}")
    return "\n".join(lines)


def print_batch_diagnosis(results):
    """Print batch diagnosis results."""
    print(f"{'='*70}")
    print(f"VALUE LEAK DIAGNOSIS ({results['total_losses']} losses / {results['total_games']} games)")
    print(f"{'='*70}")

    print(f"\n--- Loss Type Breakdown ---")
    for ltype, count in results["losses_by_type"].items():
        print(f"  {ltype}: {count}")

    print(f"\n--- Losses by World (top 10) ---")
    for world, count in list(results["losses_by_world"].items())[:10]:
        games = results["per_world"][world]
        avg_margin = sum(g["margin"] for g in games) / len(games)
        print(f"  {world}: {count} losses, avg margin ${avg_margin:+.0f}")

    print(f"\n--- Common Divergence Days ---")
    for day, count in list(results["common_divergence_days"].items())[:10]:
        print(f"  Day {day}: {count} losses diverge here")

    print(f"\n--- Biggest Leak Days ($ gap growth) ---")
    for day, total_delta in list(results["leak_by_day"].items())[:10]:
        print(f"  Day {day}: ${total_delta:+.0f} total gap growth")

    print(f"\n{'='*70}")
    print(f"PER-LOSS DETAIL (sorted by margin)")
    print(f"{'='*70}")
    losses = [d for d in results["all_diagnoses"] if d["outcome"] == "loss"]
    for d in sorted(losses, key=lambda x: x["margin"]):
        print(f"\n{format_diagnosis(d)}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Value leak diagnosis")
    parser.add_argument("path", help="Replay file or directory")
    parser.add_argument("--seat", type=int, default=0)
    parser.add_argument("--seats", help="Path to _seats.json")
    parser.add_argument("--single", action="store_true", help="Single replay mode")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    path = Path(args.path)
    if args.single or path.is_file():
        with open(path) as f:
            replay = json.load(f)
        d = diagnose_replay(replay, args.seat)
        d["ep_id"] = path.stem
        if args.json:
            json.dump(d, sys.stdout, indent=2, default=str)
        else:
            print(format_diagnosis(d))
    else:
        results = diagnose_losses(path, seats_file=args.seats)
        if args.json:
            output = {k: v for k, v in results.items() if k != "all_diagnoses"}
            json.dump(output, sys.stdout, indent=2, default=str)
        else:
            print_batch_diagnosis(results)
