#!/usr/bin/env python3
"""Autoloop v4: Reverse-engineer target agents and build hero_v2.

8-step pipeline:
  1. SCOUT      — Download target agent versions
  2. LAYER DIFF — Extract & diff closure layers
  3. TAPE DIFF  — Compare route tapes
  4. COLOSSEUM  — Diagnose: our hero vs targets (save losses)
  5. TRACER     — Analyze losses for mechanisms
  6. ABSORB     — Plan layer transplant + patches
  7. CODE GEN   — Generate hero_v2
  8. VALIDATE   — Full gauntlet with regression gates

Usage:
    python autoloop_v4.py --base _hero_from_v46 --target ahmedberatozer --name hero_v2
    python autoloop_v4.py --base _hero_from_v46 --target ahmedberatozer --name hero_v2 --patterns v47 v48
    python autoloop_v4.py --base _hero_from_v46 --target ahmedberatozer --name hero_v2 --skip-scout
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"
PYTHON = sys.executable
COLOSSEUM = str(AUTOLOOP_DIR / "colosseum.py")

# Full gauntlet opponents
GAUNTLET_OPPONENTS = [
    ("jaxa623", "jaxa623__2842-two-identical-agents-90-points-apart"),
    ("tetsutani_new", "tetsutani__market-smart-farming-kaggriculture"),
    ("ahmed_v46", "ahmedberatozer__kaggriculture-v46-first-turn-microstructure-and-s"),
    ("ahmed_v45", "ahmedberatozer__kaggriculture-v45-first-turn-wheat-round-trip"),
    ("ahmed_v44", "ahmedberatozer__kaggriculture-v44-winning-the-same-turn-sale-race"),
    ("ahmed_v43", "ahmedberatozer__kaggriculture-v43-recovering-lost-harvests"),
    ("ahmed_v42", "ahmedberatozer__kaggriculture-v42-production-that-fits-the-marke"),
    ("ahmed_v40", "ahmedberatozer__kaggriculture-v40-plans-that-fit-the-shops"),
    ("ahmed_v38", "ahmedberatozer__kaggriculture-v38-smarter-feed-stronger-margins"),
    ("degnonguidi_best", "degnonguidi__best-agent-ranking"),
    ("aurax7_v6", "aurax7__kaggriculture-shop-router-reactive-v6"),
    ("evgendvorkin", "evgendvorkin__kaggriculture"),
    ("flexonafft", "flexonafft__kaggriculture-multi-route-farming-agent"),
    ("pipe7", "_pipe7_candidate"),
    ("pipe8", "_pipe8_candidate"),
]


def log(msg):
    print(f"[autoloop_v4] {msg}", flush=True)


def banner(step, title):
    print(f"\n{'='*80}")
    print(f"  STEP {step}: {title}")
    print(f"{'='*80}")


# ═══════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════

def run_h2h(agent_a, agent_b, games=10, parallel=10, save_losses=None):
    """Run colosseum H2H and return parsed results."""
    with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as f:
        outpath = f.name
    try:
        cmd = [PYTHON, COLOSSEUM, agent_a, agent_b,
               '--games', str(games), '--parallel', str(parallel), '--output', outpath]
        if save_losses:
            os.makedirs(save_losses, exist_ok=True)
            cmd += ['--save-losses', save_losses]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600, cwd=str(WORK_DIR))
        if os.path.exists(outpath) and os.path.getsize(outpath) > 0:
            with open(outpath) as f:
                return json.load(f)
        return {"error": True, "detail": result.stderr[-300:] if result.stderr else "no output"}
    except Exception as e:
        return {"error": True, "detail": str(e)}
    finally:
        if os.path.exists(outpath):
            os.unlink(outpath)


def resolve_agent(name_or_path):
    """Resolve to agent main.py path."""
    p = Path(name_or_path)
    if p.is_file():
        return str(p)
    candidate = AGENTS_DIR / name_or_path / "main.py"
    if candidate.exists():
        return str(candidate)
    matches = list(AGENTS_DIR.glob(f"*{name_or_path}*"))
    for m in matches:
        if (m / "main.py").exists():
            return str(m / "main.py")
    return None


def find_target_agents(target_user, patterns):
    """Find downloaded agents matching target user + patterns."""
    found = {}
    for p in patterns:
        matches = list(AGENTS_DIR.glob(f"{target_user}*{p}*"))
        for m in matches:
            if (m / "main.py").exists():
                # Extract version from dirname
                dirname = m.name
                found[p] = {
                    'name': dirname,
                    'path': str(m / "main.py"),
                    'pattern': p,
                }
    return found


# ═══════════════════════════════════════════════════════════
# STEP 1: SCOUT
# ═══════════════════════════════════════════════════════════

def step1_scout(target_user, patterns, force=False):
    banner(1, f"SCOUT — downloading {target_user} {patterns}")

    sys.path.insert(0, str(AUTOLOOP_DIR))
    from scout_targeted import scout_targeted

    results = scout_targeted(target_user, patterns, force=force)

    if not results:
        log("No agents downloaded. Checking if already extracted...")
        found = find_target_agents(target_user.replace("/", "__"), patterns)
        if found:
            log(f"Found {len(found)} existing agents: {list(found.keys())}")
            return found
        log("ERROR: No target agents available")
        return {}

    # Map results to our pattern dict
    found = {}
    for slug, path in results.items():
        for p in patterns:
            if p.lower() in slug.lower():
                found[p] = {'name': slug, 'path': path, 'pattern': p}
    return found


# ═══════════════════════════════════════════════════════════
# STEP 2: LAYER DIFF
# ═══════════════════════════════════════════════════════════

def step2_layer_diff(base_agent_path, reference_path, target_agents):
    """Diff reference (e.g. v46) against each target (v47, v48) and between targets."""
    banner(2, "LAYER DIFF — extracting & comparing closure layers")

    sys.path.insert(0, str(AUTOLOOP_DIR))
    from layer_diff import full_diff, three_way_diff

    diffs = {}
    target_paths = sorted(target_agents.values(), key=lambda x: x['pattern'])

    if len(target_paths) >= 2:
        # Three-way: reference → target1 → target2
        result = three_way_diff(
            reference_path,
            target_paths[0]['path'],
            target_paths[1]['path'],
        )
        diffs['three_way'] = result
        # Also diff reference → latest target directly
        diffs['ref_to_latest'] = result['ac']
    elif len(target_paths) == 1:
        diffs['ref_to_latest'] = full_diff(reference_path, target_paths[0]['path'])
    else:
        log("No targets to diff")
        return {}

    # Summary
    latest = diffs['ref_to_latest']
    added = latest['diff']['added_names']
    modified = [n for n, _ in latest.get('modified_layers', [])]
    log(f"\nInnovations to absorb: +{len(added)} layers, ~{len(modified)} modified")
    if added:
        log(f"  New layers: {added}")
    if modified:
        log(f"  Modified: {modified}")

    return diffs


# ═══════════════════════════════════════════════════════════
# STEP 3: TAPE DIFF
# ═══════════════════════════════════════════════════════════

def step3_tape_diff(base_agent_path, target_agents):
    """Run tape-to-tape diffs."""
    banner(3, "TAPE DIFF — comparing route tapes")

    from tape_diff_tracer import extract_routes, diff_tapes

    try:
        our_routes, _ = extract_routes(base_agent_path)
    except Exception as e:
        log(f"Could not extract routes from base: {e}")
        return {}

    tape_diffs = {}
    for pattern, info in sorted(target_agents.items()):
        try:
            tgt_routes, _ = extract_routes(info['path'])
            diffs = diff_tapes(our_routes, tgt_routes)
            tape_diffs[pattern] = {
                'total_diffs': len(diffs),
                'by_route': {},
            }
            from collections import defaultdict
            by_route = defaultdict(int)
            for d in diffs:
                by_route[d['route_id']] += 1
            tape_diffs[pattern]['by_route'] = dict(by_route)
            log(f"  vs {pattern}: {len(diffs)} tape diffs across {len(by_route)} routes")
        except Exception as e:
            log(f"  vs {pattern}: ERROR — {e}")
            tape_diffs[pattern] = {'error': str(e)}

    return tape_diffs


# ═══════════════════════════════════════════════════════════
# STEP 4: COLOSSEUM DIAGNOSIS
# ═══════════════════════════════════════════════════════════

def step4_colosseum(base_agent_path, target_agents, name, games=30, parallel=10):
    """Run base vs each target, save losses for tracer."""
    banner(4, f"COLOSSEUM — {name} vs targets ({games} games each)")

    results = {}
    for pattern, info in sorted(target_agents.items()):
        opp_path = info['path']
        opp_name = f"{name}_vs_{pattern}"
        losses_dir = str(CORPUS_DIR / f"{opp_name}_losses")

        log(f"  vs {pattern}...", )
        r = run_h2h(base_agent_path, opp_path, games, parallel, losses_dir)
        if r.get("error"):
            log(f"    ERROR: {r.get('detail', 'unknown')[:100]}")
        else:
            wlt = f"{r['wins']}-{r['losses']}-{r['ties']}"
            log(f"    {wlt} (elo_rate={r['elo_rate']:.0%})")
            results[pattern] = r

    return results


# ═══════════════════════════════════════════════════════════
# STEP 5: MECHANISM TRACER
# ═══════════════════════════════════════════════════════════

def step5_tracer(name, target_agents):
    """Run v3 mechanism tracer on losses from step 4."""
    banner(5, f"TRACER — analyzing {name} losses")

    from mechanism_tracer_v3 import analyze_losses_v3

    all_traces = {}
    for pattern in sorted(target_agents.keys()):
        losses_dir = CORPUS_DIR / f"{name}_vs_{pattern}_losses"
        if not losses_dir.exists():
            continue

        log(f"\n  --- vs {pattern} ---")
        traces = analyze_losses_v3(str(losses_dir))
        if traces:
            all_traces[pattern] = traces

    # Save combined traces
    traces_path = str(CORPUS_DIR / f"{name}_v4_traces.json")
    serializable = {k: [{sk: sv for sk, sv in t.items() if sk != 'step_analyses'}
                         for t in v]
                    for k, v in all_traces.items()}
    with open(traces_path, "w") as f:
        json.dump(serializable, f, indent=2, default=str)
    log(f"\n  Saved traces to {traces_path}")

    return all_traces


# ═══════════════════════════════════════════════════════════
# STEP 6: ABSORB — Plan what to transplant
# ═══════════════════════════════════════════════════════════

def step6_absorb(diffs, tracer_results, target_agents):
    """Decide which layers to transplant, which constants to patch."""
    banner(6, "ABSORB — planning layer transplant")

    plan = {
        'layers_to_add': [],
        'constant_patches': {},
        'donor_for_opp_plan': None,
    }

    if not diffs:
        log("  No diffs available, nothing to absorb")
        return plan

    latest_diff = diffs.get('ref_to_latest', {})

    # Innovation tail (captures all code beyond the shared base)
    tail = latest_diff.get('innovation_tail')
    if tail:
        log(f"  Innovation tail: {tail['n_lines']} lines of new code")

    # Layers to add (from detected boundaries)
    added_layers = latest_diff.get('added_layers', [])
    if added_layers:
        for layer in added_layers:
            log(f"  + Layer: {layer['name']} ({layer['end_line'] - layer['start_line']} lines)")
            plan['layers_to_add'].append(layer)

    # Constants to patch from modified layers
    for name, info in latest_diff.get('modified_layers', []):
        for var, change in info.get('changed_constants', {}).items():
            if change.get('new') is not None:
                log(f"  ~ Patch: {var} = {change['new']} (was {change.get('old', '?')})")
                plan['constant_patches'][var] = change['new']

    # NOTE: opponent_plan injection disabled — it inserts a massive JSON blob
    # that breaks the agent. The manual test showed 95% elo vs v48 without it.
    # Re-enable when inject_opponent_plan is refactored to use external file loading.
    plan['donor_for_opp_plan'] = None

    # Summary
    log(f"\n  Plan: +{len(plan['layers_to_add'])} layers, "
        f"~{len(plan['constant_patches'])} patches, "
        f"opp_plan={'yes' if plan['donor_for_opp_plan'] else 'no'}")

    return plan


# ═══════════════════════════════════════════════════════════
# STEP 7: CODE GEN
# ═══════════════════════════════════════════════════════════

def step7_codegen(base_path, absorb_plan, output_name, diffs):
    """Generate hero_v2 from base + absorbed innovations."""
    banner(7, f"CODE GEN — building {output_name}")

    from layer_codegen import generate_hero_v2, smoke_test

    # Build diff_result structure expected by generate_hero_v2
    diff_result = diffs.get('ref_to_latest', {})
    diff_result['added_layers'] = absorb_plan['layers_to_add']
    # Ensure innovation_tail is passed through
    if 'innovation_tail' not in diff_result:
        diff_result['innovation_tail'] = None

    agent_path = generate_hero_v2(
        base_path=base_path,
        diff_result=diff_result,
        donor_path=absorb_plan.get('donor_for_opp_plan'),
        output_name=output_name,
        inject_opp_plan=absorb_plan.get('donor_for_opp_plan') is not None,
        constant_patches=absorb_plan['constant_patches'] or None,
    )

    if not agent_path:
        log("ERROR: Code gen failed")
        return None

    # Smoke test
    log("Smoke testing...")
    test_opp = None
    for _, opp_dir in GAUNTLET_OPPONENTS:
        p = str(AGENTS_DIR / opp_dir / "main.py")
        if os.path.exists(p):
            test_opp = p
            break

    if test_opp:
        r = run_h2h(agent_path, test_opp, games=2, parallel=2)
        if r.get("error"):
            log(f"  Smoke test FAILED: {r.get('detail', '')[:100]}")
            log("  Attempting without opponent_plan...")
            # Retry without opponent_plan injection
            from layer_codegen import generate_hero_v2 as gen
            agent_path = gen(
                base_path=base_path,
                diff_result=diff_result,
                donor_path=None,
                output_name=output_name,
                inject_opp_plan=False,
                constant_patches=absorb_plan['constant_patches'] or None,
            )
            if agent_path:
                r2 = run_h2h(agent_path, test_opp, games=2, parallel=2)
                if r2.get("error"):
                    log("  Still FAILED. Trying base + layers only (no patches)...")
                    agent_path = gen(
                        base_path=base_path,
                        diff_result={'added_layers': absorb_plan['layers_to_add'], 'modified_layers': []},
                        donor_path=None,
                        output_name=output_name,
                        inject_opp_plan=False,
                        constant_patches=None,
                    )
                    if agent_path:
                        r3 = run_h2h(agent_path, test_opp, games=2, parallel=2)
                        if r3.get("error"):
                            log("  ABORT: Cannot produce working agent")
                            return None
                else:
                    log("  OK without opponent_plan")
        else:
            wlt = f"{r['wins']}-{r['losses']}-{r['ties']}"
            log(f"  Smoke test OK ({wlt})")

    return agent_path


# ═══════════════════════════════════════════════════════════
# STEP 8: VALIDATION
# ═══════════════════════════════════════════════════════════

def step8_validate(agent_path, output_name, target_agents, baseline_results=None,
                   games=200, parallel=10):
    """Full gauntlet validation with regression gates."""
    banner(8, f"VALIDATION — {output_name} vs all opponents ({games} games each)")

    # Build opponent list: gauntlet + target agents
    opponents = list(GAUNTLET_OPPONENTS)
    for pattern, info in target_agents.items():
        opp_name = f"target_{pattern}"
        if not any(info['name'] in d for _, d in opponents):
            opponents.append((opp_name, info['name']))

    print(f"{'Opponent':<30} {'W/L/T':>10} {'Rate':>7} {'Margin':>10}")
    print("-" * 65)

    total_w, total_l, total_t = 0, 0, 0
    results = {}
    regressions = []

    for opp_name, opp_dir in opponents:
        opp_path = str(AGENTS_DIR / opp_dir / "main.py")
        if not os.path.exists(opp_path):
            continue

        r = run_h2h(agent_path, opp_path, games, parallel)
        if r.get("error"):
            print(f"{opp_name:<30} {'ERROR':>10}")
            continue

        wlt = f"{r['wins']}-{r['losses']}-{r['ties']}"
        total_w += r["wins"]; total_l += r["losses"]; total_t += r["ties"]
        print(f"{opp_name:<30} {wlt:>10} {r['elo_rate']:>6.0%} {r.get('avg_margin', 0):>+10.0f}")
        results[opp_name] = r

        # Regression check
        if baseline_results and opp_name in baseline_results:
            base_rate = baseline_results[opp_name].get('elo_rate', 0.5)
            new_rate = r['elo_rate']
            if base_rate > 0.5 and new_rate < base_rate - 0.05:
                regressions.append({
                    'opponent': opp_name,
                    'baseline': base_rate,
                    'new': new_rate,
                    'delta': new_rate - base_rate,
                })

    total = total_w + total_l + total_t
    elo_rate = (total_w + 0.5 * total_t) / total if total else 0
    print("-" * 65)
    print(f"{'TOTAL':<30} {f'{total_w}-{total_l}-{total_t}':>10} {elo_rate:>6.0%}")

    # Self-play
    log(f"\nSelf-play (20 games)...")
    sp = run_h2h(agent_path, agent_path, 20, parallel)
    if not sp.get("error"):
        log(f"  {sp['wins']}-{sp['losses']}-{sp['ties']}")

    # Target performance
    target_rates = {}
    for pattern in target_agents:
        opp_name = f"target_{pattern}"
        if opp_name in results:
            target_rates[pattern] = results[opp_name]['elo_rate']

    # Gates
    print(f"\n{'='*65}")
    print("GATE CHECKS:")
    passed = True

    # Target gate: elo_rate > 0.7 vs targets
    for pattern, rate in target_rates.items():
        ok = rate >= 0.7
        status = "PASS" if ok else "FAIL"
        print(f"  vs {pattern}: {rate:.0%} (target: ≥70%) — {status}")
        if not ok:
            passed = False

    # Regression gate
    if regressions:
        print(f"\n  REGRESSIONS ({len(regressions)}):")
        for reg in regressions:
            print(f"    vs {reg['opponent']}: {reg['baseline']:.0%} → {reg['new']:.0%} ({reg['delta']:+.0%})")
        passed = False
    else:
        print(f"  No regressions detected")

    print(f"\n  OVERALL: {'PASS' if passed else 'FAIL'}")

    # Save
    val_path = str(CORPUS_DIR / f"{output_name}_validation.json")
    with open(val_path, "w") as f:
        json.dump({
            "results": {k: {kk: vv for kk, vv in v.items() if kk != 'replays'}
                        for k, v in results.items()},
            "total_w": total_w, "total_l": total_l, "total_t": total_t,
            "elo_rate": elo_rate,
            "target_rates": target_rates,
            "regressions": regressions,
            "passed": passed,
        }, f, indent=2, default=str)
    log(f"Saved to {val_path}")

    return {'elo_rate': elo_rate, 'passed': passed, 'results': results,
            'target_rates': target_rates, 'regressions': regressions}


# ═══════════════════════════════════════════════════════════
# MAIN ORCHESTRATOR
# ═══════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Autoloop v4: reverse-engineer & absorb")
    parser.add_argument("--base", required=True, help="Base agent directory name")
    parser.add_argument("--target", default="ahmedberatozer", help="Target user to reverse-engineer")
    parser.add_argument("--reference", help="Reference agent for diffing (default: v46)")
    parser.add_argument("--name", default="hero_v2", help="Output agent name")
    parser.add_argument("--patterns", nargs="+", default=["v47", "v48"], help="Version patterns")
    parser.add_argument("--games-diagnose", type=int, default=30, help="Games for diagnosis")
    parser.add_argument("--games-validate", type=int, default=200, help="Games for validation")
    parser.add_argument("--parallel", type=int, default=10, help="Parallel workers")
    parser.add_argument("--skip-scout", action="store_true", help="Skip downloading")
    parser.add_argument("--skip-validate", action="store_true", help="Skip full validation")
    parser.add_argument("--max-iterations", type=int, default=3, help="Max improvement iterations")
    args = parser.parse_args()

    os.chdir(str(WORK_DIR))
    t0 = time.time()

    base_path = resolve_agent(args.base)
    if not base_path:
        log(f"ERROR: Base agent not found: {args.base}")
        return

    # Find reference agent (default: Ahmed's v46)
    if args.reference:
        reference_path = resolve_agent(args.reference)
    else:
        reference_path = resolve_agent("ahmedberatozer__kaggriculture-v46-first-turn-microstructure-and-s")
    if not reference_path:
        log("ERROR: Reference agent (v46) not found")
        return

    print(f"\n{'#'*80}")
    print(f"  AUTOLOOP V4: {args.base} + {args.target} {args.patterns} → {args.name}")
    print(f"{'#'*80}")
    log(f"Base:      {base_path}")
    log(f"Reference: {reference_path}")
    log(f"Target:    {args.target} {args.patterns}")

    # ── Step 1: Scout ──
    if args.skip_scout:
        target_agents = find_target_agents(args.target, args.patterns)
        if not target_agents:
            log("ERROR: No target agents found (and --skip-scout). Run without --skip-scout.")
            return
        log(f"Using existing agents: {list(target_agents.keys())}")
    else:
        target_agents = step1_scout(args.target, args.patterns)
        if not target_agents:
            log("ERROR: Could not obtain target agents")
            log("Tip: Check if the notebooks are public on Kaggle")
            return

    log(f"Target agents: {json.dumps({k: v['name'] for k, v in target_agents.items()}, indent=2)}")

    # ── Step 2: Layer Diff ──
    diffs = step2_layer_diff(base_path, reference_path, target_agents)

    # ── Step 3: Tape Diff ──
    tape_diffs = step3_tape_diff(base_path, target_agents)

    # ── Step 4: Colosseum Diagnosis ──
    colosseum_results = step4_colosseum(
        base_path, target_agents, args.name,
        args.games_diagnose, args.parallel
    )

    # ── Step 5: Tracer ──
    tracer_results = step5_tracer(args.name, target_agents)

    # ── Step 6: Absorb ──
    absorb_plan = step6_absorb(diffs, tracer_results, target_agents)

    # ── Step 7: Code Gen ──
    agent_path = step7_codegen(base_path, absorb_plan, args.name, diffs)
    if not agent_path:
        log("ABORT: Code gen failed")
        return

    # ── Step 8: Validate ──
    if args.skip_validate:
        log("Skipping validation (--skip-validate)")
        validation = None
    else:
        validation = step8_validate(
            agent_path, args.name, target_agents,
            baseline_results=None,  # TODO: load baseline from previous gauntlet
            games=args.games_validate, parallel=args.parallel,
        )

        # Iteration loop
        iteration = 1
        while validation and not validation['passed'] and iteration < args.max_iterations:
            log(f"\n{'!'*80}")
            log(f"  ITERATION {iteration + 1}: Re-analyzing failures")
            log(f"{'!'*80}")

            # Re-run tracer on new losses (from validation step)
            # The losses are saved by the colosseum during validation
            tracer_results = step5_tracer(f"{args.name}_iter{iteration + 1}", target_agents)

            # Re-plan absorption with updated signals
            absorb_plan = step6_absorb(diffs, tracer_results, target_agents)

            # Re-generate
            iter_name = f"{args.name}_iter{iteration + 1}"
            agent_path = step7_codegen(base_path, absorb_plan, iter_name, diffs)
            if not agent_path:
                log("ABORT: Iteration code gen failed")
                break

            # Re-validate
            validation = step8_validate(
                agent_path, iter_name, target_agents,
                baseline_results=colosseum_results,
                games=args.games_validate, parallel=args.parallel,
            )
            iteration += 1

    # ── Summary ──
    elapsed = time.time() - t0
    print(f"\n{'#'*80}")
    print(f"  AUTOLOOP V4 COMPLETE: {args.name}")
    if validation:
        print(f"  Elo rate: {validation['elo_rate']:.0%}")
        for pattern, rate in validation.get('target_rates', {}).items():
            print(f"  vs {pattern}: {rate:.0%}")
        print(f"  Gates: {'PASS' if validation['passed'] else 'FAIL'}")
    print(f"  Agent: {agent_path}")
    print(f"  Time: {elapsed:.0f}s ({elapsed/60:.1f}m)")
    print(f"{'#'*80}")


if __name__ == "__main__":
    main()
