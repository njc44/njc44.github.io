#!/usr/bin/env python3
"""Submit: Package and submit the best agent to Kaggle.

Runs gates, smoke test, packages, submits, and backs up.

Usage:
    python submit.py                     # Submit current best
    python submit.py --agent agent_name  # Submit a specific agent
    python submit.py --dry-run           # Do everything except actual submission
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
from datetime import datetime, date
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"
STATE_FILE = AUTOLOOP_DIR / "state.json"
BACKUP_DIR = AUTOLOOP_DIR / "backups"

PYTHON = "/Users/nathanjacob/opt/miniconda3/bin/python"
MAX_SUBMISSIONS_PER_DAY = 2


def log(msg):
    print(f"[submit] {msg}", flush=True)


def build_version_tag(state):
    """Build a human-readable version tag from state history.

    Format: v{N}_{base_short}+{kept_improvements}
    Example: v5_v40+r38+r60+r60crit+r97supply
    """
    # Count total submissions (across all days)
    version_num = len([b for b in BACKUP_DIR.iterdir() if b.is_dir()]) + 1 if BACKUP_DIR.exists() else 1

    # Short base name
    base = state.get("candidate_base", "unknown")
    if "v40" in base:
        base_short = "v40"
    elif "v41" in base:
        base_short = "v41"
    elif "v39" in base:
        base_short = "v39"
    elif "more-yield" in base:
        base_short = "moreYield"
    else:
        base_short = base.split("__")[-1][:12] if "__" in base else base[:12]

    # Collect kept improvements (abbreviated, deduplicated by module prefix)
    kept_modules = {}  # module_prefix -> latest version count
    for imp in state.get("improvements_tried", []):
        if imp.get("verdict") != "KEPT":
            continue
        name = imp["name"].split(":")[0].strip()
        # Skip rebases
        if name.startswith("rebase_to"):
            continue
        # Extract module prefix (e.g. "r60" from "r60_day0_preemptive_rescue")
        parts = name.split("_")
        prefix = parts[0]  # e.g. "r60", "r38", "r97"
        kept_modules[prefix] = kept_modules.get(prefix, 0) + 1

    # Build compact list: "r38", "r60x5", "r97"
    kept = []
    for mod, count in kept_modules.items():
        if count > 1:
            kept.append(f"{mod}x{count}")
        else:
            kept.append(mod)

    # Add colosseum Elo if available
    elo = state.get("best_public_elo")
    elo_str = f"_E{int(elo)}" if elo else ""

    tag = f"v{version_num}_{base_short}"
    if kept:
        tag += "+" + "+".join(kept)
    tag += elo_str

    # Kaggle message limit is ~50 chars, truncate if needed
    if len(tag) > 50:
        tag = tag[:47] + "..."
    return tag


def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {}


def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def smoke_test(agent_path):
    """Verify agent doesn't crash in a real game."""
    try:
        result = subprocess.run(
            [PYTHON, "-c", f"""
from kaggle_environments import make
env = make('kaggriculture')  # LB-identical: no debug, no overrides
r = env.run(['{agent_path}', '{agent_path}'])
f = r[-1]
score = f[0]['reward']
ok = f[0]['status'] == 'DONE' and f[1]['status'] == 'DONE'
print(f'OK {{score}}' if ok else 'FAIL')
"""],
            capture_output=True, text=True, timeout=30,
            cwd=str(WORK_DIR)
        )
        if "OK" in result.stdout:
            score = float(result.stdout.strip().split()[-1])
            return True, score
        return False, 0
    except Exception as e:
        log(f"  Smoke test error: {e}")
        return False, 0


def package_agent(agent_dir, output_path):
    """Package agent directory into submission tar.gz."""
    agent_dir = Path(agent_dir)
    output_path = Path(output_path)

    with tarfile.open(output_path, "w:gz") as tar:
        for f in sorted(agent_dir.iterdir()):
            if f.is_file() and f.name != "meta.json" and not f.name.startswith("."):
                if f.name == "__pycache__":
                    continue
                tar.add(f, arcname=f.name)

    # Verify
    with tarfile.open(output_path, "r:gz") as tar:
        members = tar.getnames()

    log(f"  Packaged: {len(members)} files, {output_path.stat().st_size / 1024:.1f} KB")
    log(f"  Contents: {members}")
    return True


def submit_to_kaggle(tar_path, message):
    """Submit to Kaggle competition."""
    try:
        result = subprocess.run(
            ["kaggle", "competitions", "submit",
             "-c", "kaggriculture",
             "-f", str(tar_path),
             "-m", message],
            capture_output=True, text=True, timeout=60
        )
        success = result.returncode == 0 and "Successfully" in result.stdout
        if success:
            log(f"  Submitted successfully")
        else:
            log(f"  Submission failed: {result.stdout} {result.stderr}")
        return success
    except Exception as e:
        log(f"  Submission error: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description="Submit best agent")
    parser.add_argument("--agent", type=str, help="Specific agent to submit")
    parser.add_argument("--dry-run", action="store_true", help="Skip actual submission")
    args = parser.parse_args()

    log("=== SUBMIT START ===")

    state = load_state()

    # Determine which agent to submit
    if args.agent:
        agent_name = args.agent
    else:
        # Use the candidate if it exists and is ranked, otherwise best public
        agent_name = state.get("candidate_agent", state.get("best_public_agent"))

    if not agent_name:
        log("No agent to submit — run arena first")
        return False

    agent_dir = AGENTS_DIR / agent_name
    agent_main = agent_dir / "main.py"
    if not agent_main.exists():
        log(f"Agent not found: {agent_dir}")
        return False

    log(f"Agent: {agent_name}")

    # Gate 1: Submission limit
    today = date.today().isoformat()
    if state.get("submissions_today_date") != today:
        state["submissions_today"] = 0
        state["submissions_today_date"] = today

    subs_today = state.get("submissions_today", 0)
    if subs_today >= MAX_SUBMISSIONS_PER_DAY:
        log(f"GATE FAIL: Already submitted {subs_today} times today (max {MAX_SUBMISSIONS_PER_DAY})")
        return False
    log(f"  Gate 1 (daily limit): PASS ({subs_today}/{MAX_SUBMISSIONS_PER_DAY})")

    # Gate 2: Arena ranking — must have been tournament-tested and beat our best bots
    log(f"  Gate 2 (arena ranking)...")
    rankings_file = AUTOLOOP_DIR / "rankings.json"
    if not rankings_file.exists():
        log(f"  Gate 2: FAIL — no arena rankings exist. Run arena first.")
        return False

    with open(rankings_file) as f:
        rankings = json.load(f)

    agent_stats = rankings.get("agents", {}).get(agent_name)
    if not agent_stats:
        log(f"  Gate 2: FAIL — agent '{agent_name}' has no arena ranking. Run arena --challenge {agent_name} first.")
        return False

    agent_elo = agent_stats.get("elo", 0)
    agent_wr = agent_stats.get("win_rate", 0)
    matchups_played = agent_stats.get("matchups_played", 0)

    # Must have played at least 3 matchups
    if matchups_played < 3:
        log(f"  Gate 2: FAIL — only {matchups_played} matchups played (need >= 3)")
        return False

    # Must be top 2 in arena OR have > 60% overall win rate
    sorted_agents = sorted(rankings.get("agents", {}).items(),
                           key=lambda x: x[1].get("elo", 0), reverse=True)
    rank = next((i for i, (n, _) in enumerate(sorted_agents, 1) if n == agent_name), 999)

    if rank > 2 and agent_wr < 0.60:
        log(f"  Gate 2: FAIL — rank #{rank}, WR {agent_wr*100:.0f}% (need top 2 or >60% WR)")
        return False

    log(f"  Gate 2 (arena ranking): PASS — rank #{rank}, Elo {agent_elo:.0f}, "
        f"WR {agent_wr*100:.0f}%, {matchups_played} matchups")

    # Gate 3: Smoke test
    log(f"  Gate 3 (smoke test)...")
    ok, score = smoke_test(str(agent_main))
    if not ok:
        log(f"  Gate 3: FAIL — agent crashes")
        return False
    log(f"  Gate 3 (smoke test): PASS (score: ${score:,.0f})")

    # Gate 4: Package
    tar_path = WORK_DIR / "submission.tar.gz"
    log(f"  Gate 4 (package)...")
    if not package_agent(agent_dir, tar_path):
        log(f"  Gate 4: FAIL")
        return False
    log(f"  Gate 4 (package): PASS")

    # Submit
    if args.dry_run:
        log(f"  DRY RUN — would submit {agent_name}")
    else:
        version_tag = build_version_tag(state)
        message = version_tag
        log(f"  Version tag: {version_tag}")
        if not submit_to_kaggle(tar_path, message):
            return False

        # Backup with version tag
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        backup_name = f"submitted_{datetime.now().strftime('%Y%m%d_%H%M')}_{version_tag}"
        backup_path = BACKUP_DIR / backup_name
        shutil.copytree(agent_dir, backup_path)
        shutil.copy2(tar_path, backup_path / "submission.tar.gz")
        log(f"  Backed up to: {backup_path}")

        # Update state
        state["submissions_today"] = subs_today + 1
        state["submissions_today_date"] = today
        state["last_submission_time"] = datetime.now().isoformat()
        state["last_submitted_agent"] = agent_name
        state["last_submitted_version"] = version_tag
        save_state(state)

    log("=== SUBMIT DONE ===")
    return True


if __name__ == "__main__":
    main()
