#!/bin/bash
# ──────────────────────────────────────────────────────────────
# Kaggriculture Unified Autoloop Daemon
#
# PHILOSOPHY:
#   AI proposes, deterministic code judges.
#   Claude writes fixes. colosseum.py runs tests.
#   Claude NEVER runs games, reports scores, or decides keep/revert.
#   The daemon owns ALL measurement and ALL decisions.
#
# Flow:
#   1. SCOUT   — Download top public notebooks, extract agents
#   2. RANK    — H2H tournament to find the best agents
#   3. IMPROVE — Claude proposes ONE code change (no testing)
#   4. JUDGE   — Daemon runs colosseum.py: candidate vs base, 200 games
#   5. DECIDE  — Keep only if Elo-significant (p<0.05) or strong directional signal
#   6. Repeat 3-5 up to 5 times until candidate beats base
#   7. SUBMIT  — If candidate beats base, package and submit
#
# Usage:
#   ./daemon.sh --once           # Single full cycle
#   ./daemon.sh --loop           # Continuous 3hr cycles
#   ./daemon.sh --status         # Show current state
#   nohup ./daemon.sh --loop &   # Background
# ──────────────────────────────────────────────────────────────

set -uo pipefail

WORK_DIR="/Users/nathanjacob/Documents/kaggle/kaggriculture"
AUTOLOOP_DIR="$WORK_DIR/autoloop"
LOG_DIR="$AUTOLOOP_DIR/logs"
STATE_FILE="$AUTOLOOP_DIR/state.json"

PYTHON="/Users/nathanjacob/opt/miniconda3/bin/python"
CLAUDE="/opt/homebrew/bin/claude"

CYCLE_INTERVAL=10800    # 3 hours between full cycles
SUBMIT_INTERVAL=21600   # 6 hours between submissions
COLOSSEUM_GAMES=200     # Games per H2H test (200+ for statistical significance)
MAX_IMPROVE_ATTEMPTS=5  # Max fix attempts per cycle

mkdir -p "$LOG_DIR"

# ── Logging ────────────────────────────────────────────────

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_DIR/daemon.log"
}

# ── Status ─────────────────────────────────────────────────

show_status() {
    echo ""
    echo "═══════════════════════════════════════════════════════════"
    echo "  KAGGRICULTURE UNIFIED AUTOLOOP"
    echo "═══════════════════════════════════════════════════════════"
    if [ -f "$STATE_FILE" ]; then
        $PYTHON -c "
import json
with open('$STATE_FILE') as f:
    s = json.load(f)
print(f'  Best Public Agent:  {s.get(\"best_public_agent\", \"unknown\")}')
print(f'  Candidate Agent:    {s.get(\"candidate_agent\", \"none\")}')
print(f'  Candidate Base:     {s.get(\"candidate_base\", \"none\")}')
print(f'  Last Improvement:   {s.get(\"last_improvement\", \"none\")}')
print(f'  Last Result:        {s.get(\"last_improvement_result\", \"none\")}')
print(f'  Last Colosseum:     {s.get(\"last_colosseum\", \"none\")}')
print(f'  Last Submission:    {s.get(\"last_submission_time\", \"never\")}')
print(f'  Submissions Today:  {s.get(\"submissions_today\", 0)}')
print()
tried = s.get('improvements_tried', [])
if tried:
    print(f'  Improvements ({len(tried)} total, last 5):')
    for t in tried[-5:]:
        v = t.get('verdict', '?')
        n = t.get('name', '?')
        wr = t.get('colosseum_wr', '?')
        print(f'    {v:>8s}: {n} (colosseum WR: {wr})')
" 2>/dev/null
    else
        echo "  No state file yet. Run: ./daemon.sh --once"
    fi
    echo "═══════════════════════════════════════════════════════════"
}

# ── Phase 1: SCOUT ─────────────────────────────────────────

run_scout() {
    log "═══ PHASE 1: SCOUT ═══"
    local scout_log="$LOG_DIR/scout_$(date +%Y%m%d_%H%M%S).log"

    if [ ! -d "$AUTOLOOP_DIR/agents/reyhanks_dynamic" ]; then
        log "First run — seeding known agents..."
        $PYTHON "$AUTOLOOP_DIR/scout.py" --seed > "$scout_log" 2>&1
    fi

    $PYTHON "$AUTOLOOP_DIR/scout.py" >> "$scout_log" 2>&1
    log "Scout exit code: $?"
}

# ── Phase 2: RANK ──────────────────────────────────────────

run_rank() {
    local mode="${1:-quick}"
    log "═══ PHASE 2: RANK (mode=$mode) ═══"
    local rank_log="$LOG_DIR/rank_$(date +%Y%m%d_%H%M%S).log"

    local args="--games $COLOSSEUM_GAMES"
    [ "$mode" = "quick" ] && args="$args --quick"

    $PYTHON "$AUTOLOOP_DIR/arena.py" $args > "$rank_log" 2>&1
    log "Rank exit code: $?"
}

# ── Phase 2.5: DIAGNOSE (replay analysis — no AI) ─────────

run_diagnose() {
    log "═══ PHASE 2.5: DIAGNOSE (Root Cause Analysis — twin-expanded corpus) ═══"
    local diag_log="$LOG_DIR/diagnose_$(date +%Y%m%d_%H%M%S).log"

    # Download recent replays from our latest submission + analyze full corpus
    $PYTHON "$AUTOLOOP_DIR/root_cause_analyzer.py" --download-ours 50 --analyze \
        > "$diag_log" 2>&1

    local exit_code=$?
    if [ $exit_code -ne 0 ]; then
        log "  Diagnosis failed (exit $exit_code), continuing without"
        return 0
    fi

    if [ -f "$AUTOLOOP_DIR/corpus/rca_report.txt" ]; then
        local rec_lines n_losses
        rec_lines=$(wc -l < "$AUTOLOOP_DIR/corpus/rca_report.txt")
        n_losses=$($PYTHON -c "import json; print(len(json.load(open('$AUTOLOOP_DIR/corpus/rca_losses.json'))))" 2>/dev/null || echo 0)
        log "  RCA complete ($rec_lines line report, $n_losses classified losses)"
    else
        log "  No RCA report produced"
    fi
}

# ── Phase 3: IMPROVE (AI proposes ONLY — no testing) ───────

run_propose_fix() {
    # Claude ONLY reads code and writes a fix.
    # It does NOT run games, report scores, or decide keep/revert.
    local improve_log="$LOG_DIR/improve_$(date +%Y%m%d_%H%M%S).log"

    local prompt
    prompt=$(cat "$AUTOLOOP_DIR/improve_prompt.md")

    echo "$prompt" | $CLAUDE -p \
        --allowedTools "Read,Write,Edit,Grep,Glob" \
        --model sonnet \
        --verbose > "$improve_log" 2>&1

    log "  Claude exit code: $?"
    return $?
}

# ── Phase 4: JUDGE (Daemon runs colosseum — no AI) ────────

run_colosseum_vs_base() {
    # The daemon runs this. Claude never touches it.
    # LB-identical: make('kaggriculture'), no debug, no overrides.
    local output_file="$LOG_DIR/colosseum_$(date +%Y%m%d_%H%M%S).json"

    local candidate="$AUTOLOOP_DIR/agents/_candidate/main.py"
    local base_name
    base_name=$($PYTHON -c "
import json
with open('$STATE_FILE') as f:
    print(json.load(f).get('candidate_base', ''))
" 2>/dev/null)

    if [ -z "$base_name" ]; then
        log "  ERROR: No candidate_base in state"
        return 1
    fi

    local base="$AUTOLOOP_DIR/agents/$base_name/main.py"

    if [ ! -f "$candidate" ] || [ ! -f "$base" ]; then
        log "  ERROR: candidate or base not found"
        return 1
    fi

    log "  Colosseum: _candidate vs $base_name ($COLOSSEUM_GAMES games, LB-identical rules)"

    $PYTHON "$AUTOLOOP_DIR/colosseum.py" \
        "$candidate" "$base" \
        --games "$COLOSSEUM_GAMES" \
        --output "$output_file" > "$LOG_DIR/colosseum_stdout_$(date +%Y%m%d_%H%M%S).log" 2>&1

    if [ ! -f "$output_file" ]; then
        log "  ERROR: Colosseum produced no output"
        return 1
    fi

    # Read results — Elo-correct: only W/L/T matters, margin is irrelevant
    local verdict
    verdict=$($PYTHON -c "
import json
with open('$output_file') as f:
    r = json.load(f)

w, l, t = r['wins'], r['losses'], r['ties']
total = w + l + t
elo_rate = r.get('elo_rate', (w + 0.5*t) / total if total else 0.5)
p_value = r.get('p_value', 1.0)
is_sig = r.get('is_significant', False)
sig_tag = '***' if is_sig else '(not significant)'

print(f'{w}W-{l}L-{t}T elo_rate={elo_rate:.1%} p={p_value:.3f} {sig_tag}')

# KEEP only if:
#   1. Elo rate > 0.5 (we're better, not worse), AND
#   2. Statistically significant (p < 0.05), OR
#   3. Strong directional signal: wins > losses AND total decisive games >= 10
decisive = w + l
if is_sig and elo_rate > 0.5:
    exit(0)  # KEEP — statistically confirmed improvement
elif w > l and decisive >= 10 and elo_rate > 0.55:
    exit(0)  # KEEP — strong directional signal even if p > 0.05
else:
    exit(1)  # REVERT — not enough evidence
")
    local keep=$?

    log "  Colosseum result: $verdict"

    # Save to state
    echo "$output_file" > "$AUTOLOOP_DIR/.last_colosseum"

    if [ $keep -eq 0 ]; then
        log "  VERDICT: KEEP (Elo-significant improvement)"
        return 0
    else
        log "  VERDICT: REVERT (insufficient evidence of improvement)"
        return 1
    fi
}

# ── Phase 5: DECIDE (keep or revert) ──────────────────────

revert_candidate() {
    log "  Reverting candidate from backup..."
    if [ -d "$AUTOLOOP_DIR/agents/_candidate_backup" ]; then
        rm -rf "$AUTOLOOP_DIR/agents/_candidate"
        cp -r "$AUTOLOOP_DIR/agents/_candidate_backup" "$AUTOLOOP_DIR/agents/_candidate"
        log "  Reverted."
    else
        log "  WARNING: No backup to revert to"
    fi
}

backup_candidate() {
    rm -rf "$AUTOLOOP_DIR/agents/_candidate_backup"
    cp -r "$AUTOLOOP_DIR/agents/_candidate" "$AUTOLOOP_DIR/agents/_candidate_backup"
}

update_state_after_judge() {
    local verdict="$1"  # KEPT or REVERTED
    local colosseum_file="$2"

    $PYTHON -c "
import json
from datetime import datetime

with open('$STATE_FILE') as f:
    state = json.load(f)

# Read colosseum results
try:
    with open('$colosseum_file') as f:
        col = json.load(f)
    wr = col['win_rate']
    elo_rate = col.get('elo_rate', wr)
    p_value = col.get('p_value', 1.0)
    is_sig = col.get('is_significant', False)
    sig_tag = '***' if is_sig else ''
    summary = f\"{col['wins']}W-{col['losses']}L-{col['ties']}T elo={elo_rate:.1%} p={p_value:.3f}{sig_tag}\"
except:
    wr = 0
    elo_rate = 0.5
    p_value = 1.0
    summary = 'unknown'

state['last_improvement_result'] = '$verdict'
state['last_colosseum'] = summary
state['last_improve_run'] = datetime.now().isoformat()

# Append to improvements_tried
tried = state.get('improvements_tried', [])
tried.append({
    'name': state.get('last_improvement', 'unknown'),
    'verdict': '$verdict',
    'colosseum_wr': round(wr, 3),
    'colosseum_elo_rate': round(elo_rate, 3),
    'colosseum_p_value': round(p_value, 4),
    'colosseum_summary': summary,
    'timestamp': datetime.now().isoformat(),
})
state['improvements_tried'] = tried

with open('$STATE_FILE', 'w') as f:
    json.dump(state, f, indent=2)
" 2>/dev/null
}

# ── The Improve Loop ──────────────────────────────────────

run_improve_loop() {
    log "═══ PHASE 3-5: IMPROVE LOOP (max $MAX_IMPROVE_ATTEMPTS attempts) ═══"

    # Ensure candidate exists (rebase if needed)
    if [ ! -f "$AUTOLOOP_DIR/agents/_candidate/main.py" ]; then
        log "  No candidate — running rebase via Claude..."
        run_propose_fix
    fi

    local attempt=0
    local kept_count=0
    local total_attempts=0

    while [ $attempt -lt $MAX_IMPROVE_ATTEMPTS ]; do
        attempt=$((attempt + 1))
        total_attempts=$attempt
        log ""
        log "  ┌─────────────────────────────────────"
        log "  │ Attempt $attempt/$MAX_IMPROVE_ATTEMPTS"
        log "  └─────────────────────────────────────"

        # Step 1: Backup current candidate
        backup_candidate
        log "  Backed up candidate"

        # Step 2: Claude proposes a fix (NO Bash tool — can't run games)
        log "  Asking Claude to propose a fix..."
        run_propose_fix || {
            log "  Claude failed, stopping loop"
            break
        }

        # Step 3: Check if candidate was actually modified
        local diff_lines
        diff_lines=$(diff "$AUTOLOOP_DIR/agents/_candidate/main.py" \
                          "$AUTOLOOP_DIR/agents/_candidate_backup/main.py" 2>/dev/null | wc -l)

        if [ "$diff_lines" -eq 0 ]; then
            log "  No code change detected — Claude didn't modify the file"
            revert_candidate
            continue
        fi
        log "  Code changed ($diff_lines diff lines)"

        # Step 4: DAEMON runs the test (Claude never sees this)
        log "  Running Colosseum (daemon-controlled, LB-identical)..."
        local colosseum_file="$LOG_DIR/colosseum_$(date +%Y%m%d_%H%M%S).json"

        $PYTHON "$AUTOLOOP_DIR/colosseum.py" \
            "$AUTOLOOP_DIR/agents/_candidate/main.py" \
            "$AUTOLOOP_DIR/agents/_candidate_backup/main.py" \
            --games "$COLOSSEUM_GAMES" \
            --output "$colosseum_file" > "$LOG_DIR/colosseum_stdout_$(date +%Y%m%d_%H%M%S).log" 2>&1

        if [ ! -f "$colosseum_file" ]; then
            log "  Colosseum failed to produce results — reverting"
            revert_candidate
            continue
        fi

        # Step 5: DAEMON decides keep/revert (Elo-correct: significance test)
        local verdict_line
        verdict_line=$($PYTHON -c "
import json
with open('$colosseum_file') as f:
    r = json.load(f)
w, l, t = r['wins'], r['losses'], r['ties']
total = w + l + t
elo_rate = r.get('elo_rate', (w + 0.5*t) / total if total else 0.5)
p_value = r.get('p_value', 1.0)
is_sig = r.get('is_significant', False)
sig_tag = '***' if is_sig else '(not significant)'
print(f'{w}W-{l}L-{t}T elo={elo_rate:.1%} p={p_value:.3f} {sig_tag}')
" 2>/dev/null)

        local keep_decision
        keep_decision=$($PYTHON -c "
import json
with open('$colosseum_file') as f:
    r = json.load(f)
w, l, t = r['wins'], r['losses'], r['ties']
elo_rate = r.get('elo_rate', (w + 0.5*t) / (w+l+t) if (w+l+t) else 0.5)
is_sig = r.get('is_significant', False)
decisive = w + l
if is_sig and elo_rate > 0.5:
    print('KEEP')
elif w > l and decisive >= 10 and elo_rate > 0.55:
    print('KEEP')
else:
    print('REVERT')
" 2>/dev/null)

        log "  Colosseum: $verdict_line"

        if [ "$keep_decision" = "KEEP" ]; then
            log "  ✓ KEEP (Elo-significant improvement)"
            update_state_after_judge "KEPT" "$colosseum_file"
            kept_count=$((kept_count + 1))
        else
            log "  ✗ REVERT (insufficient evidence of improvement)"
            revert_candidate
            update_state_after_judge "REVERTED" "$colosseum_file"
        fi
    done

    log ""
    log "═══ IMPROVE LOOP DONE: $total_attempts attempts, $kept_count kept ═══"
}

# ── Final Verify: Gauntlet vs top 5 ──────────────────────

run_final_verify() {
    log "═══ PHASE 6: FINAL VERIFY (gauntlet vs top 5) ═══"

    if [ ! -f "$AUTOLOOP_DIR/agents/_candidate/main.py" ]; then
        log "  No candidate to verify"
        return 1
    fi

    local gauntlet_output="$LOG_DIR/gauntlet_$(date +%Y%m%d_%H%M%S).json"

    $PYTHON "$AUTOLOOP_DIR/colosseum.py" \
        "$AUTOLOOP_DIR/agents/_candidate/main.py" \
        --gauntlet \
        --games "$COLOSSEUM_GAMES" \
        --top-n 5 \
        --output "$gauntlet_output" > "$LOG_DIR/gauntlet_stdout_$(date +%Y%m%d_%H%M%S).log" 2>&1

    log "  Gauntlet complete. Results in: $gauntlet_output"

    # Update state with gauntlet results
    if [ -f "$gauntlet_output" ]; then
        $PYTHON -c "
import json
with open('$gauntlet_output') as f:
    results = json.load(f)
with open('$STATE_FILE') as f:
    state = json.load(f)

tw = tl = tt = 0
lines = []
for name, r in results.items():
    tw += r['wins']; tl += r['losses']; tt += r['ties']
    total = r['wins'] + r['losses'] + r['ties']
    wr = r['wins']/total if total else 0
    lines.append(f'  vs {name}: {r[\"wins\"]}W-{r[\"losses\"]}L-{r[\"ties\"]}T WR={wr*100:.0f}%')

total = tw + tl + tt
overall_wr = tw/total if total else 0
state['gauntlet_summary'] = f'{tw}W-{tl}L-{tt}T WR={overall_wr*100:.0f}%'
state['gauntlet_details'] = lines

with open('$STATE_FILE', 'w') as f:
    json.dump(state, f, indent=2)

print(f'  Overall: {tw}W-{tl}L-{tt}T WR={overall_wr*100:.0f}%')
for line in lines:
    print(line)
" 2>/dev/null
    fi
}

# ── Phase 7: SUBMIT ───────────────────────────────────────

run_submit() {
    log "═══ PHASE 7: SUBMIT ═══"
    local submit_log="$LOG_DIR/submit_$(date +%Y%m%d_%H%M%S).log"

    # Submit _candidate if it exists, otherwise best public
    local agent="_candidate"
    if [ ! -f "$AUTOLOOP_DIR/agents/_candidate/main.py" ]; then
        agent=$($PYTHON -c "
import json
with open('$AUTOLOOP_DIR/rankings.json') as f:
    r = json.load(f)
best = max(r['agents'].items(), key=lambda x: x[1].get('elo', 0))
print(best[0])
" 2>/dev/null)
    fi

    [ -z "$agent" ] && { log "No agent to submit"; return 1; }

    log "  Submitting: $agent"
    $PYTHON "$AUTOLOOP_DIR/submit.py" --agent "$agent" > "$submit_log" 2>&1
    log "  Submit exit code: $?"
}

# ── Full Cycle ─────────────────────────────────────────────

run_cycle() {
    local cycle_start
    cycle_start=$(date +%s)

    log "╔══════════════════════════════════════════════════════════╗"
    log "║  CYCLE START — $(date '+%Y-%m-%d %H:%M:%S')                    ║"
    log "╚══════════════════════════════════════════════════════════╝"

    # Phase 1: Scout
    run_scout || log "Scout had issues, continuing..."

    # Phase 2: Rank
    if [ -f "$AUTOLOOP_DIR/rankings.json" ]; then
        run_rank "quick" || log "Rank had issues, continuing..."
    else
        run_rank "full" || log "Rank had issues, continuing..."
    fi

    # Phase 2.5: Diagnose (pull LB replays, analyze losses)
    run_diagnose || log "Diagnosis had issues, continuing..."

    # Phase 3-5: Improve loop (Claude reads diagnosis, proposes fix, daemon judges)
    run_improve_loop || log "Improve loop had issues, continuing..."

    # Phase 6: Final gauntlet vs top 5
    run_final_verify || log "Verify had issues, continuing..."

    # Phase 7: Submit (time-gated)
    local now last_submit
    now=$(date +%s)
    last_submit=$($PYTHON -c "
import json
from datetime import datetime
try:
    with open('$STATE_FILE') as f:
        ts = json.load(f).get('last_submission_time', '')
    print(int(datetime.fromisoformat(ts).timestamp()) if ts else 0)
except: print(0)
" 2>/dev/null || echo 0)

    if (( now - last_submit >= SUBMIT_INTERVAL )); then
        run_submit || log "Submit had issues"
    else
        log "Skipping submit — next in $(( (SUBMIT_INTERVAL - (now - last_submit)) / 60 ))m"
    fi

    local elapsed=$(( $(date +%s) - cycle_start ))
    log "╔══════════════════════════════════════════════════════════╗"
    log "║  CYCLE DONE — ${elapsed}s elapsed                           ║"
    log "╚══════════════════════════════════════════════════════════╝"
}

# ── Main ───────────────────────────────────────────────────

main() {
    local mode="${1:---loop}"
    case "$mode" in
        --once)   log "Single cycle"; run_cycle ;;
        --scout)    run_scout ;;
        --rank)     run_rank "${2:-full}" ;;
        --diagnose) run_diagnose ;;
        --improve)  run_improve_loop ;;
        --verify)   run_final_verify ;;
        --submit)   run_submit ;;
        --status) show_status ;;
        --loop|*)
            log "════════════════════════════════════════════════════════════"
            log "  KAGGRICULTURE AUTOLOOP DAEMON"
            log "  Philosophy: AI proposes, deterministic code judges"
            log "  Colosseum: $COLOSSEUM_GAMES games, LB-identical rules"
            log "  Max improve attempts: $MAX_IMPROVE_ATTEMPTS per cycle"
            log "  PID: $$"
            log "════════════════════════════════════════════════════════════"
            while true; do
                run_cycle
                log "Sleeping $((CYCLE_INTERVAL / 60))min until next cycle..."
                sleep "$CYCLE_INTERVAL"
            done ;;
    esac
}

main "$@"
