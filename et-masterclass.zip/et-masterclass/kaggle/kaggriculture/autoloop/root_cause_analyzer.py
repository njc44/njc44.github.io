#!/usr/bin/env python3
"""Root Cause Analyzer: Classify losses into categorical causes across a large corpus.

Works on any replay — ours or twins'. Builds a rolling corpus, classifies each loss,
computes frequency × impact = expected value for each root cause.

Usage:
    python root_cause_analyzer.py --download-ours 50       # Download 50 of our episodes
    python root_cause_analyzer.py --download-twin 16762101 50  # Download 50 from twin teamId
    python root_cause_analyzer.py --analyze                # Run analysis on all cached replays
    python root_cause_analyzer.py --full-pipeline          # Download all + analyze
"""
import argparse
import json
import subprocess
from collections import defaultdict
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
REPLAY_DIR = AUTOLOOP_DIR / "replays"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"
STATE_FILE = AUTOLOOP_DIR / "state.json"

# All known team names that are "us" or our twins
# (replays where both players are twins = mirror matches)
OUR_TEAM = "Nathan Jacob"

# Item → producing asset
ITEM_TO_ASSET = {
    "MILK": "COW", "WOOL": "SHEEP", "EGG": "GOOSE",
    "WHEAT": "WHEAT", "TOMATO": "TOMATO", "CARROT": "CARROT",
    "MELON": "MELON", "STRAWBERRY": "STRAWBERRY",
}

# ═══════════════════════════════════════════════════════════
# ROOT CAUSE TAXONOMY
# ═══════════════════════════════════════════════════════════
# Each root cause has:
#   - detector function(replay_data) → (detected: bool, details: dict)
#   - severity: how much money this typically costs

ROOT_CAUSES = [
    "cow_death_day1",       # COW dies on day 0-1 from not being fed
    "animal_death_late",    # Animal dies after day 1
    "asset_gap_animal",     # Opponent has more animals (not from death)
    "asset_gap_crop",       # Opponent has more crops planted
    "sell_timing",          # We have similar assets but lose on sell timing/price
    "shed_overflow",        # Shed hits 100, items wasted
    "worker_deficit",       # Fewer workers than opponent
    "fertilizer_gap",       # Opponent sells more fertilizer
    "idle_workers",         # High idle rate vs opponent
    "tape_mismatch",       # Different tape entirely (<50% early similarity)
    "late_divergence",      # Close game, diverges after day 15
    "unknown",              # Can't classify
]


def log(msg):
    print(f"[rca] {msg}", flush=True)


# ═══════════════════════════════════════════════════════════
# REPLAY PARSING (works for any player, not just "us")
# ═══════════════════════════════════════════════════════════

def identify_seats(replay, target_team=None):
    """Identify which seat belongs to target_team. Returns (target_seat, opp_seat, opp_name).
    If target_team is None, returns (0, 1, team1_name) — analyze from seat 0's perspective."""
    teams = replay.get("info", {}).get("TeamNames", [])
    if target_team:
        for i, name in enumerate(teams):
            if name.strip() == target_team.strip():
                opp = 1 - i
                return i, opp, teams[opp] if opp < len(teams) else "unknown"
    return 0, 1, teams[1] if len(teams) > 1 else "unknown"


def extract_game_data(replay, target_seat):
    """Extract all features needed for root cause classification."""
    steps = replay.get("steps", [])
    opp_seat = 1 - target_seat
    rewards = replay.get("rewards", [0, 0])
    target_reward = rewards[target_seat]
    opp_reward = rewards[opp_seat]
    margin = target_reward - opp_reward

    data = {
        "margin": margin,
        "target_reward": target_reward,
        "opp_reward": opp_reward,
        "result": "WIN" if margin > 0 else ("LOSS" if margin < 0 else "TIE"),
    }

    # Money curves
    money_us, money_opp = [], []
    for day in range(30):
        step_idx = day * 24
        if step_idx >= len(steps):
            break
        obs = steps[step_idx][0]["observation"]
        money_us.append(obs["farms"][target_seat]["money"])
        money_opp.append(obs["farms"][opp_seat]["money"])
    data["money_us"] = money_us
    data["money_opp"] = money_opp

    # Turning point
    margin_timeline = [u - o for u, o in zip(money_us, money_opp)]
    tp = None
    for i, m in enumerate(margin_timeline):
        if m < -500 and all(m2 <= 0 for m2 in margin_timeline[i:]):
            tp = i
            break
    data["turning_point"] = tp

    # Animal deaths
    deaths = {"us": [], "opp": []}
    for player_key, seat in [("us", target_seat), ("opp", opp_seat)]:
        for day in range(29):
            s_before = day * 24
            s_after = (day + 1) * 24
            if s_after >= len(steps):
                break
            farm_before = steps[s_before][0]["observation"]["farms"][seat]
            farm_after = steps[s_after][0]["observation"]["farms"][seat]
            for r in range(len(farm_before.get("tiles", []))):
                for c in range(len(farm_before["tiles"][r])):
                    tb = farm_before["tiles"][r][c]
                    ta = farm_after["tiles"][r][c]
                    if (isinstance(tb, dict) and "animal" in tb and
                            (not isinstance(ta, dict) or "animal" not in ta)):
                        deaths[player_key].append({
                            "day": day, "animal": tb["animal"],
                            "pos": [r, c], "unfed": tb.get("consecutive_unfed", 0)
                        })
    data["animal_deaths"] = deaths

    # Asset counts at day 15
    assets = {"us": defaultdict(int), "opp": defaultdict(int)}
    for player_key, seat in [("us", target_seat), ("opp", opp_seat)]:
        step_idx = min(15 * 24 + 12, len(steps) - 1)
        if step_idx >= 0:
            obs = steps[step_idx][0]["observation"]
            farm = obs["farms"][seat]
            for row in farm.get("tiles", []):
                for t in row:
                    if isinstance(t, dict):
                        if "animal" in t:
                            assets[player_key][t["animal"]] += 1
                        if "crop" in t:
                            assets[player_key][t["crop"]] += 1
    data["assets_day15"] = dict(assets)

    # Worker counts at day 15
    step_idx = min(15 * 24 + 12, len(steps) - 1)
    if step_idx >= 0:
        obs = steps[step_idx][0]["observation"]
        data["workers_us"] = 1 + len(obs["farms"][target_seat].get("hands", []))
        data["workers_opp"] = 1 + len(obs["farms"][opp_seat].get("hands", []))
    else:
        data["workers_us"] = data["workers_opp"] = 1

    # Sell quantities per item
    sell_qty = {"us": defaultdict(int), "opp": defaultdict(int)}
    for step_idx, step_data in enumerate(steps):
        for player_key, seat in [("us", target_seat), ("opp", opp_seat)]:
            action = step_data[seat].get("action") or {}
            for order in action.get("market", []):
                if order and len(order) >= 3 and order[0] == "SELL":
                    sell_qty[player_key][order[1]] += int(order[2])
    data["sell_qty"] = dict(sell_qty)

    # Shed overflow detection
    shed_overflow_days = []
    for day in range(30):
        step_idx = day * 24 + 23
        if step_idx >= len(steps):
            break
        private = steps[step_idx][target_seat].get("observation", {}).get("private", {})
        shed = private.get("shed", {})
        total = sum(v for v in shed.values() if isinstance(v, (int, float)))
        if total >= 100:
            shed_overflow_days.append(day)
    data["shed_overflow_days"] = shed_overflow_days

    # Early action similarity (first 144 steps = 6 days)
    matches = 0
    window = min(144, len(steps))
    for si in range(window):
        act_a = steps[si][target_seat].get("action", {}).get("market", [])
        act_b = steps[si][opp_seat].get("action", {}).get("market", [])
        if json.dumps(act_a, sort_keys=True) == json.dumps(act_b, sort_keys=True):
            matches += 1
    data["early_similarity"] = matches / window if window > 0 else 0

    # Shop combo
    for day in range(30):
        step_idx = min(day * 24 + 23, len(steps) - 1)
        obs = steps[step_idx][0]["observation"]
        shops = obs.get("town", {}).get("unlocked_shops", [])
        if len(shops) >= 2:
            unique = []
            for s in shops:
                if s not in unique:
                    unique.append(s)
            data["shop_combo"] = "+".join(unique[:3])
            break
    else:
        data["shop_combo"] = "unknown"

    # Idle rate (PASS actions during hours 0-21)
    for player_key, seat in [("us", target_seat), ("opp", opp_seat)]:
        pass_count = 0
        total_actions = 0
        for si, sd in enumerate(steps):
            if si % 24 >= 22:
                continue
            action = sd[seat].get("action") or {}
            farmer = action.get("farmer", [])
            total_actions += 1
            if farmer == ["PASS"] or farmer == "PASS":
                pass_count += 1
            for hand in action.get("hands", []):
                total_actions += 1
                if hand == ["PASS"] or hand == "PASS":
                    pass_count += 1
        data[f"idle_rate_{player_key}"] = round(pass_count / total_actions, 4) if total_actions else 0

    return data


# ═══════════════════════════════════════════════════════════
# ROOT CAUSE DETECTORS
# ═══════════════════════════════════════════════════════════

def classify_root_causes(game_data):
    """Classify a LOSS into one or more root causes. Returns list of (cause, confidence, details)."""
    causes = []

    # 1. Cow death on day 0-1
    our_deaths = game_data["animal_deaths"]["us"]
    early_cow_deaths = [d for d in our_deaths if d["animal"] == "COW" and d["day"] <= 1]
    opp_early_cow_deaths = [d for d in game_data["animal_deaths"]["opp"] if d["animal"] == "COW" and d["day"] <= 1]
    if early_cow_deaths and len(early_cow_deaths) > len(opp_early_cow_deaths):
        positions = [tuple(d["pos"]) for d in early_cow_deaths]
        causes.append(("cow_death_day1", 0.9, {
            "count": len(early_cow_deaths),
            "positions": positions,
            "opp_deaths": len(opp_early_cow_deaths),
            "est_impact": len(early_cow_deaths) * 15000,  # ~$15K per cow over 28 days of MILK
        }))

    # 2. Animal death after day 1
    late_deaths = [d for d in our_deaths if d["day"] > 1]
    opp_late_deaths = [d for d in game_data["animal_deaths"]["opp"] if d["day"] > 1]
    if len(late_deaths) > len(opp_late_deaths):
        causes.append(("animal_death_late", 0.7, {
            "count": len(late_deaths),
            "animals": [d["animal"] for d in late_deaths],
            "days": [d["day"] for d in late_deaths],
        }))

    # 3. Asset gap — animals
    our_animals = game_data["assets_day15"]["us"]
    opp_animals = game_data["assets_day15"]["opp"]
    animal_types = {"COW", "SHEEP", "GOOSE"}
    animal_gap = {}
    for a in animal_types:
        gap = opp_animals.get(a, 0) - our_animals.get(a, 0)
        if gap > 0:
            animal_gap[a] = gap
    # Only flag if there's a meaningful gap AND it wasn't caused by deaths we already counted
    death_animals = defaultdict(int)
    for d in our_deaths:
        death_animals[d["animal"]] += 1
    non_death_gap = {a: g for a, g in animal_gap.items() if g > death_animals.get(a, 0)}
    if non_death_gap:
        causes.append(("asset_gap_animal", 0.6, {
            "gaps": non_death_gap,
            "total_gap": sum(non_death_gap.values()),
        }))

    # 4. Asset gap — crops
    crop_types = {"WHEAT", "TOMATO", "CARROT", "MELON", "STRAWBERRY"}
    crop_gap = {}
    for c in crop_types:
        gap = opp_animals.get(c, 0) - our_animals.get(c, 0)
        if gap > 2:  # small crop differences are noise
            crop_gap[c] = gap
    if crop_gap:
        causes.append(("asset_gap_crop", 0.5, {
            "gaps": crop_gap,
            "total_gap": sum(crop_gap.values()),
        }))

    # 5. Sell timing — similar assets but opponent earns more
    our_sq = game_data["sell_qty"]["us"]
    opp_sq = game_data["sell_qty"]["opp"]
    # If assets are similar but sell quantities differ significantly
    if not animal_gap and not crop_gap:
        fert_gap = opp_sq.get("FERTILIZER", 0) - our_sq.get("FERTILIZER", 0)
        if fert_gap > 5:
            causes.append(("fertilizer_gap", 0.6, {
                "us_fert": our_sq.get("FERTILIZER", 0),
                "opp_fert": opp_sq.get("FERTILIZER", 0),
                "gap": fert_gap,
            }))
        elif abs(game_data["margin"]) > 1000:
            causes.append(("sell_timing", 0.4, {
                "margin": game_data["margin"],
                "sell_qty_diff": {k: opp_sq.get(k, 0) - our_sq.get(k, 0)
                                  for k in set(list(our_sq.keys()) + list(opp_sq.keys()))
                                  if abs(opp_sq.get(k, 0) - our_sq.get(k, 0)) > 2},
            }))

    # 6. Shed overflow
    if game_data["shed_overflow_days"]:
        causes.append(("shed_overflow", 0.5, {
            "days": game_data["shed_overflow_days"],
            "count": len(game_data["shed_overflow_days"]),
        }))

    # 7. Worker deficit
    w_diff = game_data["workers_opp"] - game_data["workers_us"]
    if w_diff >= 2:
        causes.append(("worker_deficit", 0.6, {
            "us": game_data["workers_us"],
            "opp": game_data["workers_opp"],
            "gap": w_diff,
        }))

    # 8. Fertilizer gap (even when assets differ)
    fert_gap = opp_sq.get("FERTILIZER", 0) - our_sq.get("FERTILIZER", 0)
    if fert_gap > 10 and not any(c[0] == "fertilizer_gap" for c in causes):
        causes.append(("fertilizer_gap", 0.5, {
            "us_fert": our_sq.get("FERTILIZER", 0),
            "opp_fert": opp_sq.get("FERTILIZER", 0),
            "gap": fert_gap,
        }))

    # 9. Idle workers
    idle_diff = game_data["idle_rate_us"] - game_data["idle_rate_opp"]
    if idle_diff > 0.05:  # 5%+ more idle than opponent
        causes.append(("idle_workers", 0.4, {
            "us_idle": game_data["idle_rate_us"],
            "opp_idle": game_data["idle_rate_opp"],
            "diff": round(idle_diff, 4),
        }))

    # 10. Tape mismatch
    if game_data["early_similarity"] < 0.5:
        causes.append(("tape_mismatch", 0.3, {
            "similarity": game_data["early_similarity"],
        }))

    # 11. Late divergence
    tp = game_data["turning_point"]
    if tp and tp >= 15 and abs(game_data["margin"]) < 10000:
        causes.append(("late_divergence", 0.4, {
            "turning_point": tp,
            "margin": game_data["margin"],
        }))

    # 12. Unknown
    if not causes:
        causes.append(("unknown", 0.1, {
            "margin": game_data["margin"],
            "note": "No detectable root cause pattern",
        }))

    # Sort by confidence
    causes.sort(key=lambda x: x[1], reverse=True)
    return causes


# ═══════════════════════════════════════════════════════════
# TWIN FINGERPRINTING
# ═══════════════════════════════════════════════════════════

def fingerprint_player(steps, seat, window=144):
    """Generate a fingerprint from market actions in first 144 steps.
    Returns a hashable tuple for grouping twins."""
    actions = []
    for si in range(min(window, len(steps))):
        market = steps[si][seat].get("action", {}).get("market", [])
        actions.append(json.dumps(market, sort_keys=True))
    return tuple(actions)


def compute_similarity(fp1, fp2):
    """Fraction of matching entries between two fingerprints."""
    if len(fp1) != len(fp2):
        return 0.0
    matches = sum(1 for a, b in zip(fp1, fp2) if a == b)
    return matches / len(fp1) if fp1 else 0.0


# ═══════════════════════════════════════════════════════════
# CORPUS MANAGEMENT
# ═══════════════════════════════════════════════════════════

def download_episodes(submission_id, max_eps=50):
    """Download episodes for a submission, return list of episode IDs."""
    result = subprocess.run(
        ["kaggle", "competitions", "episodes", str(submission_id)],
        capture_output=True, text=True, timeout=30
    )
    episodes = []
    for line in result.stdout.strip().split("\n"):
        parts = line.strip().split()
        if parts and parts[0].isdigit():
            episodes.append(int(parts[0]))
    return episodes[:max_eps]


def download_replay(episode_id):
    """Download and cache a single replay."""
    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    cached = REPLAY_DIR / f"{episode_id}.json"
    if cached.exists():
        return cached
    try:
        subprocess.run(
            ["kaggle", "competitions", "replay", str(episode_id),
             "-p", str(REPLAY_DIR.resolve()), "-q"],
            capture_output=True, text=True, timeout=60
        )
        downloaded = REPLAY_DIR / f"episode-{episode_id}-replay.json"
        if downloaded.exists():
            downloaded.rename(cached)
            return cached
        if cached.exists():
            return cached
        return None
    except Exception:
        return None


def get_team_submissions(team_id):
    """Get submission IDs for a team."""
    result = subprocess.run(
        ["kaggle", "competitions", "team-submissions", str(team_id), "--format", "json"],
        capture_output=True, text=True, timeout=15
    )
    # Handle pagination token in output
    lines = result.stdout.strip().split("\n")
    json_lines = []
    for line in lines:
        if line.startswith("Next Page Token"):
            continue
        json_lines.append(line)
    json_text = "\n".join(json_lines)
    try:
        subs = json.loads(json_text)
        return [(s.get("ref", s.get("id")), s.get("publicScore", "?")) for s in subs]
    except Exception:
        # Fall back to table parsing
        subs = []
        for line in result.stdout.strip().split("\n"):
            parts = line.strip().split()
            if parts and parts[0].isdigit():
                subs.append((int(parts[0]), "?"))
        return subs


# ═══════════════════════════════════════════════════════════
# MAIN ANALYSIS
# ═══════════════════════════════════════════════════════════

def analyze_corpus(target_team=None, twin_names=None):
    """Analyze all cached replays from target_team's perspective.

    Also analyzes games where known twins are playing (from their perspective).
    """
    if twin_names is None:
        twin_names = set()
    if target_team:
        twin_names.add(target_team)

    replay_files = sorted(REPLAY_DIR.glob("*.json"))
    log(f"Analyzing {len(replay_files)} cached replays...")

    all_games = []       # Every game record
    all_losses = []      # Only losses
    fingerprints = {}    # team_name -> fingerprint (from first game seen)

    for replay_file in replay_files:
        try:
            replay = json.load(open(replay_file))
        except Exception:
            continue

        teams = replay.get("info", {}).get("TeamNames", [])
        if len(teams) < 2:
            continue

        episode_id = replay_file.stem
        steps = replay.get("steps", [])

        # Determine which perspective(s) to analyze from
        perspectives = []
        for i, team in enumerate(teams):
            if team.strip() in twin_names:
                perspectives.append((i, team.strip()))

        # If neither player is us/twin, check fingerprint similarity
        if not perspectives:
            # Fingerprint both and check against known twins
            for i, team in enumerate(teams):
                fp = fingerprint_player(steps, i)
                fingerprints.setdefault(team, fp)
                # Check similarity against known twin fingerprints
                for known_twin in twin_names:
                    if known_twin in fingerprints:
                        sim = compute_similarity(fp, fingerprints[known_twin])
                        if sim >= 0.9:
                            perspectives.append((i, team.strip()))
                            twin_names.add(team.strip())
                            log(f"  Discovered new twin: {team} (sim={sim:.0%})")
                            break

        if not perspectives:
            # Still useful — fingerprint for future matching
            for i, team in enumerate(teams):
                fp = fingerprint_player(steps, i)
                fingerprints.setdefault(team.strip(), fp)
            continue

        for target_seat, team_name in perspectives:
            opp_seat = 1 - target_seat
            opp_name = teams[opp_seat].strip()

            # Fingerprint both players
            fp_target = fingerprint_player(steps, target_seat)
            fp_opp = fingerprint_player(steps, opp_seat)
            fingerprints.setdefault(team_name, fp_target)
            fingerprints.setdefault(opp_name, fp_opp)

            # Check if opponent is also a twin (mirror match)
            opp_is_twin = opp_name in twin_names
            if not opp_is_twin:
                for known_twin in list(twin_names):
                    if known_twin in fingerprints:
                        sim = compute_similarity(fp_opp, fingerprints[known_twin])
                        if sim >= 0.9:
                            opp_is_twin = True
                            twin_names.add(opp_name)
                            log(f"  Discovered new twin: {opp_name} (sim={sim:.0%})")
                            break

            game_data = extract_game_data(replay, target_seat)
            game_data["episode_id"] = episode_id
            game_data["team"] = team_name
            game_data["opponent"] = opp_name
            game_data["opp_is_twin"] = opp_is_twin

            all_games.append(game_data)

            if game_data["result"] == "LOSS":
                root_causes = classify_root_causes(game_data)
                game_data["root_causes"] = root_causes
                all_losses.append(game_data)

    return all_games, all_losses, twin_names, fingerprints


def compute_statistics(all_games, all_losses):
    """Compute frequency, impact, and expected value for each root cause."""
    n_games = len(all_games)
    n_losses = len(all_losses)
    n_wins = sum(1 for g in all_games if g["result"] == "WIN")
    n_ties = sum(1 for g in all_games if g["result"] == "TIE")

    # Count root cause frequencies
    cause_counts = defaultdict(int)
    cause_margins = defaultdict(list)
    cause_details = defaultdict(list)

    for loss in all_losses:
        primary_cause = loss["root_causes"][0][0] if loss["root_causes"] else "unknown"
        cause_counts[primary_cause] += 1
        cause_margins[primary_cause].append(abs(loss["margin"]))
        cause_details[primary_cause].append({
            "episode": loss["episode_id"],
            "opponent": loss["opponent"],
            "margin": loss["margin"],
            "shop_combo": loss["shop_combo"],
            "details": loss["root_causes"][0][2] if loss["root_causes"] else {},
        })

    # Also count ALL causes (not just primary)
    all_cause_counts = defaultdict(int)
    for loss in all_losses:
        for cause, conf, details in loss["root_causes"]:
            all_cause_counts[cause] += 1

    # Rank by COUNT (each loss = same Elo hit regardless of margin)
    cause_ev = {}
    for cause in set(list(cause_counts.keys()) + list(all_cause_counts.keys())):
        freq_primary = cause_counts.get(cause, 0) / n_losses if n_losses > 0 else 0
        freq_any = all_cause_counts.get(cause, 0) / n_losses if n_losses > 0 else 0
        avg_margin = sum(cause_margins.get(cause, [0])) / len(cause_margins.get(cause, [1])) if cause_margins.get(cause) else 0

        cause_ev[cause] = {
            "primary_count": cause_counts.get(cause, 0),
            "any_count": all_cause_counts.get(cause, 0),
            "primary_freq": round(freq_primary, 3),
            "any_freq": round(freq_any, 3),
            "avg_margin_when_primary": round(avg_margin),
            # Elo impact = count of losses this causes (margin irrelevant)
            "elo_impact": cause_counts.get(cause, 0),
            "examples": cause_details.get(cause, [])[:5],
        }

    # Sort by count (most frequent = most Elo impact)
    cause_ev = dict(sorted(cause_ev.items(), key=lambda x: x[1]["primary_count"], reverse=True))

    # Shop combo breakdown
    shop_stats = defaultdict(lambda: {"W": 0, "L": 0, "T": 0, "margins": []})
    for game in all_games:
        combo = game["shop_combo"]
        r = game["result"][0]
        shop_stats[combo][r] += 1
        if game["result"] == "LOSS":
            shop_stats[combo]["margins"].append(game["margin"])

    return {
        "n_games": n_games,
        "n_wins": n_wins,
        "n_losses": n_losses,
        "n_ties": n_ties,
        "win_rate": round(n_wins / n_games, 3) if n_games > 0 else 0,
        "avg_loss_margin": round(sum(abs(l["margin"]) for l in all_losses) / n_losses) if n_losses > 0 else 0,
        "cause_ev": cause_ev,
        "shop_stats": {k: {kk: vv for kk, vv in v.items() if kk != "margins"}
                       for k, v in shop_stats.items()},
        "shop_loss_margins": {k: {"avg": round(sum(v["margins"]) / len(v["margins"])) if v["margins"] else 0,
                                   "count": len(v["margins"])}
                              for k, v in shop_stats.items() if v["margins"]},
    }


def format_report(stats, twin_names):
    """Format a human-readable report."""
    lines = []
    lines.append("=" * 70)
    lines.append("  ROOT CAUSE ANALYSIS — STATISTICAL REPORT")
    lines.append("=" * 70)
    lines.append(f"Games analyzed: {stats['n_games']} ({stats['n_wins']}W / {stats['n_losses']}L / {stats['n_ties']}T)")
    lines.append(f"Win rate: {stats['win_rate']:.1%}")
    lines.append(f"Avg loss margin: ${stats['avg_loss_margin']:,}")
    lines.append(f"Twin network: {len(twin_names)} teams")
    lines.append("")

    lines.append("-" * 70)
    lines.append("ROOT CAUSES RANKED BY ELO IMPACT (count of losses — margin is irrelevant)")
    lines.append("-" * 70)

    for cause, data in stats["cause_ev"].items():
        if data["primary_count"] == 0:
            continue
        lines.append(f"\n  {cause}")
        lines.append(f"    Primary in: {data['primary_count']}/{stats['n_losses']} losses ({data['primary_freq']:.0%})")
        lines.append(f"    Present in: {data['any_count']}/{stats['n_losses']} losses ({data['any_freq']:.0%})")
        lines.append(f"    Elo impact: {data['elo_impact']} losses (each = same Elo hit)")
        lines.append(f"    Avg margin: ${data['avg_margin_when_primary']:,} (informational only)")
        # Show examples
        for ex in data["examples"][:3]:
            lines.append(f"      eg: vs {ex['opponent']} in {ex['shop_combo']} (${ex['margin']:,})")
            if ex.get("details"):
                for k, v in list(ex["details"].items())[:2]:
                    lines.append(f"          {k}: {v}")

    lines.append("")
    lines.append("-" * 70)
    lines.append("SHOP COMBO PERFORMANCE (losses)")
    lines.append("-" * 70)
    for combo, data in sorted(stats.get("shop_loss_margins", {}).items(),
                               key=lambda x: x[1]["avg"]):
        w = stats["shop_stats"].get(combo, {}).get("W", 0)
        l = stats["shop_stats"].get(combo, {}).get("L", 0)
        t = stats["shop_stats"].get(combo, {}).get("T", 0)
        lines.append(f"  {combo:40s} {w}W/{l}L/{t}T  avg loss: ${data['avg']:,}")

    lines.append("")
    lines.append("=" * 70)
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Root Cause Analyzer")
    parser.add_argument("--analyze", action="store_true", help="Analyze all cached replays")
    parser.add_argument("--download-ours", type=int, metavar="N", help="Download N of our episodes per submission")
    parser.add_argument("--download-twin", nargs=2, metavar=("TEAM_ID", "N"), help="Download N episodes from twin team")
    parser.add_argument("--full-pipeline", action="store_true", help="Download all + analyze")
    args = parser.parse_args()

    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    CORPUS_DIR.mkdir(parents=True, exist_ok=True)

    # Known twins from earlier analysis
    twin_names = {
        "Nathan Jacob",
        "Kazama Yusuke", "Zhongyi Dai", "Peng Wang", "Munal Singh",
        "Chris Deotte", "Pilkwang Kim", "Quickpanda", "Luvsh81", "Naru041104",
    }

    if args.download_ours or args.full_pipeline:
        n = args.download_ours or 100
        our_subs = [56216059, 56211878, 56218744]  # Top scoring submissions
        for sid in our_subs:
            eps = download_episodes(sid, n)
            log(f"Downloading {len(eps)} episodes from our sub {sid}...")
            for i, ep in enumerate(eps):
                download_replay(ep)
                if (i + 1) % 25 == 0:
                    log(f"  {i+1}/{len(eps)}")
            log(f"  Done: {len(eps)} episodes")

    if args.download_twin:
        team_id, n = int(args.download_twin[0]), int(args.download_twin[1])
        subs = get_team_submissions(team_id)
        for sid, score in subs:
            eps = download_episodes(sid, n)
            log(f"Downloading {len(eps)} episodes from twin sub {sid} (score={score})...")
            for i, ep in enumerate(eps):
                download_replay(ep)
                if (i + 1) % 25 == 0:
                    log(f"  {i+1}/{len(eps)}")
            log(f"  Done: {len(eps)} episodes")

    if args.analyze or args.full_pipeline:
        all_games, all_losses, discovered_twins, fingerprints = analyze_corpus(
            target_team=OUR_TEAM, twin_names=twin_names
        )

        stats = compute_statistics(all_games, all_losses)

        # Save results
        report = format_report(stats, discovered_twins)
        print(report)

        output_file = CORPUS_DIR / "rca_report.txt"
        with open(output_file, "w") as f:
            f.write(report)

        stats_file = CORPUS_DIR / "rca_stats.json"
        # Remove non-serializable examples details for JSON
        stats_clean = json.loads(json.dumps(stats, default=str))
        with open(stats_file, "w") as f:
            json.dump(stats_clean, f, indent=2)

        corpus_file = CORPUS_DIR / "rca_losses.json"
        losses_clean = []
        for loss in all_losses:
            losses_clean.append({
                "episode_id": loss["episode_id"],
                "team": loss["team"],
                "opponent": loss["opponent"],
                "opp_is_twin": loss["opp_is_twin"],
                "margin": loss["margin"],
                "shop_combo": loss["shop_combo"],
                "turning_point": loss["turning_point"],
                "early_similarity": loss["early_similarity"],
                "root_causes": [(c, conf, str(d)) for c, conf, d in loss["root_causes"]],
            })
        with open(corpus_file, "w") as f:
            json.dump(losses_clean, f, indent=2)

        log(f"\nSaved: {output_file}, {stats_file}, {corpus_file}")
        log(f"Discovered {len(discovered_twins)} twins total: {sorted(discovered_twins)}")


if __name__ == "__main__":
    main()
