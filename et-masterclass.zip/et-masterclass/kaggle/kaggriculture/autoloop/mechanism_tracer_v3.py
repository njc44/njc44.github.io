#!/usr/bin/env python3
"""Mechanism Tracer v3: Step-level analysis with market microstructure awareness.

Upgrades over v2:
1. Fix seat detection (use our_seat from colosseum replays)
2. Step-level checkpoints (steps 0-5 individually, then daily)
3. Market order list sequence comparison (index position, frontload detection)
4. Price impact simulation (who profits from each order list)

Designed to discover the mechanisms Ahmed found in v45→v46 that v2 missed.
"""
import json
import math
from collections import defaultdict
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# MARKET PRICE MODEL (exact Kaggle formula from R37)
# ═══════════════════════════════════════════════════════════

_PRICE_FLOOR = 1
_HINGE_GAIN = 8.0
_MARKET_PARAMS = {
    "WHEAT":      {"base":  25, "I0": 10000, "T": 400, "below_func": "sqrt",   "below_target": 0.80, "above_func": "log",    "above_target": 0.20},
    "CARROT":     {"base":  35, "I0": 10000, "T": 450, "below_func": "hinge",  "below_target": 1.00, "above_func": "sqrt",   "above_target": 0.70},
    "TOMATO":     {"base":  60, "I0": 10000, "T": 200, "below_func": "hinge",  "below_target": 0.40, "above_func": "sqrt",   "above_target": 0.60},
    "STRAWBERRY": {"base": 120, "I0": 10000, "T": 100, "below_func": "sqrt",   "below_target": 0.70, "above_func": "linear", "above_target": 1.60},
    "MELON":      {"base": 250, "I0": 10000, "T": 300, "below_func": "log",    "below_target": 0.20, "above_func": "sq",     "above_target": 3.60},
    "EGG":        {"base":  50, "I0": 10000, "T": 332, "below_func": "hinge",  "below_target": 0.40, "above_func": "log",    "above_target": 0.20},
    "MILK":       {"base": 160, "I0": 10000, "T": 122, "below_func": "sqrt",   "below_target": 0.60, "above_func": "linear", "above_target": 1.60},
    "WOOL":       {"base": 200, "I0": 10000, "T": 105, "below_func": "log",    "below_target": 0.20, "above_func": "sq",     "above_target": 3.20},
    "FERTILIZER": {"base": 100, "I0": 10000, "T": 200, "below_func": "linear", "below_target": 0.40, "above_func": "linear", "above_target": 0.40},
}


def _shape(func, x, T=None):
    x = max(0.0, x)
    if func == "linear": return x
    if func == "sq": return x * x
    if func == "sqrt": return math.sqrt(x)
    if func == "log": return math.log(1.0 + x)
    if func == "hinge":
        if not T or T <= 0: return x
        u = x / T
        return u + _HINGE_GAIN * max(0.0, u - 1.0) ** 2
    return x


def market_price(item, inventory):
    """Compute exact market price for an item at given inventory level."""
    p = _MARKET_PARAMS[item]
    base, I0, T = p["base"], p["I0"], p["T"]
    if inventory < I0:
        amp = p["below_target"] * base / _shape(p["below_func"], T, T)
        v = base + amp * _shape(p["below_func"], I0 - inventory, T)
    else:
        amp = p["above_target"] * base / _shape(p["above_func"], T, T)
        v = base - amp * _shape(p["above_func"], inventory - I0, T)
    return max(_PRICE_FLOOR, int(round(v)))


def simulate_lockstep_orders(orders_a, orders_b, inventory):
    """Simulate lockstep market settlement for two players' order lists.

    The engine processes both players' orders index-by-index:
    - At index i, both players' order[i] executes against the SAME inventory
    - BUY decreases inventory (price goes up for subsequent buys)
    - SELL increases inventory (price goes down for subsequent sells)

    Returns: dict with per-player revenue, cost, net, and per-order details.
    """
    inv = dict(inventory)
    results = {"a": {"revenue": 0, "cost": 0, "details": []}, "b": {"revenue": 0, "cost": 0, "details": []}}
    max_idx = max(len(orders_a), len(orders_b))

    for idx in range(max_idx):
        for player, orders, key in [("a", orders_a, "a"), ("b", orders_b, "b")]:
            if idx >= len(orders):
                continue
            o = orders[idx]
            if not o or len(o) < 3:
                continue
            op, item = o[0], o[1]
            try:
                qty = int(o[2])
            except (ValueError, IndexError):
                continue

            if item not in _MARKET_PARAMS:
                continue

            if op == "SELL":
                total = 0
                for _ in range(qty):
                    p = market_price(item, inv.get(item, 10000))
                    total += p
                    if p > 1:
                        inv[item] = inv.get(item, 10000) + 1
                results[key]["revenue"] += total
                results[key]["details"].append({"op": "SELL", "item": item, "qty": qty, "total": total, "avg_price": total / max(1, qty)})
            elif op == "BUY_PRODUCT":
                total = 0
                for _ in range(qty):
                    p = market_price(item, inv.get(item, 10000) - 1)
                    total += p
                    inv[item] = inv.get(item, 10000) - 1
                results[key]["cost"] += total
                results[key]["details"].append({"op": "BUY", "item": item, "qty": qty, "total": total, "avg_price": total / max(1, qty)})

    results["a"]["net"] = results["a"]["revenue"] - results["a"]["cost"]
    results["b"]["net"] = results["b"]["revenue"] - results["b"]["cost"]
    results["advantage_a"] = results["a"]["net"] - results["b"]["net"]
    return results


# ═══════════════════════════════════════════════════════════
# STEP-LEVEL ANALYSIS
# ═══════════════════════════════════════════════════════════

def analyze_step(steps, our_seat, opp_seat, step_idx):
    """Detailed analysis of a single step's market orders."""
    if step_idx >= len(steps):
        return None

    our_action = steps[step_idx][our_seat].get("action") or {}
    opp_action = steps[step_idx][opp_seat].get("action") or {}
    our_market = our_action.get("market", [])
    opp_market = opp_action.get("market", [])
    obs = steps[step_idx][0].get("observation", {})
    inventory = {k: int(v) for k, v in obs.get("market", {}).get("inventory", {}).items()}

    analysis = {
        "step": step_idx,
        "day": step_idx // 24,
        "hour": step_idx % 24,
        "our_orders": our_market,
        "opp_orders": opp_market,
        "orders_identical": json.dumps(our_market, sort_keys=True) == json.dumps(opp_market, sort_keys=True),
    }

    if not analysis["orders_identical"] and our_market and opp_market:
        # Simulate price impact
        sim = simulate_lockstep_orders(our_market, opp_market, inventory)
        analysis["our_net"] = sim["a"]["net"]
        analysis["opp_net"] = sim["b"]["net"]
        analysis["advantage"] = sim["advantage_a"]
        analysis["our_details"] = sim["a"]["details"]
        analysis["opp_details"] = sim["b"]["details"]

        # Check for frontload difference (same orders, different sequence)
        our_ops = sorted([json.dumps(o) for o in our_market])
        opp_ops = sorted([json.dumps(o) for o in opp_market])
        analysis["same_orders_different_sequence"] = (our_ops == opp_ops and our_market != opp_market)

        # Check sell-before-buy pattern
        def has_frontloaded_sells(orders):
            first_buy_idx = next((i for i, o in enumerate(orders) if o and o[0] in ("BUY_PRODUCT",)), len(orders))
            last_sell_idx = max((i for i, o in enumerate(orders) if o and o[0] == "SELL"), default=-1)
            return last_sell_idx < first_buy_idx if first_buy_idx < len(orders) and last_sell_idx >= 0 else None

        analysis["our_frontloaded"] = has_frontloaded_sells(our_market)
        analysis["opp_frontloaded"] = has_frontloaded_sells(opp_market)

    return analysis


def trace_game_v3(replay, outcome="loss"):
    """Full step-level mechanism trace for one game.

    Improvements over v2:
    - Uses our_seat from replay (fixes 50% failure rate)
    - Step-level analysis for steps 0-10
    - Market price impact simulation
    - Order sequence detection (frontload, index position)
    """
    steps = replay.get("steps", [])
    rewards = replay.get("rewards", [0, 0])
    our_seat = replay.get("our_seat", 0)
    opp_seat = 1 - our_seat
    margin = rewards[our_seat] - rewards[opp_seat]

    if not steps:
        return None

    # Filter by outcome
    if outcome == "loss" and margin >= 0:
        return None
    elif outcome == "win" and margin <= 0:
        return None

    # ─── Step-level analysis (steps 0-10) ───
    step_analyses = []
    opening_advantage = 0
    for si in range(min(11, len(steps))):
        sa = analyze_step(steps, our_seat, opp_seat, si)
        if sa and not sa["orders_identical"]:
            step_analyses.append(sa)
            opening_advantage += sa.get("advantage", 0)

    # ─── Classify opening mechanism ───
    opening_mechanisms = []
    for sa in step_analyses:
        if sa["step"] <= 2:
            if sa.get("same_orders_different_sequence"):
                opening_mechanisms.append({
                    "type": "MARKET/order_sequence",
                    "step": sa["step"],
                    "detail": f"Same orders, different index positions. Our net: ${sa.get('our_net', 0):+.0f}, Opp net: ${sa.get('opp_net', 0):+.0f}",
                    "advantage": sa.get("advantage", 0),
                })
            elif sa.get("opp_frontloaded") and not sa.get("our_frontloaded"):
                opening_mechanisms.append({
                    "type": "MARKET/frontload_missing",
                    "step": sa["step"],
                    "detail": "Opponent frontloads SELLs before BUYs, we don't",
                    "advantage": sa.get("advantage", 0),
                })
            else:
                # Different order quantities/types
                our_buys = sum(int(o[2]) for o in sa["our_orders"] if o and o[0] == "BUY_PRODUCT" and len(o) >= 3)
                opp_buys = sum(int(o[2]) for o in sa["opp_orders"] if o and o[0] == "BUY_PRODUCT" and len(o) >= 3)
                our_sells = sum(int(o[2]) for o in sa["our_orders"] if o and o[0] == "SELL" and len(o) >= 3)
                opp_sells = sum(int(o[2]) for o in sa["opp_orders"] if o and o[0] == "SELL" and len(o) >= 3)
                opening_mechanisms.append({
                    "type": "MARKET/opening_microstructure",
                    "step": sa["step"],
                    "detail": f"Us: BUY {our_buys}/SELL {our_sells}, Opp: BUY {opp_buys}/SELL {opp_sells}. Cash impact: ${sa.get('advantage', 0):+.0f}",
                    "advantage": sa.get("advantage", 0),
                    "our_orders": sa["our_orders"],
                    "opp_orders": sa["opp_orders"],
                })

    # ─── Mid-game sell timing analysis (steps 24-696) ───
    sell_timing_diffs = []
    for si in range(24, min(696, len(steps))):
        our_action = steps[si][our_seat].get("action") or {}
        opp_action = steps[si][opp_seat].get("action") or {}
        our_sells = {o[1]: int(o[2]) for o in our_action.get("market", []) if o and o[0] == "SELL" and len(o) >= 3}
        opp_sells = {o[1]: int(o[2]) for o in opp_action.get("market", []) if o and o[0] == "SELL" and len(o) >= 3}

        # Opponent sells something we don't (or sells more)
        for item in set(list(opp_sells.keys()) + list(our_sells.keys())):
            diff = opp_sells.get(item, 0) - our_sells.get(item, 0)
            if diff > 0:
                sell_timing_diffs.append({
                    "step": si, "day": si // 24, "hour": si % 24,
                    "item": item, "opp_qty": opp_sells.get(item, 0), "our_qty": our_sells.get(item, 0),
                    "extra": diff,
                })

    # Aggregate sell timing by item
    sell_timing_by_item = defaultdict(lambda: {"count": 0, "total_extra": 0, "first_step": 999, "steps": []})
    for d in sell_timing_diffs:
        item = d["item"]
        sell_timing_by_item[item]["count"] += 1
        sell_timing_by_item[item]["total_extra"] += d["extra"]
        sell_timing_by_item[item]["first_step"] = min(sell_timing_by_item[item]["first_step"], d["step"])
        if len(sell_timing_by_item[item]["steps"]) < 5:
            sell_timing_by_item[item]["steps"].append(d["step"])

    # ─── Frontload analysis (steps 144+) ───
    frontload_misses = 0
    frontload_total = 0
    for si in range(144, min(696, len(steps))):
        our_action = steps[si][our_seat].get("action") or {}
        opp_action = steps[si][opp_seat].get("action") or {}
        our_market = our_action.get("market", [])
        opp_market = opp_action.get("market", [])
        if len(our_market) >= 2 and len(opp_market) >= 2:
            frontload_total += 1
            our_sells_first = all(o[0] != "BUY_PRODUCT" for o in our_market[:1] if o)
            opp_sells_first = all(o[0] != "BUY_PRODUCT" for o in opp_market[:1] if o)
            if opp_sells_first and not our_sells_first:
                frontload_misses += 1

    # ─── Cash tracking per step (first 10 steps) ───
    cash_trace = []
    for si in range(min(11, len(steps))):
        obs = steps[si][0].get("observation", {})
        our_cash = obs.get("farms", [{}, {}])[our_seat].get("money", 0)
        opp_cash = obs.get("farms", [{}, {}])[opp_seat].get("money", 0)
        cash_trace.append({"step": si, "our_cash": our_cash, "opp_cash": opp_cash, "gap": opp_cash - our_cash})

    # ─── Build result ───
    return {
        "margin": margin,
        "our_seat": our_seat,
        "opening_advantage": opening_advantage,
        "opening_mechanisms": opening_mechanisms,
        "sell_timing_by_item": {k: dict(v) for k, v in sell_timing_by_item.items()},
        "frontload_misses": frontload_misses,
        "frontload_total": frontload_total,
        "cash_trace": cash_trace,
        "step_analyses": step_analyses,
        "n_sell_timing_diffs": len(sell_timing_diffs),
    }


def analyze_losses_v3(losses_dir):
    """Run v3 analysis on all loss replays in a directory."""
    losses_dir = Path(losses_dir)
    traces = []

    for fpath in sorted(losses_dir.glob("*.json")):
        with open(fpath) as f:
            replay = json.load(f)
        trace = trace_game_v3(replay, outcome="loss")
        if trace:
            traces.append(trace)

    if not traces:
        print("No traces produced!")
        return

    print(f"Traced {len(traces)} losses")
    print("=" * 100)

    # Opening analysis
    print("\n── OPENING MECHANISMS (steps 0-2) ──")
    all_opening = []
    for t in traces:
        all_opening.extend(t.get("opening_mechanisms", []))

    type_counts = defaultdict(int)
    type_advantages = defaultdict(list)
    for m in all_opening:
        type_counts[m["type"]] += 1
        type_advantages[m["type"]].append(m.get("advantage", 0))

    for mtype, count in sorted(type_counts.items(), key=lambda x: -x[1]):
        avg_adv = sum(type_advantages[mtype]) / len(type_advantages[mtype]) if type_advantages[mtype] else 0
        print(f"  {mtype:.<50} {count:>3} occurrences, avg cash impact: ${avg_adv:+.0f}")
        # Show first example
        for m in all_opening:
            if m["type"] == mtype:
                print(f"    Step {m['step']}: {m['detail']}")
                if "our_orders" in m:
                    print(f"    Us:  {json.dumps(m['our_orders'])[:100]}")
                    print(f"    Opp: {json.dumps(m['opp_orders'])[:100]}")
                break

    # Cash trace (averaged)
    print("\n── CASH TRACE (steps 0-10, averaged) ──")
    avg_cash = defaultdict(lambda: {"gap": 0, "n": 0})
    for t in traces:
        for ct in t.get("cash_trace", []):
            avg_cash[ct["step"]]["gap"] += ct["gap"]
            avg_cash[ct["step"]]["n"] += 1
    for si in sorted(avg_cash.keys()):
        c = avg_cash[si]
        print(f"  Step {si:>2}: opponent cash advantage ${c['gap']/c['n']:>+8.1f}")

    # Sell timing
    print("\n── SELL TIMING DIFFERENCES (steps 24-696) ──")
    combined = defaultdict(lambda: {"count": 0, "total_extra": 0})
    for t in traces:
        for item, data in t.get("sell_timing_by_item", {}).items():
            combined[item]["count"] += data["count"]
            combined[item]["total_extra"] += data["total_extra"]

    for item, data in sorted(combined.items(), key=lambda x: -x[1]["count"]):
        avg_extra = data["total_extra"] / data["count"] if data["count"] else 0
        print(f"  {item:.<20} {data['count']:>4} steps where opp sells more (avg +{avg_extra:.1f} units)")

    # Frontload
    total_misses = sum(t.get("frontload_misses", 0) for t in traces)
    total_checks = sum(t.get("frontload_total", 0) for t in traces)
    print(f"\n── FRONTLOAD ──")
    print(f"  Opponent frontloaded when we didn't: {total_misses}/{total_checks} turns ({total_misses/max(1,total_checks)*100:.1f}%)")

    # Overall opening advantage
    avg_opening = sum(t["opening_advantage"] for t in traces) / len(traces)
    print(f"\n── SUMMARY ──")
    print(f"  Average opening cash disadvantage (steps 0-10): ${avg_opening:+.0f}")
    print(f"  Average game margin: ${sum(t['margin'] for t in traces)/len(traces):+.0f}")
    print(f"  Sell timing diffs per game: {sum(t['n_sell_timing_diffs'] for t in traces)/len(traces):.0f}")

    return traces


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        analyze_losses_v3(sys.argv[1])
    else:
        print("Usage: python mechanism_tracer_v3.py <losses_dir>")
