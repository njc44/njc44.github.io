#!/usr/bin/env python3
"""Money Ledger: Per-day per-category attribution of every dollar.

Tracks the exact money delta between consecutive steps, classifies each
delta by the action that caused it (SELL by item, BUY by item, HIRE, LAND),
and produces a per-day breakdown showing WHERE the gap between two agents
accumulates.

Uses observation data (money field + shed + actions) from replay files.
No engine simulation — just reads what actually happened.

Usage:
    python money_ledger.py <losses_dir>
    python money_ledger.py autoloop/corpus/pipe11_vs_tschinkel_losses/
    python money_ledger.py <losses_dir> --json  # machine-readable output
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

STEPS_PER_DAY = 24
TOTAL_DAYS = 30

SEED_COST = {"WHEAT": 10, "CARROT": 20, "TOMATO": 50, "STRAWBERRY": 100, "MELON": 80}
ANIMAL_COST = {"GOOSE": 300, "COW": 400, "SHEEP": 500}

# Fibonacci hire costs: fib(0)=1, fib(1)=1, fib(2)=2, ...
def _fib(n):
    a, b = 1, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def analyze_game(replay):
    """Analyze one game: per-day per-category money attribution for both players.

    Returns dict with:
      - per_day[seat][day] = {category: amount, ...}
      - totals[seat] = {category: amount, ...}
      - daily_gap[day] = opp_money - our_money
      - margin, rewards, our_seat
    """
    our_seat = replay.get("our_seat", 0)
    opp_seat = 1 - our_seat
    steps = replay.get("steps", [])
    rewards = replay.get("rewards", [0, 0])

    per_day = {0: defaultdict(lambda: defaultdict(float)),
               1: defaultdict(lambda: defaultdict(float))}
    totals = {0: defaultdict(float), 1: defaultdict(float)}

    for si in range(len(steps)):
        day = si // STEPS_PER_DAY
        hour = si % STEPS_PER_DAY

        for seat in [0, 1]:
            obs = steps[si][seat].get("observation", {})
            priv = obs.get("private", {})
            shed = dict(priv.get("shed", {}))
            action = steps[si][seat].get("action", {})
            market_orders = action.get("market", [])

            # Track hires_today from observation
            farm = obs.get("farms", [{}, {}])[seat]
            hires_today = farm.get("hires_today", 0)

            for o in market_orders:
                if not o or not isinstance(o, list):
                    continue

                op = o[0]

                if op == "SELL" and len(o) >= 3:
                    item = o[1]
                    qty = min(int(o[2]), max(0, int(shed.get(item, 0))))
                    if qty > 0:
                        # We don't know exact price per unit without lockstep sim
                        # But we know the total money change — we'll reconcile below
                        per_day[seat][day][f"sell_{item}"] += qty
                        totals[seat][f"sell_{item}"] += qty

                elif op == "BUY_PRODUCT" and len(o) >= 3:
                    item = o[1]
                    qty = int(o[2])
                    per_day[seat][day][f"buy_{item}"] += qty
                    totals[seat][f"buy_{item}"] += qty

                elif op == "BUY_SEED" and len(o) >= 3:
                    item = o[1]
                    qty = int(o[2])
                    cost = SEED_COST.get(item, 0) * qty
                    per_day[seat][day]["seed_cost"] += cost
                    per_day[seat][day][f"seed_{item}"] += qty
                    totals[seat]["seed_cost"] += cost

                elif op == "BUY_ANIMAL" and len(o) >= 3:
                    item = o[1]
                    qty = int(o[2])
                    cost = ANIMAL_COST.get(item, 0) * qty
                    per_day[seat][day]["animal_cost"] += cost
                    per_day[seat][day][f"animal_{item}"] += qty
                    totals[seat]["animal_cost"] += cost

                elif op == "HIRE":
                    # Exact cost depends on hires_today counter
                    cost = _fib(hires_today)
                    per_day[seat][day]["hire_cost"] += cost
                    per_day[seat][day]["hire_count"] += 1
                    totals[seat]["hire_cost"] += cost
                    totals[seat]["hire_count"] += 1
                    hires_today += 1

                elif op == "BUY_LAND":
                    # Cost depends on how many quadrants already unlocked
                    unlocked = len(farm.get("unlocked_quadrants", ["NW"])) - 1
                    cost = [1000, 2000, 4000][min(unlocked, 2)] if unlocked < 3 else 0
                    per_day[seat][day]["land_cost"] += cost
                    totals[seat]["land_cost"] += cost

    # Now get ACTUAL money per day from observations (ground truth)
    daily_money = {0: [], 1: []}
    for day in range(TOTAL_DAYS):
        si = day * STEPS_PER_DAY
        if si >= len(steps):
            break
        for seat in [0, 1]:
            obs = steps[si][seat].get("observation", {})
            money = obs.get("farms", [{}, {}])[seat].get("money", 0)
            daily_money[seat].append(money)

    # Compute per-day ACTUAL money changes (ground truth deltas)
    daily_delta = {0: [], 1: []}
    for seat in [0, 1]:
        for day in range(1, len(daily_money[seat])):
            delta = daily_money[seat][day] - daily_money[seat][day - 1]
            daily_delta[seat].append((day, delta))

    return {
        "per_day": {s: dict(d) for s, d in per_day.items()},
        "totals": {s: dict(t) for s, t in totals.items()},
        "daily_money": daily_money,
        "daily_delta": daily_delta,
        "rewards": rewards,
        "our_seat": our_seat,
        "margin": rewards[our_seat] - rewards[opp_seat],
    }


def analyze_losses(losses_dir, max_games=20):
    """Analyze all losses in a directory and produce aggregated ledger."""
    losses_dir = Path(losses_dir)
    loss_files = sorted(losses_dir.glob("*.json"))[:max_games]

    if not loss_files:
        print(f"No loss files found in {losses_dir}")
        return

    all_results = []
    for fpath in loss_files:
        with open(fpath) as f:
            replay = json.load(f)
        result = analyze_game(replay)
        all_results.append(result)

    n = len(all_results)
    print(f"MONEY LEDGER ({n} games)")
    avg_margin = sum(r["margin"] for r in all_results) / n
    print(f"Avg margin: ${avg_margin:+,.0f}")
    print()

    # Aggregate daily money (ground truth)
    print("=" * 80)
    print("PER-DAY MONEY & GAP (ground truth from observation)")
    print("=" * 80)
    print(f"{'Day':>4} {'Us':>10} {'Opp':>10} {'Gap':>8} {'Day Δ Us':>10} {'Day Δ Opp':>10} {'Δ Gap':>8}")
    print("-" * 70)

    for day in range(TOTAL_DAYS):
        us_money = []
        opp_money = []
        for r in all_results:
            our = r["our_seat"]
            opp = 1 - our
            if day < len(r["daily_money"][our]):
                us_money.append(r["daily_money"][our][day])
            if day < len(r["daily_money"][opp]):
                opp_money.append(r["daily_money"][opp][day])

        if not us_money:
            break

        us_avg = sum(us_money) / len(us_money)
        opp_avg = sum(opp_money) / len(opp_money)
        gap = opp_avg - us_avg

        # Day deltas
        if day > 0:
            us_prev = sum(r["daily_money"][r["our_seat"]][day-1] for r in all_results if day-1 < len(r["daily_money"][r["our_seat"]])) / n
            opp_prev = sum(r["daily_money"][1-r["our_seat"]][day-1] for r in all_results if day-1 < len(r["daily_money"][1-r["our_seat"]])) / n
            d_us = us_avg - us_prev
            d_opp = opp_avg - opp_prev
            d_gap = d_opp - d_us
            print(f"{day:>4} ${us_avg:>8,.0f} ${opp_avg:>8,.0f} ${gap:>+6,.0f} ${d_us:>+8,.0f} ${d_opp:>+8,.0f} ${d_gap:>+6,.0f}")
        else:
            print(f"{day:>4} ${us_avg:>8,.0f} ${opp_avg:>8,.0f} ${gap:>+6,.0f}")

    # Per-day action breakdown for days where gap grows most
    print()
    print("=" * 80)
    print("PER-DAY ACTION BREAKDOWN (what each side does differently)")
    print("=" * 80)

    for day in range(TOTAL_DAYS):
        # Aggregate actions for this day
        us_actions = defaultdict(float)
        opp_actions = defaultdict(float)

        for r in all_results:
            our = r["our_seat"]
            opp = 1 - our
            for k, v in r["per_day"].get(our, {}).get(day, {}).items():
                us_actions[k] += v / n
            for k, v in r["per_day"].get(opp, {}).get(day, {}).items():
                opp_actions[k] += v / n

        # Find significant differences
        all_keys = sorted(set(list(us_actions.keys()) + list(opp_actions.keys())))
        diffs = []
        for k in all_keys:
            us_v = us_actions.get(k, 0)
            opp_v = opp_actions.get(k, 0)
            diff = opp_v - us_v
            if abs(diff) > 0.5:  # at least 0.5 units/$ different
                diffs.append((k, us_v, opp_v, diff))

        if diffs:
            print(f"\n  Day {day}:")
            for k, us_v, opp_v, diff in sorted(diffs, key=lambda x: -abs(x[3])):
                unit = "$" if "cost" in k else ""
                print(f"    {k:<25} Us={unit}{us_v:>7.1f}  Opp={unit}{opp_v:>7.1f}  Δ={unit}{diff:>+7.1f}")

    # Overall totals
    print()
    print("=" * 80)
    print("OVERALL TOTALS")
    print("=" * 80)

    us_totals = defaultdict(float)
    opp_totals = defaultdict(float)
    for r in all_results:
        our = r["our_seat"]
        opp = 1 - our
        for k, v in r["totals"].get(our, {}).items():
            us_totals[k] += v / n
        for k, v in r["totals"].get(opp, {}).items():
            opp_totals[k] += v / n

    all_keys = sorted(set(list(us_totals.keys()) + list(opp_totals.keys())),
                      key=lambda x: -abs(opp_totals.get(x, 0) - us_totals.get(x, 0)))
    print(f"  {'Category':<25} {'Us':>10} {'Opp':>10} {'Gap':>10}")
    print(f"  {'-'*55}")
    for k in all_keys:
        us_v = us_totals.get(k, 0)
        opp_v = opp_totals.get(k, 0)
        diff = opp_v - us_v
        if abs(diff) > 0.1:
            print(f"  {k:<25} {us_v:>10.1f} {opp_v:>10.1f} {diff:>+10.1f}")

    return all_results


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python money_ledger.py <losses_dir>")
        sys.exit(1)

    losses_dir = sys.argv[1]
    json_mode = "--json" in sys.argv

    results = analyze_losses(losses_dir)

    if json_mode and results:
        print(json.dumps({
            "games": len(results),
            "avg_margin": sum(r["margin"] for r in results) / len(results),
        }, indent=2))
