#!/usr/bin/env python3
"""Two-phase tournament: Phase 1 filters with pipe-21, Phase 2 round-robins survivors."""
import subprocess, json, sys, time
from pathlib import Path
from itertools import combinations

PYTHON = sys.executable
COLOSSEUM = "autoloop/colosseum.py"
RESULTS_DIR = Path("autoloop/colosseum_results/tournament_p25a")
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

HERO = ("pipe25a", "autoloop/agents/pipe25a_arsgorynich_sheep")

# ── AGENTS BY AUTHOR ──
AGENTS = {
    # Ahmed v40-v57
    "ahmed_v40": "autoloop/agents/ahmedberatozer__kaggriculture-v40-plans-that-fit-the-shops",
    "ahmed_v41": "autoloop/agents/ahmedberatozer__kaggriculture-v41-review-candidate",
    "ahmed_v42": "autoloop/agents/ahmedberatozer__kaggriculture-v42-production-that-fits-the-marke",
    "ahmed_v43": "autoloop/agents/ahmedberatozer__kaggriculture-v43-recovering-lost-harvests",
    "ahmed_v44": "autoloop/agents/ahmedberatozer__kaggriculture-v44-winning-the-same-turn-sale-race",
    "ahmed_v45": "autoloop/agents/ahmedberatozer__kaggriculture-v45-first-turn-wheat-round-trip",
    "ahmed_v46": "autoloop/agents/ahmedberatozer__kaggriculture-v46-first-turn-microstructure-and-s",
    "ahmed_v47": "autoloop/agents/ahmedberatozer__kaggriculture-v47-reactive-market-coordination",
    "ahmed_v48": "autoloop/agents/ahmedberatozer__kaggriculture-v48-clear-the-queue",
    "ahmed_v49": "autoloop/agents/ahmedberatozer__kaggriculture-v49-funded-sale-timing-and-worker",
    "ahmed_v50": "autoloop/agents/ahmedberatozer__kaggriculture-v50-early-yarn-commit",
    "ahmed_v51": "autoloop/agents/ahmedberatozer__kaggriculture-v51-lean-flock",
    "ahmed_v52": "autoloop/agents/ahmedberatozer__kaggriculture-v52-lean-flock-yarn-route",
    "ahmed_v53": "autoloop/agents/ahmedberatozer__kaggriculture-v53-opening-signature",
    "ahmed_v54": "autoloop/agents/ahmedberatozer__kaggriculture-v54-productive-wheat-and-patient",
    "ahmed_v55": "autoloop/agents/ahmedberatozer__kaggriculture-v55-one-turn-market-race-edge",
    "ahmed_v56": "autoloop/agents/ahmedberatozer__kaggriculture-v56-smarter-seeds-and-fertilizer",
    "ahmed_v57": "autoloop/agents/ahmedberatozer__kaggriculture-v57-funding-order-invariant",
    # Thomas Tschinkel
    "tschinkel_v94": "autoloop/agents/tschinkel_v9_4",
    "tschinkel_v13": "autoloop/agents/tschinkel_v13",
    "tschinkel_sl3": "autoloop/agents/tschinkel_v9_4_sl3",
    "tschinkel_wfix": "autoloop/agents/tschinkel_v9_4_wheat_fix",
    "tschinkel_rg15": "autoloop/agents/tschinkel_v9_4_rg15",
    "tschinkel_op25": "autoloop/agents/tschinkel_v9_4_open25",
    "tschinkel_rr": "autoloop/agents/thomastschinkel__replay-routing",
    "tschinkel_93wr": "autoloop/agents/thomastschinkel__kaggriculture-93-8-win-rate-public-state-router",
    # Dmitrii latest 3
    "dmitrii_mw": "autoloop/agents/dmitriigluzdov__more-wheat-smarter-sales",
    "dmitrii_omw": "autoloop/agents/dmitriigluzdov__one-more-wheat",
    "dmitrii_sms": "autoloop/agents/dmitriigluzdov__smaller-market-shock",
    # LynnSakurai all
    "lynn_fj": "autoloop/agents/lynnsakurai__farmer-john-and-the-idle-seller",
    "lynn_sv2": "autoloop/agents/lynnsakurai__farming-score-v2",
    "lynn_sv4": "autoloop/agents/lynnsakurai__farming-score-v4-a-better-shop",
    "lynn_sv5": "autoloop/agents/lynnsakurai__farming-score-v5-timing-optimized",
    # Tetsutani all
    "tetsu_dpv2": "autoloop/agents/tetsutani__demand-preserving-v2",
    "tetsu_dpts": "autoloop/agents/tetsutani__demand-preserving-turn-sale-timing",
    "tetsu_msf": "autoloop/agents/tetsutani__market-smart-farming-kaggriculture",
    "tetsu_sts": "autoloop/agents/tetsutani__shape-the-shop-work-the-pasture-kaggriculture",
    # Others (notable unique agents)
    "haodou": "autoloop/agents/haodou__notebookdb6965aa8e",
    "aurax7_v6": "autoloop/agents/aurax7__kaggriculture-shop-router-reactive-v6",
    "aurax7_v4": "autoloop/agents/aurax7__kaggriculture-shop-router-reactive-v4",
    "alperen_mc": "autoloop/agents/alperen5252525__kaggriculture-metacounter-r1-scored-agent",
    "alperen_toma": "autoloop/agents/alperen5252525__turn-one-market-advantage-kaggriculture",
    "ravi_top30": "autoloop/agents/ravi123a321at__177-180-fresh-top-30-v21-1-conditional-memory",
    "leoprovorov": "autoloop/agents/leoprovorov__two-coins-at-high-noon-small-improvement",
    "jaxa623": "autoloop/agents/jaxa623__2842-two-identical-agents-90-points-apart",
    "nusrati": "autoloop/agents/nusrati__2650-score",
    # New competitors
    "prvsiyan": "autoloop/agents/prvsiyan__moon-counts-melons",
    "arsgorynich": "autoloop/agents/arsgorynich__herd-safe-v3",
    # Us pipe-15 to pipe-21
    "pipe15": "autoloop/agents/pipe15_hybrid",
    "pipe16": "autoloop/agents/pipe16_v13_hybrid",
    "pipe17": "autoloop/agents/pipe17_day3_harvest",
    "pipe18": "autoloop/agents/pipe18_full_stack",
    "pipe19": "autoloop/agents/pipe19_adv_overflow",
    "pipe20": "autoloop/agents/pipe20_sheep_fix",
    "pipe21": "autoloop/agents/pipe21_v57_sheep_fix",
    "pipe24": "autoloop/agents/pipe24_prvsiyan_sheep",
    "pipe25b": "autoloop/agents/pipe25b_jaxa_sheep",
}

PARALLEL = 5

def run_match(a_name, a_path, b_name, b_path, games, outfile):
    """Run a colosseum match, return (wins, losses, ties) or None on error."""
    if outfile.exists():
        d = json.loads(outfile.read_text())
        return (d["wins"], d["losses"], d["ties"])
    r = subprocess.run(
        [PYTHON, COLOSSEUM, a_path, b_path,
         "--games", str(games), "--parallel", str(PARALLEL),
         "--output", str(outfile)],
        capture_output=True, text=True, timeout=600
    )
    if outfile.exists():
        d = json.loads(outfile.read_text())
        return (d["wins"], d["losses"], d["ties"])
    return None

def main():
    hero_name, hero_path = HERO
    
    # ════════════════════════════════════════════════════
    # PHASE 1: pipe-21 vs ALL, 10 games each
    # ════════════════════════════════════════════════════
    print("=" * 70)
    print(f"  PHASE 1: {hero_name} vs {len(AGENTS)} opponents (10 games each)")
    print("=" * 70)
    
    survivors = {}  # name -> path (opponents who took at least 1 game/tie)
    eliminated = []
    errors = []
    
    for i, (name, path) in enumerate(sorted(AGENTS.items())):
        outfile = RESULTS_DIR / f"P1_{hero_name}_vs_{name}.json"
        print(f"  [{i+1}/{len(AGENTS)}] {hero_name} vs {name}...", end=" ", flush=True)
        t0 = time.time()
        try:
            result = run_match(hero_name, hero_path, name, path, 10, outfile)
        except Exception as e:
            print(f"ERROR ({e})")
            errors.append(name)
            continue
        elapsed = time.time() - t0
        
        if result is None:
            print(f"FAILED ({elapsed:.0f}s)")
            errors.append(name)
            continue
        
        w, l, t = result
        total = w + l + t
        print(f"{w}W-{l}L-{t}T  ({elapsed:.0f}s)", end="")
        
        if w == total and l == 0 and t == 0:
            print("  → ELIMINATED")
            eliminated.append(name)
        else:
            print(f"  → SURVIVES")
            survivors[name] = path
    
    print(f"\n{'─' * 70}")
    print(f"Phase 1 complete: {len(survivors)} survivors, {len(eliminated)} eliminated, {len(errors)} errors")
    print(f"Survivors: {', '.join(sorted(survivors.keys()))}")
    print(f"Eliminated: {', '.join(sorted(eliminated))}")
    if errors:
        print(f"Errors: {', '.join(sorted(errors))}")
    
    # Add hero to survivor pool
    all_rr = {hero_name: hero_path}
    all_rr.update(survivors)
    
    # ════════════════════════════════════════════════════
    # PHASE 2: Round-robin among survivors
    # ════════════════════════════════════════════════════
    pairs = list(combinations(sorted(all_rr.keys()), 2))
    print(f"\n{'=' * 70}")
    print(f"  PHASE 2: Round-robin among {len(all_rr)} agents ({len(pairs)} matchups, 30 games each)")
    print("=" * 70)
    
    for i, (a, b) in enumerate(pairs):
        outfile = RESULTS_DIR / f"P2_{a}_vs_{b}.json"
        if outfile.exists():
            d = json.loads(outfile.read_text())
            print(f"  [{i+1}/{len(pairs)}] {a} vs {b} — cached: {d['wins']}W-{d['losses']}L-{d['ties']}T")
            continue
        print(f"  [{i+1}/{len(pairs)}] {a} vs {b}...", end=" ", flush=True)
        t0 = time.time()
        try:
            result = run_match(a, all_rr[a], b, all_rr[b], 30, outfile)
        except Exception as e:
            print(f"ERROR ({e})")
            continue
        elapsed = time.time() - t0
        if result:
            w, l, t = result
            print(f"{w}W-{l}L-{t}T  ({elapsed:.0f}s)")
        else:
            print(f"FAILED ({elapsed:.0f}s)")
    
    # ════════════════════════════════════════════════════
    # COMPUTE ELO RATINGS
    # ════════════════════════════════════════════════════
    print(f"\n{'=' * 70}")
    print(f"  FINAL ELO RATINGS")
    print("=" * 70)
    
    from collections import defaultdict
    results = []
    wins = defaultdict(int); losses = defaultdict(int); ties = defaultdict(int)
    
    for f in sorted(RESULTS_DIR.glob("P2_*.json")):
        name = f.stem.replace("P2_", "")
        a, _, b = name.partition("_vs_")
        d = json.loads(f.read_text())
        for _ in range(d["wins"]): results.append((a, b, 1.0))
        for _ in range(d["losses"]): results.append((a, b, 0.0))
        for _ in range(d["ties"]): results.append((a, b, 0.5))
        wins[a] += d["wins"]; losses[a] += d["losses"]; ties[a] += d["ties"]
        wins[b] += d["losses"]; losses[b] += d["wins"]; ties[b] += d["ties"]
    
    agents_set = set()
    for a, b, _ in results: agents_set.add(a); agents_set.add(b)
    elo = {a: 1500 for a in agents_set}
    for _ in range(50):
        for a, b, score in results:
            ea = 1 / (1 + 10 ** ((elo[b] - elo[a]) / 400))
            elo[a] += 16 * (score - ea)
            elo[b] += 16 * ((1 - score) - (1 - ea))
    
    print(f"\n{'Rank':<6} {'Agent':<20} {'Elo':>6} {'W':>5} {'L':>5} {'T':>5} {'WinRate':>8}")
    print("─" * 62)
    ranking = sorted(elo.items(), key=lambda x: -x[1])
    for rank, (agent, rating) in enumerate(ranking, 1):
        w, l, t = wins[agent], losses[agent], ties[agent]
        g = w + l + t
        wr = (w + 0.5 * t) / g * 100 if g > 0 else 0
        marker = " ◀ OUR CANDIDATE" if agent == hero_name else ""
        print(f"  {rank:<4} {agent:<20} {rating:>6.0f} {w:>5} {l:>5} {t:>5} {wr:>7.1f}%{marker}")
    
    print(f"\nDone!")

if __name__ == "__main__":
    main()
