#!/usr/bin/env python3
"""Round-robin tournament runner + .docx report generator.

Runs every pair in a roster, computes Elo rankings, and generates a
formatted Word document with summary tables, color-coded matrices,
and auto-generated key findings.

Usage:
    python autoloop/tournament_report.py                        # default roster, 20 games
    python autoloop/tournament_report.py --games 50             # more games
    python autoloop/tournament_report.py --roster a b c ...     # custom roster
    python autoloop/tournament_report.py --from-results f.json  # rebuild report only
"""
import argparse
import json
import math
import os
import sys
import time
from datetime import datetime
from itertools import combinations
from pathlib import Path

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"

sys.path.insert(0, str(AUTOLOOP_DIR))
from colosseum import run_h2h, binomial_significance

DEFAULT_ROSTER = [
    "ahmedberatozer__kaggriculture-v44-winning-the-same-turn-sale-race",
    "ahmedberatozer__kaggriculture-v43-recovering-lost-harvests",
    "ahmedberatozer__kaggriculture-v42-production-that-fits-the-marke",
    "alperen5252525__kaggriculture-metacounter-r1-scored-agent",
    "leoprovorov__two-coins-at-high-noon-small-improvement",
    "ahmedberatozer__kaggriculture-v40-plans-that-fit-the-shops",
    "thomastschinkel__kaggriculture-93-8-win-rate-public-state-router",
    "alperen5252525__v62-metabalance-kaggriculture",
    "guruprasaathas111__kaggriculture-master-engine-v53e01d74d8f",
    "_pipe5_candidate",
]

PARALLEL = 10


def short_name(agent):
    """Shorten agent name for display."""
    if agent.startswith("_"):
        return agent
    parts = agent.split("__", 1)
    if len(parts) == 2:
        author = parts[0][:8]
        slug = parts[1][:30]
        return f"{author}/{slug}"
    return agent[:38]


def agent_path(name):
    return str(AGENTS_DIR / name / "main.py")


def compute_elo(matchup_results, roster):
    """Compute Elo ratings from round-robin results. K=32, start=1500."""
    elo = {name: 1500.0 for name in roster}

    # Process all games in matchup order for determinism
    for key, result in sorted(matchup_results.items()):
        a, b = result["agent_a_name"], result["agent_b_name"]
        for game in result["games"]:
            ea = 1 / (1 + 10 ** ((elo[b] - elo[a]) / 400))
            eb = 1 - ea

            outcome = game["result"]
            if outcome == "WIN":
                sa, sb = 1.0, 0.0
            elif outcome == "LOSE":
                sa, sb = 0.0, 1.0
            else:
                sa, sb = 0.5, 0.5

            elo[a] += 32 * (sa - ea)
            elo[b] += 32 * (sb - eb)

    return {name: round(rating) for name, rating in elo.items()}


def run_tournament(roster, games_per_matchup, parallel):
    """Run full round-robin. Returns dict of matchup results keyed by 'A_vs_B'."""
    os.chdir(str(WORK_DIR))

    matchups = list(combinations(range(len(roster)), 2))
    total_matchups = len(matchups)
    total_games = total_matchups * games_per_matchup

    print(f"\n{'='*70}")
    print(f"  TOURNAMENT: {len(roster)} agents, {total_matchups} matchups, "
          f"{games_per_matchup} games each = {total_games} total")
    print(f"  Parallel workers per matchup: {parallel}")
    print(f"{'='*70}\n")

    results = {}
    t_start = time.time()
    matchup_times = []

    for idx, (i, j) in enumerate(matchups):
        a_name, b_name = roster[i], roster[j]
        a_short, b_short = short_name(a_name), short_name(b_name)
        a_path, b_path = agent_path(a_name), agent_path(b_name)

        print(f"  [{idx+1}/{total_matchups}] {a_short} vs {b_short} ... ", end="", flush=True)
        m_start = time.time()

        h2h = run_h2h(a_path, b_path, games_per_matchup, parallel)

        m_elapsed = time.time() - m_start
        matchup_times.append(m_elapsed)

        key = f"{a_name}_vs_{b_name}"
        h2h["agent_a_name"] = a_name
        h2h["agent_b_name"] = b_name
        results[key] = h2h

        # Progress
        w, l, t = h2h["wins"], h2h["losses"], h2h["ties"]
        print(f"{w}W-{l}L-{t}T  elo_rate={h2h['elo_rate']:.2f}  "
              f"({m_elapsed:.0f}s)", flush=True)

        # ETA after first matchup
        if idx == 0:
            avg_t = matchup_times[0]
            eta = avg_t * (total_matchups - 1)
            print(f"  ETA: ~{eta/60:.1f} min remaining\n")

    total_elapsed = time.time() - t_start
    print(f"\n  Tournament complete in {total_elapsed/60:.1f} min "
          f"({total_elapsed:.0f}s)\n")

    return results


def build_aggregates(matchup_results, roster):
    """Build per-agent aggregates + pairwise matrices."""
    n = len(roster)
    name_to_idx = {name: i for i, name in enumerate(roster)}

    # Pairwise matrices (row=A perspective)
    elo_rate_matrix = [[None]*n for _ in range(n)]
    margin_matrix = [[None]*n for _ in range(n)]
    p_value_matrix = [[None]*n for _ in range(n)]

    # Per-agent totals
    agg = {name: {"wins": 0, "losses": 0, "ties": 0, "margins": []} for name in roster}

    for key, result in matchup_results.items():
        a, b = result["agent_a_name"], result["agent_b_name"]
        ai, bi = name_to_idx[a], name_to_idx[b]
        w, l, t = result["wins"], result["losses"], result["ties"]

        agg[a]["wins"] += w
        agg[a]["losses"] += l
        agg[a]["ties"] += t
        agg[b]["wins"] += l
        agg[b]["losses"] += w
        agg[b]["ties"] += t

        for g in result["games"]:
            agg[a]["margins"].append(g["margin"])
            agg[b]["margins"].append(-g["margin"])

        elo_rate_matrix[ai][bi] = result["elo_rate"]
        elo_rate_matrix[bi][ai] = round(1.0 - result["elo_rate"], 4)

        margin_matrix[ai][bi] = result["avg_margin"]
        margin_matrix[bi][ai] = -result["avg_margin"]

        p_value_matrix[ai][bi] = result["p_value"]
        p_value_matrix[bi][ai] = result["p_value"]

    # Per-agent summary
    summaries = []
    for name in roster:
        a = agg[name]
        total = a["wins"] + a["losses"] + a["ties"]
        win_pct = a["wins"] / total * 100 if total else 0
        avg_margin = sum(a["margins"]) / len(a["margins"]) if a["margins"] else 0
        summaries.append({
            "name": name,
            "short": short_name(name),
            "wins": a["wins"],
            "losses": a["losses"],
            "ties": a["ties"],
            "total": total,
            "win_pct": round(win_pct, 1),
            "avg_margin": round(avg_margin),
        })

    return summaries, elo_rate_matrix, margin_matrix, p_value_matrix


def generate_findings(summaries, elo_ratings, elo_rate_matrix, p_value_matrix, roster):
    """Auto-generate key findings as bullet points."""
    findings = []
    n = len(roster)
    name_to_idx = {name: i for i, name in enumerate(roster)}

    # Sort by elo
    ranked = sorted(summaries, key=lambda s: elo_ratings.get(s["name"], 0), reverse=True)

    # 1. Strongest overall
    top = ranked[0]
    findings.append(
        f"Strongest agent: {top['short']} (Elo {elo_ratings[top['name']]}, "
        f"{top['wins']}W-{top['losses']}L-{top['ties']}T, "
        f"{top['win_pct']:.0f}% win rate)."
    )

    # 2. Insignificant matchups
    insignificant = []
    for i in range(n):
        for j in range(i+1, n):
            p = p_value_matrix[i][j]
            if p is not None and p > 0.05:
                insignificant.append(
                    f"{short_name(roster[i])} vs {short_name(roster[j])} (p={p:.3f})"
                )
    if insignificant:
        findings.append(
            f"Statistically insignificant matchups (p>0.05): {'; '.join(insignificant)}."
        )
    else:
        findings.append("All matchups are statistically significant (p<0.05).")

    # 3. Local hero analysis
    pipe5 = "_pipe5_candidate"
    if pipe5 in name_to_idx:
        pi = name_to_idx[pipe5]
        top6 = roster[:6]
        beaten = []
        lost_to = []
        for t6 in top6:
            ti = name_to_idx[t6]
            er = elo_rate_matrix[pi][ti]
            if er is not None:
                if er > 0.5:
                    beaten.append(short_name(t6))
                elif er < 0.5:
                    lost_to.append(f"{short_name(t6)} (elo_rate={er:.2f})")
        if not lost_to:
            findings.append(
                f"pipe-5 beats ALL top-6 agents: {', '.join(beaten)}."
            )
        else:
            findings.append(
                f"pipe-5 loses to: {'; '.join(lost_to)}. "
                f"Beats: {', '.join(beaten) if beaten else 'none of top-6'}."
            )

    # 4. Surprising results (A beats B, B beats C, C beats A — rock-paper-scissors)
    surprises = []
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            for k in range(n):
                if k == i or k == j:
                    continue
                er_ij = elo_rate_matrix[i][j]
                er_jk = elo_rate_matrix[j][k]
                er_ki = elo_rate_matrix[k][i]
                if (er_ij is not None and er_jk is not None and er_ki is not None
                        and er_ij > 0.6 and er_jk > 0.6 and er_ki > 0.6):
                    trio = tuple(sorted([roster[i], roster[j], roster[k]]))
                    label = (f"{short_name(roster[i])} > {short_name(roster[j])} > "
                             f"{short_name(roster[k])} > {short_name(roster[i])}")
                    if trio not in [t[0] for t in surprises]:
                        surprises.append((trio, label))
    if surprises:
        for _, label in surprises[:3]:
            findings.append(f"Rock-paper-scissors cycle: {label}.")
    else:
        findings.append("No strong non-transitive (rock-paper-scissors) cycles detected.")

    return findings


def set_cell_shading(cell, color_hex):
    """Set background shading on a table cell."""
    shading_elm = cell._element.get_or_add_tcPr()
    shading = shading_elm.makeelement(qn('w:shd'), {
        qn('w:fill'): color_hex,
        qn('w:val'): 'clear',
    })
    shading_elm.append(shading)


def elo_rate_color(rate):
    """Return hex color for elo rate: green (>0.7), yellow (0.4-0.7), red (<0.4)."""
    if rate is None:
        return "FFFFFF"
    if rate > 0.7:
        return "C6EFCE"  # green
    elif rate >= 0.4:
        return "FFEB9C"  # yellow
    else:
        return "FFC7CE"  # red


def generate_docx(roster, elo_ratings, summaries, elo_rate_matrix, margin_matrix,
                  p_value_matrix, findings, output_path):
    """Generate the tournament report .docx."""
    doc = Document()

    # Style defaults
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Calibri'
    font.size = Pt(10)

    # Header
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    heading = doc.add_heading(f"Kaggriculture Tournament Report — {now}", level=1)

    # Sort by Elo for display
    ranked = sorted(summaries, key=lambda s: elo_ratings.get(s["name"], 0), reverse=True)
    ranked_names = [s["name"] for s in ranked]

    # ---- Section 1: Summary Table ----
    doc.add_heading("Overall Rankings", level=2)
    cols = ["Rank", "Agent", "Elo", "W-L-T", "Avg Margin", "Win%"]
    table = doc.add_table(rows=1 + len(ranked), cols=len(cols))
    table.style = 'Light Grid Accent 1'

    # Header row
    for ci, col_name in enumerate(cols):
        cell = table.rows[0].cells[ci]
        cell.text = col_name
        cell.paragraphs[0].runs[0].bold = True
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

    for ri, s in enumerate(ranked):
        row = table.rows[ri + 1]
        elo = elo_ratings.get(s["name"], 1500)
        values = [
            str(ri + 1),
            s["short"],
            str(elo),
            f"{s['wins']}-{s['losses']}-{s['ties']}",
            f"{s['avg_margin']:+,}",
            f"{s['win_pct']:.1f}%",
        ]
        for ci, val in enumerate(values):
            row.cells[ci].text = val
            row.cells[ci].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph("")

    # ---- Section 2: Elo Rate Matrix ----
    doc.add_heading("Elo Rate Matrix (row vs column)", level=2)
    n = len(ranked_names)
    name_to_idx = {name: i for i, name in enumerate(roster)}

    matrix_table = doc.add_table(rows=n + 1, cols=n + 1)
    matrix_table.style = 'Table Grid'

    # Header row + col
    matrix_table.rows[0].cells[0].text = ""
    for ci, name in enumerate(ranked_names):
        matrix_table.rows[0].cells[ci + 1].text = short_name(name)[:15]
        p = matrix_table.rows[0].cells[ci + 1].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in p.runs:
            run.font.size = Pt(7)
            run.font.bold = True

    for ri, a_name in enumerate(ranked_names):
        ai = name_to_idx[a_name]
        cell0 = matrix_table.rows[ri + 1].cells[0]
        cell0.text = short_name(a_name)[:15]
        for run in cell0.paragraphs[0].runs:
            run.font.size = Pt(7)
            run.font.bold = True

        for ci, b_name in enumerate(ranked_names):
            bi = name_to_idx[b_name]
            cell = matrix_table.rows[ri + 1].cells[ci + 1]
            if ai == bi:
                cell.text = "—"
                set_cell_shading(cell, "D9D9D9")
            else:
                rate = elo_rate_matrix[ai][bi]
                cell.text = f"{rate:.2f}" if rate is not None else "?"
                set_cell_shading(cell, elo_rate_color(rate))
            cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in cell.paragraphs[0].runs:
                run.font.size = Pt(8)

    doc.add_paragraph("")

    # ---- Section 3: Avg Margin Matrix ----
    doc.add_heading("Average Margin Matrix (row vs column, $)", level=2)
    margin_table = doc.add_table(rows=n + 1, cols=n + 1)
    margin_table.style = 'Table Grid'

    margin_table.rows[0].cells[0].text = ""
    for ci, name in enumerate(ranked_names):
        margin_table.rows[0].cells[ci + 1].text = short_name(name)[:15]
        p = margin_table.rows[0].cells[ci + 1].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in p.runs:
            run.font.size = Pt(7)
            run.font.bold = True

    for ri, a_name in enumerate(ranked_names):
        ai = name_to_idx[a_name]
        cell0 = margin_table.rows[ri + 1].cells[0]
        cell0.text = short_name(a_name)[:15]
        for run in cell0.paragraphs[0].runs:
            run.font.size = Pt(7)
            run.font.bold = True

        for ci, b_name in enumerate(ranked_names):
            bi = name_to_idx[b_name]
            cell = margin_table.rows[ri + 1].cells[ci + 1]
            if ai == bi:
                cell.text = "—"
                set_cell_shading(cell, "D9D9D9")
            else:
                m = margin_matrix[ai][bi]
                cell.text = f"{m:+,}" if m is not None else "?"
                if m is not None:
                    color = "C6EFCE" if m > 0 else ("FFC7CE" if m < 0 else "FFEB9C")
                    set_cell_shading(cell, color)
            cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in cell.paragraphs[0].runs:
                run.font.size = Pt(8)

    doc.add_paragraph("")

    # ---- Section 4: Key Findings ----
    doc.add_heading("Key Findings", level=2)
    for finding in findings:
        doc.add_paragraph(finding, style='List Bullet')

    # Save
    CORPUS_DIR.mkdir(parents=True, exist_ok=True)
    doc.save(str(output_path))
    print(f"  Report saved: {output_path}")


def print_summary_table(ranked, elo_ratings):
    """Print summary to stdout."""
    print(f"\n{'='*80}")
    print(f"  {'Rank':>4}  {'Agent':<40}  {'Elo':>5}  {'W-L-T':>10}  {'Margin':>8}  {'Win%':>6}")
    print(f"  {'-'*4}  {'-'*40}  {'-'*5}  {'-'*10}  {'-'*8}  {'-'*6}")
    for ri, s in enumerate(ranked):
        elo = elo_ratings.get(s["name"], 1500)
        print(f"  {ri+1:>4}  {s['short']:<40}  {elo:>5}  "
              f"{s['wins']:>3}-{s['losses']:<3}-{s['ties']:<3}  "
              f"{s['avg_margin']:>+8,}  {s['win_pct']:>5.1f}%")
    print(f"{'='*80}\n")


def run_full_tournament(roster, games_per_matchup=20, parallel=10):
    """Run tournament and generate report. Returns results dict.
    Callable from autoloop.py without going through CLI."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    results_path = CORPUS_DIR / f"tournament_results_{timestamp}.json"
    report_path = CORPUS_DIR / f"tournament_report_{timestamp}.docx"

    # Validate roster
    for name in roster:
        p = Path(agent_path(name))
        if not p.exists():
            raise FileNotFoundError(f"Agent not found: {p}")

    # Run tournament
    matchup_results = run_tournament(roster, games_per_matchup, parallel)

    # Save raw results
    CORPUS_DIR.mkdir(parents=True, exist_ok=True)
    saved = {
        "roster": roster,
        "games_per_matchup": games_per_matchup,
        "parallel": parallel,
        "timestamp": datetime.now().isoformat(),
        "matchups": {},
    }
    for key, result in matchup_results.items():
        save_copy = {k: v for k, v in result.items() if k != "error_details"}
        saved["matchups"][key] = save_copy
    with open(results_path, "w") as f:
        json.dump(saved, f, indent=2, default=str)
    print(f"  Results saved: {results_path}")

    # Compute
    elo_ratings = compute_elo(matchup_results, roster)
    summaries, elo_rate_matrix, margin_matrix, p_value_matrix = build_aggregates(
        matchup_results, roster
    )
    findings = generate_findings(summaries, elo_ratings, elo_rate_matrix, p_value_matrix, roster)

    # Sort by Elo for display
    ranked = sorted(summaries, key=lambda s: elo_ratings.get(s["name"], 0), reverse=True)

    # Print to stdout
    print_summary_table(ranked, elo_ratings)
    print("  Key Findings:")
    for f_text in findings:
        print(f"    - {f_text}")
    print()

    # Generate docx
    generate_docx(roster, elo_ratings, summaries, elo_rate_matrix, margin_matrix,
                  p_value_matrix, findings, report_path)

    print(f"\n  Done. Report: {report_path}")
    print(f"  Results: {results_path}\n")

    return {
        "roster": roster,
        "games_per_matchup": games_per_matchup,
        "parallel": parallel,
        "matchup_results": matchup_results,
        "elo_ratings": elo_ratings,
        "summaries": summaries,
        "findings": findings,
        "results_path": str(results_path),
        "report_path": str(report_path),
    }


def main():
    parser = argparse.ArgumentParser(description="Round-robin tournament + .docx report")
    parser.add_argument("--games", type=int, default=20, help="Games per matchup (default 20)")
    parser.add_argument("--roster", nargs="+", help="Custom roster of agent names")
    parser.add_argument("--from-results", type=str, help="Rebuild report from saved JSON")
    parser.add_argument("--parallel", type=int, default=PARALLEL, help=f"Parallel workers (default {PARALLEL})")
    args = parser.parse_args()

    roster = args.roster if args.roster else DEFAULT_ROSTER

    if args.from_results:
        # Rebuild report from saved results — stays in main() since it's CLI-only
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")
        report_path = CORPUS_DIR / f"tournament_report_{timestamp}.docx"

        print(f"  Loading results from {args.from_results}")
        with open(args.from_results) as f:
            saved = json.load(f)
        roster = saved["roster"]
        matchup_results = saved["matchups"]

        elo_ratings = compute_elo(matchup_results, roster)
        summaries, elo_rate_matrix, margin_matrix, p_value_matrix = build_aggregates(
            matchup_results, roster
        )
        findings = generate_findings(summaries, elo_ratings, elo_rate_matrix, p_value_matrix, roster)
        ranked = sorted(summaries, key=lambda s: elo_ratings.get(s["name"], 0), reverse=True)

        print_summary_table(ranked, elo_ratings)
        print("  Key Findings:")
        for f_text in findings:
            print(f"    - {f_text}")
        print()

        generate_docx(roster, elo_ratings, summaries, elo_rate_matrix, margin_matrix,
                      p_value_matrix, findings, report_path)
        print(f"\n  Done. Report: {report_path}\n")
    else:
        run_full_tournament(roster, args.games, args.parallel)


if __name__ == "__main__":
    main()
