#!/usr/bin/env python3
"""Twin Analyzer: Cluster LB opponents by behavioral similarity to our agent.

Identifies "twins" — opponents using the same base agent (V9/V39/TTV1) with
different modifications. High-scoring twins reveal what modifications work on LB.

Strategy:
  1. Load our LB replays
  2. For each game, extract both players' action sequences (first N steps)
  3. Compute action agreement between our agent and each opponent
  4. Cluster opponents: twin (>85% agreement), cousin (60-85%), different (<60%)
  5. Among twins, find who scores higher than us and what they do differently

Usage:
    python twin_analyzer.py --episodes-file /tmp/pipe29_episodes.txt
    python twin_analyzer.py --replay-dir autoloop/replays --our-team "Nathan Jacob"
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
REPLAY_DIR = WORK_DIR / "autoloop" / "replays"
OUR_TEAM = "Nathan Jacob"


def load_replay(path):
    """Load a replay JSON file."""
    with open(path) as f:
        return json.load(f)


def identify_seats(replay):
    """Return (our_seat, opp_seat, opp_name) or None if we're not in this game."""
    info = replay.get("info", {})
    teams = info.get("TeamNames", [])

    our_seat = None
    for i, name in enumerate(teams):
        if "Nathan" in str(name):
            our_seat = i
            break

    if our_seat is None:
        return None

    opp_seat = 1 - our_seat
    opp_name = teams[opp_seat] if opp_seat < len(teams) else "Unknown"
    return our_seat, opp_seat, opp_name


def extract_actions(replay, seat, max_step=720):
    """Extract action sequence for a player from replay steps."""
    steps = replay.get("steps", [])
    actions = []
    for step_idx in range(min(max_step, len(steps))):
        step = steps[step_idx]
        if seat < len(step):
            action = step[seat].get("action", {})
            actions.append(action)
        else:
            actions.append({})
    return actions


def action_agreement(actions_a, actions_b, step_range=None):
    """Compute fraction of steps where two action sequences agree.

    Compares: farmer commands, hand commands, market orders.
    Returns agreement ratio [0, 1].
    """
    if step_range:
        start, end = step_range
        actions_a = actions_a[start:end]
        actions_b = actions_b[start:end]

    if not actions_a or not actions_b:
        return 0.0

    n = min(len(actions_a), len(actions_b))
    agree = 0

    for i in range(n):
        a, b = actions_a[i], actions_b[i]
        if not isinstance(a, dict) or not isinstance(b, dict):
            continue

        # Compare farmer actions
        fa = a.get("farmer", ["PASS"])
        fb = b.get("farmer", ["PASS"])
        farmer_match = (fa == fb)

        # Compare hand actions
        ha = a.get("hands", [])
        hb = b.get("hands", [])
        hands_match = (ha == hb)

        # Compare market orders
        ma = sorted([tuple(x) if isinstance(x, list) else x for x in a.get("market", [])])
        mb = sorted([tuple(x) if isinstance(x, list) else x for x in b.get("market", [])])
        market_match = (ma == mb)

        # All three must match for full agreement
        if farmer_match and hands_match and market_match:
            agree += 1

    return agree / n if n > 0 else 0.0


def extract_sell_profile(actions, step_range=None):
    """Extract per-product sell quantities over a step range."""
    if step_range:
        start, end = step_range
        actions = actions[start:end]

    sells = defaultdict(int)
    for action in actions:
        if not isinstance(action, dict):
            continue
        for order in action.get("market", []):
            if isinstance(order, list) and len(order) >= 3 and order[0] == "SELL":
                sells[order[1]] += int(order[2])
    return dict(sells)


def extract_buy_profile(actions, step_range=None):
    """Extract per-product buy quantities over a step range."""
    if step_range:
        start, end = step_range
        actions = actions[start:end]

    buys = defaultdict(int)
    for action in actions:
        if not isinstance(action, dict):
            continue
        for order in action.get("market", []):
            if isinstance(order, list) and len(order) >= 3 and order[0] == "BUY":
                buys[order[1]] += int(order[2])
    return dict(buys)


def extract_money_at_end(replay, seat):
    """Get final money (reward) for a player."""
    steps = replay.get("steps", [])
    if steps:
        last = steps[-1]
        if seat < len(last):
            return last[seat].get("reward", 0) or 0
    return 0


def extract_money_curve(replay, seat):
    """Get money at each day boundary."""
    steps = replay.get("steps", [])
    curve = []
    for day in range(31):
        step_idx = day * 24
        if step_idx >= len(steps):
            break
        obs = steps[step_idx][0].get("observation", {})
        farms = obs.get("farms", [])
        if seat < len(farms):
            curve.append(farms[seat].get("money", 0))
    return curve


def analyze_replays(replay_dir, episode_ids=None, our_team=OUR_TEAM):
    """Main analysis: cluster opponents and find twin divergence."""
    replay_dir = Path(replay_dir)

    if episode_ids:
        replay_files = [replay_dir / f"{eid}.json" for eid in episode_ids]
    else:
        replay_files = sorted(replay_dir.glob("*.json"))

    print(f"Scanning {len(replay_files)} replay files...")

    # Per-opponent stats
    opponents = defaultdict(lambda: {
        "games": 0, "wins": 0, "losses": 0,
        "total_agreement_early": 0.0,  # steps 0-144 (days 0-5)
        "total_agreement_mid": 0.0,    # steps 144-432 (days 6-17)
        "total_agreement_late": 0.0,   # steps 432-720 (days 18-29)
        "our_total_reward": 0, "opp_total_reward": 0,
        "sell_gaps": defaultdict(int),  # product -> (opp_sells - our_sells) in losses
        "loss_episodes": [],
        "win_episodes": [],
    })

    skipped = 0
    analyzed = 0

    for rpath in replay_files:
        if not rpath.exists():
            skipped += 1
            continue

        try:
            replay = load_replay(rpath)
        except (json.JSONDecodeError, OSError):
            skipped += 1
            continue

        seats = identify_seats(replay)
        if seats is None:
            skipped += 1
            continue

        our_seat, opp_seat, opp_name = seats

        our_actions = extract_actions(replay, our_seat)
        opp_actions = extract_actions(replay, opp_seat)

        our_reward = extract_money_at_end(replay, our_seat)
        opp_reward = extract_money_at_end(replay, opp_seat)
        margin = our_reward - opp_reward

        opp = opponents[opp_name]
        opp["games"] += 1
        opp["our_total_reward"] += our_reward
        opp["opp_total_reward"] += opp_reward

        if margin > 0:
            opp["wins"] += 1
            opp["win_episodes"].append(rpath.stem)
        else:
            opp["losses"] += 1
            opp["loss_episodes"].append(rpath.stem)

            # Track sell gaps in losses
            our_sells = extract_sell_profile(opp_actions)  # wait, this should be our_actions
            # Actually: in losses, what does the OPPONENT sell more of?
            our_sells_total = extract_sell_profile(our_actions)
            opp_sells_total = extract_sell_profile(opp_actions)
            for product in set(list(our_sells_total.keys()) + list(opp_sells_total.keys())):
                gap = opp_sells_total.get(product, 0) - our_sells_total.get(product, 0)
                opp["sell_gaps"][product] += gap

        # Action agreement in different phases
        early_agree = action_agreement(our_actions, opp_actions, (0, 144))
        mid_agree = action_agreement(our_actions, opp_actions, (144, 432))
        late_agree = action_agreement(our_actions, opp_actions, (432, 720))

        opp["total_agreement_early"] += early_agree
        opp["total_agreement_mid"] += mid_agree
        opp["total_agreement_late"] += late_agree

        analyzed += 1

    print(f"Analyzed {analyzed} games, skipped {skipped}")

    # Classify opponents
    twins = []      # >85% early agreement
    cousins = []    # 60-85% early agreement
    different = []  # <60% early agreement

    for name, stats in sorted(opponents.items(), key=lambda x: -x[1]["games"]):
        if stats["games"] == 0:
            continue

        avg_early = stats["total_agreement_early"] / stats["games"]
        avg_mid = stats["total_agreement_mid"] / stats["games"]
        avg_late = stats["total_agreement_late"] / stats["games"]
        win_rate = stats["wins"] / stats["games"]
        avg_our = stats["our_total_reward"] / stats["games"]
        avg_opp = stats["opp_total_reward"] / stats["games"]
        avg_margin = avg_our - avg_opp

        entry = {
            "name": name,
            "games": stats["games"],
            "wins": stats["wins"],
            "losses": stats["losses"],
            "win_rate": win_rate,
            "avg_margin": avg_margin,
            "agreement_early": avg_early,
            "agreement_mid": avg_mid,
            "agreement_late": avg_late,
            "sell_gaps_in_losses": dict(stats["sell_gaps"]),
            "loss_episodes": stats["loss_episodes"][:5],
        }

        if avg_early > 0.85:
            twins.append(entry)
        elif avg_early > 0.60:
            cousins.append(entry)
        else:
            different.append(entry)

    return {
        "total_games": analyzed,
        "twins": sorted(twins, key=lambda x: x["win_rate"]),
        "cousins": sorted(cousins, key=lambda x: x["win_rate"]),
        "different": sorted(different, key=lambda x: x["win_rate"]),
    }


def print_report(results):
    """Print human-readable twin analysis report."""
    print(f"\n{'='*80}")
    print(f"TWIN ANALYSIS — {results['total_games']} games analyzed")
    print(f"{'='*80}\n")

    for category, label in [("twins", "TWINS (>85% early agreement — same base)"),
                             ("cousins", "COUSINS (60-85% — related base)"),
                             ("different", "DIFFERENT (<60% — different architecture)")]:
        entries = results[category]
        print(f"\n{'─'*70}")
        print(f"  {label}: {len(entries)} opponents")
        print(f"{'─'*70}")

        if not entries:
            print("  (none)")
            continue

        print(f"  {'Opponent':30s} {'Games':>5s} {'WR':>6s} {'Margin':>8s} {'Early':>6s} {'Mid':>6s} {'Late':>6s}")
        for e in entries:
            print(f"  {e['name'][:30]:30s} {e['games']:5d} {e['win_rate']:5.0%} {e['avg_margin']:+8.0f} "
                  f"{e['agreement_early']:5.1%} {e['agreement_mid']:5.1%} {e['agreement_late']:5.1%}")

        # For twins we lose to, show sell gaps
        if category == "twins":
            losing_twins = [e for e in entries if e["win_rate"] < 0.5 and e["losses"] > 0]
            if losing_twins:
                print(f"\n  SELL GAPS in losses against twins (opp sells more = positive):")
                agg_gaps = defaultdict(int)
                agg_count = 0
                for e in losing_twins:
                    for product, gap in e["sell_gaps_in_losses"].items():
                        agg_gaps[product] += gap
                    agg_count += e["losses"]

                if agg_count > 0:
                    for product in sorted(agg_gaps.keys(), key=lambda p: -abs(agg_gaps[p])):
                        avg_gap = agg_gaps[product] / agg_count
                        print(f"    {product:15s}: {avg_gap:+8.1f} units/game ({agg_gaps[product]:+d} total over {agg_count} losses)")


def deep_diff_twin(replay_dir, episode_id, our_team=OUR_TEAM):
    """Deep step-by-step diff for a specific game against a twin.

    Shows exactly where and how the twin diverges from us.
    """
    replay = load_replay(Path(replay_dir) / f"{episode_id}.json")
    seats = identify_seats(replay)
    if not seats:
        print(f"Can't find our team in episode {episode_id}")
        return

    our_seat, opp_seat, opp_name = seats
    our_actions = extract_actions(replay, our_seat)
    opp_actions = extract_actions(replay, opp_seat)

    our_reward = extract_money_at_end(replay, our_seat)
    opp_reward = extract_money_at_end(replay, opp_seat)

    print(f"\nDEEP DIFF: Episode {episode_id}")
    print(f"  Us ({our_team}): ${our_reward:,.0f}")
    print(f"  Opp ({opp_name}): ${opp_reward:,.0f}")
    print(f"  Margin: ${our_reward - opp_reward:+,.0f}")

    # Find first divergence point
    first_div = None
    div_count = 0

    for step in range(min(len(our_actions), len(opp_actions))):
        a = our_actions[step]
        b = opp_actions[step]
        if not isinstance(a, dict) or not isinstance(b, dict):
            continue

        fa, fb = a.get("farmer", []), b.get("farmer", [])
        ha, hb = a.get("hands", []), b.get("hands", [])
        ma = sorted([tuple(x) if isinstance(x, list) else x for x in a.get("market", [])])
        mb = sorted([tuple(x) if isinstance(x, list) else x for x in b.get("market", [])])

        diffs = []
        if fa != fb:
            diffs.append(f"farmer: us={fa} opp={fb}")
        if ha != hb:
            diffs.append(f"hands: us={ha} opp={hb}")
        if ma != mb:
            diffs.append(f"market: us={ma} opp={mb}")

        if diffs:
            if first_div is None:
                first_div = step
            div_count += 1
            day = step // 24
            hour = step % 24

            if div_count <= 20:  # Show first 20 divergences
                print(f"\n  Step {step} (day {day} hour {hour}):")
                for d in diffs:
                    print(f"    {d[:200]}")

    total = min(len(our_actions), len(opp_actions))
    agree_pct = (total - div_count) / total if total else 0
    print(f"\n  Summary: {div_count} divergent steps out of {total} ({agree_pct:.1%} agreement)")
    print(f"  First divergence: step {first_div} (day {first_div // 24 if first_div else '?'})")

    # Sell comparison by day range
    print(f"\n  SELL COMPARISON:")
    for label, start, end in [("Days 0-5", 0, 144), ("Days 6-11", 144, 288),
                                ("Days 12-17", 288, 432), ("Days 18-23", 432, 576),
                                ("Days 24-29", 576, 720)]:
        our_sells = extract_sell_profile(our_actions, (start, end))
        opp_sells = extract_sell_profile(opp_actions, (start, end))
        products = sorted(set(list(our_sells.keys()) + list(opp_sells.keys())))

        gaps = []
        for p in products:
            ours = our_sells.get(p, 0)
            opps = opp_sells.get(p, 0)
            if ours != opps:
                gaps.append(f"{p}: us={ours} opp={opps} (gap={opps-ours:+d})")

        if gaps:
            print(f"    {label}:")
            for g in gaps:
                print(f"      {g}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Twin analyzer for LB replays")
    parser.add_argument("--replay-dir", default=str(REPLAY_DIR))
    parser.add_argument("--episodes-file", help="File with episode IDs, one per line")
    parser.add_argument("--our-team", default=OUR_TEAM)
    parser.add_argument("--deep-diff", type=str, help="Episode ID for deep diff")
    args = parser.parse_args()

    if args.deep_diff:
        deep_diff_twin(args.replay_dir, args.deep_diff, args.our_team)
    else:
        episode_ids = None
        if args.episodes_file:
            with open(args.episodes_file) as f:
                episode_ids = [line.strip() for line in f if line.strip().isdigit()]

        results = analyze_replays(args.replay_dir, episode_ids, args.our_team)
        print_report(results)

        # Save results
        out = Path(args.replay_dir).parent / "twin_analysis.json"
        with open(out, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        print(f"\nResults saved to {out}")
