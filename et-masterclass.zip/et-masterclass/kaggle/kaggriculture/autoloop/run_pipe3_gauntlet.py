#!/usr/bin/env python3
"""Run pipe-3 gauntlet: pipe-3 vs all agents, 200 games each, sequential."""
import subprocess
import json
import os
import sys
import time

PYTHON = "/Users/nathanjacob/opt/miniconda3/bin/python"
BASE = "/Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop"
COLOSSEUM = os.path.join(BASE, "colosseum.py")
CANDIDATE = os.path.join(BASE, "agents/_candidate/main.py")
AGENTS_DIR = os.path.join(BASE, "agents")
OUTPUT_FILE = os.path.join(BASE, "corpus/pipe3_gauntlet.json")

GAMES = 200
PARALLEL = 10

def get_opponents():
    """Build list of all opponents."""
    opponents = []

    # All non-underscore agents
    for name in sorted(os.listdir(AGENTS_DIR)):
        if name.startswith("_"):
            continue
        agent_path = os.path.join(AGENTS_DIR, name, "main.py")
        if os.path.exists(agent_path):
            opponents.append((name, agent_path))

    # Specific underscore agents
    for name in ["_candidate_pipe1", "_candidate_v41"]:
        agent_path = os.path.join(AGENTS_DIR, name, "main.py")
        if os.path.exists(agent_path):
            opponents.append((name, agent_path))

    return opponents

def run_match(opponent_name, opponent_path):
    """Run a single colosseum match, return parsed result."""
    print(f"\n{'='*60}")
    print(f"  pipe-3 vs {opponent_name}")
    print(f"{'='*60}")

    tmp_output = os.path.join(BASE, "corpus", f"_tmp_{opponent_name}.json")

    cmd = [
        PYTHON, COLOSSEUM,
        CANDIDATE, opponent_path,
        "--games", str(GAMES),
        "--parallel", str(PARALLEL),
        "--output", tmp_output,
    ]

    start = time.time()
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    elapsed = time.time() - start

    # Print stdout for progress
    if result.stdout:
        # Print last few lines (summary)
        lines = result.stdout.strip().split('\n')
        for line in lines[-8:]:
            print(line)

    if result.stderr:
        # Only print errors, not warnings
        for line in result.stderr.strip().split('\n'):
            if 'error' in line.lower() or 'traceback' in line.lower():
                print(f"  STDERR: {line}")

    # Parse result
    if os.path.exists(tmp_output):
        with open(tmp_output) as f:
            data = json.load(f)
        os.remove(tmp_output)
        data['opponent'] = opponent_name
        data['elapsed_seconds'] = round(elapsed, 1)
        return data
    else:
        print(f"  WARNING: No output file for {opponent_name}")
        return {
            'opponent': opponent_name,
            'error': result.stderr[-500:] if result.stderr else 'no output',
            'elapsed_seconds': round(elapsed, 1),
        }

def main():
    opponents = get_opponents()
    print(f"Pipe-3 Gauntlet: {len(opponents)} matches, {GAMES} games each, --parallel {PARALLEL}")
    print(f"Running sequentially to avoid overloading CPU.\n")

    results = []
    total_start = time.time()

    for i, (name, path) in enumerate(opponents):
        print(f"\n[{i+1}/{len(opponents)}]", end="")
        try:
            res = run_match(name, path)
            results.append(res)
        except subprocess.TimeoutExpired:
            print(f"  TIMEOUT for {name}")
            results.append({'opponent': name, 'error': 'timeout'})
        except Exception as e:
            print(f"  ERROR for {name}: {e}")
            results.append({'opponent': name, 'error': str(e)})

    total_elapsed = time.time() - total_start

    # Sort by elo_rate (pipe-3's win rate) descending
    def sort_key(r):
        if 'error' in r:
            return -1
        # elo_rate might be under different keys depending on colosseum output
        for key in ['elo_rate', 'win_rate', 'a_win_rate']:
            if key in r:
                return r[key]
        return -1

    results.sort(key=sort_key, reverse=True)

    # Save full results
    gauntlet = {
        'candidate': 'pipe-3',
        'candidate_path': CANDIDATE,
        'games_per_match': GAMES,
        'parallel': PARALLEL,
        'total_matches': len(results),
        'total_elapsed_seconds': round(total_elapsed, 1),
        'results': results,
    }

    with open(OUTPUT_FILE, 'w') as f:
        json.dump(gauntlet, f, indent=2)

    # Print summary table
    print(f"\n\n{'='*80}")
    print(f"  PIPE-3 GAUNTLET RESULTS ({len(results)} opponents, {GAMES} games each)")
    print(f"  Total time: {total_elapsed/60:.1f} minutes")
    print(f"{'='*80}")
    print(f"{'#':>3}  {'Opponent':<55} {'Rate':>6}  {'W-L-T':>10}")
    print(f"{'-'*3}  {'-'*55} {'-'*6}  {'-'*10}")

    for i, r in enumerate(results):
        name = r.get('opponent', '?')[:55]
        if 'error' in r:
            print(f"{i+1:>3}  {name:<55} {'ERROR':>6}  {r.get('error','')[:10]:>10}")
        else:
            rate = None
            wins = losses = ties = '?'
            for key in ['elo_rate', 'win_rate', 'a_win_rate']:
                if key in r:
                    rate = r[key]
                    break
            for wk in ['a_wins', 'wins']:
                if wk in r:
                    wins = r[wk]
                    break
            for lk in ['a_losses', 'losses']:
                if lk in r:
                    losses = r[lk]
                    break
            for tk in ['ties', 'draws']:
                if tk in r:
                    ties = r[tk]
                    break

            rate_str = f"{rate:.1%}" if rate is not None else "?"
            wlt = f"{wins}-{losses}-{ties}"
            print(f"{i+1:>3}  {name:<55} {rate_str:>6}  {wlt:>10}")

    print(f"\nResults saved to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
