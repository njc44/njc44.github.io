#!/usr/bin/env python3
"""Cluster Engine: Union-Find based strategy clustering from LB replays.

Discovers strategy clusters across the entire leaderboard without requiring
our own submission. Uses disjoint sets (union-find) with high similarity
threshold to group teams by strategy family.

Then identifies inter-cluster losses: when our cluster loses to a higher-Elo
cluster, those losses contain the exact structural gap we need to close.

Usage:
    python cluster_engine.py --build --top 100     # Build clusters from top 100 LB teams
    python cluster_engine.py --status              # Show cluster map
    python cluster_engine.py --analyze             # Find inter-cluster losses for our cluster
"""
import argparse
import json
import subprocess
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
REPLAY_DIR = AUTOLOOP_DIR / "replays"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"
CLUSTER_FILE = CORPUS_DIR / "clusters.json"

OUR_TEAM = "Nathan Jacob"
SIMILARITY_THRESHOLD = 0.90
FINGERPRINT_WINDOW = 144  # first 144 market actions


def log(msg):
    print(f"[cluster] {msg}", flush=True)


# ═══════════════════════════════════════════════════════════
# UNION-FIND
# ═══════════════════════════════════════════════════════════

class UnionFind:
    def __init__(self):
        self.parent = {}
        self.rank = {}

    def find(self, x):
        if x not in self.parent:
            self.parent[x] = x
            self.rank[x] = 0
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # path compression
        return self.parent[x]

    def union(self, x, y):
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return
        # union by rank
        if self.rank[rx] < self.rank[ry]:
            rx, ry = ry, rx
        self.parent[ry] = rx
        if self.rank[rx] == self.rank[ry]:
            self.rank[rx] += 1

    def clusters(self):
        groups = defaultdict(set)
        for x in self.parent:
            groups[self.find(x)].add(x)
        return dict(groups)


# ═══════════════════════════════════════════════════════════
# KAGGLE API
# ═══════════════════════════════════════════════════════════

def get_leaderboard(max_entries=200):
    """Fetch leaderboard."""
    all_entries = []
    page_token = None
    while len(all_entries) < max_entries:
        cmd = ["kaggle", "competitions", "leaderboard", "kaggriculture",
               "--show", "--format", "json", "--page-size", "100"]
        if page_token:
            cmd.extend(["--page-token", page_token])
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        lines = result.stdout.strip().split("\n")
        token_line = ""
        json_start = 0
        for i, line in enumerate(lines):
            if line.startswith("Next Page Token"):
                token_line = line.split("=", 1)[1].strip()
                json_start = i + 1
                break
        json_text = "\n".join(lines[json_start:])
        try:
            entries = json.loads(json_text)
            all_entries.extend(entries)
        except Exception:
            break
        page_token = token_line if token_line else None
        if not page_token:
            break
    return all_entries


def get_team_submissions(team_id):
    """Get submission IDs for a team."""
    result = subprocess.run(
        ["kaggle", "competitions", "team-submissions", str(team_id), "--format", "json"],
        capture_output=True, text=True, timeout=15
    )
    lines = result.stdout.strip().split("\n")
    json_lines = [l for l in lines if not l.startswith("Next Page Token")]
    try:
        subs = json.loads("\n".join(json_lines))
        return [s.get("ref", s.get("id")) for s in subs]
    except Exception:
        subs = []
        for line in result.stdout.strip().split("\n"):
            parts = line.strip().split()
            if parts and parts[0].isdigit():
                subs.append(int(parts[0]))
        return subs


def get_episode_ids(submission_id, max_eps=20):
    """Get episode IDs for a submission."""
    result = subprocess.run(
        ["kaggle", "competitions", "episodes", str(submission_id)],
        capture_output=True, text=True, timeout=30
    )
    episodes = []
    for line in result.stdout.strip().split("\n"):
        parts = line.strip().split()
        if parts and parts[0].isdigit():
            episodes.append(int(parts[0]))
    return episodes[:max_eps]


def download_replay(episode_id, freshness_hours=36):
    """Download and cache a single replay."""
    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    cached = REPLAY_DIR / f"{episode_id}.json"
    if cached.exists():
        age_secs = time.time() - cached.stat().st_mtime
        if age_secs > freshness_hours * 3600:
            cached.unlink()
        else:
            return cached
    try:
        subprocess.run(
            ["kaggle", "competitions", "replay", str(episode_id),
             "-p", str(REPLAY_DIR.resolve()), "-q"],
            capture_output=True, text=True, timeout=60
        )
        downloaded = REPLAY_DIR / f"episode-{episode_id}-replay.json"
        if downloaded.exists():
            downloaded.rename(cached)
            return cached
        return cached if cached.exists() else None
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════
# FINGERPRINTING
# ═══════════════════════════════════════════════════════════

def fingerprint_from_replay(replay, seat):
    """Extract fingerprint: first N market actions as strings."""
    steps = replay.get("steps", [])
    actions = []
    for si in range(min(FINGERPRINT_WINDOW, len(steps))):
        market = steps[si][seat].get("action", {}).get("market", [])
        actions.append(json.dumps(market, sort_keys=True))
    return actions


def compute_similarity(fp1, fp2):
    if not fp1 or not fp2:
        return 0.0
    n = min(len(fp1), len(fp2))
    if n == 0:
        return 0.0
    matches = sum(1 for a, b in zip(fp1[:n], fp2[:n]) if a == b)
    return matches / n


# ═══════════════════════════════════════════════════════════
# CLUSTER BUILDING
# ═══════════════════════════════════════════════════════════

def build_clusters(top_n=100, eps_per_team=10, our_team=None, freshness_hours=36):
    """Build strategy clusters from top N LB teams.

    1. Fetch leaderboard
    2. Download episodes from top teams
    3. Fingerprint every player in every replay
    4. Union-Find: merge teams with >90% similarity
    5. Rank clusters by average Elo
    """
    if our_team is None:
        our_team = OUR_TEAM
    log(f"Fetching leaderboard (top {top_n})...")
    lb = get_leaderboard(top_n)
    log(f"  Got {len(lb)} teams")

    # Build team_id → info map
    team_info = {}
    for entry in lb:
        name = entry["teamName"]
        team_info[name] = {
            "team_id": entry["teamId"],
            "elo": float(entry["score"]),
            "rank": int(entry.get("rank", 0)),
        }

    # Download episodes from top teams and fingerprint
    fingerprints = {}  # team_name → fingerprint
    edges = []  # (team_a, team_b, episode_id, result_for_a, similarity)
    teams_processed = 0

    for entry in lb[:top_n]:
        name = entry["teamName"]
        team_id = entry["teamId"]
        elo = float(entry["score"])

        teams_processed += 1
        if teams_processed % 10 == 0:
            log(f"  Processing team {teams_processed}/{min(top_n, len(lb))}: {name} (Elo {elo:.0f})")

        try:
            subs = get_team_submissions(team_id)
        except Exception:
            continue

        if not subs:
            continue

        # Download episodes from most recent submission only
        sub_id = subs[0]
        try:
            ep_ids = get_episode_ids(sub_id, eps_per_team)
        except Exception:
            continue

        for ep_id in ep_ids:
            replay_path = download_replay(ep_id, freshness_hours=freshness_hours)
            if not replay_path:
                continue

            try:
                replay = json.load(open(replay_path))
            except Exception:
                continue

            teams = replay.get("info", {}).get("TeamNames", [])
            rewards = replay.get("rewards", [0, 0])
            steps = replay.get("steps", [])

            if len(teams) < 2 or len(steps) < FINGERPRINT_WINDOW:
                continue

            # Fingerprint both players
            for seat in [0, 1]:
                t = teams[seat].strip()
                if t not in fingerprints:
                    fp = fingerprint_from_replay(replay, seat)
                    if len(fp) >= FINGERPRINT_WINDOW:
                        fingerprints[t] = fp

            # Record edge
            t0, t1 = teams[0].strip(), teams[1].strip()
            margin_0 = rewards[0] - rewards[1]
            result_0 = "W" if margin_0 > 0 else ("L" if margin_0 < 0 else "T")

            # Compute similarity if both fingerprinted
            sim = 0.0
            if t0 in fingerprints and t1 in fingerprints:
                sim = compute_similarity(fingerprints[t0], fingerprints[t1])

            edges.append({
                "a": t0, "b": t1,
                "episode_id": str(ep_id),
                "result_for_a": result_0,
                "similarity": round(sim, 3),
                "margin": margin_0,
            })

    log(f"  Fingerprinted {len(fingerprints)} teams from {len(edges)} games")

    # Union-Find: merge similar teams
    uf = UnionFind()
    for t in fingerprints:
        uf.find(t)  # ensure all teams are in UF

    merge_count = 0
    teams_list = list(fingerprints.keys())
    for i in range(len(teams_list)):
        for j in range(i + 1, len(teams_list)):
            t1, t2 = teams_list[i], teams_list[j]
            sim = compute_similarity(fingerprints[t1], fingerprints[t2])
            if sim >= SIMILARITY_THRESHOLD:
                uf.union(t1, t2)
                merge_count += 1

    log(f"  Merged {merge_count} pairs at {SIMILARITY_THRESHOLD:.0%} threshold")

    clusters = uf.clusters()

    # Enrich clusters with Elo data
    cluster_data = {}
    for root, members in clusters.items():
        elos = [team_info[m]["elo"] for m in members if m in team_info]
        avg_elo = sum(elos) / len(elos) if elos else 0
        max_elo = max(elos) if elos else 0
        min_elo = min(elos) if elos else 0

        # Find our cluster
        contains_us = our_team in members

        cluster_data[root] = {
            "members": sorted(members),
            "size": len(members),
            "avg_elo": round(avg_elo),
            "max_elo": round(max_elo),
            "min_elo": round(min_elo),
            "contains_us": contains_us,
            "representative": max(members, key=lambda m: team_info.get(m, {}).get("elo", 0)),
        }

    # Sort clusters by avg_elo descending
    ranked_clusters = sorted(cluster_data.items(), key=lambda x: x[1]["avg_elo"], reverse=True)

    # Assign cluster IDs
    for idx, (root, data) in enumerate(ranked_clusters):
        data["cluster_id"] = f"C{idx}"
        if data["contains_us"]:
            data["cluster_id"] = f"C{idx}*"  # mark ours

    # Find inter-cluster edges (games between different clusters)
    inter_cluster_edges = []
    for edge in edges:
        if edge["a"] not in fingerprints or edge["b"] not in fingerprints:
            continue
        root_a = uf.find(edge["a"])
        root_b = uf.find(edge["b"])
        if root_a != root_b:
            inter_cluster_edges.append({
                **edge,
                "cluster_a": cluster_data.get(root_a, {}).get("cluster_id", "?"),
                "cluster_b": cluster_data.get(root_b, {}).get("cluster_id", "?"),
            })

    # Build team_to_cluster mapping
    team_to_cluster = {}
    for _, data in ranked_clusters:
        for member in data["members"]:
            team_to_cluster[member] = data["cluster_id"]

    # Save
    result = {
        "clusters": {data["cluster_id"]: data for _, data in ranked_clusters},
        "team_to_cluster": team_to_cluster,
        "team_info": {k: v for k, v in team_info.items() if k in fingerprints},
        "inter_cluster_edges": inter_cluster_edges,
        "meta": {
            "teams_fingerprinted": len(fingerprints),
            "total_edges": len(edges),
            "inter_cluster_edges": len(inter_cluster_edges),
            "clusters_found": len(clusters),
            "similarity_threshold": SIMILARITY_THRESHOLD,
            "top_n": top_n,
            "timestamp": datetime.now().isoformat(),
        }
    }

    CORPUS_DIR.mkdir(exist_ok=True)
    with open(CLUSTER_FILE, "w") as f:
        json.dump(result, f, indent=2, default=str)

    # Save fingerprints separately (large)
    with open(CORPUS_DIR / "fingerprints.json", "w") as f:
        json.dump(fingerprints, f)

    log(f"  Saved {len(clusters)} clusters to {CLUSTER_FILE}")
    return result


# ═══════════════════════════════════════════════════════════
# ANALYSIS
# ═══════════════════════════════════════════════════════════

def show_status():
    """Print cluster map."""
    if not CLUSTER_FILE.exists():
        print("No clusters built yet. Run --build first.")
        return

    data = json.load(open(CLUSTER_FILE))
    clusters = data["clusters"]
    meta = data["meta"]

    print("=" * 80)
    print("  STRATEGY CLUSTER MAP")
    print("=" * 80)
    print(f"  Teams fingerprinted: {meta['teams_fingerprinted']}")
    print(f"  Clusters found: {meta['clusters_found']}")
    print(f"  Similarity threshold: {meta['similarity_threshold']:.0%}")
    print(f"  Inter-cluster games: {meta['inter_cluster_edges']}")
    print()

    print(f"  {'ID':>5s}  {'Size':>5s}  {'Avg Elo':>8s}  {'Range':>15s}  {'Representative':<30s}")
    print("-" * 80)

    for cid, cdata in sorted(clusters.items(), key=lambda x: x[1]["avg_elo"], reverse=True):
        elo_range = f"{cdata['min_elo']}-{cdata['max_elo']}"
        marker = " ← US" if cdata["contains_us"] else ""
        print(f"  {cid:>5s}  {cdata['size']:>5d}  {cdata['avg_elo']:>8d}  {elo_range:>15s}  "
              f"{cdata['representative']:<30s}{marker}")

    # Show inter-cluster W/L/T summary
    print()
    print("-" * 80)
    print("  INTER-CLUSTER MATCHUPS")
    print("-" * 80)

    matchup_stats = defaultdict(lambda: {"W": 0, "L": 0, "T": 0})
    for edge in data.get("inter_cluster_edges", []):
        key = (edge["cluster_a"], edge["cluster_b"])
        matchup_stats[key][edge["result_for_a"]] += 1

    for (ca, cb), stats in sorted(matchup_stats.items()):
        total = stats["W"] + stats["L"] + stats["T"]
        if total < 2:
            continue
        elo_a = clusters.get(ca, {}).get("avg_elo", 0)
        elo_b = clusters.get(cb, {}).get("avg_elo", 0)
        print(f"  {ca} (elo {elo_a}) vs {cb} (elo {elo_b}): "
              f"{stats['W']}W-{stats['L']}L-{stats['T']}T ({total} games)")

    print("=" * 80)


def analyze_our_cluster(our_team=None):
    """Find losses of our cluster against higher-Elo clusters."""
    if our_team is None:
        our_team = OUR_TEAM
    if not CLUSTER_FILE.exists():
        print("No clusters built yet. Run --build first.")
        return

    data = json.load(open(CLUSTER_FILE))
    clusters = data["clusters"]

    # Find our cluster
    our_cid = None
    for cid, cdata in clusters.items():
        if cdata["contains_us"]:
            our_cid = cid
            break

    if not our_cid:
        print(f"  {our_team} not found in any cluster")
        return

    our_cluster = clusters[our_cid]
    our_members = set(our_cluster["members"])

    print(f"\n  Our cluster: {our_cid}")
    print(f"  Members: {our_cluster['size']}")
    print(f"  Avg Elo: {our_cluster['avg_elo']}")
    print(f"  Range: {our_cluster['min_elo']}-{our_cluster['max_elo']}")

    # Find inter-cluster losses
    losses_by_cluster = defaultdict(list)
    for edge in data.get("inter_cluster_edges", []):
        # Check if our cluster lost
        if edge["cluster_a"] == our_cid and edge["result_for_a"] == "L":
            losses_by_cluster[edge["cluster_b"]].append(edge)
        elif edge["cluster_b"] == our_cid and edge["result_for_a"] == "W":
            # flip perspective
            losses_by_cluster[edge["cluster_a"]].append({
                **edge,
                "a": edge["b"], "b": edge["a"],
                "result_for_a": "L",
                "cluster_a": edge["cluster_b"],
                "cluster_b": edge["cluster_a"],
            })

    if not losses_by_cluster:
        print("  No inter-cluster losses found. Need more replay data.")
        return

    print(f"\n  LOSSES TO HIGHER CLUSTERS:")
    for cid, losses in sorted(losses_by_cluster.items(),
                               key=lambda x: clusters.get(x[0], {}).get("avg_elo", 0), reverse=True):
        opp_cluster = clusters.get(cid, {})
        print(f"\n  vs {cid} (avg elo {opp_cluster.get('avg_elo', '?')}, "
              f"size {opp_cluster.get('size', '?')}):")
        print(f"    Losses: {len(losses)}")
        print(f"    Their representative: {opp_cluster.get('representative', '?')}")

        for loss in losses[:5]:
            print(f"      episode {loss['episode_id']}: "
                  f"{loss['a']} vs {loss['b']}, margin={loss.get('margin', '?'):+,}")

    # Identify the next cluster up (closest higher Elo)
    our_elo = our_cluster["avg_elo"]
    higher_clusters = [(cid, c) for cid, c in clusters.items()
                       if c["avg_elo"] > our_elo and not c["contains_us"]]
    higher_clusters.sort(key=lambda x: x[1]["avg_elo"])

    if higher_clusters:
        next_cid, next_cluster = higher_clusters[0]
        print(f"\n  NEXT CLUSTER TO STUDY: {next_cid}")
        print(f"    Avg Elo: {next_cluster['avg_elo']} (+{next_cluster['avg_elo'] - our_elo} above us)")
        print(f"    Size: {next_cluster['size']}")
        print(f"    Representative: {next_cluster['representative']}")
        print(f"    Members: {', '.join(next_cluster['members'][:10])}")
        losses_to_next = losses_by_cluster.get(next_cid, [])
        print(f"    Our losses to them: {len(losses_to_next)}")
        print(f"\n  → Download more replays between our cluster and {next_cid}")
        print(f"  → Run mechanism tracer on those losses")
        print(f"  → The divergence IS the structural gap to close")


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Cluster Engine: Strategy clustering from LB replays")
    parser.add_argument("--build", action="store_true", help="Build clusters from LB data")
    parser.add_argument("--top", type=int, default=100, help="Top N teams to analyze")
    parser.add_argument("--eps-per-team", type=int, default=10, help="Episodes to download per team")
    parser.add_argument("--status", action="store_true", help="Show cluster map")
    parser.add_argument("--analyze", action="store_true", help="Analyze our cluster's losses")
    args = parser.parse_args()

    if args.status:
        show_status()
    elif args.analyze:
        analyze_our_cluster()
    elif args.build:
        build_clusters(args.top, args.eps_per_team)
        show_status()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
