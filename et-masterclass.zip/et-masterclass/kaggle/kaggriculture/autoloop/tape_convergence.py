#!/usr/bin/env python3
"""
Tape-level convergence analysis: compare our 144-action fingerprint
against the top 5 superior twins to find high-confidence differences.

Each fingerprint has 144 steps: step i maps to day (i // 24), hour (i % 24).
"""

import json
from collections import defaultdict

FINGERPRINTS_PATH = "/Users/nathanjacob/Documents/kaggle/kaggriculture/autoloop/corpus/fingerprints.json"

OUR_KEY = "Nathan Jacob"
TWINS = {
    "lumen":    {"elo": 2941, "similarity": 99.3},
    "Catalyst": {"elo": 2969, "similarity": 98.6},
    "アルモンド":  {"elo": 2962, "similarity": 98.6},
    "Cow Boy":  {"elo": 2940, "similarity": 97.9},
    "mikelou1": {"elo": 2924, "similarity": 98.6},
}

def main():
    with open(FINGERPRINTS_PATH) as f:
        fps = json.load(f)

    ours = fps[OUR_KEY]
    assert len(ours) == 144, f"Expected 144 actions, got {len(ours)}"

    twin_fps = {}
    for name in TWINS:
        twin_fps[name] = fps[name]
        assert len(twin_fps[name]) == 144, f"{name} has {len(twin_fps[name])} actions"

    # ── Collect all differences ──
    diffs = []  # list of {step, day, hour, ours, theirs: {name: action}, consensus_count, consensus_action}

    for step in range(144):
        our_action = ours[step]
        differing_twins = {}
        for name in TWINS:
            twin_action = twin_fps[name][step]
            if twin_action != our_action:
                differing_twins[name] = twin_action

        if not differing_twins:
            continue

        # Count consensus: how many twins agree on the SAME alternative action
        alt_actions = defaultdict(list)
        for name, action in differing_twins.items():
            alt_actions[action].append(name)

        # Find the most common alternative
        best_alt_action, best_alt_names = max(alt_actions.items(), key=lambda x: len(x[1]))

        diffs.append({
            "step": step,
            "day": step // 24,
            "hour": step % 24,
            "our_action": our_action,
            "differing_twins": differing_twins,
            "consensus_count": len(best_alt_names),
            "consensus_names": best_alt_names,
            "consensus_action": best_alt_action,
            "total_differing": len(differing_twins),
        })

    # ── Summary stats ──
    print("=" * 90)
    print("TAPE-LEVEL CONVERGENCE ANALYSIS")
    print(f"Our fingerprint: {OUR_KEY} (144 actions)")
    print(f"Comparing against {len(TWINS)} superior twins")
    print("=" * 90)

    print(f"\nTotal steps where at least 1 twin differs: {len(diffs)} / 144")
    print()

    # Per-twin diff counts
    print("Per-twin difference counts:")
    for name, meta in sorted(TWINS.items(), key=lambda x: -x[1]["elo"]):
        diff_count = sum(1 for step in range(144) if twin_fps[name][step] != ours[step])
        print(f"  {name:15s}  Elo {meta['elo']}  similarity {meta['similarity']:.1f}%  "
              f"diffs: {diff_count}/144 ({100*diff_count/144:.1f}%)")

    # ── Ranked by consensus (highest first) ──
    diffs_sorted = sorted(diffs, key=lambda d: (-d["consensus_count"], -d["total_differing"], d["step"]))

    print("\n" + "=" * 90)
    print("DIFFERENCES RANKED BY CONSENSUS (highest confidence first)")
    print("=" * 90)

    for d in diffs_sorted:
        consensus_pct = d["consensus_count"]
        marker = ""
        if consensus_pct >= 4:
            marker = " *** HIGH CONFIDENCE ***"
        elif consensus_pct >= 3:
            marker = " ** MEDIUM CONFIDENCE **"

        print(f"\nStep {d['step']:3d}  (Day {d['day']}, Hour {d['hour']:2d})  "
              f"| {d['total_differing']}/5 twins differ  "
              f"| consensus: {d['consensus_count']}/5 agree on alt{marker}")

        # Parse and display actions more readably
        print(f"  OUR action:       {d['our_action']}")
        print(f"  CONSENSUS action: {d['consensus_action']}")
        if d["consensus_count"] < d["total_differing"]:
            # Some twins have other alternatives
            other_actions = {}
            for name, action in d["differing_twins"].items():
                if name not in d["consensus_names"]:
                    other_actions[name] = action
            for name, action in other_actions.items():
                print(f"  {name:15s}:  {action}")
        print(f"  Consensus by: {', '.join(d['consensus_names'])}")

    # ── Group by day ──
    print("\n" + "=" * 90)
    print("DIFFERENCES GROUPED BY DAY")
    print("=" * 90)

    by_day = defaultdict(list)
    for d in diffs_sorted:
        by_day[d["day"]].append(d)

    for day in sorted(by_day.keys()):
        day_diffs = by_day[day]
        high_conf = sum(1 for d in day_diffs if d["consensus_count"] >= 4)
        med_conf = sum(1 for d in day_diffs if d["consensus_count"] == 3)
        print(f"\n  Day {day}: {len(day_diffs)} differences "
              f"(high-conf: {high_conf}, med-conf: {med_conf})")
        for d in sorted(day_diffs, key=lambda x: (-x["consensus_count"], x["step"])):
            marker = "*" * min(d["consensus_count"], 5)
            print(f"    Step {d['step']:3d} (h{d['hour']:02d})  "
                  f"consensus {d['consensus_count']}/5  {marker:5s}  "
                  f"us: {d['our_action'][:60]:60s} -> {d['consensus_action'][:60]}")

    # ── Actionable summary ──
    print("\n" + "=" * 90)
    print("ACTIONABLE SUMMARY")
    print("=" * 90)

    high_conf_diffs = [d for d in diffs_sorted if d["consensus_count"] >= 4]
    med_conf_diffs = [d for d in diffs_sorted if d["consensus_count"] == 3]
    low_conf_diffs = [d for d in diffs_sorted if d["consensus_count"] < 3]

    print(f"\n  HIGH confidence (4-5/5 twins agree): {len(high_conf_diffs)} steps")
    print(f"  MEDIUM confidence (3/5 twins agree):  {len(med_conf_diffs)} steps")
    print(f"  LOW confidence (1-2/5 twins agree):   {len(low_conf_diffs)} steps")

    if high_conf_diffs:
        print("\n  HIGH-CONFIDENCE CHANGES TO MAKE:")
        for i, d in enumerate(high_conf_diffs, 1):
            print(f"    {i}. Step {d['step']} (Day {d['day']}, Hour {d['hour']:02d}): "
                  f"change from")
            print(f"         {d['our_action']}")
            print(f"       to")
            print(f"         {d['consensus_action']}")
            print(f"       ({d['consensus_count']}/5 twins: {', '.join(d['consensus_names'])})")


if __name__ == "__main__":
    main()
