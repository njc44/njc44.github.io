#!/usr/bin/env python3
"""Mechanism Tracer: Deterministic causal analysis of losses.

Traces the exact actions where our agent diverged from the winning opponent,
classifies each divergence by game mechanic, and produces specific fix candidates.

NO AI. NO interpretation. Pure replay parsing + classification.

Autoloop v2 additions:
  - Dual-outcome tracing (losses AND wins for control group)
  - Fisher's exact test for mechanism significance
  - Intra-cluster vs inter-cluster split
  - Superior twin loss analysis ("potentially acceptable trade-offs")

Usage:
    python mechanism_tracer.py --analyze                   # Analyze all cached replays
    python mechanism_tracer.py --analyze --team "Nathan Jacob"  # Only our losses
    python mechanism_tracer.py --top 3                     # Show top 3 mechanism candidates
    python mechanism_tracer.py --full-analysis twins.json  # Autoloop v2 full pipeline
"""
import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

from scipy.stats import fisher_exact

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
REPLAY_DIR = AUTOLOOP_DIR / "replays"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"

OUR_TEAM = "Nathan Jacob"

# Game constants
STEPS_PER_DAY = 24
TOTAL_DAYS = 30
ANIMAL_COST = {"COW": 400, "SHEEP": 500, "GOOSE": 300}
SEED_COST = {"WHEAT": 10, "CARROT": 20, "TOMATO": 50, "STRAWBERRY": 100, "MELON": 80}

# Checkpoint days: key decision boundaries
CHECKPOINT_DAYS = [0, 1, 5, 10, 20, 29]


def log(msg):
    print(f"[tracer] {msg}", flush=True)


# ═══════════════════════════════════════════════════════════
# CHECKPOINT EXTRACTION
# ═══════════════════════════════════════════════════════════

def extract_checkpoint(steps, seat, day):
    """Extract full state snapshot at end of a day."""
    step_idx = min((day + 1) * STEPS_PER_DAY - 1, len(steps) - 1)
    if step_idx < 0:
        return None

    obs = steps[step_idx][0]["observation"]
    farm = obs["farms"][seat]
    # Private data is only in our own seat's observation
    private = steps[step_idx][seat].get("observation", {}).get("private", {})

    # Cash
    cash = farm.get("money", 0)

    # Animals
    animals = defaultdict(int)
    animals_unfed = defaultdict(int)
    crops = defaultdict(int)
    structures = defaultdict(int)
    for row in farm.get("tiles", []):
        for t in row:
            if not isinstance(t, dict):
                continue
            if "animal" in t:
                animals[t["animal"]] += 1
                if t.get("consecutive_unfed", 0) > 0:
                    animals_unfed[t["animal"]] += 1
            if "crop" in t:
                crops[t["crop"]] += 1
            kind = t.get("kind", "")
            if kind:
                structures[kind] += 1

    # Workers
    workers = 1 + len(farm.get("hands", []))

    # Shed contents (from private if available, else estimate)
    shed = dict(private.get("shed", {})) if private else {}
    shed_total = sum(v for v in shed.values() if isinstance(v, (int, float)))

    # Cumulative sell revenue (count sells up to this step)
    sell_revenue = 0
    sell_qty = defaultdict(int)
    buy_spend = 0
    for si in range((day + 1) * STEPS_PER_DAY):
        if si >= len(steps):
            break
        action = steps[si][seat].get("action") or {}
        for order in action.get("market", []):
            if not order or len(order) < 3:
                continue
            item, qty = order[1], int(order[2])
            if order[0] == "SELL":
                price = obs.get("market", {}).get("prices", {}).get(item, 0)
                sell_revenue += price * qty
                sell_qty[item] += qty
            elif order[0] in ("BUY_PRODUCT", "BUY_ANIMAL", "BUY_SEED"):
                if order[0] == "BUY_ANIMAL":
                    buy_spend += ANIMAL_COST.get(item, 0) * qty
                elif order[0] == "BUY_SEED":
                    buy_spend += SEED_COST.get(item, 0) * qty

    return {
        "day": day,
        "cash": cash,
        "animals": dict(animals),
        "animals_unfed": dict(animals_unfed),
        "crops": dict(crops),
        "structures": dict(structures),
        "workers": workers,
        "shed_total": shed_total,
        "sell_revenue": sell_revenue,
        "sell_qty": dict(sell_qty),
        "buy_spend": buy_spend,
    }


def compute_checkpoint_deltas(ours, opps):
    """Compute (opponent - us) for each metric at each checkpoint."""
    deltas = {}
    for day in CHECKPOINT_DAYS:
        us = ours.get(day)
        opp = opps.get(day)
        if not us or not opp:
            continue

        d = {"day": day}

        # Scalar deltas
        d["cash"] = opp["cash"] - us["cash"]
        d["workers"] = opp["workers"] - us["workers"]
        d["shed_total"] = opp["shed_total"] - us["shed_total"]
        d["sell_revenue"] = opp["sell_revenue"] - us["sell_revenue"]
        d["buy_spend"] = opp["buy_spend"] - us["buy_spend"]

        # Animal deltas
        all_animals = set(list(us["animals"].keys()) + list(opp["animals"].keys()))
        d["animals"] = {a: opp["animals"].get(a, 0) - us["animals"].get(a, 0)
                        for a in all_animals if opp["animals"].get(a, 0) != us["animals"].get(a, 0)}

        # Crop deltas
        all_crops = set(list(us["crops"].keys()) + list(opp["crops"].keys()))
        d["crops"] = {c: opp["crops"].get(c, 0) - us["crops"].get(c, 0)
                      for c in all_crops if opp["crops"].get(c, 0) != us["crops"].get(c, 0)}

        # Structure deltas
        all_structs = set(list(us["structures"].keys()) + list(opp["structures"].keys()))
        d["structures"] = {s: opp["structures"].get(s, 0) - us["structures"].get(s, 0)
                           for s in all_structs if opp["structures"].get(s, 0) != us["structures"].get(s, 0)}

        deltas[day] = d

    return deltas


def find_first_divergence(deltas):
    """Find earliest checkpoint with meaningful divergence. Returns (day, metric, magnitude)."""
    thresholds = {
        "cash": 150,
        "workers": 1,
        "animals": 1,  # any animal count diff
        "crops": 2,
        "structures": 1,
    }

    for day in CHECKPOINT_DAYS:
        d = deltas.get(day)
        if not d:
            continue

        # Check each metric
        if abs(d["cash"]) >= thresholds["cash"]:
            return day, "cash", d["cash"]
        if abs(d["workers"]) >= thresholds["workers"]:
            return day, "workers", d["workers"]
        if d["animals"]:
            total_gap = sum(abs(v) for v in d["animals"].values())
            if total_gap >= thresholds["animals"]:
                return day, "animals", d["animals"]
        if d["structures"]:
            total_gap = sum(abs(v) for v in d["structures"].values())
            if total_gap >= thresholds["structures"]:
                return day, "structures", d["structures"]
        if d["crops"]:
            total_gap = sum(abs(v) for v in d["crops"].values())
            if total_gap >= thresholds["crops"]:
                return day, "crops", d["crops"]

    return None, None, None


# ═══════════════════════════════════════════════════════════
# ACTION TRACE
# ═══════════════════════════════════════════════════════════

def trace_actions(steps, our_seat, opp_seat, day_start, day_end):
    """Extract all differing market orders and worker actions between two players
    in the step range [day_start*24, day_end*24)."""
    diffs = []

    for step_idx in range(day_start * STEPS_PER_DAY, min((day_end + 1) * STEPS_PER_DAY, len(steps))):
        our_action = steps[step_idx][our_seat].get("action") or {}
        opp_action = steps[step_idx][opp_seat].get("action") or {}

        day = step_idx // STEPS_PER_DAY
        hour = step_idx % STEPS_PER_DAY

        # Compare market orders
        our_market = our_action.get("market", [])
        opp_market = opp_action.get("market", [])

        our_market_str = json.dumps(our_market, sort_keys=True)
        opp_market_str = json.dumps(opp_market, sort_keys=True)

        if our_market_str != opp_market_str:
            diffs.append({
                "step": step_idx,
                "day": day,
                "hour": hour,
                "type": "market",
                "ours": our_market,
                "opponent": opp_market,
            })

        # Compare farmer actions
        our_farmer = our_action.get("farmer", ["PASS"])
        opp_farmer = opp_action.get("farmer", ["PASS"])
        if json.dumps(our_farmer) != json.dumps(opp_farmer):
            diffs.append({
                "step": step_idx,
                "day": day,
                "hour": hour,
                "type": "farmer",
                "ours": our_farmer,
                "opponent": opp_farmer,
            })

        # Compare hand actions
        our_hands = our_action.get("hands", [])
        opp_hands = opp_action.get("hands", [])
        for hand_idx in range(max(len(our_hands), len(opp_hands))):
            our_hand = our_hands[hand_idx] if hand_idx < len(our_hands) else ["PASS"]
            opp_hand = opp_hands[hand_idx] if hand_idx < len(opp_hands) else ["PASS"]
            if json.dumps(our_hand) != json.dumps(opp_hand):
                diffs.append({
                    "step": step_idx,
                    "day": day,
                    "hour": hour,
                    "type": f"hand_{hand_idx}",
                    "ours": our_hand,
                    "opponent": opp_hand,
                })

    return diffs


# ═══════════════════════════════════════════════════════════
# MECHANISM CLASSIFICATION
# ═══════════════════════════════════════════════════════════

def classify_market_diff(our_orders, opp_orders):
    """Classify a market order difference into a mechanism category."""
    def parse_orders(orders):
        parsed = {"buys": {}, "sells": {}, "hires": 0, "land": 0}
        for o in orders:
            if not o or len(o) < 1:
                continue
            op = o[0]
            if op == "HIRE":
                parsed["hires"] += 1
            elif op == "BUY_LAND":
                parsed["land"] += 1
            elif len(o) >= 3:
                item, qty = o[1], int(o[2])
                if op in ("BUY_PRODUCT", "BUY_SEED", "BUY_ANIMAL"):
                    key = f"{op}:{item}"
                    parsed["buys"][key] = parsed["buys"].get(key, 0) + qty
                elif op == "SELL":
                    parsed["sells"][item] = parsed["sells"].get(item, 0) + qty
        return parsed

    ours = parse_orders(our_orders)
    opps = parse_orders(opp_orders)

    # Classify the difference
    categories = []

    # Different buy quantities
    all_buy_keys = set(list(ours["buys"].keys()) + list(opps["buys"].keys()))
    for key in all_buy_keys:
        our_qty = ours["buys"].get(key, 0)
        opp_qty = opps["buys"].get(key, 0)
        if our_qty != opp_qty:
            op_type, item = key.split(":", 1)
            if "ANIMAL" in op_type:
                categories.append(("ECONOMIC/animal_acquisition", key, our_qty, opp_qty))
            elif "SEED" in op_type:
                categories.append(("ECONOMIC/seed_investment", key, our_qty, opp_qty))
            elif "PRODUCT" in op_type:
                categories.append(("ECONOMIC/resource_purchase", key, our_qty, opp_qty))

    # Different sell quantities/items
    all_sell_items = set(list(ours["sells"].keys()) + list(opps["sells"].keys()))
    for item in all_sell_items:
        our_qty = ours["sells"].get(item, 0)
        opp_qty = opps["sells"].get(item, 0)
        if our_qty != opp_qty:
            categories.append(("MARKET/sell_quantity", f"SELL:{item}", our_qty, opp_qty))

    # Different hire counts
    if ours["hires"] != opps["hires"]:
        categories.append(("LABOR/hire_timing", "HIRE", ours["hires"], opps["hires"]))

    # Different land purchases
    if ours["land"] != opps["land"]:
        categories.append(("ECONOMIC/land_expansion", "BUY_LAND", ours["land"], opps["land"]))

    if not categories:
        # Sell ordering difference (same items/quantities, different order)
        if ours["sells"] == opps["sells"] and ours["buys"] == opps["buys"]:
            categories.append(("MARKET/sell_ordering", "order_diff", 0, 0))

    return categories


def classify_worker_diff(our_action, opp_action):
    """Classify a worker action difference."""
    our_op = our_action[0] if our_action else "PASS"
    opp_op = opp_action[0] if opp_action else "PASS"

    if our_op == "PASS" and opp_op != "PASS":
        return ("WORKER/idle_vs_active", f"PASS→{opp_op}", our_action, opp_action)
    elif our_op != opp_op:
        return ("WORKER/action_choice", f"{our_op}→{opp_op}", our_action, opp_action)
    elif len(our_action) > 1 and len(opp_action) > 1 and our_action[1] != opp_action[1]:
        return ("WORKER/target_choice", f"{our_action}→{opp_action}", our_action, opp_action)
    else:
        return ("WORKER/pathing", f"{our_action}→{opp_action}", our_action, opp_action)


# ═══════════════════════════════════════════════════════════
# FULL TRACE PER GAME
# ═══════════════════════════════════════════════════════════

def trace_game(replay, target_team=None, outcome="loss"):
    """Full mechanism trace for one game.

    Args:
        replay: Full replay dict (Kaggle API or colosseum format).
        target_team: Team name to analyze from. If None, uses seat 0.
        outcome: "loss" = only losses, "win" = only wins, "any" = all games.

    Returns trace dict or None if game doesn't match the outcome filter.
    """
    teams = replay.get("info", {}).get("TeamNames", [])
    steps = replay.get("steps", [])
    rewards = replay.get("rewards", [0, 0])

    if len(teams) < 2:
        return None

    # Find our seat
    our_seat = None
    if target_team:
        for i, t in enumerate(teams):
            if t.strip() == target_team.strip():
                our_seat = i
    if our_seat is None:
        our_seat = 0

    opp_seat = 1 - our_seat
    margin = rewards[our_seat] - rewards[opp_seat]

    # Filter by outcome
    if outcome == "loss" and margin >= 0:
        return None
    elif outcome == "win" and margin <= 0:
        return None

    # Early action similarity (twin check)
    matches = 0
    window = min(144, len(steps))
    for si in range(window):
        our_m = steps[si][our_seat].get("action", {}).get("market", [])
        opp_m = steps[si][opp_seat].get("action", {}).get("market", [])
        if json.dumps(our_m, sort_keys=True) == json.dumps(opp_m, sort_keys=True):
            matches += 1
    similarity = matches / window if window > 0 else 0

    # Extract checkpoints
    our_checkpoints = {}
    opp_checkpoints = {}
    for day in CHECKPOINT_DAYS:
        our_checkpoints[day] = extract_checkpoint(steps, our_seat, day)
        opp_checkpoints[day] = extract_checkpoint(steps, opp_seat, day)

    # Compute deltas
    deltas = compute_checkpoint_deltas(our_checkpoints, opp_checkpoints)

    # Find first divergence
    div_day, div_metric, div_magnitude = find_first_divergence(deltas)

    if div_day is None:
        # No clear checkpoint divergence found — late-game or subtle
        div_day = 29
        div_metric = "unknown"
        div_magnitude = margin

    # Trace actions leading to divergence
    # Look at the day OF divergence and the day BEFORE
    trace_start = max(0, div_day - 1) if div_day > 0 else 0
    action_diffs = trace_actions(steps, our_seat, opp_seat, trace_start, div_day)

    # Classify each diff
    mechanisms = []
    for diff in action_diffs:
        if diff["type"] == "market":
            cats = classify_market_diff(diff["ours"], diff["opponent"])
            for cat, detail, our_val, opp_val in cats:
                mechanisms.append({
                    "category": cat,
                    "step": diff["step"],
                    "day": diff["day"],
                    "hour": diff["hour"],
                    "detail": detail,
                    "our_value": our_val,
                    "opp_value": opp_val,
                    "our_action": diff["ours"],
                    "opp_action": diff["opponent"],
                })
        else:
            cat = classify_worker_diff(diff["ours"], diff["opponent"])
            mechanisms.append({
                "category": cat[0],
                "step": diff["step"],
                "day": diff["day"],
                "hour": diff["hour"],
                "detail": cat[1],
                "our_value": str(diff["ours"]),
                "opp_value": str(diff["opponent"]),
                "our_action": diff["ours"],
                "opp_action": diff["opponent"],
            })

    # Get shop combo
    shop_combo = "unknown"
    for day in range(TOTAL_DAYS):
        si = min(day * STEPS_PER_DAY + 23, len(steps) - 1)
        shops = steps[si][0]["observation"].get("town", {}).get("unlocked_shops", [])
        if len(shops) >= 2:
            unique = []
            for s in shops:
                if s not in unique:
                    unique.append(s)
            shop_combo = "+".join(unique[:3])
            break

    # Get game seed for targeted replay
    seed = replay.get("info", {}).get("seed", None)

    return {
        "episode_id": replay.get("info", {}).get("EpisodeId", "unknown"),
        "team": teams[our_seat],
        "opponent": teams[opp_seat],
        "outcome": "win" if margin > 0 else ("tie" if margin == 0 else "loss"),
        "margin": margin,
        "similarity": round(similarity, 3),
        "shop_combo": shop_combo,
        "seed": seed,
        "divergence": {
            "day": div_day,
            "metric": div_metric,
            "magnitude": div_magnitude,
        },
        "mechanisms": mechanisms,
        "primary_mechanism": mechanisms[0]["category"] if mechanisms else "unknown",
        "checkpoints": {
            "ours": {str(k): v for k, v in our_checkpoints.items() if v},
            "opponent": {str(k): v for k, v in opp_checkpoints.items() if v},
        },
        "deltas": {str(k): v for k, v in deltas.items()},
    }


# ═══════════════════════════════════════════════════════════
# AGGREGATION + FIX CANDIDATES
# ═══════════════════════════════════════════════════════════

def aggregate_mechanisms(traces):
    """Aggregate mechanism traces into ranked fix candidates."""
    # Count mechanism categories across all losses
    category_counts = defaultdict(int)
    category_examples = defaultdict(list)
    category_actions = defaultdict(lambda: defaultdict(int))

    for trace in traces:
        seen_categories = set()
        for mech in trace["mechanisms"]:
            cat = mech["category"]
            if cat not in seen_categories:
                category_counts[cat] += 1
                seen_categories.add(cat)
                if len(category_examples[cat]) < 5:
                    category_examples[cat].append({
                        "episode": trace["episode_id"],
                        "opponent": trace["opponent"],
                        "margin": trace["margin"],
                        "shop_combo": trace["shop_combo"],
                        "step": mech["step"],
                        "day": mech["day"],
                        "detail": mech["detail"],
                        "our_action": mech.get("our_action"),
                        "opp_action": mech.get("opp_action"),
                    })

            # Track specific action differences
            action_key = f"{mech['detail']}@day{mech['day']}"
            category_actions[cat][action_key] += 1

    # Rank by count
    ranked = sorted(category_counts.items(), key=lambda x: x[1], reverse=True)

    # Build fix candidates
    candidates = []
    for cat, count in ranked:
        # Find the most common specific action within this category
        top_actions = sorted(category_actions[cat].items(), key=lambda x: x[1], reverse=True)

        candidates.append({
            "mechanism": cat,
            "count": count,
            "frequency": round(count / len(traces), 3) if traces else 0,
            "top_specific_action": top_actions[0] if top_actions else None,
            "examples": category_examples[cat],
        })

    return candidates


def format_report(candidates, traces, team_filter):
    """Format human-readable mechanism report."""
    n_losses = len(traces)
    lines = []
    lines.append("=" * 80)
    lines.append("  MECHANISM TRACER — CAUSAL LOSS ANALYSIS")
    lines.append("=" * 80)
    lines.append(f"  Losses analyzed: {n_losses}")
    lines.append(f"  Team filter: {team_filter or 'all'}")
    lines.append(f"  Tape twins only: losses where similarity > 80%")

    # Filter to tape twin losses
    twin_traces = [t for t in traces if t["similarity"] >= 0.8]
    non_twin_traces = [t for t in traces if t["similarity"] < 0.8]
    lines.append(f"  Twin losses: {len(twin_traces)}")
    lines.append(f"  Non-twin losses: {len(non_twin_traces)}")

    lines.append("")
    lines.append("-" * 80)
    lines.append("  MECHANISMS RANKED BY FREQUENCY (each loss = same Elo hit)")
    lines.append("-" * 80)

    for cand in candidates:
        if cand["count"] == 0:
            continue
        lines.append(f"\n  {cand['mechanism']}")
        lines.append(f"    In {cand['count']}/{n_losses} losses ({cand['frequency']:.0%})")
        if cand["top_specific_action"]:
            action_key, action_count = cand["top_specific_action"]
            lines.append(f"    Most common: {action_key} ({action_count} occurrences)")

        for ex in cand["examples"][:3]:
            lines.append(f"      eg: vs {ex['opponent']} day {ex['day']} step {ex['step']}"
                         f" ({ex['shop_combo']}, margin={ex['margin']:+,.0f})")
            if ex.get("our_action") and ex.get("opp_action"):
                lines.append(f"          us:  {json.dumps(ex['our_action'])[:80]}")
                lines.append(f"          opp: {json.dumps(ex['opp_action'])[:80]}")

    # Divergence day distribution
    lines.append("")
    lines.append("-" * 80)
    lines.append("  DIVERGENCE DAY DISTRIBUTION")
    lines.append("-" * 80)
    day_counts = defaultdict(int)
    for t in traces:
        day_counts[t["divergence"]["day"]] += 1
    for day in sorted(day_counts.keys()):
        bar = "#" * day_counts[day]
        lines.append(f"    Day {day:2d}: {day_counts[day]:3d} losses {bar}")

    # Fix candidates summary
    lines.append("")
    lines.append("-" * 80)
    lines.append("  FIX CANDIDATES (deterministic, from opponent actions)")
    lines.append("-" * 80)
    for i, cand in enumerate(candidates[:5]):
        if cand["count"] == 0:
            continue
        lines.append(f"\n  CANDIDATE #{i+1}: {cand['mechanism']}")
        lines.append(f"    Frequency: {cand['count']}/{n_losses} losses")
        if cand["top_specific_action"]:
            lines.append(f"    Action: {cand['top_specific_action'][0]}")
        if cand["examples"]:
            ex = cand["examples"][0]
            lines.append(f"    Our action:  {json.dumps(ex.get('our_action', '?'))[:100]}")
            lines.append(f"    Opp action:  {json.dumps(ex.get('opp_action', '?'))[:100]}")
            lines.append(f"    At: step {ex['step']} (day {ex['day']}), {ex['shop_combo']}")

    lines.append("")
    lines.append("=" * 80)
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════
# AUTOLOOP V2: FISHER'S TEST + CLUSTER SPLIT + TWIN LOSSES
# ═══════════════════════════════════════════════════════════

def _count_mechanisms_per_game(traces):
    """Count how many games contain each mechanism category (binary per game).

    Returns dict: {category: count_of_games_containing_it}
    """
    counts = defaultdict(int)
    for trace in traces:
        seen = set()
        for mech in trace["mechanisms"]:
            cat = mech["category"]
            if cat not in seen:
                counts[cat] += 1
                seen.add(cat)
    return dict(counts)


def fisher_test_mechanisms(loss_traces, win_traces):
    """For each mechanism, build a 2x2 contingency table and run Fisher's exact test.

    Tests whether a mechanism appears significantly MORE often in losses than wins.
    This filters noise: mechanisms that appear equally in both are NOT causal.

    Args:
        loss_traces: list of trace dicts from losing games
        win_traces: list of trace dicts from winning games

    Returns: list of dicts sorted by p-value ascending:
        [{mechanism, loss_count, win_count, loss_total, win_total,
          loss_freq, win_freq, odds_ratio, p_value, significant}]
    """
    loss_cats = _count_mechanisms_per_game(loss_traces)
    win_cats = _count_mechanisms_per_game(win_traces)

    all_cats = set(loss_cats.keys()) | set(win_cats.keys())
    n_losses = len(loss_traces)
    n_wins = len(win_traces)

    if n_losses == 0 or n_wins == 0:
        return []

    results = []
    for cat in all_cats:
        a = loss_cats.get(cat, 0)    # mechanism present in losses
        b = n_losses - a              # mechanism absent in losses
        c = win_cats.get(cat, 0)      # mechanism present in wins
        d = n_wins - c                # mechanism absent in wins

        table = [[a, b], [c, d]]
        odds_ratio, p_value = fisher_exact(table, alternative='greater')

        effect_size = (a / n_losses) - (c / n_wins)

        results.append({
            "mechanism": cat,
            "loss_count": a,
            "win_count": c,
            "loss_total": n_losses,
            "win_total": n_wins,
            "loss_freq": round(a / n_losses, 3),
            "win_freq": round(c / n_wins, 3),
            "odds_ratio": round(odds_ratio, 3) if not math.isinf(odds_ratio) else 999.0,
            "p_value": round(p_value, 4),
            "effect_size": round(effect_size, 3),
            "significant": p_value < 0.05,
        })

    results.sort(key=lambda x: x["p_value"])
    return results


def split_traces_by_cluster(traces, our_cluster_id, twin_cluster_map):
    """Split traces into intra-cluster and inter-cluster groups.

    Args:
        traces: list of trace dicts
        our_cluster_id: our cluster ID (e.g. "C19")
        twin_cluster_map: dict mapping opponent name -> cluster_id

    Returns: (intra_traces, inter_traces)
        intra = opponents in our cluster (how to top our cluster)
        inter = opponents from higher clusters (how to push boundary)
    """
    clean_id = our_cluster_id.rstrip("*")
    intra = []
    inter = []
    for t in traces:
        opp_cluster = twin_cluster_map.get(t["opponent"], "").rstrip("*")
        if opp_cluster == clean_id:
            intra.append(t)
        else:
            inter.append(t)
    return intra, inter


def analyze_twin_losses(twin_name, twin_elo, replay_paths, replay_dir):
    """Analyze replays where a superior twin LOST.

    These losses reveal what structural trade-offs the twin's strategy entails.
    Marked as "potentially acceptable" — human reviews.

    Args:
        twin_name: name of the superior twin
        twin_elo: twin's Elo rating
        replay_paths: list of episode IDs or file paths
        replay_dir: Path to replay directory

    Returns: {
        "twin": twin_name,
        "twin_elo": twin_elo,
        "losses_analyzed": int,
        "mechanisms": list of mechanism candidates (from aggregate_mechanisms),
        "note": "potentially_acceptable"
    }
    """
    traces = []
    for ep_id in replay_paths:
        replay_path = replay_dir / f"{ep_id}.json" if not str(ep_id).endswith(".json") else Path(ep_id)
        if not replay_path.exists():
            continue
        try:
            replay = json.load(open(replay_path))
        except Exception:
            continue
        trace = trace_game(replay, target_team=twin_name, outcome="loss")
        if trace:
            traces.append(trace)

    return {
        "twin": twin_name,
        "twin_elo": twin_elo,
        "losses_analyzed": len(traces),
        "mechanisms": aggregate_mechanisms(traces) if traces else [],
        "loss_traces": traces,
        "note": "potentially_acceptable",
    }


def run_full_analysis(replay_dir, superior_twins, our_cluster_id, our_team,
                      twin_cluster_map=None, colosseum_loss_dirs=None,
                      freshness_hours=None):
    """Complete Autoloop v2 mechanism analysis pipeline.

    Args:
        replay_dir: Path to replay directory (Kaggle API replays)
        superior_twins: list of dicts with {name, elo, cluster_id, replay_episode_ids, loss_episode_ids}
        our_cluster_id: our cluster ID (e.g. "C19")
        our_team: our team name
        twin_cluster_map: dict mapping team_name -> cluster_id (from clusters.json)
        colosseum_loss_dirs: optional list of Paths to colosseum loss directories
        freshness_hours: if set, only load replays newer than this many hours

    Returns: {
        "intra_cluster": {fisher_results, loss_count, win_count, candidates},
        "inter_cluster": {fisher_results, loss_count, win_count, candidates},
        "superior_twin_losses": {twin_name: {mechanisms, acceptable_loss_rate, ...}},
        "all_fisher_results": [...],
        "meta": {...}
    }
    """
    import time as _time
    if twin_cluster_map is None:
        twin_cluster_map = {}

    # Collect replays — with optional freshness filter
    all_replay_files = sorted(replay_dir.glob("*.json")) if replay_dir.exists() else []
    if freshness_hours and freshness_hours > 0:
        cutoff = _time.time() - freshness_hours * 3600
        replay_files = [f for f in all_replay_files if f.stat().st_mtime >= cutoff]
        log(f"Freshness filter: {len(replay_files)}/{len(all_replay_files)} replays within {freshness_hours}h")
    else:
        replay_files = all_replay_files

    # OPTIMIZATION: Use replay index to skip replays that don't contain our team.
    # The index maps replay filename → list of team names (built lazily, cached to disk).
    index_file = Path(replay_dir) / "_team_index.json" if replay_dir else None
    team_index = {}
    if index_file and index_file.exists():
        try:
            team_index = json.load(open(index_file))
        except Exception:
            team_index = {}

    # Filter to only replays containing our team (or unknown/unindexed ones)
    our_replay_files = []
    index_dirty = False
    for f in replay_files:
        fname = f.name
        if fname in team_index:
            if our_team in team_index[fname]:
                our_replay_files.append(f)
        else:
            # Not indexed yet — quick string search in first 2KB
            try:
                with open(f, 'rb') as fh:
                    header = fh.read(2000).decode('utf-8', errors='ignore')
                if our_team in header:
                    team_index[fname] = [our_team]
                    index_dirty = True
                    our_replay_files.append(f)
                else:
                    team_index[fname] = []
                    index_dirty = True
            except Exception:
                our_replay_files.append(f)  # include if can't peek

    # Save updated index
    if index_dirty and index_file:
        try:
            with open(index_file, 'w') as fh:
                json.dump(team_index, fh)
        except Exception:
            pass

    log(f"Team filter: {len(our_replay_files)}/{len(replay_files)} replays contain '{our_team}'")

    # Also load colosseum loss files if provided
    colosseum_replays = []
    if colosseum_loss_dirs:
        for loss_dir in colosseum_loss_dirs:
            loss_dir = Path(loss_dir)
            if loss_dir.exists():
                for f in sorted(loss_dir.glob("*.json")):
                    try:
                        colosseum_replays.append(json.load(open(f)))
                    except Exception:
                        continue

    log(f"Loading {len(our_replay_files)} API replays + {len(colosseum_replays)} colosseum replays")

    # Trace all games from our perspective — both losses AND wins
    all_loss_traces = []
    all_win_traces = []

    # From API replays (only those containing our team)
    for i, replay_file in enumerate(our_replay_files):
        if i % 200 == 0 and i > 0:
            log(f"  Tracing replay {i}/{len(our_replay_files)}...")
        try:
            replay = json.load(open(replay_file))
        except Exception:
            continue
        teams = replay.get("info", {}).get("TeamNames", [])
        if len(teams) < 2:
            continue
        if our_team not in [t.strip() for t in teams]:
            continue

        loss_trace = trace_game(replay, target_team=our_team, outcome="loss")
        if loss_trace:
            all_loss_traces.append(loss_trace)
        win_trace = trace_game(replay, target_team=our_team, outcome="win")
        if win_trace:
            all_win_traces.append(win_trace)

    # From colosseum losses (always losses from our perspective = agent_a)
    for replay in colosseum_replays:
        loss_trace = trace_game(replay, target_team="agent_a", outcome="loss")
        if loss_trace:
            all_loss_traces.append(loss_trace)
        win_trace = trace_game(replay, target_team="agent_a", outcome="win")
        if win_trace:
            all_win_traces.append(win_trace)

    log(f"Traced {len(all_loss_traces)} losses, {len(all_win_traces)} wins")

    # Split by cluster
    intra_losses, inter_losses = split_traces_by_cluster(
        all_loss_traces, our_cluster_id, twin_cluster_map)
    intra_wins, inter_wins = split_traces_by_cluster(
        all_win_traces, our_cluster_id, twin_cluster_map)

    log(f"Intra-cluster: {len(intra_losses)} losses, {len(intra_wins)} wins")
    log(f"Inter-cluster: {len(inter_losses)} losses, {len(inter_wins)} wins")

    # Fisher's test — all combined
    all_fisher = fisher_test_mechanisms(all_loss_traces, all_win_traces)

    # Fisher's test — intra-cluster
    intra_fisher = fisher_test_mechanisms(intra_losses, intra_wins)

    # Fisher's test — inter-cluster
    inter_fisher = fisher_test_mechanisms(inter_losses, inter_wins)

    # Aggregate fix candidates (traditional frequency-based, for backward compat)
    all_candidates = aggregate_mechanisms(all_loss_traces)
    intra_candidates = aggregate_mechanisms(intra_losses)
    inter_candidates = aggregate_mechanisms(inter_losses)

    # Superior twin loss analysis
    twin_loss_analysis = {}
    for twin in superior_twins:
        twin_name = twin.get("name", "")
        twin_elo = twin.get("elo", 0)
        loss_eps = twin.get("loss_episode_ids", [])
        if loss_eps:
            analysis = analyze_twin_losses(twin_name, twin_elo, loss_eps, replay_dir)
            twin_loss_analysis[twin_name] = {
                "twin_elo": twin_elo,
                "cluster_id": twin.get("cluster_id", ""),
                "losses_analyzed": analysis["losses_analyzed"],
                "mechanisms": analysis["mechanisms"],
                "note": analysis["note"],
            }

    result = {
        "intra_cluster": {
            "cluster_id": our_cluster_id,
            "loss_count": len(intra_losses),
            "win_count": len(intra_wins),
            "fisher_results": intra_fisher,
            "candidates": intra_candidates,
        },
        "inter_cluster": {
            "loss_count": len(inter_losses),
            "win_count": len(inter_wins),
            "fisher_results": inter_fisher,
            "candidates": inter_candidates,
        },
        "all_fisher_results": all_fisher,
        "all_candidates": all_candidates,
        "superior_twin_losses": twin_loss_analysis,
        "meta": {
            "our_team": our_team,
            "our_cluster_id": our_cluster_id,
            "total_losses": len(all_loss_traces),
            "total_wins": len(all_win_traces),
            "n_superior_twins": len(superior_twins),
            "n_twin_losses_analyzed": sum(
                v["losses_analyzed"] for v in twin_loss_analysis.values()),
        },
    }

    return result


def format_fisher_report(fisher_results, label, n_losses, n_wins):
    """Format Fisher's test results as human-readable text."""
    lines = []
    lines.append(f"\n{'─' * 80}")
    lines.append(f"  {label} — Fisher's Exact Test (losses={n_losses}, wins={n_wins})")
    lines.append(f"{'─' * 80}")
    lines.append(f"  {'Mechanism':<35} {'Loss%':>6} {'Win%':>6} {'OR':>7} {'p-value':>8} {'Sig':>4}")
    lines.append(f"  {'─' * 70}")

    for r in fisher_results:
        sig = " ***" if r["significant"] else ""
        lines.append(
            f"  {r['mechanism']:<35} {r['loss_freq']:>5.0%} {r['win_freq']:>5.0%} "
            f"{r['odds_ratio']:>7.1f} {r['p_value']:>8.4f}{sig}"
        )

    sig_count = sum(1 for r in fisher_results if r["significant"])
    lines.append(f"\n  {sig_count}/{len(fisher_results)} mechanisms statistically significant (p<0.05)")
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Mechanism Tracer")
    parser.add_argument("--analyze", action="store_true", help="Analyze all cached replays")
    parser.add_argument("--full-analysis", type=str, metavar="TWINS_JSON",
                        help="Autoloop v2: full analysis with twin targets JSON")
    parser.add_argument("--team", type=str, default=None, help="Filter to specific team's losses")
    parser.add_argument("--top", type=int, default=5, help="Number of top candidates to show")
    parser.add_argument("--twin-only", action="store_true", help="Only analyze losses vs tape twins (>80% sim)")
    parser.add_argument("--cluster-id", type=str, default=None, help="Our cluster ID for v2 analysis")
    parser.add_argument("--loss-dirs", nargs="*", help="Colosseum loss directories to include")
    args = parser.parse_args()

    # Autoloop v2: full analysis pipeline
    if args.full_analysis:
        twins_data = json.load(open(args.full_analysis))
        our_team = args.team or OUR_TEAM
        cluster_id = args.cluster_id or "C19"

        # Build twin_cluster_map from twins data
        twin_cluster_map = {}
        for twin in twins_data:
            twin_cluster_map[twin["name"]] = twin.get("cluster_id", "")

        loss_dirs = [Path(d) for d in args.loss_dirs] if args.loss_dirs else None

        result = run_full_analysis(
            replay_dir=REPLAY_DIR,
            superior_twins=twins_data,
            our_cluster_id=cluster_id,
            our_team=our_team,
            twin_cluster_map=twin_cluster_map,
            colosseum_loss_dirs=loss_dirs,
        )

        # Print Fisher results
        print(format_fisher_report(
            result["all_fisher_results"], "ALL MECHANISMS",
            result["meta"]["total_losses"], result["meta"]["total_wins"]))
        if result["intra_cluster"]["fisher_results"]:
            print(format_fisher_report(
                result["intra_cluster"]["fisher_results"], "INTRA-CLUSTER (top of our cluster)",
                result["intra_cluster"]["loss_count"], result["intra_cluster"]["win_count"]))
        if result["inter_cluster"]["fisher_results"]:
            print(format_fisher_report(
                result["inter_cluster"]["fisher_results"], "INTER-CLUSTER (push boundary)",
                result["inter_cluster"]["loss_count"], result["inter_cluster"]["win_count"]))

        # Print superior twin losses
        if result["superior_twin_losses"]:
            print(f"\n{'─' * 80}")
            print(f"  SUPERIOR TWIN LOSSES (potentially acceptable trade-offs)")
            print(f"{'─' * 80}")
            for twin_name, info in result["superior_twin_losses"].items():
                print(f"\n  {twin_name} (Elo {info['twin_elo']}, cluster {info['cluster_id']})")
                print(f"    Losses analyzed: {info['losses_analyzed']}")
                for m in info["mechanisms"][:3]:
                    print(f"    - {m['mechanism']}: {m['count']}x ({m['frequency']:.0%})")

        # Save
        CORPUS_DIR.mkdir(exist_ok=True)
        analysis_file = CORPUS_DIR / "mechanism_analysis.json"
        # Remove non-serializable fields
        save_result = json.loads(json.dumps(result, default=str))
        with open(analysis_file, "w") as f:
            json.dump(save_result, f, indent=2)
        log(f"Saved full analysis to {analysis_file}")
        return

    if not args.analyze:
        parser.print_help()
        return

    # Load all cached replays
    replay_files = sorted(REPLAY_DIR.glob("*.json"))
    log(f"Loading {len(replay_files)} replays...")

    # Determine which teams to analyze from
    target_teams = set()
    if args.team:
        target_teams.add(args.team)
    else:
        target_teams.add(OUR_TEAM)

    # Also analyze from known twin perspectives if no specific team
    if not args.team:
        # Auto-discover twins from replays
        twin_names = {OUR_TEAM}
        fingerprints = {}
        for replay_file in replay_files:
            try:
                replay = json.load(open(replay_file))
            except Exception:
                continue
            teams = replay.get("info", {}).get("TeamNames", [])
            steps = replay.get("steps", [])
            if len(teams) < 2 or len(steps) < 144:
                continue

            for i, team in enumerate(teams):
                if team.strip() in twin_names:
                    # Fingerprint the opponent
                    opp_seat = 1 - i
                    opp_name = teams[opp_seat].strip()
                    opp_actions = tuple(
                        json.dumps(steps[si][opp_seat].get("action", {}).get("market", []), sort_keys=True)
                        for si in range(min(144, len(steps)))
                    )
                    if opp_name not in fingerprints:
                        fingerprints[opp_name] = opp_actions
                    # Check similarity to known twins
                    for known in list(twin_names):
                        if known in fingerprints:
                            matches = sum(1 for a, b in zip(opp_actions, fingerprints[known]) if a == b)
                            sim = matches / len(opp_actions) if opp_actions else 0
                            if sim >= 0.9:
                                twin_names.add(opp_name)
                                break

        target_teams = twin_names
        log(f"Discovered {len(twin_names)} twins")

    # Trace all losses
    traces = []
    for replay_file in replay_files:
        try:
            replay = json.load(open(replay_file))
        except Exception:
            continue

        teams = replay.get("info", {}).get("TeamNames", [])
        if len(teams) < 2:
            continue

        for team in target_teams:
            if team in [t.strip() for t in teams]:
                trace = trace_game(replay, target_team=team)
                if trace:
                    if args.twin_only and trace["similarity"] < 0.8:
                        continue
                    traces.append(trace)

    log(f"Traced {len(traces)} losses")

    if not traces:
        log("No losses to analyze")
        return

    # Aggregate
    candidates = aggregate_mechanisms(traces)

    # Report
    report = format_report(candidates, traces, args.team)
    print(report)

    # Save
    CORPUS_DIR.mkdir(exist_ok=True)

    report_file = CORPUS_DIR / "mechanism_report.txt"
    with open(report_file, "w") as f:
        f.write(report)

    traces_file = CORPUS_DIR / "mechanism_traces.json"
    # Slim down traces for JSON (remove full checkpoint data)
    slim_traces = []
    for t in traces:
        slim = {k: v for k, v in t.items() if k != "checkpoints"}
        slim_traces.append(slim)
    with open(traces_file, "w") as f:
        json.dump(slim_traces, f, indent=2, default=str)

    candidates_file = CORPUS_DIR / "mechanism_candidates.json"
    with open(candidates_file, "w") as f:
        json.dump(candidates, f, indent=2, default=str)

    log(f"Saved: {report_file}, {traces_file}, {candidates_file}")


if __name__ == "__main__":
    main()
