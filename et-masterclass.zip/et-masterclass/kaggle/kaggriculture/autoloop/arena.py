#!/usr/bin/env python3
"""Arena: H2H tournament ranking of all agents.

Runs round-robin (or targeted) matches between agents.
Produces rankings and identifies the best agent.

Usage:
    python arena.py                          # Full round-robin
    python arena.py --quick                  # Only test new/unranked agents
    python arena.py --challenge agent_name   # Test one agent against the current top 3
    python arena.py --games 20              # Games per matchup (default 20)
"""
import argparse
import json
import math
import os
import sys
import time
from datetime import datetime
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"
STATE_FILE = AUTOLOOP_DIR / "state.json"
RANKINGS_FILE = AUTOLOOP_DIR / "rankings.json"

PYTHON = "/Users/nathanjacob/opt/miniconda3/bin/python"

sys.path.insert(0, str(WORK_DIR))


def log(msg):
    print(f"[arena] {msg}", flush=True)


# ── Stats ─────────────────────────────────────────────────────

def wilson_ci(wins, total, z=1.96):
    if total == 0:
        return (0.0, 0.0)
    p = wins / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denom
    return (max(0, center - margin), min(1, center + margin))


# ── Match runner ──────────────────────────────────────────────

def run_matchup(a_path, b_path, games_per_seat=10, timeout_per_game=30):
    """Run agent A vs agent B, alternating seats. Returns stats dict."""
    from kaggle_environments import make
    import signal

    wins, losses, ties, errors = 0, 0, 0, 0
    scores_a, scores_b = [], []

    total_games = games_per_seat * 2
    for i in range(total_games):
        if i < games_per_seat:
            p0, p1, cand_seat = str(a_path), str(b_path), 0
        else:
            p0, p1, cand_seat = str(b_path), str(a_path), 1

        try:
            game_start = time.time()
            # LB-identical: no debug flag, no config overrides
            env = make("kaggriculture")
            result = env.run([p0, p1])
            game_elapsed = time.time() - game_start

            # If a single game takes > timeout, mark as slow and bail
            if game_elapsed > timeout_per_game:
                errors += total_games - i - 1  # count remaining as errors
                log(f"    Game took {game_elapsed:.0f}s (>{timeout_per_game}s), aborting matchup")
                break

            final = result[-1]
            r0, r1 = final[0]["reward"], final[1]["reward"]
            s0, s1 = final[0]["status"], final[1]["status"]

            if s0 != "DONE" or s1 != "DONE":
                errors += 1
                continue

            rc = r0 if cand_seat == 0 else r1
            ro = r1 if cand_seat == 0 else r0
            scores_a.append(rc)
            scores_b.append(ro)

            if rc > ro:
                wins += 1
            elif ro > rc:
                losses += 1
            else:
                ties += 1
        except Exception as e:
            errors += 1

    total = wins + losses + ties
    wr = wins / total if total else 0
    ci = wilson_ci(wins, total)
    avg_a = sum(scores_a) / len(scores_a) if scores_a else 0
    avg_b = sum(scores_b) / len(scores_b) if scores_b else 0

    return {
        "wins": wins, "losses": losses, "ties": ties, "errors": errors,
        "total": total, "win_rate": wr,
        "ci_95": list(ci),
        "avg_score_a": avg_a, "avg_score_b": avg_b,
        "margin": avg_a - avg_b,
    }


# ── Load state ────────────────────────────────────────────────

def load_state():
    if STATE_FILE.exists():
        with open(STATE_FILE) as f:
            return json.load(f)
    return {}


def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def load_rankings():
    if RANKINGS_FILE.exists():
        with open(RANKINGS_FILE) as f:
            return json.load(f)
    return {"agents": {}, "matchups": {}, "last_updated": None}


def save_rankings(rankings):
    rankings["last_updated"] = datetime.now().isoformat()
    with open(RANKINGS_FILE, "w") as f:
        json.dump(rankings, f, indent=2)


# ── Get all available agents ──────────────────────────────────

def get_agents():
    """Return dict of agent_name -> main.py path."""
    agents = {}
    for d in sorted(AGENTS_DIR.iterdir()):
        if d.is_dir() and (d / "main.py").exists():
            agents[d.name] = str(d / "main.py")
    return agents


# ── Tournament ────────────────────────────────────────────────

def run_tournament(agents, games_per_seat=10, quick=False, challenge=None, top_n=5):
    """Run H2H matches and return rankings."""
    rankings = load_rankings()
    agent_names = list(agents.keys())

    if challenge:
        # Test the challenged agent against top N
        if challenge not in agents:
            log(f"Agent '{challenge}' not found")
            return rankings

        # Find top N from existing rankings
        sorted_agents = sorted(
            rankings.get("agents", {}).items(),
            key=lambda x: x[1].get("elo", 1000), reverse=True
        )
        opponents = [name for name, _ in sorted_agents[:top_n] if name in agents and name != challenge]
        if not opponents:
            opponents = [n for n in agent_names if n != challenge][:3]

        pairs = [(challenge, opp) for opp in opponents]
        log(f"Challenge mode: {challenge} vs {opponents}")

    elif quick:
        # Only test agents that don't have rankings yet
        ranked = set(rankings.get("agents", {}).keys())
        new_agents = [n for n in agent_names if n not in ranked]
        if not new_agents:
            log("No new agents to rank")
            return rankings

        # Find top 3 existing agents to test against
        sorted_agents = sorted(
            rankings.get("agents", {}).items(),
            key=lambda x: x[1].get("elo", 1000), reverse=True
        )
        benchmarks = [name for name, _ in sorted_agents[:3] if name in agents]
        if not benchmarks:
            # Prefer known-strong agents as initial benchmarks
            preferred = ["reyhanks_dynamic", "reyhanksatria__kaggriculture-dynamic-route-agent",
                         "flexon_powerful", "nusrati__2650-score", "prvsiyan_soil"]
            benchmarks = [p for p in preferred if p in agents][:3]
            if not benchmarks:
                benchmarks = agent_names[:3]

        pairs = [(new, bench) for new in new_agents for bench in benchmarks if new != bench]
        log(f"Quick mode: testing {new_agents} against {benchmarks}")

    else:
        # Full round-robin
        pairs = [(a, b) for i, a in enumerate(agent_names)
                 for b in agent_names[i+1:]]
        log(f"Full round-robin: {len(pairs)} matchups across {len(agent_names)} agents")

    # Run matches
    matchups = rankings.get("matchups", {})
    for i, (a, b) in enumerate(pairs):
        key = f"{a}_vs_{b}"
        rev_key = f"{b}_vs_{a}"

        # Skip if already have recent results (unless full mode)
        if not challenge and key in matchups and quick:
            continue

        log(f"  [{i+1}/{len(pairs)}] {a} vs {b} ({games_per_seat*2} games)...")
        t0 = time.time()
        stats = run_matchup(agents[a], agents[b], games_per_seat)
        elapsed = time.time() - t0

        verdict = "WINS" if stats["win_rate"] >= 0.55 else ("LOSES" if stats["win_rate"] <= 0.45 else "EVEN")
        log(f"    {stats['wins']}W-{stats['losses']}L-{stats['ties']}T  "
            f"WR={stats['win_rate']*100:.1f}%  Margin={stats['margin']:+,.0f}  "
            f"({elapsed:.0f}s) -> {verdict}")

        matchups[key] = {
            "agent_a": a, "agent_b": b,
            **stats,
            "timestamp": datetime.now().isoformat(),
        }

    rankings["matchups"] = matchups

    # Compute Elo-style ratings from matchup results
    elo = {name: 1500.0 for name in agent_names}
    K = 32

    # Run Elo updates from all matchups (multiple passes for convergence)
    for _ in range(5):
        for key, m in matchups.items():
            a, b = m["agent_a"], m["agent_b"]
            if a not in elo or b not in elo:
                continue

            ea = 1 / (1 + 10 ** ((elo[b] - elo[a]) / 400))
            eb = 1 - ea
            sa = m["win_rate"]
            sb = 1 - sa

            elo[a] += K * (sa - ea)
            elo[b] += K * (sb - eb)

    # Build agent summaries
    agent_summaries = {}
    for name in agent_names:
        total_wins, total_losses, total_ties = 0, 0, 0
        total_margin = 0
        matchup_count = 0

        for key, m in matchups.items():
            if m["agent_a"] == name:
                total_wins += m["wins"]
                total_losses += m["losses"]
                total_ties += m["ties"]
                total_margin += m["margin"]
                matchup_count += 1
            elif m["agent_b"] == name:
                total_wins += m["losses"]  # reversed
                total_losses += m["wins"]
                total_ties += m["ties"]
                total_margin -= m["margin"]
                matchup_count += 1

        total = total_wins + total_losses + total_ties
        agent_summaries[name] = {
            "elo": round(elo.get(name, 1500), 1),
            "wins": total_wins,
            "losses": total_losses,
            "ties": total_ties,
            "total_games": total,
            "win_rate": total_wins / total if total else 0,
            "avg_margin": total_margin / matchup_count if matchup_count else 0,
            "matchups_played": matchup_count,
        }

    rankings["agents"] = agent_summaries

    # Sort and display
    sorted_agents = sorted(agent_summaries.items(), key=lambda x: x[1]["elo"], reverse=True)

    log(f"\n{'='*70}")
    log(f"  ARENA RANKINGS")
    log(f"{'='*70}")
    log(f"  {'Rank':<5} {'Agent':<30} {'Elo':<8} {'W-L-T':<15} {'WR':<8} {'Margin':<10}")
    log(f"  {'-'*5} {'-'*30} {'-'*8} {'-'*15} {'-'*8} {'-'*10}")
    for rank, (name, s) in enumerate(sorted_agents, 1):
        log(f"  {rank:<5} {name:<30} {s['elo']:<8.0f} "
            f"{s['wins']}W-{s['losses']}L-{s['ties']}T{'':<3} "
            f"{s['win_rate']*100:<8.1f} {s['avg_margin']:+,.0f}")
    log(f"{'='*70}\n")

    save_rankings(rankings)

    # Update state with best agent
    if sorted_agents:
        best_name = sorted_agents[0][0]
        best_stats = sorted_agents[0][1]

        state = load_state()
        state["best_public_agent"] = best_name
        state["best_public_elo"] = best_stats["elo"]
        state["best_public_wr"] = best_stats["win_rate"]
        state["arena_last_run"] = datetime.now().isoformat()
        state["arena_agent_count"] = len(agent_names)
        state["rankings_summary"] = [
            {"name": name, "elo": s["elo"], "wr": round(s["win_rate"], 3)}
            for name, s in sorted_agents[:5]
        ]
        save_state(state)

        log(f"Best public agent: {best_name} (Elo {best_stats['elo']:.0f})")

    return rankings


# ── Entry point ───────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Arena: H2H tournament")
    parser.add_argument("--games", type=int, default=20,
                        help="Total games per matchup (split across seats)")
    parser.add_argument("--quick", action="store_true",
                        help="Only rank new/unranked agents")
    parser.add_argument("--challenge", type=str,
                        help="Test one specific agent against top N")
    parser.add_argument("--top-n", type=int, default=5,
                        help="Number of top agents to test against in challenge mode (default 5)")
    args = parser.parse_args()

    log("=== ARENA START ===")

    agents = get_agents()
    if len(agents) < 2:
        log(f"Need at least 2 agents, found {len(agents)}")
        return

    log(f"Agents: {list(agents.keys())}")

    games_per_seat = max(1, args.games // 2)
    run_tournament(agents, games_per_seat=games_per_seat,
                   quick=args.quick, challenge=args.challenge,
                   top_n=getattr(args, 'top_n', 5))

    log("=== ARENA DONE ===")


if __name__ == "__main__":
    main()
