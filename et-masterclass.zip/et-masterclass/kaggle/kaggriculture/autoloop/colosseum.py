#!/usr/bin/env python3
"""Colosseum: The ONLY test harness for agent evaluation.

This script is the single source of truth for all game results.
No AI, no interpretation, no shortcuts. Same rules as the Kaggle LB.

Design principles:
  - DETERMINISTIC: Same inputs → same outputs. No AI in the loop.
  - LB-IDENTICAL: Uses make('kaggriculture') with NO debug flag, NO config overrides.
  - HONEST: Reports exactly what happened. Never summarizes, never interprets.

Usage:
    python colosseum.py candidate.py base.py --games 30
    python colosseum.py candidate.py base.py --games 30 --output results.json
    python colosseum.py --gauntlet candidate.py --games 20  # vs top 5 from rankings
"""
import argparse
import json
import math
import os
import sys
import time
from datetime import datetime
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"
RANKINGS_FILE = AUTOLOOP_DIR / "rankings.json"


def wilson_ci(wins, total, z=1.96):
    """Wilson score confidence interval for win rate."""
    if total == 0:
        return (0.0, 0.0)
    p = wins / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    spread = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denom
    return (max(0, center - spread), min(1, center + spread))


def binomial_significance(wins, losses, ties):
    """Test if win rate is significantly different from 50% (i.e., the improvement matters).

    For Elo, ties are draws (0.5 each). We test:
      H0: elo_points_rate = 0.5 (no improvement)
      H1: elo_points_rate != 0.5

    Uses normal approximation to binomial.
    Returns: (elo_points_rate, p_value, is_significant_at_05)
    """
    # Elo points: win=1, tie=0.5, loss=0
    total = wins + losses + ties
    if total == 0:
        return 0.5, 1.0, False

    elo_points = wins + 0.5 * ties
    elo_rate = elo_points / total  # expected: 0.5 if no difference

    # Standard error under H0 (p=0.5)
    se = math.sqrt(0.25 / total)
    if se == 0:
        return elo_rate, 1.0, False

    z = (elo_rate - 0.5) / se
    # Two-tailed p-value (normal approximation)
    p_value = 2 * (1 - _normal_cdf(abs(z)))

    return round(elo_rate, 4), round(p_value, 4), p_value < 0.05


def _normal_cdf(x):
    """Approximation of the standard normal CDF."""
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def _resolve_agent_path(path_str):
    """Resolve agent path: if it's a directory, append /main.py."""
    p = Path(path_str)
    if p.is_dir():
        main_py = p / "main.py"
        if main_py.exists():
            return str(main_py)
    return path_str


def _run_single_game(args):
    """Run one game. Module-level function for ProcessPoolExecutor pickling."""
    agent_a, agent_b, game_idx, total_games, save_losses_dir = args
    from kaggle_environments import make

    agent_a = _resolve_agent_path(agent_a)
    agent_b = _resolve_agent_path(agent_b)

    games_per_seat = total_games // 2
    seat = 0 if game_idx < games_per_seat else 1
    if seat == 0:
        p0, p1 = str(agent_a), str(agent_b)
    else:
        p0, p1 = str(agent_b), str(agent_a)

    game_start = time.time()
    try:
        env = make("kaggriculture")
        result = env.run([p0, p1])
        elapsed = time.time() - game_start

        final = result[-1]
        r0, r1 = final[0]["reward"], final[1]["reward"]
        s0, s1 = final[0]["status"], final[1]["status"]

        if s0 != "DONE" or s1 != "DONE":
            return {"type": "error", "game": game_idx, "seat": seat,
                    "elapsed": round(elapsed, 1), "error": f"Non-DONE status: {s0}, {s1}"}

        score_a = r0 if seat == 0 else r1
        score_b = r1 if seat == 0 else r0
        margin = score_a - score_b
        outcome = "WIN" if margin > 0 else ("LOSE" if margin < 0 else "TIE")

        # Save full replay for losses (and optionally ties) to disk
        if save_losses_dir and outcome in ("LOSE", "TIE"):
            _save_loss_replay(result, game_idx, seat, margin, save_losses_dir)

        return {"type": "game", "game": game_idx, "seat": seat,
                "score_a": score_a, "score_b": score_b, "margin": margin,
                "result": outcome, "elapsed": round(elapsed, 1)}
    except Exception as e:
        elapsed = time.time() - game_start
        return {"type": "error", "game": game_idx, "seat": seat,
                "elapsed": round(elapsed, 1), "error": str(e)}


def _save_loss_replay(result, game_idx, our_seat, margin, save_dir):
    """Save full step data for a loss/tie to disk. Compact format for mechanism tracer."""
    save_path = Path(save_dir)
    save_path.mkdir(parents=True, exist_ok=True)

    steps_data = []
    for step in result:
        step_entry = []
        for player in [0, 1]:
            step_entry.append({
                "action": step[player].get("action", {}),
                "observation": {
                    "farms": step[player].get("observation", {}).get("farms", []),
                    "market": step[player].get("observation", {}).get("market", {}),
                    "town": step[player].get("observation", {}).get("town", {}),
                    "private": step[player].get("observation", {}).get("private", {}),
                    "step": step[player].get("observation", {}).get("step", 0),
                    "player": step[player].get("observation", {}).get("player", 0),
                }
            })
        steps_data.append(step_entry)

    replay = {
        "game": game_idx,
        "our_seat": our_seat,
        "margin": margin,
        "rewards": [result[-1][0]["reward"], result[-1][1]["reward"]],
        "info": {"TeamNames": ["agent_a", "agent_b"]},
        "steps": steps_data,
    }

    out_file = save_path / f"loss_{game_idx:04d}.json"
    with open(out_file, "w") as f:
        json.dump(replay, f)


def run_h2h(agent_a, agent_b, total_games=30, parallel=1, save_losses_dir=None):
    """Run agent_a vs agent_b. LB-identical rules. No debug flag.

    Returns a dict with every game's result and aggregate stats.
    This function NEVER interprets results — it only reports facts.
    If save_losses_dir is set, saves full replay data for losses and ties to that directory.
    """
    games = []
    errors = []

    args_list = [(str(agent_a), str(agent_b), i, total_games, save_losses_dir)
                 for i in range(total_games)]

    if parallel > 1:
        from concurrent.futures import ProcessPoolExecutor, as_completed
        with ProcessPoolExecutor(max_workers=parallel) as executor:
            futures = [executor.submit(_run_single_game, a) for a in args_list]
            for future in as_completed(futures):
                r = future.result()
                if r["type"] == "game":
                    games.append(r)
                else:
                    errors.append(r)
    else:
        for a in args_list:
            r = _run_single_game(a)
            if r["type"] == "game":
                games.append(r)
            else:
                errors.append(r)

    # Aggregate — pure arithmetic, no interpretation
    wins = sum(1 for g in games if g["result"] == "WIN")
    losses = sum(1 for g in games if g["result"] == "LOSE")
    ties = sum(1 for g in games if g["result"] == "TIE")
    total_played = wins + losses + ties

    avg_score_a = sum(g["score_a"] for g in games) / len(games) if games else 0
    avg_score_b = sum(g["score_b"] for g in games) / len(games) if games else 0
    avg_margin = sum(g["margin"] for g in games) / len(games) if games else 0

    ci = wilson_ci(wins, total_played)

    # Elo-correct scoring: ties count as 0.5 for each player
    elo_rate, p_value, is_significant = binomial_significance(wins, losses, ties)

    # Cohen's h: effect size. <0.2 = negligible, 0.2-0.5 = small, 0.5-0.8 = medium, >0.8 = large
    cohens_h = 2 * math.asin(math.sqrt(elo_rate)) - 2 * math.asin(math.sqrt(0.5)) if total_played else 0

    return {
        "agent_a": str(agent_a),
        "agent_b": str(agent_b),
        "total_requested": total_games,
        "total_played": total_played,
        "wins": wins,
        "losses": losses,
        "ties": ties,
        "errors": len(errors),
        "win_rate": wins / total_played if total_played else 0,
        "ci_95": list(ci),
        # Elo-correct metrics (THE ONES THAT MATTER)
        "elo_rate": elo_rate,          # wins + 0.5*ties / total. >0.5 = better for Elo
        "p_value": p_value,            # statistical significance vs H0: no difference
        "is_significant": is_significant,  # p < 0.05
        "cohens_h": round(cohens_h, 3),   # effect size: <0.2 negligible, 0.2-0.5 small, >0.5 medium+
        # Legacy (informational only — margin does NOT affect Elo)
        "avg_score_a": round(avg_score_a),
        "avg_score_b": round(avg_score_b),
        "avg_margin": round(avg_margin),
        "games": games,
        "error_details": errors,
        "timestamp": datetime.now().isoformat(),
        "config": "LB-identical: make('kaggriculture'), no debug, no overrides",
    }


def print_report(result, label_a="Agent A", label_b="Agent B"):
    """Print a clean report. Facts only."""
    print(f"\n{'='*70}")
    print(f"  COLOSSEUM REPORT")
    print(f"  {label_a} vs {label_b}")
    print(f"  Config: {result['config']}")
    print(f"{'='*70}")
    print(f"  Result:   {result['wins']}W-{result['losses']}L-{result['ties']}T "
          f"({result['total_played']} games, {result['errors']} errors)")
    sig_marker = "***" if result.get('is_significant') else "(not significant)"
    h = result.get('cohens_h', 0)
    h_label = "negligible" if abs(h) < 0.2 else ("small" if abs(h) < 0.5 else ("medium" if abs(h) < 0.8 else "large"))
    print(f"  Elo Rate: {result.get('elo_rate', 0)*100:.1f}% "
          f"(p={result.get('p_value', 1):.3f}) {sig_marker}")
    print(f"  Effect:   h={h:+.3f} ({h_label})")
    print(f"  Win Rate: {result['win_rate']*100:.1f}% "
          f"(95% CI: [{result['ci_95'][0]*100:.0f}%-{result['ci_95'][1]*100:.0f}%])")
    print(f"  Avg Margin: {result['avg_margin']:+,} (NOTE: margin does NOT affect Elo)")

    # Show per-game results
    print(f"\n  Per-game:")
    for g in result["games"]:
        tag = g["result"]
        print(f"    Game {g['game']:2d} (seat {g['seat']}): {tag:4s}  "
              f"${g['score_a']:>9,.0f} vs ${g['score_b']:>9,.0f}  "
              f"margin={g['margin']:+,.0f}  ({g['elapsed']:.0f}s)")

    if result["error_details"]:
        print(f"\n  Errors:")
        for e in result["error_details"]:
            print(f"    Game {e['game']}: {e['error']}")

    print(f"{'='*70}\n")


def get_top_n_agents(n=5):
    """Get top N agents from arena rankings."""
    if not RANKINGS_FILE.exists():
        return []

    with open(RANKINGS_FILE) as f:
        rankings = json.load(f)

    agents = rankings.get("agents", {})
    sorted_agents = sorted(agents.items(), key=lambda x: x[1].get("elo", 0), reverse=True)

    result = []
    for name, stats in sorted_agents[:n]:
        path = AGENTS_DIR / name / "main.py"
        if path.exists():
            result.append((name, str(path)))

    return result


def run_gauntlet(candidate_path, total_games=30, top_n=5, parallel=1, save_losses_dir=None):
    """Run candidate against top N agents from rankings."""
    top_agents = get_top_n_agents(top_n)
    if not top_agents:
        print("ERROR: No ranked agents found. Run arena first.")
        return None

    all_results = {}
    total_wins, total_losses, total_ties = 0, 0, 0

    for name, opp_path in top_agents:
        if str(candidate_path) == opp_path:
            continue  # skip self

        print(f"\n  vs {name} ({total_games} games)...", flush=True)
        result = run_h2h(candidate_path, opp_path, total_games, parallel, save_losses_dir)
        print_report(result, "_candidate", name)

        all_results[name] = result
        total_wins += result["wins"]
        total_losses += result["losses"]
        total_ties += result["ties"]

    total = total_wins + total_losses + total_ties
    print(f"\n{'#'*70}")
    print(f"  GAUNTLET SUMMARY")
    print(f"  Candidate: {candidate_path}")
    print(f"  Overall: {total_wins}W-{total_losses}L-{total_ties}T "
          f"({total_wins/total*100:.0f}% WR)" if total else "  No games played")
    print(f"{'#'*70}\n")

    return all_results


def main():
    parser = argparse.ArgumentParser(
        description="Colosseum: LB-identical agent testing. No AI. No lies.")
    parser.add_argument("agent_a", nargs="?", help="Path to agent A (or candidate for gauntlet)")
    parser.add_argument("agent_b", nargs="?", help="Path to agent B")
    parser.add_argument("--games", type=int, default=200, help="Total games (split across seats). 200+ recommended for significance.")
    parser.add_argument("--output", type=str, help="Save results to JSON file")
    parser.add_argument("--gauntlet", action="store_true",
                        help="Run agent_a against top N from arena rankings")
    parser.add_argument("--top-n", type=int, default=5, help="Top N agents for gauntlet (default 5)")
    parser.add_argument("--parallel", type=int, default=1, help="Parallel workers (default 1, try 10 for speed)")
    parser.add_argument("--save-losses", type=str, metavar="DIR",
                        help="Save full replay data for losses+ties to this directory (for mechanism tracer)")

    args = parser.parse_args()

    if not args.agent_a:
        parser.print_help()
        return

    os.chdir(str(WORK_DIR))

    if args.gauntlet:
        results = run_gauntlet(args.agent_a, args.games, args.top_n, args.parallel, args.save_losses)
        if args.output and results:
            with open(args.output, "w") as f:
                json.dump(results, f, indent=2, default=str)
            print(f"Saved to {args.output}")
    else:
        if not args.agent_b:
            print("ERROR: Need agent_b for H2H. Use --gauntlet for top-N test.")
            return

        result = run_h2h(args.agent_a, args.agent_b, args.games, args.parallel, args.save_losses)
        name_a = Path(args.agent_a).parent.name
        name_b = Path(args.agent_b).parent.name
        print_report(result, name_a, name_b)

        if args.output:
            with open(args.output, "w") as f:
                json.dump(result, f, indent=2, default=str)
            print(f"Saved to {args.output}")


if __name__ == "__main__":
    main()
