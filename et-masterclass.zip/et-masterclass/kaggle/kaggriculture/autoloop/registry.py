#!/usr/bin/env python3
"""Experiment Registry: Log every candidate tested, prevent retrying known failures.

Every candidate that passes through the autoloop v5 pipeline gets logged here
with its panel result (+a/-b), colosseum result, and final status.

Before generating a new candidate, check_similar() catches duplicates.

Usage:
    python registry.py --log '{"description": "BUY 20/SELL 15 opening", "domain": "opening"}'
    python registry.py --query --domain opening
    python registry.py --query --status rejected
    python registry.py --check '{"description": "BUY 20/SELL 15 opening", "domain": "opening"}'
    python registry.py --summary
"""
import argparse
import hashlib
import json
import os
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


REGISTRY_PATH = Path(__file__).parent / "corpus" / "experiment_registry.json"


@dataclass
class Experiment:
    id: str
    description: str
    domain: str  # "opening" | "animal" | "sell_timing" | "hire" | "crop" | "shed" | "absorb"
    code_hash: str = ""
    panel_result: Optional[dict] = None   # {plus_a, minus_b, net, games_tested}
    colosseum_result: Optional[dict] = None  # {wins, losses, ties, elo_rate}
    timestamp: str = ""
    status: str = "pending"  # "pending" | "panel_pass" | "colosseum_pass" | "accepted" | "rejected"
    rejection_reason: Optional[str] = None
    source: str = "manual"  # "auditor:OpeningAuditor" | "absorb:v48_ADV" | "manual"
    candidate_spec: Optional[dict] = None

    def to_dict(self):
        return {k: v for k, v in asdict(self).items() if v is not None}

    @classmethod
    def from_dict(cls, d):
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        return cls(**{k: v for k, v in d.items() if k in valid_fields})


def _jaccard(a: str, b: str) -> float:
    """Token-overlap Jaccard similarity on whitespace-split strings."""
    tokens_a = set(a.lower().split())
    tokens_b = set(b.lower().split())
    if not tokens_a or not tokens_b:
        return 0.0
    return len(tokens_a & tokens_b) / len(tokens_a | tokens_b)


class ExperimentRegistry:
    def __init__(self, path=None):
        self.path = Path(path) if path else REGISTRY_PATH
        self.experiments = []
        self._load()

    def _load(self):
        if self.path.exists():
            with open(self.path) as f:
                data = json.load(f)
            self.experiments = [Experiment.from_dict(e) for e in data.get("experiments", [])]
        else:
            self.experiments = []

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "version": 1,
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "experiments": [e.to_dict() for e in self.experiments],
        }
        with open(self.path, "w") as f:
            json.dump(data, f, indent=2)

    def _next_id(self):
        existing = [int(e.id.split("_")[1]) for e in self.experiments
                    if e.id.startswith("EXP_") and e.id.split("_")[1].isdigit()]
        n = max(existing, default=0) + 1
        return f"EXP_{n:03d}"

    def log(self, description: str, domain: str, source: str = "manual",
            code_hash: str = "", candidate_spec: dict = None,
            panel_result: dict = None, colosseum_result: dict = None,
            status: str = "pending", rejection_reason: str = None) -> str:
        """Log a new experiment. Returns the experiment ID."""
        exp = Experiment(
            id=self._next_id(),
            description=description,
            domain=domain,
            code_hash=code_hash,
            panel_result=panel_result,
            colosseum_result=colosseum_result,
            timestamp=datetime.now(timezone.utc).isoformat(),
            status=status,
            rejection_reason=rejection_reason,
            source=source,
            candidate_spec=candidate_spec,
        )
        self.experiments.append(exp)
        self._save()
        return exp.id

    def check_similar(self, description: str, domain: str,
                      code_hash: str = "", threshold: float = 0.7):
        """Check if a similar experiment exists. Returns list of matches."""
        matches = []
        for exp in self.experiments:
            # Exact code hash match
            if code_hash and exp.code_hash and code_hash == exp.code_hash:
                matches.append(exp)
                continue
            # Same domain + high description similarity
            if exp.domain == domain and _jaccard(description, exp.description) >= threshold:
                matches.append(exp)
        return matches

    def check_rejected(self, description: str, domain: str, code_hash: str = ""):
        """Check if a similar experiment was already REJECTED. Returns matches."""
        similar = self.check_similar(description, domain, code_hash)
        return [e for e in similar if e.status == "rejected"]

    def update(self, exp_id: str, status: str = None, rejection_reason: str = None,
               panel_result: dict = None, colosseum_result: dict = None):
        """Update an existing experiment."""
        for exp in self.experiments:
            if exp.id == exp_id:
                if status:
                    exp.status = status
                if rejection_reason:
                    exp.rejection_reason = rejection_reason
                if panel_result:
                    exp.panel_result = panel_result
                if colosseum_result:
                    exp.colosseum_result = colosseum_result
                self._save()
                return True
        return False

    def query(self, domain: str = None, status: str = None,
              keyword: str = None):
        """Query experiments by domain, status, or keyword."""
        results = self.experiments
        if domain:
            results = [e for e in results if e.domain == domain]
        if status:
            results = [e for e in results if e.status == status]
        if keyword:
            kw = keyword.lower()
            results = [e for e in results if kw in e.description.lower()]
        return results

    def summary(self):
        """Print a summary of all experiments."""
        total = len(self.experiments)
        by_status = {}
        by_domain = {}
        for e in self.experiments:
            by_status[e.status] = by_status.get(e.status, 0) + 1
            by_domain[e.domain] = by_domain.get(e.domain, 0) + 1

        print(f"Experiment Registry: {total} experiments")
        print(f"  By status: {by_status}")
        print(f"  By domain: {by_domain}")
        print()

        # Show recent experiments
        recent = sorted(self.experiments, key=lambda e: e.timestamp, reverse=True)[:10]
        if recent:
            print(f"{'ID':<10} {'Status':<12} {'Domain':<12} {'Description':<50} {'Panel':<15}")
            print("-" * 99)
            for e in recent:
                panel = ""
                if e.panel_result:
                    p = e.panel_result
                    panel = f"+{p.get('plus_a', '?')}/-{p.get('minus_b', '?')}"
                desc = e.description[:48]
                print(f"{e.id:<10} {e.status:<12} {e.domain:<12} {desc:<50} {panel:<15}")


def main():
    parser = argparse.ArgumentParser(description="Experiment Registry")
    parser.add_argument("--log", help="Log experiment (JSON string)")
    parser.add_argument("--query", action="store_true", help="Query experiments")
    parser.add_argument("--domain", help="Filter by domain")
    parser.add_argument("--status", help="Filter by status")
    parser.add_argument("--keyword", help="Filter by keyword")
    parser.add_argument("--check", help="Check for similar experiments (JSON string)")
    parser.add_argument("--update-id", help="Experiment ID to update")
    parser.add_argument("--update-status", help="New status")
    parser.add_argument("--update-reason", help="Rejection reason")
    parser.add_argument("--summary", action="store_true", help="Print summary")
    parser.add_argument("--registry-path", help="Override registry path")
    args = parser.parse_args()

    reg = ExperimentRegistry(args.registry_path)

    if args.log:
        data = json.loads(args.log)
        exp_id = reg.log(**data)
        print(f"Logged: {exp_id}")

    elif args.check:
        data = json.loads(args.check)
        similar = reg.check_similar(
            description=data.get("description", ""),
            domain=data.get("domain", ""),
            code_hash=data.get("code_hash", ""),
        )
        if similar:
            print(f"Found {len(similar)} similar experiments:")
            for e in similar:
                print(f"  {e.id} [{e.status}] {e.description[:60]}")
                if e.status == "rejected":
                    print(f"    REJECTED: {e.rejection_reason}")
        else:
            print("No similar experiments found.")

    elif args.update_id:
        ok = reg.update(args.update_id, status=args.update_status,
                        rejection_reason=args.update_reason)
        print("Updated" if ok else "Not found")

    elif args.query:
        results = reg.query(domain=args.domain, status=args.status, keyword=args.keyword)
        for e in results:
            panel = ""
            if e.panel_result:
                p = e.panel_result
                panel = f" panel=+{p.get('plus_a', '?')}/-{p.get('minus_b', '?')}"
            print(f"  {e.id} [{e.status}] {e.domain}: {e.description[:60]}{panel}")
            if e.rejection_reason:
                print(f"    reason: {e.rejection_reason}")

    elif args.summary:
        reg.summary()

    else:
        reg.summary()


if __name__ == "__main__":
    main()
