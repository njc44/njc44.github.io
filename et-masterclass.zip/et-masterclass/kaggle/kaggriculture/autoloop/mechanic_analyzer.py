#!/usr/bin/env python3
"""Mechanic Analyzer: Generate candidate layers from game engine rules.

Each auditor examines one game mechanic, compares our agent's decisions to
the theoretical optimum, and proposes candidate improvements.

This is the ORIGINATION engine — generates ideas from game rules, not from
opponent code diffs. Complements (not replaces) v4's absorption pipeline.

Usage:
    python mechanic_analyzer.py --agent agents/pipe11/main.py --all
    python mechanic_analyzer.py --agent agents/pipe11/main.py --audit opening
    python mechanic_analyzer.py --agent agents/pipe11/main.py --audit sell_timing --replays replays/
    python mechanic_analyzer.py --list  # list available auditors
"""
import argparse
import json
import math
import os
import sys
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import List, Optional

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
sys.path.insert(0, str(AUTOLOOP_DIR))


def log(msg):
    print(f"[mechanic] {msg}", flush=True)


# ═══════════════════════════════════════════════════════════
# GAME CONSTANTS (from kaggle_environments kaggriculture.py)
# ═══════════════════════════════════════════════════════════

STEPS_PER_DAY = 24
TOTAL_DAYS = 30
TOTAL_STEPS = 720

# Hire costs: Fibonacci sequence. N-th hire of a day costs fib(N-1).
HIRE_COSTS = [1, 1]
while len(HIRE_COSTS) < 20:
    HIRE_COSTS.append(HIRE_COSTS[-1] + HIRE_COSTS[-2])

ANIMAL_SPECS = {
    "GOOSE": {"cost": 300, "structure": "COOP", "first_yield_day": 4,
              "interval": 1, "max_held": 4, "product": "EGG", "feed": False},
    "COW":   {"cost": 400, "structure": "PASTURE", "first_yield_day": 8,
              "interval": 2, "max_held": 6, "product": "MILK", "feed": True},
    "SHEEP": {"cost": 500, "structure": "PASTURE", "first_yield_day": 6,
              "interval": 3, "max_held": 6, "product": "WOOL", "feed": True},
}

CROP_SPECS = {
    "WHEAT":      {"seed_cost": 10,  "yield": 4, "grow_days": 2, "max_yield": 6},
    "CARROT":     {"seed_cost": 20,  "yield": 3, "grow_days": 2, "max_yield": 4},
    "TOMATO":     {"seed_cost": 50,  "yield": 2, "grow_days": 8, "ongoing": True},
    "STRAWBERRY": {"seed_cost": 100, "yield": 1, "grow_days": 10, "ongoing": True},
    "MELON":      {"seed_cost": 80,  "yield": 1, "grow_days": 10},
}

SHED_CAPACITY = 100

# Shop demand: which products each shop type consumes
SHOP_DEMAND = {
    "BAKERY":          ["EGG", "WHEAT"],
    "PIZZA_SHOP":      ["MILK", "TOMATO", "WHEAT"],
    "BRUNCH_SPOT":     ["EGG", "WHEAT", "STRAWBERRY"],
    "YARN_STORE":      ["WOOL"],
    "ICE_CREAM_SHOP":  ["STRAWBERRY", "MILK", "WHEAT"],
    "PET_CAFE":        ["CARROT"],
    "SMOOTHIE_SHOP":   ["STRAWBERRY", "MILK"],
    "FARMERS_MARKET":  ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY"],
}

# Product → animal mapping
PRODUCT_ANIMAL = {"EGG": "GOOSE", "MILK": "COW", "WOOL": "SHEEP"}


# Import market price model from mechanism_tracer_v3
try:
    from mechanism_tracer_v3 import market_price, _MARKET_PARAMS
except ImportError:
    _MARKET_PARAMS = None
    def market_price(item, inventory):
        return 25  # fallback


# ═══════════════════════════════════════════════════════════
# CANDIDATE SPEC
# ═══════════════════════════════════════════════════════════

@dataclass
class CandidateSpec:
    id: str
    domain: str             # "opening" | "animal" | "sell_timing" | "hire" | "crop" | "shed"
    description: str
    estimated_impact: str   # "+15/-0 expected from Tschinkel analogy"
    source: str             # "auditor:HireAuditor"
    code_template: str = "" # Optional Python layer code
    details: dict = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)


# ═══════════════════════════════════════════════════════════
# AUDITORS
# ═══════════════════════════════════════════════════════════

class OpeningAuditor:
    """Wraps fix_search.py. Sweeps BUY/SELL quantities with lockstep simulation.

    Tschinkel's finding: BUY 20/SELL 15 is optimal (+107/-0 on 6,648 openings).
    Our pipe-8 used BUY 5 only. This auditor finds the best opening config.
    """
    name = "OpeningAuditor"
    domain = "opening"

    def audit(self, agent_path=None, replays=None) -> List[CandidateSpec]:
        candidates = []
        try:
            from fix_search import sweep_openings, recommend_opening
            results = sweep_openings()
            rec = recommend_opening(results)
            if rec:
                candidates.append(CandidateSpec(
                    id=f"OPENING_{rec.get('buy', '?')}_{rec.get('sell', '?')}",
                    domain=self.domain,
                    description=f"Opening: BUY {rec.get('buy')} / SELL {rec.get('sell')} wheat at step 0",
                    estimated_impact=f"avg_net_cash={rec.get('avg_net_cash', '?')}, "
                                     f"min_cash={rec.get('min_cash_after', '?')}",
                    source=f"auditor:{self.name}",
                    details=rec,
                ))
        except Exception as e:
            log(f"  OpeningAuditor error: {e}")

        # Also propose Tschinkel's proven opening
        candidates.append(CandidateSpec(
            id="OPENING_BUY20_SELL15",
            domain=self.domain,
            description="Tschinkel v9/4 opening: BUY 20 / SELL 15 wheat at step 0 (net +5). "
                        "+107/-0 on 6,648 recorded openings.",
            estimated_impact="+107/-0 (Tschinkel verified)",
            source=f"auditor:{self.name}",
            details={"buy": 20, "sell": 15, "source": "tschinkel_v9_4"},
        ))

        return candidates


class AnimalAuditor:
    """Recommend optimal COW/SHEEP/GOOSE mix based on shop types.

    Key insights from game analysis:
    - COW preference is universal above 2900 Elo
    - CARE banking is most of what animals produce (3× for COW/SHEEP, 2× for GOOSE)
    - Sheep placed day 11 get 5 harvests vs 4 on day 12 (Tschinkel VE1: +8/-1)
    - Animal choice should be conditioned on shop reveals
    """
    name = "AnimalAuditor"
    domain = "animal"

    def _score_animal(self, animal, shops, placement_day):
        """Score expected revenue from placing an animal on a given day."""
        spec = ANIMAL_SPECS[animal]
        product = spec["product"]

        # Count how many shops demand this product
        demand_shops = sum(1 for s in shops if product in SHOP_DEMAND.get(s, []))

        # Production schedule
        first = placement_day + spec["first_yield_day"]
        if first >= TOTAL_DAYS:
            return 0

        harvests = 0
        day = first
        while day < TOTAL_DAYS:
            harvests += 1
            day += spec["interval"]

        # Revenue estimate: base_price × yield_per_harvest × harvests
        # With CARE banking: yield is max_held (fully cared)
        if _MARKET_PARAMS and product in _MARKET_PARAMS:
            base_price = _MARKET_PARAMS[product]["base"]
        else:
            base_price = {"EGG": 50, "MILK": 160, "WOOL": 200}[product]

        yield_per = spec["max_held"]  # assuming full care
        revenue = base_price * yield_per * harvests

        # Demand multiplier: premium products crash if no shop demands them
        if demand_shops == 0:
            revenue *= 0.3  # can still sell at base, but glut risk
        elif demand_shops >= 2:
            revenue *= 1.2  # high demand = sells at premium

        # Cost: animal + structure + daily feed (wheat at ~$25)
        feed_cost = 25 * (TOTAL_DAYS - placement_day) if spec["feed"] else 0
        net = revenue - spec["cost"] - feed_cost

        return net

    def audit(self, agent_path=None, replays=None) -> List[CandidateSpec]:
        candidates = []

        # Analyze optimal animal for common shop pairs
        shop_types = list(SHOP_DEMAND.keys())
        cow_wins = 0
        sheep_wins = 0
        goose_wins = 0
        total_pairs = 0

        for s1 in shop_types:
            for s2 in shop_types:
                shops = [s1, s2]
                scores = {}
                for animal in ["COW", "SHEEP", "GOOSE"]:
                    # Score at day 10 (typical animal purchase day)
                    scores[animal] = self._score_animal(animal, shops, 10)

                best = max(scores, key=scores.get)
                if best == "COW":
                    cow_wins += 1
                elif best == "SHEEP":
                    sheep_wins += 1
                else:
                    goose_wins += 1
                total_pairs += 1

        candidates.append(CandidateSpec(
            id="ANIMAL_SHOP_CONDITIONAL",
            domain=self.domain,
            description=f"Shop-conditional animal choice: COW wins {cow_wins}/{total_pairs} pairs, "
                        f"SHEEP {sheep_wins}/{total_pairs}, GOOSE {goose_wins}/{total_pairs}. "
                        f"Replace fixed GOOSE purchases with shop-conditioned COW/SHEEP.",
            estimated_impact="COW preference universal above 2900 (Tschinkel + cluster analysis)",
            source=f"auditor:{self.name}",
            details={"cow_wins": cow_wins, "sheep_wins": sheep_wins,
                     "goose_wins": goose_wins, "total_pairs": total_pairs},
        ))

        # VE1: Sheep on day 11 instead of 12
        candidates.append(CandidateSpec(
            id="ANIMAL_VE1_SHEEP_DAY11",
            domain=self.domain,
            description="Place sheep expansion on day 11 instead of 12 in yarn-store towns. "
                        "Gets 5th harvest (day 29) instead of 4. +8/-1 (Tschinkel verified).",
            estimated_impact="+8/-1 on eligible games (Tschinkel VE1)",
            source=f"auditor:{self.name}",
            details={"source": "tschinkel_VE1", "placement_day": 11,
                     "harvests_gained": 1, "eligible": "towns with 2+ yarn stores in first 3 shops"},
        ))

        return candidates


class SellTimingAuditor:
    """Analyze sale timing using price curve analysis and rival sale detection.

    Key insights:
    - Premium books (MILK, WOOL, STRAWBERRY, MELON) crash after 60-160 units
    - First seller takes the price, second sells into the crash
    - Rival sales are observable: rival_sold = inventory' - inventory + town_draw - own_sold
    - RACE: pull sales forward when rival starts selling (Tschinkel: +massive)
    - ORDERPRI2: most exposed product sells first in market list
    """
    name = "SellTimingAuditor"
    domain = "sell_timing"

    def _compute_price_cliff(self, item):
        """Find how many units until price hits $1 floor."""
        if not _MARKET_PARAMS or item not in _MARKET_PARAMS:
            return None
        I0 = _MARKET_PARAMS[item]["I0"]
        for surplus in range(0, 500):
            p = market_price(item, I0 + surplus)
            if p <= 1:
                return surplus
        return 500

    def audit(self, agent_path=None, replays=None) -> List[CandidateSpec]:
        candidates = []

        # Compute price cliffs for premium items
        premium_items = ["MILK", "WOOL", "STRAWBERRY", "MELON"]
        cliffs = {}
        for item in premium_items:
            cliff = self._compute_price_cliff(item)
            if cliff is not None:
                cliffs[item] = cliff

        candidates.append(CandidateSpec(
            id="SELL_RACE_SYSTEM",
            domain=self.domain,
            description=f"RACE system: detect rival premium sales via inventory delta, pull our "
                        f"planned sales forward up to 40 turns. Gate: don't race into glutted books. "
                        f"Price cliffs: {cliffs}",
            estimated_impact="Massive — Tschinkel's top innovation. RACE+RACEPX+RACEGATE.",
            source=f"auditor:{self.name}",
            details={"cliffs": cliffs, "source": "tschinkel_v9_RACE",
                     "horizon": 40, "margin": 12, "start_step": 192},
        ))

        candidates.append(CandidateSpec(
            id="SELL_ORDERPRI2",
            domain=self.domain,
            description="Reorder market list so the product most exposed to a rival batch "
                        "sells first. Track rival's unsold stock from public info "
                        "(tile harvests + recovered sales). +54/-10 (Tschinkel verified).",
            estimated_impact="+54/-10 on 3,296 recorded games (Tschinkel ORDERPRI2)",
            source=f"auditor:{self.name}",
            details={"source": "tschinkel_v9_ORDERPRI2"},
        ))

        candidates.append(CandidateSpec(
            id="SELL_PREDICT_LIBRARY",
            domain=self.domain,
            description="Build a library of sale events from top-25 replays. Match rival's "
                        "recent sales against library. Sell our planned lots just before "
                        "the best-matching recorded streams say the rival will sell.",
            estimated_impact="High — Tschinkel's 451K event library is his strongest unique edge",
            source=f"auditor:{self.name}",
            details={"source": "tschinkel_v9_PREDICT", "library_size": "451K events",
                     "items": ["MILK", "WOOL", "STRAWBERRY"]},
        ))

        return candidates


class HireAuditor:
    """Analyze hiring efficiency using Fibonacci cost curve.

    Key insight (Tschinkel SL2): hands 12 and 13 cost $144 + $233 = $377/day.
    On non-harvest days, one hand can do the work. +15/-0.
    """
    name = "HireAuditor"
    domain = "hire"

    def audit(self, agent_path=None, replays=None) -> List[CandidateSpec]:
        candidates = []

        # Compute cost curve
        cost_table = [(n + 1, HIRE_COSTS[n]) for n in range(15)]
        expensive = [(n, c) for n, c in cost_table if c >= 100]

        candidates.append(CandidateSpec(
            id="HIRE_SL2_NONHARVEST",
            domain=self.domain,
            description=f"Skip expensive hires on non-harvest days. Hires 12+ cost "
                        f"${HIRE_COSTS[11]}+/day. On days without wool/milk/egg production, "
                        f"keep one hand instead of two for sheep expansion. +15/-0 (Tschinkel SL2).",
            estimated_impact="+15/-0 on affected towns (Tschinkel verified)",
            source=f"auditor:{self.name}",
            details={"hire_costs": cost_table[:15], "source": "tschinkel_SL2",
                     "threshold_hire": 12, "threshold_cost": HIRE_COSTS[11]},
        ))

        candidates.append(CandidateSpec(
            id="HIRE_VT1_LAST_DAYS",
            domain=self.domain,
            description="On day 29: skip FEED and CARE (no production follows). "
                        "On day 28: skip CARE (banked care isn't used). "
                        "+3/-0 (Tschinkel VT1).",
            estimated_impact="+3/-0 (Tschinkel verified)",
            source=f"auditor:{self.name}",
            details={"source": "tschinkel_VT1", "day_29": "skip feed+care",
                     "day_28": "skip care only"},
        ))

        return candidates


class ShedAuditor:
    """Detect shed overflow risk and propose fixes.

    Shed has 100 slots. At end of each day, worker cargo drops to shed.
    Anything past 100 is destroyed. Tschinkel's fixes:
    - OVERFLOW (V43): sell excess at hour 23
    - SHEDROOM: sell spare goods at hours 22-23
    - COURIER: walk premium cargo to shed before midnight
    - CAPHARV: harvest animal before stored yield overflows (+20/-0)
    """
    name = "ShedAuditor"
    domain = "shed"

    def audit(self, agent_path=None, replays=None) -> List[CandidateSpec]:
        candidates = []

        candidates.append(CandidateSpec(
            id="SHED_CAPHARV",
            domain=self.domain,
            description="Harvest animals before their stored yield overflows the cap. "
                        "COW/SHEEP cap at 6, GOOSE at 4. When a worker is about to CARE "
                        "for an animal whose stored yield would overflow at tonight's "
                        "production, harvest instead. +20/-0 (Tschinkel verified).",
            estimated_impact="+20/-0 on 1,000 recent top-25 games (Tschinkel CAPHARV)",
            source=f"auditor:{self.name}",
            details={"source": "tschinkel_CAPHARV",
                     "caps": {"GOOSE": 4, "COW": 6, "SHEEP": 6}},
        ))

        candidates.append(CandidateSpec(
            id="SHED_OVERFLOW_SELL",
            domain=self.domain,
            description="At hour 23, sell exactly the shed stock that the midnight drop "
                        "would destroy. SHEDROOM extends this to hours 22-23 for spare goods. "
                        "+16/-2 (Tschinkel verified).",
            estimated_impact="+16/-2 (Tschinkel SHEDROOM)",
            source=f"auditor:{self.name}",
            details={"source": "tschinkel_OVERFLOW+SHEDROOM"},
        ))

        candidates.append(CandidateSpec(
            id="SHED_COURIER",
            domain=self.domain,
            description="Walk premium cargo (MILK, WOOL, STRAWBERRY) to shed before midnight "
                        "so it sells today rather than tomorrow.",
            estimated_impact="Small but consistent — prevents premium goods sitting overnight",
            source=f"auditor:{self.name}",
            details={"source": "tschinkel_COURIER",
                     "premium_items": ["MILK", "WOOL", "STRAWBERRY"]},
        ))

        return candidates


# ═══════════════════════════════════════════════════════════
# ORCHESTRATOR
# ═══════════════════════════════════════════════════════════

ALL_AUDITORS = [
    OpeningAuditor(),
    AnimalAuditor(),
    SellTimingAuditor(),
    HireAuditor(),
    ShedAuditor(),
]

AUDITOR_MAP = {a.domain: a for a in ALL_AUDITORS}


def run_all_auditors(agent_path=None, replays=None) -> List[CandidateSpec]:
    """Run all auditors and collect candidates."""
    candidates = []
    for auditor in ALL_AUDITORS:
        log(f"Running {auditor.name}...")
        try:
            results = auditor.audit(agent_path, replays)
            for c in results:
                log(f"  {c.id}: {c.description[:80]}")
            candidates.extend(results)
        except Exception as e:
            log(f"  ERROR in {auditor.name}: {e}")
    log(f"\nTotal candidates: {len(candidates)}")
    return candidates


def run_auditor(domain, agent_path=None, replays=None) -> List[CandidateSpec]:
    """Run a single auditor by domain name."""
    auditor = AUDITOR_MAP.get(domain)
    if not auditor:
        log(f"Unknown auditor domain: {domain}. Available: {list(AUDITOR_MAP.keys())}")
        return []
    log(f"Running {auditor.name}...")
    return auditor.audit(agent_path, replays)


def main():
    parser = argparse.ArgumentParser(description="Mechanic Analyzer")
    parser.add_argument("--agent", help="Agent path to analyze")
    parser.add_argument("--replays", help="Replay directory for auditors that need game data")
    parser.add_argument("--all", action="store_true", help="Run all auditors")
    parser.add_argument("--audit", help="Run specific auditor (opening, animal, sell_timing, hire, shed)")
    parser.add_argument("--list", action="store_true", help="List available auditors")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    if args.list:
        print("Available auditors:")
        for a in ALL_AUDITORS:
            print(f"  {a.domain:<15} {a.name}")
        return

    if args.all:
        candidates = run_all_auditors(args.agent, args.replays)
    elif args.audit:
        candidates = run_auditor(args.audit, args.agent, args.replays)
    else:
        parser.print_help()
        return

    if args.json:
        print(json.dumps([c.to_dict() for c in candidates], indent=2))
    else:
        print(f"\n{'='*70}")
        print(f"CANDIDATES: {len(candidates)}")
        print(f"{'='*70}")
        for c in candidates:
            print(f"\n  [{c.id}] ({c.domain})")
            print(f"  {c.description}")
            print(f"  Impact: {c.estimated_impact}")
            print(f"  Source: {c.source}")


if __name__ == "__main__":
    main()
