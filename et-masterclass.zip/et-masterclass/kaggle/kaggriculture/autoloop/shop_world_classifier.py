#!/usr/bin/env python3
"""Shop World Classifier: Classify games by their (shop1, shop2) world.

8 shops × 8 shops = 64 possible worlds. Each world produces different
optimal routes and economic conditions.

Usage:
    python shop_world_classifier.py <replay_dir>
    python shop_world_classifier.py <replay_dir> --seats _seats.json
    python shop_world_classifier.py <replay_dir> --json
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

SHOPS = sorted([
    "BAKERY", "BRUNCH_SPOT", "FARMERS_MARKET", "ICE_CREAM_SHOP",
    "PET_CAFE", "PIZZA_SHOP", "SMOOTHIE_SHOP", "YARN_STORE",
])


def extract_shop_pair(replay):
    """Extract (shop1, shop2) from a replay.
    Shop 1 unlocks at step 72 (day 3), shop 2 at step 144 (day 6).
    """
    steps = replay.get("steps", [])
    shop1 = shop2 = "UNKNOWN"

    if len(steps) > 72:
        obs = steps[72][0].get("observation", {})
        unlocked = obs.get("town", {}).get("unlocked_shops", [])
        if len(unlocked) >= 1:
            shop1 = unlocked[0]

    if len(steps) > 144:
        obs = steps[144][0].get("observation", {})
        unlocked = obs.get("town", {}).get("unlocked_shops", [])
        if len(unlocked) >= 2:
            shop2 = unlocked[1]

    return (shop1, shop2)


def world_id(shop1, shop2):
    return f"{shop1}+{shop2}"


def classify_replays(replay_dir, seats_file=None):
    """Classify all replays in a directory by shop world.

    Args:
        replay_dir: Path to directory containing replay JSONs
        seats_file: Optional path to _seats.json mapping ep_id -> our_seat

    Returns:
        dict keyed by world_id with game stats
    """
    replay_dir = Path(replay_dir)
    seats = {}
    if seats_file:
        seats_path = Path(seats_file)
        if not seats_path.exists() and not seats_path.is_absolute():
            seats_path = replay_dir / Path(seats_file).name
        if seats_path.exists():
            with open(seats_path) as f:
                seats = json.load(f)

    worlds = defaultdict(lambda: {"games": [], "wins": 0, "losses": 0, "ties": 0})
    replay_files = sorted(replay_dir.glob("*.json"))

    for fpath in replay_files:
        if fpath.name.startswith("_"):
            continue
        try:
            with open(fpath) as f:
                replay = json.load(f)
        except (json.JSONDecodeError, OSError):
            continue

        ep_id = fpath.stem
        shop1, shop2 = extract_shop_pair(replay)
        wid = world_id(shop1, shop2)

        rewards = replay.get("rewards", [0, 0])
        our_seat = int(seats.get(ep_id, 0))
        opp_seat = 1 - our_seat
        our_reward = rewards[our_seat] if rewards[our_seat] is not None else 0
        opp_reward = rewards[opp_seat] if rewards[opp_seat] is not None else 0

        if our_reward > opp_reward:
            outcome = "win"
            worlds[wid]["wins"] += 1
        elif our_reward < opp_reward:
            outcome = "loss"
            worlds[wid]["losses"] += 1
        else:
            outcome = "tie"
            worlds[wid]["ties"] += 1

        seed = replay.get("info", {}).get("seed", None)
        teams = replay.get("info", {}).get("TeamNames", [])
        opp_name = teams[opp_seat] if len(teams) > opp_seat else "unknown"

        worlds[wid]["games"].append({
            "ep_id": ep_id,
            "shop1": shop1,
            "shop2": shop2,
            "our_reward": our_reward,
            "opp_reward": opp_reward,
            "margin": our_reward - opp_reward,
            "outcome": outcome,
            "seed": seed,
            "opponent": opp_name,
        })

    # Compute summary stats per world
    result = {}
    for wid, data in sorted(worlds.items()):
        n = len(data["games"])
        result[wid] = {
            "shop1": data["games"][0]["shop1"],
            "shop2": data["games"][0]["shop2"],
            "count": n,
            "wins": data["wins"],
            "losses": data["losses"],
            "ties": data["ties"],
            "win_rate": data["wins"] / n if n else 0,
            "avg_margin": sum(g["margin"] for g in data["games"]) / n if n else 0,
            "avg_score": sum(g["our_reward"] for g in data["games"]) / n if n else 0,
            "games": data["games"],
        }
    return result


def print_world_report(classified, sort_by="count"):
    total_games = sum(w["count"] for w in classified.values())
    total_wins = sum(w["wins"] for w in classified.values())
    total_losses = sum(w["losses"] for w in classified.values())
    total_ties = sum(w["ties"] for w in classified.values())

    print(f"{'='*70}")
    print(f"SHOP WORLD CLASSIFICATION ({total_games} games)")
    print(f"Overall: {total_wins}W {total_losses}L {total_ties}T "
          f"({100*total_wins/total_games:.0f}% win)" if total_games else "No games")
    print(f"Unique worlds: {len(classified)}/64")
    print(f"{'='*70}")

    sorted_worlds = sorted(classified.values(),
                           key=lambda w: w.get(sort_by, 0),
                           reverse=(sort_by != "win_rate"))
    if sort_by == "win_rate":
        sorted_worlds = sorted(classified.values(), key=lambda w: w["win_rate"])

    print(f"\n{'World':40s} {'N':>3} {'W':>3} {'L':>3} {'T':>3} {'WR%':>5} {'Avg$':>8} {'AvgMgn':>8}")
    print("-" * 75)
    for w in sorted_worlds:
        wr_str = f"{100*w['win_rate']:.0f}%"
        marker = " !!!" if w["win_rate"] < 0.5 and w["count"] >= 2 else ""
        print(f"{w['shop1'][:18]+'+'+w['shop2'][:18]:40s} "
              f"{w['count']:3d} {w['wins']:3d} {w['losses']:3d} {w['ties']:3d} "
              f"{wr_str:>5} ${w['avg_score']:7.0f} ${w['avg_margin']:+7.0f}{marker}")

    # Highlight weak worlds
    weak = [w for w in classified.values() if w["win_rate"] < 0.5 and w["count"] >= 2]
    if weak:
        print(f"\n{'='*70}")
        print(f"WEAK WORLDS (win rate < 50%, 2+ games):")
        for w in sorted(weak, key=lambda x: x["win_rate"]):
            print(f"  {w['shop1']}+{w['shop2']}: {w['wins']}W {w['losses']}L "
                  f"({100*w['win_rate']:.0f}%) avg margin ${w['avg_margin']:+.0f}")
            for g in w["games"]:
                print(f"    EP {g['ep_id']}: ${g['our_reward']:.0f} vs ${g['opp_reward']:.0f} "
                      f"({g['outcome']}) vs {g['opponent']}")

    # 8x8 grid
    print(f"\n{'='*70}")
    print("WORLD MATRIX (win_rate%, count in parens)")
    print(f"{'':20s}", end="")
    for s2 in SHOPS:
        print(f"{s2[:6]:>8s}", end="")
    print()
    for s1 in SHOPS:
        print(f"{s1[:20]:20s}", end="")
        for s2 in SHOPS:
            wid = world_id(s1, s2)
            if wid in classified:
                w = classified[wid]
                wr = f"{100*w['win_rate']:.0f}%"
                print(f"{wr+'('+str(w['count'])+')':>8s}", end="")
            else:
                print(f"{'---':>8s}", end="")
        print()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Classify replays by shop world")
    parser.add_argument("replay_dir", help="Directory containing replay JSON files")
    parser.add_argument("--seats", help="Path to _seats.json file")
    parser.add_argument("--sort", default="count", choices=["count", "win_rate", "avg_margin"])
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()

    seats_file = args.seats
    classified = classify_replays(args.replay_dir, seats_file=seats_file)

    if args.json:
        # Remove game details for JSON output
        output = {k: {kk: vv for kk, vv in v.items() if kk != "games"} for k, v in classified.items()}
        json.dump(output, sys.stdout, indent=2)
    else:
        print_world_report(classified, sort_by=args.sort)
