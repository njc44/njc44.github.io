#!/usr/bin/env python3
"""Tape Recorder: Generate per-world tapes by running reactive agents in the
simulator and recording their actions.

For each shop pair, runs multiple reactive agents, picks the best-scoring tape.
Outputs a single agent file with embedded tapes and a shop-pair router.
"""
import json
import sys
import time
from collections import defaultdict
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AGENTS_DIR = WORK_DIR / "autoloop" / "agents"
OUTPUT_DIR = WORK_DIR / "autoloop" / "recorded_tapes"
OUTPUT_DIR.mkdir(exist_ok=True)

# Reactive agents to record from (best available)
SOURCE_AGENTS = [
    str(AGENTS_DIR / "lynnsakurai__farming-score-v5-timing-optimized" / "main.py"),
    str(AGENTS_DIR / "lynnsakurai__farming-score-v2" / "main.py"),
    str(AGENTS_DIR / "statma_kaggriculture-herd-safe-sale-window-race-ca25" / "main.py"),
]

# Also use pipe-29 as a source (it's strong overall)
PIPE29 = str(AGENTS_DIR / "pipe29_ttv1_sheep" / "main.py")
SOURCE_AGENTS.append(PIPE29)

GAMES_PER_AGENT = 30  # enough to cover most shop pairs
SHOP_TYPES = ['BAKERY', 'BRUNCH_SPOT', 'FARMERS_MARKET', 'ICE_CREAM_SHOP',
              'PET_CAFE', 'PIZZA_SHOP', 'SMOOTHIE_SHOP', 'YARN_STORE']


def log(msg):
    print(f"[recorder] {msg}", flush=True)


def record_tapes():
    """Record tapes from all source agents."""
    from kaggle_environments import make

    # Collect: shop_pair -> list of (score, tape, agent_name, shops_full)
    world_tapes = defaultdict(list)

    for agent_path in SOURCE_AGENTS:
        agent_name = Path(agent_path).parent.name
        log(f"Recording from {agent_name}...")

        for i in range(GAMES_PER_AGENT):
            try:
                env = make('kaggriculture')
                r = env.run([agent_path, agent_path])

                if r[-1][0]["status"] != "DONE":
                    continue

                score = r[-1][0]["reward"]
                shops = r[6 * 24][0]["observation"]["town"]["unlocked_shops"]
                shop_pair = tuple(sorted(shops[:2]))  # sort for canonical key

                # Record tape
                tape = []
                for s in range(len(r)):
                    action = r[s][0].get("action", {})
                    # Compact: only store non-empty fields
                    compact = {}
                    if action.get("farmer") and action["farmer"] != ["PASS"]:
                        compact["farmer"] = action["farmer"]
                    if action.get("hands"):
                        compact["hands"] = action["hands"]
                    if action.get("market"):
                        compact["market"] = action["market"]
                    tape.append(compact)

                world_tapes[shop_pair].append({
                    "score": score,
                    "tape": tape,
                    "agent": agent_name,
                    "shops": shops,
                })

                if (i + 1) % 10 == 0:
                    log(f"  {i + 1}/{GAMES_PER_AGENT} games...")

            except Exception as e:
                log(f"  Game {i} error: {e}")

    return world_tapes


def select_best_tapes(world_tapes):
    """For each shop pair, pick the highest-scoring tape."""
    best = {}
    for shop_pair, entries in sorted(world_tapes.items()):
        top = max(entries, key=lambda x: x["score"])
        best[shop_pair] = top
        log(f"  {shop_pair}: ${top['score']:,.0f} from {top['agent']} ({len(entries)} candidates)")
    return best


def build_agent(best_tapes):
    """Build a standalone agent with embedded tapes and router."""
    # Serialize tapes
    tape_data = {}
    for shop_pair, entry in best_tapes.items():
        key = "+".join(shop_pair)
        tape_data[key] = entry["tape"]

    # Find the overall best tape as default
    default_entry = max(best_tapes.values(), key=lambda x: x["score"])
    default_key = "+".join(max(best_tapes.keys(), key=lambda k: best_tapes[k]["score"]))

    tape_json = json.dumps(tape_data)

    agent_code = f'''import json

_TAPES = json.loads('{tape_json}')
_DEFAULT_KEY = "{default_key}"
_STATE = {{}}

def agent(observation, configuration=None):
    step = int(observation["step"])
    player = int(observation["player"])

    # Select tape at step 144 (day 6) based on first 2 shops
    if player not in _STATE:
        _STATE[player] = {{"key": _DEFAULT_KEY}}

    if step == 144:
        shops = observation.get("town", {{}}).get("unlocked_shops", [])
        if len(shops) >= 2:
            key = "+".join(sorted(shops[:2]))
            if key in _TAPES:
                _STATE[player]["key"] = key

    key = _STATE[player]["key"]
    tape = _TAPES.get(key, _TAPES[_DEFAULT_KEY])

    if step < len(tape):
        action = tape[step]
        # Reconstruct full action from compact format
        result = {{
            "farmer": action.get("farmer", ["PASS"]),
            "hands": action.get("hands", []),
            "market": action.get("market", []),
        }}
        # Ensure hands match current worker count
        n_hands = len(observation["farms"][player].get("hands", []))
        while len(result["hands"]) < n_hands:
            result["hands"].append(["PASS"])
        result["hands"] = result["hands"][:n_hands]
        return result

    return {{"farmer": ["PASS"], "hands": [], "market": []}}
'''

    out_path = OUTPUT_DIR / "main.py"
    out_path.write_text(agent_code)
    log(f"Agent written to {out_path} ({len(agent_code) // 1024} KB)")
    return out_path


def main():
    log("=== TAPE RECORDER START ===")

    log("Step 1: Recording tapes...")
    world_tapes = record_tapes()
    log(f"Recorded {sum(len(v) for v in world_tapes.values())} tapes across {len(world_tapes)} shop worlds")

    log("\nStep 2: Selecting best tapes...")
    best = select_best_tapes(world_tapes)

    log(f"\nStep 3: Building agent...")
    agent_path = build_agent(best)

    # Step 4: Quick test
    log("\nStep 4: Smoke test...")
    from kaggle_environments import make
    env = make('kaggriculture')
    r = env.run([str(agent_path), str(agent_path)])
    score = r[-1][0]["reward"]
    log(f"Smoke test: score=${score:,.0f}, status={r[-1][0]['status']}")

    log("\n=== TAPE RECORDER DONE ===")


if __name__ == "__main__":
    main()
