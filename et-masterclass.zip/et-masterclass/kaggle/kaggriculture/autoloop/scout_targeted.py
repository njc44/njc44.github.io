#!/usr/bin/env python3
"""Scout Targeted: Download specific agents by username + version pattern.

Usage:
    python scout_targeted.py --user ahmedberatozer --pattern v47 v48
    python scout_targeted.py --user ahmedberatozer --all-versions
"""
import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

# Reuse scout.py infrastructure
AUTOLOOP_DIR = Path(__file__).resolve().parent
AGENTS_DIR = AUTOLOOP_DIR / "agents"
NOTEBOOK_CACHE = AUTOLOOP_DIR / ".notebook_cache"
sys.path.insert(0, str(AUTOLOOP_DIR))
from scout import extract_agent, smoke_test


def log(msg):
    print(f"[scout_targeted] {msg}", flush=True)


def list_user_notebooks(username, competition="kaggriculture", page_size=50):
    """List all notebooks by a user for a competition."""
    refs = []
    for sort_by in ["dateCreated", "dateRun"]:
        try:
            result = subprocess.run(
                ["kaggle", "kernels", "list", "--user", username,
                 "--competition", competition, "--sort-by", sort_by,
                 "--page-size", str(page_size)],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                for line in result.stdout.strip().split("\n")[1:]:
                    parts = line.split()
                    if parts and "/" in parts[0]:
                        refs.append(parts[0])
        except Exception as e:
            log(f"  Warning: list --sort-by {sort_by} failed: {e}")
    return list(dict.fromkeys(refs))  # dedupe, preserve order


def download_notebook(ref):
    """Download a single notebook. Returns path to downloaded dir or None."""
    slug = ref.replace("/", "__")
    dest = NOTEBOOK_CACHE / slug
    dest.mkdir(parents=True, exist_ok=True)

    log(f"  Downloading: {ref}")
    try:
        result = subprocess.run(
            ["kaggle", "kernels", "pull", ref, "-p", str(dest)],
            capture_output=True, text=True, timeout=60
        )
        if result.returncode == 0:
            return dest
        log(f"    Failed: {result.stderr.strip()}")
    except Exception as e:
        log(f"    Failed: {e}")

    # Clean up empty dir
    try:
        if dest.exists() and not any(dest.iterdir()):
            dest.rmdir()
    except OSError:
        pass
    return None


def extract_and_test(slug, nb_dir):
    """Extract agent from notebook dir, smoke test, save to agents/."""
    agent_dir = AGENTS_DIR / slug

    # Find notebook file
    nb_files = list(nb_dir.glob("*.ipynb")) + list(nb_dir.glob("*.py"))
    if not nb_files:
        log(f"    No notebook/py files found in {nb_dir}")
        return None

    code = extract_agent(nb_files[0])
    if not code:
        log(f"    No agent code extracted")
        return None

    agent_dir.mkdir(parents=True, exist_ok=True)
    (agent_dir / "main.py").write_text(code)

    log(f"    Extracted {len(code)} chars, {code.count(chr(10)) + 1} lines")
    log(f"    Smoke testing...")

    if smoke_test(agent_dir):
        log(f"    PASS")
        meta = {
            "source_notebook": slug,
            "code_size": len(code),
            "code_lines": code.count("\n") + 1,
            "extracted_at": __import__("datetime").datetime.now().isoformat(),
            "smoke_test": "pass",
        }
        (agent_dir / "meta.json").write_text(json.dumps(meta, indent=2))
        return str(agent_dir / "main.py")
    else:
        log(f"    FAIL — agent crashes, removing")
        import shutil
        shutil.rmtree(agent_dir, ignore_errors=True)
        return None


def scout_targeted(username, patterns=None, competition="kaggriculture", force=False):
    """Download and extract agents matching username + version patterns.

    Args:
        username: Kaggle username (e.g. 'ahmedberatozer')
        patterns: List of substrings to match in slug (e.g. ['v47', 'v48']).
                  If None, downloads all.
        force: Re-download even if already cached.

    Returns: dict of {slug: agent_path} for successfully extracted agents.
    """
    log(f"=== SCOUT TARGETED: {username} ===")
    refs = list_user_notebooks(username, competition)
    log(f"  Found {len(refs)} notebooks by {username}")

    if patterns:
        filtered = []
        for ref in refs:
            slug_lower = ref.lower()
            if any(p.lower() in slug_lower for p in patterns):
                filtered.append(ref)
        log(f"  Filtered to {len(filtered)} matching {patterns}")
        refs = filtered

    if not refs:
        log("  No matching notebooks found")
        return {}

    results = {}
    for ref in refs:
        slug = ref.replace("/", "__")
        agent_path = AGENTS_DIR / slug / "main.py"

        # Skip if already extracted (unless force)
        if agent_path.exists() and not force:
            log(f"  SKIP {slug}: already extracted")
            results[slug] = str(agent_path)
            continue

        nb_dir = NOTEBOOK_CACHE / slug
        if not nb_dir.exists() or not any(nb_dir.iterdir()) or force:
            nb_dir = download_notebook(ref)
            if nb_dir is None:
                continue

        path = extract_and_test(slug, nb_dir)
        if path:
            results[slug] = path

    log(f"=== RESULTS: {len(results)} agents ===")
    for slug, path in results.items():
        log(f"  {slug}")
    return results


def main():
    parser = argparse.ArgumentParser(description="Scout Targeted: download specific agents")
    parser.add_argument("--user", default="ahmedberatozer", help="Kaggle username")
    parser.add_argument("--pattern", nargs="+", help="Version patterns to match (e.g. v47 v48)")
    parser.add_argument("--all-versions", action="store_true", help="Download all versions")
    parser.add_argument("--competition", default="kaggriculture")
    parser.add_argument("--force", action="store_true", help="Re-download even if cached")
    args = parser.parse_args()

    patterns = None if args.all_versions else (args.pattern or ["v47", "v48"])
    results = scout_targeted(args.user, patterns, args.competition, args.force)

    if not results:
        print("\nNo agents found. Check if the notebooks are public.")
        print("You can manually place notebooks in:")
        print(f"  {NOTEBOOK_CACHE}/ahmedberatozer__kaggriculture-v47-<slug>/")
        print(f"  {NOTEBOOK_CACHE}/ahmedberatozer__kaggriculture-v48-<slug>/")
        print("Then run: python scout_targeted.py --user ahmedberatozer --pattern v47 v48")


if __name__ == "__main__":
    main()
