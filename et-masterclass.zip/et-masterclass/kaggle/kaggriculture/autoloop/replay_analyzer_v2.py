#!/usr/bin/env python3
"""Replay Analyzer V2: 6-Layer Attribution Chain.

Deterministic. No AI. Traces money gaps to specific code-level instructions.

Layers:
  1. Money Curve — actual money per day from observations (ground truth)
  2. Sell Quantity Attribution — per-item sell qty gaps + money gap timing
  3. Asset Tracing — producing asset counts per day, divergence detection
  4. Acquisition Attribution — exact step opponent acquired extra assets
  5. Decision Attribution — map to shop combo / tape routing
  6. Quantified Instruction — specific, testable fix with expected impact

Key design choice: We do NOT estimate revenue from price*qty (prices are
distorted by large sell orders). We use the actual money curve as ground
truth and sell QUANTITIES as directional signals.

Usage:
    python replay_analyzer_v2.py --submission-id 56211878 --max-episodes 10
    python replay_analyzer_v2.py --from-state
    python replay_analyzer_v2.py --episodes 108674164 108673229
    python replay_analyzer_v2.py --local   # analyze all cached replays
"""
import argparse
import json
import subprocess
from collections import defaultdict
from datetime import datetime
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
REPLAY_DIR = AUTOLOOP_DIR / "replays"
DIAGNOSIS_DIR = AUTOLOOP_DIR / "diagnosis"
STATE_FILE = AUTOLOOP_DIR / "state.json"
OUR_TEAM = "Nathan Jacob"
MAX_CACHED_REPLAYS = 50

# Item → producing asset
ITEM_TO_ASSET = {
    "MILK": {"type": "animal", "asset": "COW"},
    "WOOL": {"type": "animal", "asset": "SHEEP"},
    "EGG": {"type": "animal", "asset": "GOOSE"},
    "WHEAT": {"type": "crop", "asset": "WHEAT"},
    "TOMATO": {"type": "crop", "asset": "TOMATO"},
    "CARROT": {"type": "crop", "asset": "CARROT"},
    "MELON": {"type": "crop", "asset": "MELON"},
    "STRAWBERRY": {"type": "crop", "asset": "STRAWBERRY"},
}


def log(msg):
    print(f"[v2] {msg}", flush=True)


# ═══════════════════════════════════════════════════════════
# REPLAY ACQUISITION
# ═══════════════════════════════════════════════════════════

def discover_episodes(submission_id, max_episodes=10):
    try:
        result = subprocess.run(
            ["kaggle", "competitions", "episodes", str(submission_id)],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            log(f"  Failed to list episodes: {result.stderr}")
            return []
        episodes = []
        for line in result.stdout.strip().split("\n")[2:]:
            parts = line.split()
            if parts and parts[0].strip().isdigit():
                episodes.append(int(parts[0].strip()))
        log(f"  Found {len(episodes)} episodes, taking {min(len(episodes), max_episodes)}")
        return episodes[:max_episodes]
    except Exception as e:
        log(f"  Episode discovery error: {e}")
        return []


def get_latest_submission_id():
    try:
        result = subprocess.run(
            ["kaggle", "competitions", "submissions", "kaggriculture"],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            return None
        for line in result.stdout.strip().split("\n")[2:]:
            parts = line.split()
            if parts and parts[0].strip().isdigit():
                return int(parts[0].strip())
    except Exception:
        pass
    return None


def download_replay(episode_id):
    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    cached = REPLAY_DIR / f"{episode_id}.json"
    if cached.exists():
        return cached
    try:
        subprocess.run(
            ["kaggle", "competitions", "replay", str(episode_id),
             "-p", str(REPLAY_DIR), "-q"],
            capture_output=True, text=True, timeout=60, cwd=str(REPLAY_DIR)
        )
        downloaded = REPLAY_DIR / f"episode-{episode_id}-replay.json"
        if downloaded.exists():
            downloaded.rename(cached)
            return cached
        for f in REPLAY_DIR.glob(f"*{episode_id}*"):
            f.rename(cached)
            return cached
        log(f"  Download failed for {episode_id}")
        return None
    except Exception as e:
        log(f"  Download error {episode_id}: {e}")
        return None


def prune_cache():
    replays = sorted(REPLAY_DIR.glob("*.json"), key=lambda f: f.stat().st_mtime)
    while len(replays) > MAX_CACHED_REPLAYS:
        replays.pop(0).unlink()


def identify_our_seat(replay):
    for source_key in ["Agents", "TeamNames"]:
        entries = replay.get("info", {}).get(source_key, [])
        for i, entry in enumerate(entries):
            name = entry.get("Name", entry) if isinstance(entry, dict) else entry
            if str(name).strip() == OUR_TEAM:
                return i
    log("  WARNING: Could not identify our seat, defaulting to 0")
    return 0


# ═══════════════════════════════════════════════════════════
# LAYER 1: MONEY CURVE (ground truth)
# ═══════════════════════════════════════════════════════════

def extract_money_curve(steps, our_seat):
    """Money at each day start + final reward. This is GROUND TRUTH."""
    opp_seat = 1 - our_seat
    us, opp = [], []
    for day in range(30):
        step_idx = day * 24
        if step_idx >= len(steps):
            break
        obs = steps[step_idx][0]["observation"]
        us.append(obs["farms"][our_seat]["money"])
        opp.append(obs["farms"][opp_seat]["money"])
    return us, opp


def find_gap_opening_days(money_us, money_opp):
    """Find the days where the money gap widened most against us.

    Returns list of (day, delta_change) sorted by impact.
    delta_change < 0 means gap widened against us that day.
    """
    margin = [u - o for u, o in zip(money_us, money_opp)]
    day_changes = []
    for i in range(1, len(margin)):
        delta = margin[i] - margin[i - 1]
        day_changes.append((i, round(delta)))

    # Sort by delta (worst days first — where we fell behind fastest)
    day_changes.sort(key=lambda x: x[1])
    return day_changes


def find_turning_point(margin_timeline):
    """First day where margin drops below -500 and stays negative."""
    for i, m in enumerate(margin_timeline):
        if m < -500:
            if all(m2 <= 0 for m2 in margin_timeline[i:]):
                return i
    return None


# ═══════════════════════════════════════════════════════════
# LAYER 2: SELL QUANTITY ATTRIBUTION
# ═══════════════════════════════════════════════════════════

def extract_sell_quantities(steps, our_seat):
    """Count sell quantities per item per day for both players.

    Returns: {seat: {item: {day: qty}}} and per-item totals.
    """
    opp_seat = 1 - our_seat
    # Per-day per-item sell quantities
    daily = {our_seat: defaultdict(lambda: defaultdict(int)),
             opp_seat: defaultdict(lambda: defaultdict(int))}
    # Totals
    totals = {our_seat: defaultdict(int), opp_seat: defaultdict(int)}

    for step_idx, step_data in enumerate(steps):
        day = step_idx // 24
        for seat in [our_seat, opp_seat]:
            action = step_data[seat].get("action") or {}
            for order in action.get("market", []):
                if order and len(order) >= 3 and order[0] == "SELL":
                    item, qty = order[1], int(order[2])
                    daily[seat][item][day] += qty
                    totals[seat][item] += qty

    return daily, totals


def compute_sell_qty_gaps(totals, our_seat):
    """Per-item sell quantity gap. Negative = we sold less.

    Returns: {item: {us_qty, opp_qty, gap}} sorted by gap.
    """
    opp_seat = 1 - our_seat
    all_items = set(totals[our_seat].keys()) | set(totals[opp_seat].keys())
    gaps = {}
    for item in all_items:
        us_qty = totals[our_seat][item]
        opp_qty = totals[opp_seat][item]
        gaps[item] = {
            "us_qty": us_qty,
            "opp_qty": opp_qty,
            "gap": us_qty - opp_qty,  # negative = we sold less
        }
    return dict(sorted(gaps.items(), key=lambda x: x[1]["gap"]))


def extract_buy_orders(steps, our_seat):
    """Extract all buy orders (BUY_ANIMAL, BUY_SEED, BUY_PRODUCT) per player.

    Returns: {seat: [order_dict, ...]}
    """
    opp_seat = 1 - our_seat
    buys = {our_seat: [], opp_seat: []}

    for step_idx, step_data in enumerate(steps):
        day = step_idx // 24
        hour = step_idx % 24
        for seat in [our_seat, opp_seat]:
            action = step_data[seat].get("action") or {}
            for order in action.get("market", []):
                if order and len(order) >= 3 and order[0].startswith("BUY"):
                    buys[seat].append({
                        "step": step_idx, "day": day, "hour": hour,
                        "type": order[0], "item": order[1], "qty": int(order[2]),
                    })
    return buys


def compute_buy_qty_gaps(buys, our_seat):
    """Per category buy quantity gap."""
    opp_seat = 1 - our_seat
    us_by_key = defaultdict(int)
    opp_by_key = defaultdict(int)
    for b in buys[our_seat]:
        us_by_key[f"{b['type']}:{b['item']}"] += b["qty"]
    for b in buys[opp_seat]:
        opp_by_key[f"{b['type']}:{b['item']}"] += b["qty"]

    all_keys = set(us_by_key.keys()) | set(opp_by_key.keys())
    gaps = {}
    for key in all_keys:
        gaps[key] = {
            "us_qty": us_by_key[key],
            "opp_qty": opp_by_key[key],
            "gap": us_by_key[key] - opp_by_key[key],
        }
    return dict(sorted(gaps.items(), key=lambda x: abs(x[1]["gap"]), reverse=True))


# ── Supplementary: Worker & Shed Analysis ─────────────────

def extract_worker_counts(steps, our_seat):
    """Worker count per day (1 farmer + hired hands)."""
    opp_seat = 1 - our_seat
    us, opp = [], []
    for day in range(30):
        step_idx = day * 24 + 12
        if step_idx >= len(steps):
            break
        obs = steps[step_idx][0]["observation"]
        us.append(1 + len(obs["farms"][our_seat].get("hands", [])))
        opp.append(1 + len(obs["farms"][opp_seat].get("hands", [])))
    return us, opp


def extract_idle_rate(steps, our_seat):
    """Fraction of PASS actions during productive hours (0-21)."""
    opp_seat = 1 - our_seat
    result = {}
    for player_key, seat in [("us", our_seat), ("opp", opp_seat)]:
        pass_count = 0
        total = 0
        for step_idx, step_data in enumerate(steps):
            if step_idx % 24 >= 22:
                continue
            action = step_data[seat].get("action") or {}
            farmer = action.get("farmer", [])
            total += 1
            if farmer == ["PASS"] or farmer == "PASS":
                pass_count += 1
            for hand in action.get("hands", []):
                total += 1
                if hand == ["PASS"] or hand == "PASS":
                    pass_count += 1
        result[player_key] = round(pass_count / total, 3) if total else 0
    return result


def extract_shed_overflow(steps, our_seat):
    """Days where shed was at or near capacity."""
    opp_seat = 1 - our_seat
    result = {}
    for player_key, seat in [("us", our_seat), ("opp", opp_seat)]:
        days_at_100 = []
        max_items = 0
        for day in range(30):
            step_idx = day * 24 + 23
            if step_idx >= len(steps):
                break
            private = steps[step_idx][seat].get("observation", {}).get("private", {})
            shed = private.get("shed", {})
            total = sum(v for v in shed.values() if isinstance(v, (int, float)))
            if total >= 100:
                days_at_100.append(day)
            max_items = max(max_items, total)
        result[player_key] = {"days_at_100": days_at_100, "max_items": max_items}
    return result


# ═══════════════════════════════════════════════════════════
# LAYER 3: ASSET TRACING
# ═══════════════════════════════════════════════════════════

def count_assets_per_day(steps, seat):
    """Count each asset type on the farm at each day boundary."""
    counts = {}
    for day in range(30):
        step_idx = day * 24 + 12  # mid-day snapshot
        if step_idx >= len(steps):
            break
        obs = steps[step_idx][0]["observation"]
        farm = obs["farms"][seat]
        day_counts = defaultdict(int)
        for row in farm.get("tiles", []):
            for t in row:
                if not isinstance(t, dict):
                    continue
                if "animal" in t:
                    day_counts[t["animal"]] += 1
                elif "crop" in t:
                    day_counts[t["crop"]] += 1
                kind = t.get("kind", "")
                if kind in ("COOP", "BARN", "PEN"):
                    day_counts[f"_{kind}"] += 1
        counts[day] = dict(day_counts)
    return counts


def trace_asset_divergence(steps, our_seat, sell_qty_gaps):
    """For top sell-qty-gap items, trace to the producing asset and find
    when asset counts diverged between players."""
    opp_seat = 1 - our_seat
    us_assets = count_assets_per_day(steps, our_seat)
    opp_assets = count_assets_per_day(steps, opp_seat)

    traces = []
    for item, qgap in sell_qty_gaps.items():
        if qgap["gap"] >= 0:
            continue  # we sold more or equal — not a problem
        if item not in ITEM_TO_ASSET:
            continue

        asset_info = ITEM_TO_ASSET[item]
        asset_name = asset_info["asset"]

        us_timeline = [us_assets.get(d, {}).get(asset_name, 0) for d in range(30)]
        opp_timeline = [opp_assets.get(d, {}).get(asset_name, 0) for d in range(30)]

        divergence_day = None
        max_divergence = 0
        for day in range(30):
            diff = opp_timeline[day] - us_timeline[day]
            if diff > 0 and divergence_day is None:
                divergence_day = day
            if diff > max_divergence:
                max_divergence = diff

        traces.append({
            "item": item,
            "asset_type": asset_info["type"],
            "asset": asset_name,
            "us_timeline": us_timeline,
            "opp_timeline": opp_timeline,
            "divergence_day": divergence_day,
            "max_divergence": max_divergence,
            "sell_qty_gap": qgap["gap"],
        })

    traces.sort(key=lambda x: x["sell_qty_gap"])
    return traces


# ═══════════════════════════════════════════════════════════
# LAYER 4: ACQUISITION ATTRIBUTION
# ═══════════════════════════════════════════════════════════

def find_acquisition_events(buys, our_seat, asset_traces):
    """For each traced asset divergence, find the exact step opponent
    acquired the extra asset and what we did instead."""
    opp_seat = 1 - our_seat
    events = []

    for trace in asset_traces:
        if trace["divergence_day"] is None:
            continue

        asset = trace["asset"]
        target_type = "BUY_ANIMAL" if trace["asset_type"] == "animal" else "BUY_SEED"

        opp_asset_buys = [b for b in buys[opp_seat]
                          if b["type"] == target_type and b["item"] == asset]
        our_asset_buys = [b for b in buys[our_seat]
                          if b["type"] == target_type and b["item"] == asset]

        opp_by_step = {b["step"]: b for b in opp_asset_buys}
        our_by_step = {b["step"]: b for b in our_asset_buys}

        opp_total = sum(b["qty"] for b in opp_asset_buys)
        our_total = sum(b["qty"] for b in our_asset_buys)

        # Steps where opponent bought this asset but we didn't
        unmatched = []
        for step, txn in sorted(opp_by_step.items()):
            if step not in our_by_step:
                our_at_step = [b for b in buys[our_seat] if b["step"] == step]
                unmatched.append({
                    "step": step, "day": txn["day"], "hour": txn["hour"],
                    "opp_bought": f"{txn['qty']}x {asset}",
                    "our_actions": ([f"{b['type']} {b['qty']}x {b['item']}" for b in our_at_step]
                                   if our_at_step else ["nothing"]),
                })

        events.append({
            "item": trace["item"],
            "asset": asset,
            "opp_total_bought": opp_total,
            "our_total_bought": our_total,
            "qty_gap": opp_total - our_total,
            "divergence_day": trace["divergence_day"],
            "sell_qty_gap": trace["sell_qty_gap"],
            "unmatched_opp_buys": unmatched[:5],
        })

    events.sort(key=lambda x: x["sell_qty_gap"])
    return events


# ═══════════════════════════════════════════════════════════
# LAYER 5: DECISION ATTRIBUTION
# ═══════════════════════════════════════════════════════════

def extract_shop_timeline(steps):
    shop_timeline = {}
    for day in range(30):
        step_idx = min(day * 24 + 23, len(steps) - 1)
        if step_idx < 0:
            break
        obs = steps[step_idx][0]["observation"]
        shops = obs.get("town", {}).get("unlocked_shops", [])
        if shops:
            shop_timeline[day] = shops
    return shop_timeline


def get_shop_combo(steps):
    timeline = extract_shop_timeline(steps)
    for day in sorted(timeline.keys()):
        shops = timeline[day]
        if len(shops) >= 2:
            unique = []
            for s in shops:
                if s not in unique:
                    unique.append(s)
            return "+".join(unique[:3])
    return "unknown"


def _compute_early_action_similarity(steps, seat_a, seat_b, window=144):
    """Fraction of first `window` steps with identical market orders."""
    matches = 0
    total = 0
    for step_idx in range(min(window, len(steps))):
        act_a = steps[step_idx][seat_a].get("action", {}).get("market", [])
        act_b = steps[step_idx][seat_b].get("action", {}).get("market", [])
        total += 1
        if json.dumps(act_a, sort_keys=True) == json.dumps(act_b, sort_keys=True):
            matches += 1
    return matches / total if total > 0 else 0.0


def attribute_decisions(steps, our_seat, acquisition_events, shop_combo, margin):
    """Map acquisition gaps to tape routing decisions."""
    shop_timeline = extract_shop_timeline(steps)
    opp_seat = 1 - our_seat
    early_sim = _compute_early_action_similarity(steps, our_seat, opp_seat)

    attributions = []
    for event in acquisition_events:
        if not event["unmatched_opp_buys"]:
            continue

        div_day = event["divergence_day"]
        active_shops = None
        for d in sorted(shop_timeline.keys(), reverse=True):
            if d <= div_day:
                active_shops = shop_timeline[d]
                break

        if early_sim > 0.8:
            attr_type = "REACTIVE_LAYER"
            explanation = (f"Early actions {early_sim:.0%} similar — same tape base. "
                          f"Divergence at day {div_day} is a reactive layer gap.")
        elif early_sim > 0.5:
            attr_type = "TAPE_VARIANT"
            explanation = (f"Early actions {early_sim:.0%} similar — related tape variant. "
                          f"Different {event['asset']} acquisition strategy.")
        else:
            attr_type = "DIFFERENT_TAPE"
            explanation = (f"Early actions only {early_sim:.0%} similar — different tape entirely.")

        attributions.append({
            "item": event["item"],
            "asset": event["asset"],
            "qty_gap": event["qty_gap"],
            "sell_qty_gap": event["sell_qty_gap"],
            "divergence_day": div_day,
            "shop_combo": shop_combo,
            "active_shops_at_divergence": active_shops,
            "attribution_type": attr_type,
            "early_similarity": round(early_sim, 3),
            "explanation": explanation,
            "key_step": event["unmatched_opp_buys"][0] if event["unmatched_opp_buys"] else None,
        })

    return attributions


# ═══════════════════════════════════════════════════════════
# LAYER 6: QUANTIFIED INSTRUCTION
# ═══════════════════════════════════════════════════════════

def generate_instructions(decision_attributions, asset_traces, acquisition_events,
                          shop_combo, margin, gap_days):
    """Produce specific, testable instructions for code changes.

    Fires from three sources:
    1. Full chain (Layer 5 decision attributions → strongest signal)
    2. Asset divergences (Layer 3 → even without acquisition match)
    3. Money curve timing (Layer 1 → even without asset match)
    """
    instructions = []
    abs_margin = abs(margin)
    seen_assets = set()

    # Source 1: Full chain instructions (highest confidence)
    for attr in decision_attributions:
        asset = attr["asset"]
        seen_assets.add(asset)
        item = attr["item"]
        div_day = attr["divergence_day"]
        attr_type = attr["attribution_type"]
        qty_gap = attr["qty_gap"]

        if attr_type == "REACTIVE_LAYER":
            instructions.append({
                "priority": "HIGH", "source": "full_chain",
                "target": f"Reactive layer for {shop_combo} games",
                "action": (f"Add override: day >= {max(0, div_day - 1)}, "
                          f"buy {qty_gap}x more {asset}. "
                          f"Under-acquiring vs opponent by {qty_gap} units."),
                "expected_impact": f"Close ${abs_margin:,.0f} gap",
                "item": item, "asset": asset,
                "code_hint": f"reactive_overrides for '{shop_combo}'",
            })
        elif attr_type == "TAPE_VARIANT":
            instructions.append({
                "priority": "HIGH", "source": "full_chain",
                "target": f"Tape selection for {shop_combo}",
                "action": (f"Switch to tape variant with +{qty_gap} more {asset}."),
                "expected_impact": f"Close ${abs_margin:,.0f} gap",
                "item": item, "asset": asset,
                "code_hint": f"tape/routing dict for '{shop_combo}'",
            })
        else:
            instructions.append({
                "priority": "MEDIUM", "source": "full_chain",
                "target": f"Strategy review for {shop_combo}",
                "action": (f"Opponent uses different approach: +{qty_gap} more {asset}."),
                "expected_impact": f"Close ${abs_margin:,} gap (uncertain)",
                "item": item, "asset": asset,
                "code_hint": f"Review tape for '{shop_combo}'",
            })

    # Source 2: Asset divergences without full chain match
    for trace in asset_traces:
        if trace["asset"] in seen_assets:
            continue
        if trace["divergence_day"] is None or trace["max_divergence"] < 2:
            continue
        seen_assets.add(trace["asset"])

        instructions.append({
            "priority": "HIGH" if trace["max_divergence"] >= 4 else "MEDIUM",
            "source": "asset_divergence",
            "target": f"Asset acquisition for {shop_combo}",
            "action": (f"Opponent has +{trace['max_divergence']} more {trace['asset']} "
                      f"from day {trace['divergence_day']}. Produces more {trace['item']}. "
                      f"Acquire more {trace['asset']} earlier."),
            "expected_impact": (f"+{trace['max_divergence']} {trace['asset']} "
                               f"= more {trace['item']} revenue"),
            "item": trace["item"], "asset": trace["asset"],
            "code_hint": (f"BUY_{'ANIMAL' if trace['asset_type'] == 'animal' else 'SEED'} "
                         f"for {trace['asset']} in '{shop_combo}' tape"),
        })

    # Source 3: Money gap timing (if no asset-level instructions found)
    if not instructions and gap_days:
        worst_days = [d for d, delta in gap_days[:3] if delta < -1000]
        if worst_days:
            day_str = ", ".join(str(d) for d in worst_days)
            instructions.append({
                "priority": "MEDIUM", "source": "money_curve",
                "target": f"Performance on days {day_str} in {shop_combo}",
                "action": (f"Money gap widens sharply on days {day_str}. "
                          f"Opponent either sells at better prices or has more "
                          f"production capacity during this window. "
                          f"Check sell timing and asset count."),
                "expected_impact": f"Close ${abs_margin:,.0f} gap",
                "item": "unknown", "asset": "unknown",
                "code_hint": f"Review reactive sells and production for days {day_str}",
            })

    priority_order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    instructions.sort(key=lambda x: priority_order.get(x["priority"], 9))
    return instructions


# ═══════════════════════════════════════════════════════════
# FULL GAME ANALYSIS
# ═══════════════════════════════════════════════════════════

def analyze_game_v2(replay_path):
    """Full 6-layer analysis of one replay."""
    with open(replay_path) as f:
        replay = json.load(f)

    steps = replay.get("steps", [])
    if not steps:
        return None

    our_seat = identify_our_seat(replay)
    opp_seat = 1 - our_seat
    info = replay.get("info", {})
    agents = info.get("Agents", [])
    opp_name = agents[opp_seat].get("Name", "unknown") if len(agents) > opp_seat else "unknown"

    final = steps[-1]
    our_score = final[our_seat]["reward"]
    opp_score = final[opp_seat]["reward"]
    margin = our_score - opp_score
    result_tag = "WIN" if margin > 0 else ("LOSS" if margin < 0 else "TIE")

    # Layer 1: Money Curve
    money_us, money_opp = extract_money_curve(steps, our_seat)
    margin_timeline = [u - o for u, o in zip(money_us, money_opp)]
    gap_days = find_gap_opening_days(money_us, money_opp)
    turning_point = find_turning_point(margin_timeline)

    # Layer 2: Sell Quantity Attribution
    _daily_sells, sell_totals = extract_sell_quantities(steps, our_seat)
    sell_qty_gaps = compute_sell_qty_gaps(sell_totals, our_seat)
    buys = extract_buy_orders(steps, our_seat)
    buy_qty_gaps = compute_buy_qty_gaps(buys, our_seat)

    # Supplementary signals
    workers_us, workers_opp = extract_worker_counts(steps, our_seat)
    idle_rates = extract_idle_rate(steps, our_seat)
    shed_data = extract_shed_overflow(steps, our_seat)

    # Layer 3: Asset Tracing
    asset_traces = trace_asset_divergence(steps, our_seat, sell_qty_gaps)

    # Layer 4: Acquisition Attribution
    acquisition_events = find_acquisition_events(buys, our_seat, asset_traces)

    # Early action similarity (needed for twin detection + Layer 5)
    early_sim = _compute_early_action_similarity(steps, our_seat, 1 - our_seat)

    # Layer 5: Decision Attribution
    shop_combo = get_shop_combo(steps)
    decision_attrs = attribute_decisions(steps, our_seat, acquisition_events,
                                        shop_combo, margin)

    # Layer 6: Quantified Instructions
    instructions = generate_instructions(decision_attrs, asset_traces,
                                         acquisition_events, shop_combo,
                                         margin, gap_days)

    return {
        "episode_id": replay.get("id"),
        "seed": info.get("seed"),
        "our_seat": our_seat,
        "opponent_name": opp_name,
        "result": result_tag,
        "our_final_money": our_score,
        "opp_final_money": opp_score,
        "margin": margin,
        "shop_combo": shop_combo,

        # Layer 1
        "money_curve_us": money_us,
        "money_curve_opp": money_opp,
        "margin_timeline": margin_timeline,
        "turning_point_day": turning_point,
        "worst_gap_days": gap_days[:5],  # top 5 worst days

        # Layer 2
        "sell_qty_gaps": sell_qty_gaps,
        "buy_qty_gaps": buy_qty_gaps,

        # Layer 3
        "asset_traces": asset_traces,

        # Layer 4
        "acquisition_events": acquisition_events,

        # Layer 5
        "decision_attributions": decision_attrs,

        # Layer 6
        "instructions": instructions,

        # Supplementary
        "early_similarity": round(early_sim, 3),
        "workers_us": workers_us,
        "workers_opp": workers_opp,
        "idle_rate_us": idle_rates["us"],
        "idle_rate_opp": idle_rates["opp"],
        "shed_us": shed_data["us"],
        "shed_opp": shed_data["opp"],
    }


# ═══════════════════════════════════════════════════════════
# TWIN NETWORK ANALYSIS
# ═══════════════════════════════════════════════════════════

def build_twin_network(analyses):
    """Cross-game opponent analysis: twins, killers, and shared loss patterns.

    Definitions:
    - TWIN: Opponent with early_similarity > 0.8 (same tape base as us).
            Twins who beat us reveal reactive layer gaps.
    - KILLER: Opponent who beat us by $1K-$10K (small margin = similar strength,
             one exploitable fix). Killers with high similarity = highest value.
    - CLUSTER: Opponents grouped by play style (early_similarity + shop_combo).
              Multiple losses to the same cluster = systematic weakness.

    Returns: {twins, killers, clusters, loss_pattern_groups}
    """
    opponents = {}  # name → list of game results

    for a in analyses:
        name = a["opponent_name"]
        if name not in opponents:
            opponents[name] = []
        opponents[name].append({
            "episode_id": a["episode_id"],
            "result": a["result"],
            "margin": a["margin"],
            "shop_combo": a["shop_combo"],
            "early_similarity": a["early_similarity"],
            "turning_point_day": a["turning_point_day"],
            # Key divergences for pattern matching
            "asset_divergences": [
                {"asset": t["asset"], "day": t["divergence_day"], "mag": t["max_divergence"]}
                for t in a["asset_traces"] if t["divergence_day"] is not None
            ],
        })

    # ── Classify opponents ──

    twins = []   # high similarity (same tape base)
    killers = [] # beat us by small margin (exploitable)

    for name, games in opponents.items():
        avg_sim = sum(g["early_similarity"] for g in games) / len(games)
        avg_margin = sum(g["margin"] for g in games) / len(games)
        results = [g["result"] for g in games]
        losses_to = [g for g in games if g["result"] == "LOSS"]
        wins_vs = [g for g in games if g["result"] == "WIN"]

        opp_info = {
            "name": name,
            "games_played": len(games),
            "avg_similarity": round(avg_sim, 3),
            "avg_margin": round(avg_margin),
            "results": results,
            "shop_combos": list(set(g["shop_combo"] for g in games)),
        }

        # Twin: plays very similarly to us
        if avg_sim > 0.8:
            opp_info["classification"] = "TWIN"
            opp_info["insight"] = (
                f"Same tape base ({avg_sim:.0%} similar). "
                + (f"They beat us in {len(losses_to)}/{len(games)} games — "
                   f"reactive layer difference."
                   if losses_to else
                   f"We {'beat' if wins_vs else 'tied'} them — our reactive layers are adequate.")
            )
            twins.append(opp_info)

        # Killer: beat us by $1K-$10K (small margin = exploitable)
        for g in losses_to:
            if -10000 < g["margin"] < -1000:
                killer_info = dict(opp_info)
                killer_info["classification"] = "KILLER"
                killer_info["kill_margin"] = g["margin"]
                killer_info["kill_shop_combo"] = g["shop_combo"]
                killer_info["kill_episode"] = g["episode_id"]
                killer_info["kill_similarity"] = g["early_similarity"]
                killer_info["insight"] = (
                    f"Beat us by ${abs(g['margin']):,.0f} in {g['shop_combo']}. "
                    f"Similarity: {g['early_similarity']:.0%}. "
                    + ("Same tape — small reactive fix could close gap."
                       if g["early_similarity"] > 0.8 else
                       "Different tape — study their approach for this shop combo."
                       if g["early_similarity"] < 0.5 else
                       "Related variant — look for the key difference.")
                )
                killers.append(killer_info)

    # Sort killers by margin (closest losses first — most exploitable)
    killers.sort(key=lambda x: abs(x["kill_margin"]))

    # ── Cluster opponents by play style ──
    # Group by (high/mid/low similarity) × (shop_combo)
    clusters = defaultdict(lambda: {"opponents": [], "our_results": [], "margins": []})
    for a in analyses:
        sim = a["early_similarity"]
        sim_band = "SAME_TAPE" if sim > 0.8 else "VARIANT" if sim > 0.5 else "DIFFERENT"
        key = f"{sim_band}|{a['shop_combo']}"
        clusters[key]["opponents"].append(a["opponent_name"])
        clusters[key]["our_results"].append(a["result"])
        clusters[key]["margins"].append(a["margin"])

    cluster_summary = {}
    for key, data in clusters.items():
        n = len(data["opponents"])
        wins = data["our_results"].count("WIN")
        losses = data["our_results"].count("LOSS")
        ties = data["our_results"].count("TIE")
        avg_margin = round(sum(data["margins"]) / n) if n else 0
        cluster_summary[key] = {
            "count": n, "wins": wins, "losses": losses, "ties": ties,
            "avg_margin": avg_margin,
            "opponents": list(set(data["opponents"])),
        }

    # Sort clusters by avg_margin (worst first)
    cluster_summary = dict(sorted(cluster_summary.items(),
                                  key=lambda x: x[1]["avg_margin"]))

    # ── Shared loss patterns ──
    # Group losses that share the same shop_combo + similar asset divergence
    loss_patterns = defaultdict(list)
    for a in analyses:
        if a["result"] != "LOSS":
            continue
        # Pattern key: shop_combo + primary asset divergence (if any)
        primary_div = None
        for t in a["asset_traces"]:
            if t["divergence_day"] is not None and t["max_divergence"] >= 2:
                primary_div = t["asset"]
                break
        pattern_key = f"{a['shop_combo']}|{primary_div or 'no_asset_div'}"
        loss_patterns[pattern_key].append({
            "episode_id": a["episode_id"],
            "opponent": a["opponent_name"],
            "margin": a["margin"],
            "similarity": a["early_similarity"],
        })

    # Only keep patterns with 2+ losses (systematic)
    shared_patterns = {k: v for k, v in loss_patterns.items() if len(v) >= 2}

    # ── Code diffs: downloaded agents vs our candidate ──
    code_diffs = _build_code_diffs()

    return {
        "twins": twins,
        "killers": killers,
        "clusters": cluster_summary,
        "shared_loss_patterns": shared_patterns,
        "code_diffs": code_diffs,
    }


def _build_code_diffs():
    """Diff every downloaded agent's main.py against our _candidate/main.py.

    Groups agents by diff size:
    - MICRO (<20 lines): Nearly identical — reactive layer tweaks only
    - SMALL (20-100 lines): Same base, meaningful reactive differences
    - MEDIUM (100-500 lines): Related codebase, significant divergence
    - LARGE (500+ lines): Different approach entirely

    For MICRO/SMALL diffs, extract the actual changed lines as they represent
    the kind of reactive layer differences that separate twins from killers.
    """
    import difflib

    candidate_path = AUTOLOOP_DIR / "agents" / "_candidate" / "main.py"
    if not candidate_path.exists():
        return {"error": "no _candidate/main.py", "agents": []}

    try:
        candidate_code = candidate_path.read_text().splitlines()
    except Exception:
        return {"error": "could not read _candidate/main.py", "agents": []}

    agents_dir = AUTOLOOP_DIR / "agents"
    results = []

    for agent_dir in sorted(agents_dir.iterdir()):
        if not agent_dir.is_dir():
            continue
        name = agent_dir.name
        if name.startswith("_"):
            continue  # skip _candidate, _candidate_backup

        agent_main = agent_dir / "main.py"
        if not agent_main.exists():
            continue

        try:
            agent_code = agent_main.read_text().splitlines()
        except Exception:
            continue

        # Compute unified diff
        diff = list(difflib.unified_diff(candidate_code, agent_code,
                                         fromfile="_candidate", tofile=name,
                                         lineterm=""))
        diff_lines = len([l for l in diff if l.startswith("+") or l.startswith("-")]
                        ) - 2  # exclude --- and +++ header lines
        diff_lines = max(0, diff_lines)

        if diff_lines < 20:
            category = "MICRO"
        elif diff_lines < 100:
            category = "SMALL"
        elif diff_lines < 500:
            category = "MEDIUM"
        else:
            category = "LARGE"

        entry = {
            "agent": name,
            "diff_lines": diff_lines,
            "category": category,
            "agent_code_lines": len(agent_code),
        }

        # For MICRO/SMALL diffs, include the actual diff (these are the
        # reactive layer tweaks that could explain killer behavior)
        if category in ("MICRO", "SMALL"):
            # Extract only the changed hunks, skip noise
            meaningful_changes = []
            for line in diff:
                if line.startswith("@@"):
                    meaningful_changes.append(line)
                elif line.startswith("+") and not line.startswith("+++"):
                    meaningful_changes.append(line)
                elif line.startswith("-") and not line.startswith("---"):
                    meaningful_changes.append(line)
            entry["diff_preview"] = meaningful_changes[:50]  # cap at 50 lines

        results.append(entry)

    # Sort by diff size
    results.sort(key=lambda x: x["diff_lines"])

    # Summary counts
    counts = {"MICRO": 0, "SMALL": 0, "MEDIUM": 0, "LARGE": 0}
    for r in results:
        counts[r["category"]] += 1

    # Also diff candidate vs its base (from state.json)
    base_diff = None
    try:
        with open(STATE_FILE) as f:
            state = json.load(f)
        base_name = state.get("candidate_base", "")
        if base_name:
            base_path = agents_dir / base_name / "main.py"
            if base_path.exists():
                base_code = base_path.read_text().splitlines()
                diff = list(difflib.unified_diff(base_code, candidate_code,
                                                 fromfile=base_name, tofile="_candidate",
                                                 lineterm=""))
                diff_lines_count = max(0, len([l for l in diff
                                               if l.startswith("+") or l.startswith("-")]) - 2)
                meaningful = []
                for line in diff:
                    if line.startswith("@@") or (line.startswith("+") and not line.startswith("+++")) \
                       or (line.startswith("-") and not line.startswith("---")):
                        meaningful.append(line)
                base_diff = {
                    "base_agent": base_name,
                    "diff_lines": diff_lines_count,
                    "diff_preview": meaningful[:80],
                }
    except Exception:
        pass

    return {
        "total_agents": len(results),
        "counts": counts,
        "agents": results,
        "candidate_vs_base": base_diff,
    }


# ═══════════════════════════════════════════════════════════
# CROSS-GAME AGGREGATION
# ═══════════════════════════════════════════════════════════

def aggregate_v2(analyses):
    """Cross-game pattern detection + twin network."""
    wins = [a for a in analyses if a["result"] == "WIN"]
    losses = [a for a in analyses if a["result"] == "LOSS"]
    ties = [a for a in analyses if a["result"] == "TIE"]

    # Twin network
    twin_network = build_twin_network(analyses)

    # Aggregate sell qty gaps by item across losses
    item_qty_gaps = defaultdict(lambda: {"total_gap": 0, "game_count": 0, "games": []})
    for a in losses:
        for item, qgap in a["sell_qty_gaps"].items():
            if qgap["gap"] < 0:
                item_qty_gaps[item]["total_gap"] += qgap["gap"]
                item_qty_gaps[item]["game_count"] += 1
                item_qty_gaps[item]["games"].append(a["episode_id"])
    item_qty_gaps = dict(sorted(item_qty_gaps.items(), key=lambda x: x[1]["total_gap"]))

    # Aggregate by shop combo
    result_key_map = {"WIN": "wins", "LOSS": "losses", "TIE": "ties"}
    shop_stats = defaultdict(lambda: {"wins": 0, "losses": 0, "ties": 0,
                                      "margins": [], "top_qty_gaps": defaultdict(int)})
    for a in analyses:
        combo = a["shop_combo"]
        shop_stats[combo][result_key_map[a["result"]]] += 1
        shop_stats[combo]["margins"].append(a["margin"])
        for item, qgap in a["sell_qty_gaps"].items():
            if qgap["gap"] < 0:
                shop_stats[combo]["top_qty_gaps"][item] += qgap["gap"]

    for combo, stats in shop_stats.items():
        stats["avg_margin"] = round(sum(stats["margins"]) / len(stats["margins"])) if stats["margins"] else 0
        stats["top_qty_gaps"] = dict(sorted(stats["top_qty_gaps"].items(), key=lambda x: x[1]))
        del stats["margins"]

    # Worst gap days across losses (where do we consistently fall behind?)
    day_impact = defaultdict(list)
    for a in losses:
        for day, delta in a["worst_gap_days"]:
            if delta < 0:
                day_impact[day].append(delta)
    # Average impact per day across losses
    avg_day_impact = {d: round(sum(deltas) / len(deltas))
                      for d, deltas in day_impact.items() if len(deltas) >= 2}
    avg_day_impact = dict(sorted(avg_day_impact.items(), key=lambda x: x[1]))

    # Collect instructions, deduplicate
    all_instructions = []
    seen = set()
    for a in losses:
        for inst in a["instructions"]:
            key = (inst["asset"], a["shop_combo"])
            if key not in seen:
                seen.add(key)
                inst_copy = dict(inst)
                inst_copy["from_episode"] = a["episode_id"]
                inst_copy["game_margin"] = a["margin"]
                all_instructions.append(inst_copy)

    priority_order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    all_instructions.sort(key=lambda x: priority_order.get(x["priority"], 9))

    return {
        "total_games": len(analyses),
        "wins": len(wins),
        "losses": len(losses),
        "ties": len(ties),
        "avg_margin_wins": round(sum(a["margin"] for a in wins) / len(wins)) if wins else 0,
        "avg_margin_losses": round(sum(a["margin"] for a in losses) / len(losses)) if losses else 0,
        "item_qty_gap_ranking": item_qty_gaps,
        "shop_combo_stats": dict(shop_stats),
        "consistent_bad_days": avg_day_impact,
        "twin_network": twin_network,
        "instructions": all_instructions,
        "timestamp": datetime.now().isoformat(),
    }


# ═══════════════════════════════════════════════════════════
# REPORT
# ═══════════════════════════════════════════════════════════

def generate_report(aggregate, analyses):
    losses = [a for a in analyses if a["result"] == "LOSS"]
    L = []

    L.append("=" * 70)
    L.append("  REPLAY ANALYZER V2 — 6-LAYER ATTRIBUTION CHAIN")
    L.append("=" * 70)
    L.append(f"Games: {aggregate['total_games']} "
             f"({aggregate['wins']}W / {aggregate['losses']}L / {aggregate['ties']}T)")
    L.append(f"Avg win margin:  ${aggregate['avg_margin_wins']:+,}")
    L.append(f"Avg loss margin: ${aggregate['avg_margin_losses']:+,}")
    L.append("")

    if not losses:
        L.append("NO LOSSES. All games won or tied.")
        return "\n".join(L)

    # ── Sell Qty Gap Ranking ──
    L.append("-" * 70)
    L.append("SELL QUANTITY GAPS (across all losses, items we sold LESS of)")
    L.append("-" * 70)
    for item, data in aggregate["item_qty_gap_ranking"].items():
        L.append(f"  {item:15s}  qty gap: {data['total_gap']:>+8}  "
                 f"in {data['game_count']}/{len(losses)} losses")
    L.append("")

    # ── Consistent Bad Days ──
    if aggregate["consistent_bad_days"]:
        L.append("-" * 70)
        L.append("CONSISTENTLY BAD DAYS (avg money delta in 2+ losses)")
        L.append("-" * 70)
        for day, avg_delta in list(aggregate["consistent_bad_days"].items())[:5]:
            L.append(f"  Day {day:2d}:  avg delta ${avg_delta:+,}/day")
        L.append("")

    # ── Shop Combo Performance ──
    L.append("-" * 70)
    L.append("SHOP COMBO PERFORMANCE")
    L.append("-" * 70)
    for combo, stats in sorted(aggregate["shop_combo_stats"].items(),
                               key=lambda x: x[1]["avg_margin"]):
        L.append(f"  {combo:40s}  {stats['wins']}W/{stats['losses']}L/{stats['ties']}T  "
                 f"avg: ${stats['avg_margin']:+,}")
        if stats["top_qty_gaps"]:
            worst = list(stats["top_qty_gaps"].items())[:3]
            gap_str = ", ".join(f"{item}: {gap:+}" for item, gap in worst)
            L.append(f"    Sell qty gaps: {gap_str}")
    L.append("")

    # ── Twin Network ──
    tn = aggregate.get("twin_network", {})
    if tn.get("killers") or tn.get("twins") or tn.get("shared_loss_patterns"):
        L.append("-" * 70)
        L.append("TWIN NETWORK ANALYSIS")
        L.append("-" * 70)

        if tn.get("twins"):
            L.append("  Twins (same tape base, >80% early action similarity):")
            for t in tn["twins"]:
                results_str = "/".join(t["results"])
                L.append(f"    {t['name']:25s}  sim={t['avg_similarity']:.0%}  "
                         f"margin=${t['avg_margin']:+,}  [{results_str}]")
                L.append(f"      {t['insight']}")
            L.append("")

        if tn.get("killers"):
            L.append("  Killers (beat us by $1K-$10K — exploitable gap):")
            for k in tn["killers"]:
                L.append(f"    {k['name']:25s}  margin=${k['kill_margin']:+,.0f}  "
                         f"sim={k['kill_similarity']:.0%}  shops={k['kill_shop_combo']}")
                L.append(f"      {k['insight']}")
            L.append("")

        if tn.get("shared_loss_patterns"):
            L.append("  Shared loss patterns (same shop+divergence in 2+ losses):")
            for pattern, games in tn["shared_loss_patterns"].items():
                parts = pattern.split("|")
                combo, div = parts[0], parts[1] if len(parts) > 1 else "?"
                opps = ", ".join(g["opponent"] for g in games)
                avg_m = round(sum(g["margin"] for g in games) / len(games))
                L.append(f"    {combo} | {div}: {len(games)} losses (avg ${avg_m:+,}) vs {opps}")
            L.append("")

        # Cluster summary (only show clusters with losses)
        loss_clusters = {k: v for k, v in tn.get("clusters", {}).items() if v["losses"] > 0}
        if loss_clusters:
            L.append("  Opponent clusters (style × shop combo, losses only):")
            for key, cl in loss_clusters.items():
                sim_band, combo = key.split("|", 1)
                L.append(f"    {sim_band:12s} × {combo:30s}  "
                         f"{cl['wins']}W/{cl['losses']}L/{cl['ties']}T  "
                         f"avg=${cl['avg_margin']:+,}")

        L.append("")

    # ── Code Diffs ──
    cd = tn.get("code_diffs", {})
    if cd.get("agents"):
        L.append("-" * 70)
        L.append("CODE DIFFS vs _candidate (downloaded agents)")
        L.append("-" * 70)
        counts = cd.get("counts", {})
        L.append(f"  {cd['total_agents']} agents: "
                 f"{counts.get('MICRO',0)} micro (<20 lines), "
                 f"{counts.get('SMALL',0)} small (20-100), "
                 f"{counts.get('MEDIUM',0)} medium (100-500), "
                 f"{counts.get('LARGE',0)} large (500+)")
        L.append("")

        # Candidate vs its base
        cvb = cd.get("candidate_vs_base")
        if cvb:
            L.append(f"  _candidate vs base ({cvb['base_agent']}): "
                     f"{cvb['diff_lines']} changed lines")
            preview = cvb.get("diff_preview", [])
            added = [l for l in preview if l.startswith("+")]
            removed = [l for l in preview if l.startswith("-")]
            if added or removed:
                L.append(f"    {len(added)} added, {len(removed)} removed")
            L.append("")

        # Show MICRO and SMALL diffs (these are the exploitable edges)
        interesting = [a for a in cd["agents"] if a["category"] in ("MICRO", "SMALL")]
        if interesting:
            L.append("  Close variants (potential reactive layer diffs):")
            for ag in interesting[:10]:
                L.append(f"    {ag['agent']:50s}  {ag['diff_lines']:>4} lines  [{ag['category']}]")
                preview = ag.get("diff_preview", [])
                added = [l[1:].strip() for l in preview if l.startswith("+") and l[1:].strip()]
                removed = [l[1:].strip() for l in preview if l.startswith("-") and l[1:].strip()]
                if added[:2]:
                    for line in added[:2]:
                        L.append(f"      + {line[:80]}")
                if removed[:2]:
                    for line in removed[:2]:
                        L.append(f"      - {line[:80]}")
            L.append("")

        # Show top 5 closest MEDIUM diffs (if no MICRO/SMALL found)
        if not interesting:
            closest_medium = [a for a in cd["agents"] if a["category"] == "MEDIUM"][:5]
            if closest_medium:
                L.append("  Closest agents (MEDIUM diffs — related codebases):")
                for ag in closest_medium:
                    L.append(f"    {ag['agent']:50s}  {ag['diff_lines']:>4} lines")
                L.append("")

    # ── Per-Game Deep Dive ──
    L.append("-" * 70)
    L.append("PER-GAME ATTRIBUTION (losses, worst first)")
    L.append("-" * 70)

    for a in sorted(losses, key=lambda x: x["margin"]):
        L.append("")
        L.append(f"  Episode {a['episode_id']} vs {a['opponent_name']}")
        L.append(f"  Margin: ${a['margin']:+,.0f} | Shops: {a['shop_combo']}")
        L.append(f"  Score: us=${a['our_final_money']:,.0f}  opp=${a['opp_final_money']:,.0f}")

        if a["turning_point_day"] is not None:
            L.append(f"  Turning point: day {a['turning_point_day']}")

        # Worst days
        worst = [(d, delta) for d, delta in a["worst_gap_days"][:3] if delta < -500]
        if worst:
            day_str = ", ".join(f"day {d} (${delta:+,})" for d, delta in worst)
            L.append(f"  Worst days: {day_str}")

        # Sell qty gaps
        neg_gaps = [(item, g) for item, g in a["sell_qty_gaps"].items() if g["gap"] < -10]
        if neg_gaps:
            neg_gaps.sort(key=lambda x: x[1]["gap"])
            L.append("  Sell qty gaps:")
            for item, g in neg_gaps[:3]:
                L.append(f"    {item:15s}  us={g['us_qty']:>6}  opp={g['opp_qty']:>6}  "
                         f"gap={g['gap']:>+6}")

        # Asset traces
        traces_with_div = [t for t in a["asset_traces"] if t["divergence_day"] is not None]
        if traces_with_div:
            L.append("  Asset divergences:")
            for trace in traces_with_div[:3]:
                L.append(f"    {trace['asset']:10s}  diverged day {trace['divergence_day']}  "
                         f"(opp +{trace['max_divergence']} more)")

        # Acquisition events
        acq_with_unmatched = [e for e in a["acquisition_events"] if e["unmatched_opp_buys"]]
        if acq_with_unmatched:
            L.append("  Key acquisitions missed:")
            for event in acq_with_unmatched[:2]:
                buy = event["unmatched_opp_buys"][0]
                our_act = ", ".join(buy["our_actions"])
                L.append(f"    Step {buy['step']} (day {buy['day']}): "
                         f"opp bought {buy['opp_bought']}, we did: {our_act}")

        # Decision attribution
        if a["decision_attributions"]:
            L.append("  Decision attribution:")
            for da in a["decision_attributions"][:2]:
                L.append(f"    [{da['attribution_type']}] {da['explanation']}")

        # Supplementary signals
        signals = []
        # Worker deficit
        if len(a["workers_us"]) > 14 and len(a["workers_opp"]) > 14:
            w_gap = a["workers_opp"][14] - a["workers_us"][14]
            if w_gap >= 2:
                signals.append(f"workers: {w_gap} fewer than opp by day 15")
        # Idle rate
        idle_diff = a["idle_rate_us"] - a["idle_rate_opp"]
        if idle_diff > 0.03:
            signals.append(f"idle: {a['idle_rate_us']:.1%} vs opp {a['idle_rate_opp']:.1%}")
        # Shed overflow
        if a["shed_us"]["days_at_100"]:
            signals.append(f"shed at 100: days {a['shed_us']['days_at_100']}")
        if signals:
            L.append(f"  Signals: {' | '.join(signals)}")

    # ── Instructions ──
    L.append("")
    L.append("=" * 70)
    L.append("  QUANTIFIED INSTRUCTIONS (deduplicated across games)")
    L.append("=" * 70)

    if not aggregate["instructions"]:
        L.append("  No actionable instructions generated.")
    else:
        for i, inst in enumerate(aggregate["instructions"], 1):
            L.append("")
            L.append(f"  INSTRUCTION #{i} [{inst['priority']}]")
            L.append(f"  Target: {inst['target']}")
            L.append(f"  Action: {inst['action']}")
            L.append(f"  Expected: {inst['expected_impact']}")
            L.append(f"  Code: {inst['code_hint']}")
            L.append(f"  From: episode {inst['from_episode']} (${inst['game_margin']:+,.0f})")

    L.append("")
    L.append("=" * 70)
    return "\n".join(L)


# ═══════════════════════════════════════════════════════════
# OUTPUT FILES
# ═══════════════════════════════════════════════════════════

def write_outputs(analyses, aggregate, report):
    DIAGNOSIS_DIR.mkdir(parents=True, exist_ok=True)

    with open(DIAGNOSIS_DIR / "v2_full.json", "w") as f:
        json.dump({"aggregate": aggregate, "games": analyses}, f, indent=2, default=str)

    with open(DIAGNOSIS_DIR / "v2_instructions.json", "w") as f:
        json.dump(aggregate["instructions"], f, indent=2, default=str)

    with open(DIAGNOSIS_DIR / "v2_report.txt", "w") as f:
        f.write(report)

    # Compact per-game summary
    summary = []
    for a in analyses:
        top_gaps = {item: g["gap"] for item, g in list(a["sell_qty_gaps"].items())[:5]
                    if g["gap"] < 0}
        summary.append({
            "episode_id": a["episode_id"],
            "result": a["result"],
            "margin": a["margin"],
            "shop_combo": a["shop_combo"],
            "opponent": a["opponent_name"],
            "turning_point": a["turning_point_day"],
            "sell_qty_gaps": top_gaps,
        })
    with open(DIAGNOSIS_DIR / "v2_summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=str)

    log(f"  Output: v2_full.json, v2_instructions.json, v2_report.txt, v2_summary.json")


# ═══════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Replay Analyzer V2: 6-layer attribution chain")
    parser.add_argument("--submission-id", type=int, help="Kaggle submission ID")
    parser.add_argument("--episodes", type=int, nargs="+", help="Specific episode IDs")
    parser.add_argument("--from-state", action="store_true", help="Get submission ID from state.json")
    parser.add_argument("--local", action="store_true", help="Analyze all cached replays")
    parser.add_argument("--max-episodes", type=int, default=10)
    args = parser.parse_args()

    log("=== REPLAY ANALYZER V2 START ===")

    replay_paths = []
    if args.local:
        replay_paths = sorted(REPLAY_DIR.glob("*.json"))
        log(f"  Using {len(replay_paths)} cached replays")
    elif args.episodes:
        for ep_id in args.episodes:
            path = download_replay(ep_id)
            if path:
                replay_paths.append(path)
    else:
        sub_id = args.submission_id
        if args.from_state or not sub_id:
            sub_id = get_latest_submission_id()
        if not sub_id:
            log("No submission ID found")
            return
        log(f"  Submission ID: {sub_id}")
        episode_ids = discover_episodes(sub_id, args.max_episodes)
        for ep_id in episode_ids:
            path = download_replay(ep_id)
            if path:
                replay_paths.append(path)

    if not replay_paths:
        log("No replays to analyze")
        return

    prune_cache()

    log(f"  Analyzing {len(replay_paths)} games through 6-layer chain...")
    analyses = []
    for path in replay_paths:
        try:
            result = analyze_game_v2(path)
            if result:
                tag = result["result"]
                n_inst = len(result["instructions"])
                log(f"    {path.stem}: {tag} ${result['margin']:+,.0f} "
                    f"vs {result['opponent_name']} | {n_inst} instructions")
                analyses.append(result)
        except Exception as e:
            log(f"    {path.stem}: ERROR — {e}")
            import traceback
            traceback.print_exc()

    if not analyses:
        log("No games analyzed successfully")
        return

    aggregate = aggregate_v2(analyses)
    log(f"  Summary: {aggregate['wins']}W-{aggregate['losses']}L-{aggregate['ties']}T")
    log(f"  Unique instructions: {len(aggregate['instructions'])}")

    report = generate_report(aggregate, analyses)
    write_outputs(analyses, aggregate, report)

    print()
    print(report)
    log("=== REPLAY ANALYZER V2 DONE ===")


if __name__ == "__main__":
    main()
