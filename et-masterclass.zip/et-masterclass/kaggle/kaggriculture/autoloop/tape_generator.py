#!/usr/bin/env python3
"""Tape Generator: Produce valid 719-step action tapes from a farm plan.

Uses greedy priority scheduling. Each step, each worker picks the best
available action. Produces internally consistent tapes that can be
replayed in kaggle_environments.

Usage:
    python tape_generator.py                    # Generate default tape, test it
    python tape_generator.py --plan tomato      # Generate tomato-heavy plan
    python tape_generator.py --search           # Search across plans
"""
import argparse
import copy
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

# ── Constants ────────────────────────────────────────────

BOARD_SIZE = 10
STEPS_PER_DAY = 24
TOTAL_STEPS = 719  # 30 days * 24 - 1
MAX_MARKET_ORDERS = 10
SHED_CAPACITY = 100
STARTING_MONEY = 3000

SHED_ACCESS = [(4, 4), (5, 4), (4, 5), (5, 5)]

QUADRANT_TILES = {
    'NW': [(x, y) for y in range(5) for x in range(5)],
    'NE': [(x, y) for y in range(5) for x in range(5, 10)],
    'SW': [(x, y) for y in range(5, 10) for x in range(5)],
    'SE': [(x, y) for y in range(5, 10) for x in range(5, 10)],
}

CROPS = {
    'WHEAT':      {'seed_cost': 10,  'first_yield': 2, 'max_yield_day': 4,  'max_yield': 6, 'interval': 0, 'ongoing': False},
    'CARROT':     {'seed_cost': 20,  'first_yield': 2, 'max_yield_day': 3,  'max_yield': 4, 'interval': 0, 'ongoing': False},
    'TOMATO':     {'seed_cost': 50,  'first_yield': 8, 'max_yield_day': 8,  'max_yield': 4, 'interval': 1, 'ongoing': True},
    'STRAWBERRY': {'seed_cost': 100, 'first_yield': 10,'max_yield_day': 10, 'max_yield': 4, 'interval': 2, 'ongoing': True},
    'MELON':      {'seed_cost': 80,  'first_yield': 10,'max_yield_day': 12, 'max_yield': 6, 'interval': 0, 'ongoing': False},
}

ANIMALS = {
    'GOOSE': {'cost': 300, 'structure': 'COOP',    'first_yield': 4, 'interval': 1, 'product': 'EGG'},
    'COW':   {'cost': 400, 'structure': 'PASTURE', 'first_yield': 8, 'interval': 2, 'product': 'MILK'},
    'SHEEP': {'cost': 500, 'structure': 'PASTURE', 'first_yield': 6, 'interval': 3, 'product': 'WOOL'},
}

MOVES = {'NORTH': (0, -1), 'SOUTH': (0, 1), 'EAST': (1, 0), 'WEST': (-1, 0)}

def fib_cost(n):
    """Fibonacci hire cost for nth hire today."""
    if n <= 0: return 0
    a, b = 50, 50
    for _ in range(n - 1):
        a, b = b, a + b
    return a

def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def walk_toward(pos, target):
    """Return move command toward target, or None if already there."""
    if pos == target:
        return None
    dx = target[0] - pos[0]
    dy = target[1] - pos[1]
    if abs(dx) >= abs(dy):
        return 'EAST' if dx > 0 else 'WEST'
    return 'SOUTH' if dy > 0 else 'NORTH'

def nearest_shed(pos):
    return min(SHED_ACCESS, key=lambda s: manhattan(pos, s))


# ── Farm Plans ───────────────────────────────────────────

def make_default_plan():
    """Standard wheat-heavy plan similar to TTV1."""
    return {
        'name': 'default',
        # NW quadrant crops (available day 0)
        'crops_nw': [
            ('WHEAT', [(x, y) for y in range(3) for x in range(4)]),  # 12 wheat
            ('STRAWBERRY', [(x, y) for y in range(3, 5) for x in range(5)]),  # 10 strawberry
        ],
        # NE quadrant crops (available ~day 6)
        'crops_ne': [
            ('WHEAT', [(x, y) for y in range(3) for x in range(5, 9)]),  # 12 wheat
            ('STRAWBERRY', [(x, y) for y in range(3, 5) for x in range(5, 10)]),  # 10 strawberry
        ],
        # Animals (placed in structures)
        'animals_nw': [('COW', 2), ('GOOSE', 2)],
        'animals_ne': [('COW', 2), ('SHEEP', 2)],
        'animals_sw': [('COW', 2), ('SHEEP', 2), ('GOOSE', 1)],
        # When to buy land (NE, SW, SE)
        'buy_ne_day': 6,
        'buy_sw_day': 11,
        'buy_se_day': None,  # don't buy SE
        # Late game crop rotation
        'late_crops': 'CARROT',  # replant with this after day 22
        'target_workers': 11,
    }


def make_tomato_plan():
    """Tomato-heavy for PIZZA_SHOP/FARMERS_MARKET worlds."""
    return {
        'name': 'tomato_heavy',
        'crops_nw': [
            ('WHEAT', [(x, y) for y in range(2) for x in range(4)]),  # 8 wheat
            ('TOMATO', [(x, y) for y in range(2, 4) for x in range(4)]),  # 8 tomato
            ('STRAWBERRY', [(x, y) for y in range(4, 5) for x in range(5)]),  # 5 strawberry
        ],
        'crops_ne': [
            ('WHEAT', [(x, y) for y in range(2) for x in range(5, 9)]),  # 8 wheat
            ('TOMATO', [(x, y) for y in range(2, 4) for x in range(5, 9)]),  # 8 tomato
            ('STRAWBERRY', [(x, y) for y in range(4, 5) for x in range(5, 10)]),  # 5 strawberry
        ],
        'animals_nw': [('COW', 2), ('GOOSE', 2)],
        'animals_ne': [('COW', 2), ('GOOSE', 2)],
        'animals_sw': [('COW', 2), ('SHEEP', 2), ('GOOSE', 1)],
        'buy_ne_day': 6,
        'buy_sw_day': 11,
        'buy_se_day': None,
        'late_crops': 'CARROT',
        'target_workers': 11,
    }


def make_balanced_plan():
    """Balanced: some of everything."""
    return {
        'name': 'balanced',
        'crops_nw': [
            ('WHEAT', [(x, y) for y in range(2) for x in range(4)]),  # 8 wheat
            ('TOMATO', [(x, 2) for x in range(4)]),  # 4 tomato
            ('STRAWBERRY', [(x, y) for y in range(3, 5) for x in range(5)]),  # 10 strawberry
        ],
        'crops_ne': [
            ('WHEAT', [(x, y) for y in range(2) for x in range(5, 9)]),  # 8 wheat
            ('TOMATO', [(x, 2) for x in range(5, 9)]),  # 4 tomato
            ('STRAWBERRY', [(x, y) for y in range(3, 5) for x in range(5, 10)]),  # 10 strawberry
        ],
        'animals_nw': [('COW', 2), ('GOOSE', 3)],
        'animals_ne': [('COW', 2), ('SHEEP', 2)],
        'animals_sw': [('COW', 2), ('SHEEP', 2), ('GOOSE', 1)],
        'buy_ne_day': 6,
        'buy_sw_day': 11,
        'buy_se_day': None,
        'late_crops': 'CARROT',
        'target_workers': 11,
    }


# ── Tape Generator ───────────────────────────────────────

class TapeGenerator:
    """Generate a 719-step tape from a farm plan using greedy scheduling."""

    def __init__(self, plan):
        self.plan = plan
        self.tape = []  # list of action dicts, one per step

        # Simulated state
        self.money = STARTING_MONEY
        self.shed = defaultdict(int)
        self.workers = []  # list of {pos, inventory, assigned_tiles}
        self.farmer = {'pos': (4, 4), 'inventory': defaultdict(int)}
        self.tiles = {}  # (x,y) -> tile state
        self.unlocked = {'NW'}
        self.hires_today = 0
        self.market_orders_this_step = 0
        self.day = 0
        self.hour = 0
        self.step = 0

    def generate(self):
        """Generate the full 719-step tape."""
        for step in range(TOTAL_STEPS + 1):
            self.step = step
            self.day = step // STEPS_PER_DAY
            self.hour = step % STEPS_PER_DAY

            if self.hour == 0:
                self.hires_today = 0

            self.market_orders_this_step = 0
            action = self._generate_step()
            self.tape.append(action)

        return self.tape

    def _generate_step(self):
        """Generate action for one step."""
        market = self._plan_market()
        farmer_cmd = self._plan_worker(self.farmer, is_farmer=True)
        hand_cmds = [self._plan_worker(w) for w in self.workers]

        return {
            'farmer': farmer_cmd,
            'hands': hand_cmds,
            'market': market,
        }

    def _plan_market(self):
        """Plan market orders for this step."""
        orders = []
        plan = self.plan

        # Opening: buy wheat for initial planting
        if self.step == 0:
            orders.append(['BUY_PRODUCT', 'WHEAT', 8])
            # Buy initial seeds
            for crop, tiles in plan.get('crops_nw', []):
                qty = len(tiles)
                if qty > 0:
                    orders.append(['BUY_SEED', crop, qty])
            # Hire workers (5 on day 0)
            for _ in range(min(5, plan.get('target_workers', 11))):
                orders.append(['HIRE'])
            # Buy initial animals
            for animal, count in plan.get('animals_nw', []):
                if count > 0:
                    orders.append(['BUY_ANIMAL', animal, count])
            return orders[:MAX_MARKET_ORDERS]

        # Day 1-2: more hires
        if self.day in (1, 2) and self.hour == 1:
            remaining = plan.get('target_workers', 11) - len(self.workers)
            for _ in range(min(3, remaining)):
                orders.append(['HIRE'])

        # Buy land NE
        if self.day == plan.get('buy_ne_day', 6) and self.hour == 0:
            orders.append(['BUY_LAND'])
            # Seeds for NE crops
            for crop, tiles in plan.get('crops_ne', []):
                qty = len(tiles)
                if qty > 0:
                    orders.append(['BUY_SEED', crop, qty])
            # Animals for NE
            for animal, count in plan.get('animals_ne', []):
                if count > 0:
                    orders.append(['BUY_ANIMAL', animal, count])

        # Buy land SW
        if self.day == plan.get('buy_sw_day', 11) and self.hour == 0:
            orders.append(['BUY_LAND'])
            for animal, count in plan.get('animals_sw', []):
                if count > 0:
                    orders.append(['BUY_ANIMAL', animal, count])

        # Ongoing: buy wheat for animal feed
        if self.hour == 0 and self.day >= 2:
            orders.append(['BUY_PRODUCT', 'WHEAT', 6])

        # Sell surplus from shed every few hours
        if self.hour in (6, 12, 18, 23):
            for item in ['WHEAT', 'CARROT', 'TOMATO', 'STRAWBERRY', 'MELON',
                         'EGG', 'MILK', 'WOOL', 'FERTILIZER']:
                # Keep reserves for feed
                reserve = 8 if item == 'WHEAT' else 0
                surplus = self.shed.get(item, 0) - reserve
                if surplus > 0 and len(orders) < MAX_MARKET_ORDERS:
                    orders.append(['SELL', item, surplus])

        # Late game: buy carrot/replacement seeds
        if self.day >= 22 and self.hour == 0:
            late_crop = plan.get('late_crops', 'CARROT')
            orders.append(['BUY_SEED', late_crop, 10])

        return orders[:MAX_MARKET_ORDERS]

    def _plan_worker(self, worker, is_farmer=False):
        """Plan one worker's action using greedy priority."""
        pos = worker['pos']
        inv = worker['inventory']

        # Priority 1: Drop off cargo at shed if inventory is getting full
        total_carried = sum(inv.values())
        if total_carried >= 8:
            shed = nearest_shed(pos)
            if pos == shed:
                # Drop the most valuable item
                for item in ['WOOL', 'MILK', 'EGG', 'STRAWBERRY', 'TOMATO',
                             'MELON', 'CARROT', 'WHEAT', 'FERTILIZER']:
                    if inv.get(item, 0) > 0:
                        qty = inv[item]
                        inv[item] = 0
                        self.shed[item] += qty
                        return ['PLACE', item, qty]
            move = walk_toward(pos, shed)
            if move:
                dx, dy = MOVES[move]
                worker['pos'] = (pos[0] + dx, pos[1] + dy)
                return [move]

        # Priority 2: Feed hungry animals (if have wheat)
        # Simplified: animals get fed by any worker passing through with wheat
        # In real impl, check tile states

        # Priority 3: Harvest ready crops
        # Priority 4: Water crops
        # Priority 5: Plant on empty tiles (if have seeds)
        # Priority 6: Pickup seeds/items from shed

        # For now: simple patrol pattern
        # Workers assigned to specific regions walk through their tiles
        # and perform actions based on tile state

        # Since we can't simulate tile states without the engine,
        # generate a simple patrol + action pattern

        # Move toward nearest assigned tile that needs attention
        # Fallback: PASS
        return ['PASS']

    def to_agent_file(self, output_path):
        """Write the tape as a runnable agent file."""
        tape_json = json.dumps(self.tape)
        agent_code = f'''import json

_TAPE = json.loads('{tape_json}')

def agent(observation, configuration=None):
    step = int(observation['step'])
    if step < len(_TAPE):
        return _TAPE[step]
    return {{'farmer': ['PASS'], 'hands': [], 'market': []}}
'''
        Path(output_path).write_text(agent_code)


# ── Main ─────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', default='default', choices=['default', 'tomato', 'balanced'])
    parser.add_argument('--search', action='store_true')
    parser.add_argument('--output', default=None)
    args = parser.parse_args()

    plans = {
        'default': make_default_plan,
        'tomato': make_tomato_plan,
        'balanced': make_balanced_plan,
    }

    if args.search:
        print("Search mode: testing all plans...")
        for name, plan_fn in plans.items():
            gen = TapeGenerator(plan_fn())
            tape = gen.generate()
            out = Path(f"/tmp/tape_{name}.py")
            gen.to_agent_file(out)
            print(f"  {name}: {len(tape)} steps -> {out}")
        return

    plan = plans[args.plan]()
    print(f"Generating tape for plan: {plan['name']}")
    gen = TapeGenerator(plan)
    tape = gen.generate()
    print(f"Generated {len(tape)} steps")

    output = args.output or f"/tmp/tape_{plan['name']}.py"
    gen.to_agent_file(output)
    print(f"Written to {output}")


if __name__ == '__main__':
    main()
