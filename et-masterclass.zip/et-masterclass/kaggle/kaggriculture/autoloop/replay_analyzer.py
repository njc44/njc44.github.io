#!/usr/bin/env python3
"""Replay Analyzer: Parse LB replays, diagnose where our agent loses money.

Deterministic. No AI. Downloads replays from Kaggle, extracts per-game
stats at day boundaries, identifies loss patterns, outputs structured
diagnosis for the improve phase.

Usage:
    python replay_analyzer.py --submission-id 56211878 --max-episodes 10
    python replay_analyzer.py --from-state
    python replay_analyzer.py --episodes 108674164 108673229
"""
import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
REPLAY_DIR = AUTOLOOP_DIR / "replays"
DIAGNOSIS_DIR = AUTOLOOP_DIR / "diagnosis"
STATE_FILE = AUTOLOOP_DIR / "state.json"
OUR_TEAM = "Nathan Jacob"
MAX_CACHED_REPLAYS = 50


def log(msg):
    print(f"[replay] {msg}", flush=True)


# ── Stage 1: Discover episodes ────────────────────────────

def discover_episodes(submission_id, max_episodes=10):
    """Get recent completed episode IDs for a submission."""
    try:
        result = subprocess.run(
            ["kaggle", "competitions", "episodes", str(submission_id)],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            log(f"  Failed to list episodes: {result.stderr}")
            return []

        episodes = []
        for line in result.stdout.strip().split("\n")[2:]:  # skip header
            parts = line.split()
            if parts and parts[0].strip().isdigit():
                ep_id = int(parts[0].strip())
                episodes.append(ep_id)

        log(f"  Found {len(episodes)} episodes, taking {min(len(episodes), max_episodes)}")
        return episodes[:max_episodes]
    except Exception as e:
        log(f"  Episode discovery error: {e}")
        return []


def get_latest_submission_id():
    """Get the most recent submission ID from Kaggle CLI."""
    try:
        result = subprocess.run(
            ["kaggle", "competitions", "submissions", "kaggriculture"],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            return None
        for line in result.stdout.strip().split("\n")[2:]:
            parts = line.split()
            if parts and parts[0].strip().isdigit():
                return int(parts[0].strip())
    except Exception:
        pass
    return None


# ── Stage 2: Download replays ─────────────────────────────

def download_replay(episode_id):
    """Download a replay, return path. Uses cache."""
    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    cached = REPLAY_DIR / f"{episode_id}.json"
    if cached.exists():
        return cached

    try:
        result = subprocess.run(
            ["kaggle", "competitions", "replay", str(episode_id),
             "-p", str(REPLAY_DIR), "-q"],
            capture_output=True, text=True, timeout=60,
            cwd=str(REPLAY_DIR)
        )
        # Kaggle downloads as episode-XXXXX-replay.json
        downloaded = REPLAY_DIR / f"episode-{episode_id}-replay.json"
        if downloaded.exists():
            downloaded.rename(cached)
            return cached

        # Try alternate naming
        for f in REPLAY_DIR.glob(f"*{episode_id}*"):
            f.rename(cached)
            return cached

        log(f"  Download failed for {episode_id}: file not found after download")
        return None
    except Exception as e:
        log(f"  Download error {episode_id}: {e}")
        return None


def prune_cache():
    """Keep only the newest MAX_CACHED_REPLAYS files."""
    replays = sorted(REPLAY_DIR.glob("*.json"), key=lambda f: f.stat().st_mtime)
    while len(replays) > MAX_CACHED_REPLAYS:
        old = replays.pop(0)
        old.unlink()
        log(f"  Pruned old replay: {old.name}")


# ── Stage 3: Per-game extraction ──────────────────────────

def identify_our_seat(replay):
    """Find which player index (0 or 1) is us."""
    info = replay.get("info", {})
    agents = info.get("Agents", [])
    for i, agent in enumerate(agents):
        if agent.get("Name", "").strip() == OUR_TEAM:
            return i
    # Fallback: TeamNames
    teams = info.get("TeamNames", [])
    for i, name in enumerate(teams):
        if name.strip() == OUR_TEAM:
            return i
    # Default to 0 if not found
    log(f"  WARNING: Could not identify our seat, defaulting to 0")
    return 0


def extract_money_curves(steps, our_seat):
    """Money at each day boundary (step 0, 24, 48, ..., 696) + final step."""
    opp_seat = 1 - our_seat
    us, opp = [], []
    for day in range(30):
        step_idx = day * 24
        if step_idx >= len(steps):
            break
        obs = steps[step_idx][0]["observation"]  # either player sees both farms
        us.append(obs["farms"][our_seat]["money"])
        opp.append(obs["farms"][opp_seat]["money"])
    # Final step
    if len(steps) > 0:
        final = steps[-1]
        us.append(final[our_seat]["reward"])
        opp.append(final[opp_seat]["reward"])
    return us, opp


def extract_worker_counts(steps, our_seat):
    """Worker count (1 farmer + hands) at mid-day for each day."""
    opp_seat = 1 - our_seat
    us, opp = [], []
    for day in range(30):
        step_idx = day * 24 + 12  # mid-day
        if step_idx >= len(steps):
            break
        obs = steps[step_idx][0]["observation"]
        us.append(1 + len(obs["farms"][our_seat].get("hands", [])))
        opp.append(1 + len(obs["farms"][opp_seat].get("hands", [])))
    return us, opp


def extract_tile_usage(steps, our_seat):
    """Count tiles in use (plants, animals) per day."""
    opp_seat = 1 - our_seat

    def count_tiles(farm):
        plants, animals, total = 0, 0, 0
        for row in farm.get("tiles", []):
            for t in row:
                if isinstance(t, dict):
                    if t.get("kind") == "WEED":
                        continue
                    total += 1
                    if "crop" in t:
                        plants += 1
                    elif "animal" in t:
                        animals += 1
        return {"plants": plants, "animals": animals, "total": total}

    us, opp = [], []
    for day in range(30):
        step_idx = day * 24 + 12
        if step_idx >= len(steps):
            break
        obs = steps[step_idx][0]["observation"]
        us.append(count_tiles(obs["farms"][our_seat]))
        opp.append(count_tiles(obs["farms"][opp_seat]))
    return us, opp


def extract_quadrants(steps, our_seat):
    """Track unlocked quadrants per day."""
    opp_seat = 1 - our_seat
    us, opp = [], []
    for day in range(30):
        step_idx = day * 24
        if step_idx >= len(steps):
            break
        obs = steps[step_idx][0]["observation"]
        us.append(obs["farms"][our_seat].get("unlocked_quadrants", []))
        opp.append(obs["farms"][opp_seat].get("unlocked_quadrants", []))
    return us, opp


def extract_animal_deaths(steps, our_seat):
    """Detect animal deaths by comparing tiles across day boundaries."""
    deaths = {"us": [], "opp": []}
    for player_key, seat in [("us", our_seat), ("opp", 1 - our_seat)]:
        for day in range(29):
            s_before = day * 24
            s_after = (day + 1) * 24
            if s_after >= len(steps):
                break
            farm_before = steps[s_before][0]["observation"]["farms"][seat]
            farm_after = steps[s_after][0]["observation"]["farms"][seat]
            for r in range(len(farm_before.get("tiles", []))):
                for c in range(len(farm_before["tiles"][r])):
                    tb = farm_before["tiles"][r][c]
                    ta = farm_after["tiles"][r][c]
                    if (isinstance(tb, dict) and "animal" in tb and
                            (not isinstance(ta, dict) or "animal" not in ta)):
                        deaths[player_key].append({
                            "day": day, "animal": tb["animal"],
                            "pos": [r, c], "unfed": tb.get("consecutive_unfed", 0)
                        })
    return deaths


def extract_sell_analysis(steps, our_seat):
    """Tally sell orders and estimate revenue per player."""
    result = {}
    for player_key, seat in [("us", our_seat), ("opp", 1 - our_seat)]:
        total_orders = 0
        total_qty = 0
        estimated_revenue = 0
        by_item = {}
        for step_idx, step_data in enumerate(steps):
            action = step_data[seat].get("action", {})
            market_orders = action.get("market", [])
            obs = step_data[0]["observation"]  # market prices are shared
            prices = obs.get("market", {}).get("prices", {})

            for order in market_orders:
                if not order or len(order) < 3:
                    continue
                if order[0] == "SELL":
                    item = order[1]
                    qty = int(order[2])
                    price = prices.get(item, 0)
                    rev = price * qty
                    total_orders += 1
                    total_qty += qty
                    estimated_revenue += rev
                    if item not in by_item:
                        by_item[item] = {"qty": 0, "revenue": 0, "orders": 0}
                    by_item[item]["qty"] += qty
                    by_item[item]["revenue"] += rev
                    by_item[item]["orders"] += 1

        result[player_key] = {
            "total_orders": total_orders,
            "total_qty": total_qty,
            "estimated_revenue": round(estimated_revenue),
            "by_item": by_item,
        }
    return result


def extract_shed_analysis(steps, our_seat):
    """Track shed occupancy at day boundaries."""
    result = {}
    for player_key, seat in [("us", our_seat), ("opp", 1 - our_seat)]:
        occupancy = []
        for day in range(30):
            step_idx = day * 24 + 23  # end of day
            if step_idx >= len(steps):
                break
            private = steps[step_idx][seat].get("observation", {}).get("private", {})
            shed = private.get("shed", {})
            total = sum(v for v in shed.values() if isinstance(v, (int, float)))
            occupancy.append(total)

        days_above_95 = [d for d, o in enumerate(occupancy) if o > 95]
        days_at_100 = [d for d, o in enumerate(occupancy) if o >= 100]

        result[player_key] = {
            "occupancy_per_day": occupancy,
            "max_items": max(occupancy) if occupancy else 0,
            "days_above_95": days_above_95,
            "days_at_100": days_at_100,
        }
    return result


def extract_idle_workers(steps, our_seat):
    """Count PASS actions during productive hours (0-21)."""
    result = {}
    for player_key, seat in [("us", our_seat), ("opp", 1 - our_seat)]:
        pass_count = 0
        total_actions = 0
        for step_idx, step_data in enumerate(steps):
            hour = step_idx % 24
            if hour >= 22:
                continue  # end-of-day, less productive
            action = step_data[seat].get("action", {})
            # Farmer
            farmer_act = action.get("farmer", [])
            total_actions += 1
            if farmer_act == ["PASS"] or farmer_act == "PASS":
                pass_count += 1
            # Hands
            for hand_act in action.get("hands", []):
                total_actions += 1
                if hand_act == ["PASS"] or hand_act == "PASS":
                    pass_count += 1

        result[player_key] = {
            "pass_count": pass_count,
            "total_actions": total_actions,
            "pass_rate": round(pass_count / total_actions, 3) if total_actions else 0,
        }
    return result


def extract_shops(steps):
    """Get shop combo from the game."""
    shops_by_day = {}
    # Sample at multiple points per unlock day to catch the shops
    for day in [0, 3, 6, 9, 12, 15, 18, 21, 24, 27]:
        # Try end of day (shops should be unlocked by then)
        step_idx = min(day * 24 + 23, len(steps) - 1)
        if step_idx < 0:
            break
        obs = steps[step_idx][0]["observation"]
        shops = obs.get("town", {}).get("unlocked_shops", [])
        if shops:
            shops_by_day[day] = shops
    return shops_by_day


def find_turning_point(margin_timeline):
    """First day where margin drops below -500 and never recovers to positive."""
    for i, m in enumerate(margin_timeline):
        if m < -500:
            # Check if it ever recovers
            if all(m2 <= 0 for m2 in margin_timeline[i:]):
                return i
    return None


def analyze_game(replay_path):
    """Full analysis of one replay. Returns a dict of all extracted stats."""
    with open(replay_path) as f:
        replay = json.load(f)

    steps = replay.get("steps", [])
    if not steps:
        return None

    our_seat = identify_our_seat(replay)
    opp_seat = 1 - our_seat
    info = replay.get("info", {})
    agents = info.get("Agents", [])
    opp_name = agents[opp_seat].get("Name", "unknown") if len(agents) > opp_seat else "unknown"

    # Final scores
    final = steps[-1]
    our_score = final[our_seat]["reward"]
    opp_score = final[opp_seat]["reward"]
    margin = our_score - opp_score

    # Extract all metrics
    money_us, money_opp = extract_money_curves(steps, our_seat)
    margin_timeline = [u - o for u, o in zip(money_us, money_opp)]
    workers_us, workers_opp = extract_worker_counts(steps, our_seat)
    tiles_us, tiles_opp = extract_tile_usage(steps, our_seat)
    quads_us, quads_opp = extract_quadrants(steps, our_seat)
    animal_deaths = extract_animal_deaths(steps, our_seat)
    sells = extract_sell_analysis(steps, our_seat)
    shed = extract_shed_analysis(steps, our_seat)
    idle = extract_idle_workers(steps, our_seat)
    shops = extract_shops(steps)

    # Get first 2 shops (available at day 0)
    first_shops = shops.get(0, shops.get(3, []))  # fallback to day 3 if day 0 empty
    shop_combo = "+".join(first_shops[:2]) if first_shops else "unknown"

    return {
        "episode_id": replay.get("id"),
        "seed": info.get("seed"),
        "our_seat": our_seat,
        "opponent_name": opp_name,
        "result": "WIN" if margin > 0 else ("LOSS" if margin < 0 else "TIE"),
        "our_final_money": our_score,
        "opp_final_money": opp_score,
        "margin": margin,
        "shop_combo": shop_combo,
        "shops_by_day": {str(k): v for k, v in shops.items()},

        "money_curve_us": money_us,
        "money_curve_opp": money_opp,
        "margin_timeline": margin_timeline,
        "turning_point_day": find_turning_point(margin_timeline),

        "workers_us": workers_us,
        "workers_opp": workers_opp,
        "tiles_us": tiles_us,
        "tiles_opp": tiles_opp,

        "se_used_us": "SE" in (quads_us[-1] if quads_us else []),
        "se_used_opp": "SE" in (quads_opp[-1] if quads_opp else []),

        "animal_deaths": animal_deaths,
        "sells": sells,
        "shed": shed,
        "idle_workers": idle,
    }


# ── Stage 4: Aggregate ───────────────────────────────────

def aggregate_results(analyses):
    """Cross-game pattern detection."""
    wins = [a for a in analyses if a["result"] == "WIN"]
    losses = [a for a in analyses if a["result"] == "LOSS"]
    ties = [a for a in analyses if a["result"] == "TIE"]

    # Loss pattern detection
    patterns = {}

    # Shed overflow
    shed_overflow_losses = [a for a in losses if len(a["shed"]["us"]["days_at_100"]) >= 3]
    if shed_overflow_losses:
        patterns["shed_overflow"] = {
            "count": len(shed_overflow_losses),
            "frequency": f"{len(shed_overflow_losses)}/{len(losses)} losses",
            "detail": f"Shed at 100 (capacity) for 3+ days in {len(shed_overflow_losses)} losses. "
                      f"Avg max shed in losses: {sum(a['shed']['us']['max_items'] for a in losses)/len(losses):.0f}, "
                      f"in wins: {sum(a['shed']['us']['max_items'] for a in wins)/len(wins):.0f}" if wins else "no wins to compare",
        }

    # SE quadrant unused
    se_unused_losses = [a for a in losses if not a["se_used_us"] and a["se_used_opp"]]
    if se_unused_losses:
        patterns["se_unused"] = {
            "count": len(se_unused_losses),
            "frequency": f"{len(se_unused_losses)}/{len(losses)} losses",
            "detail": f"Opponent used SE quadrant but we didn't in {len(se_unused_losses)} losses.",
        }

    # Animal deaths
    death_losses = [a for a in losses if len(a["animal_deaths"]["us"]) > 0]
    if death_losses:
        total_deaths = sum(len(a["animal_deaths"]["us"]) for a in death_losses)
        patterns["animal_deaths"] = {
            "count": len(death_losses),
            "frequency": f"{len(death_losses)}/{len(losses)} losses",
            "detail": f"{total_deaths} total animal deaths across {len(death_losses)} losses.",
        }

    # Worker deficit
    worker_deficit_losses = []
    for a in losses:
        if len(a["workers_us"]) >= 15 and len(a["workers_opp"]) >= 15:
            if a["workers_opp"][14] - a["workers_us"][14] >= 2:
                worker_deficit_losses.append(a)
    if worker_deficit_losses:
        patterns["worker_deficit"] = {
            "count": len(worker_deficit_losses),
            "frequency": f"{len(worker_deficit_losses)}/{len(losses)} losses",
            "detail": f"2+ fewer workers than opponent by day 15 in {len(worker_deficit_losses)} losses.",
        }

    # Sell revenue gap
    sell_gap_losses = []
    for a in losses:
        our_rev = a["sells"]["us"]["estimated_revenue"]
        opp_rev = a["sells"]["opp"]["estimated_revenue"]
        if opp_rev - our_rev > 5000:
            sell_gap_losses.append(a)
    if sell_gap_losses:
        avg_gap = sum(a["sells"]["opp"]["estimated_revenue"] - a["sells"]["us"]["estimated_revenue"]
                      for a in sell_gap_losses) / len(sell_gap_losses)
        patterns["sell_revenue_gap"] = {
            "count": len(sell_gap_losses),
            "frequency": f"{len(sell_gap_losses)}/{len(losses)} losses",
            "detail": f"Opponent outsold us by $5K+ in {len(sell_gap_losses)} losses (avg gap: ${avg_gap:,.0f}).",
        }

    # Idle workers
    idle_losses = [a for a in losses if a["idle_workers"]["us"]["pass_rate"] > a["idle_workers"]["opp"]["pass_rate"] + 0.05]
    if idle_losses:
        patterns["idle_workers"] = {
            "count": len(idle_losses),
            "frequency": f"{len(idle_losses)}/{len(losses)} losses",
            "detail": f"Higher worker idle rate than opponent in {len(idle_losses)} losses.",
        }

    return {
        "total_games": len(analyses),
        "wins": len(wins),
        "losses": len(losses),
        "ties": len(ties),
        "avg_margin_wins": round(sum(a["margin"] for a in wins) / len(wins)) if wins else 0,
        "avg_margin_losses": round(sum(a["margin"] for a in losses) / len(losses)) if losses else 0,
        "loss_patterns": patterns,
        "timestamp": datetime.now().isoformat(),
    }


# ── Stage 5: Output ───────────────────────────────────────

def generate_recommendations(aggregate, analyses):
    """Plain-text ranked recommendations for Claude."""
    losses = [a for a in analyses if a["result"] == "LOSS"]
    wins = [a for a in analyses if a["result"] == "WIN"]

    lines = []
    lines.append(f"REPLAY DIAGNOSIS — {aggregate['total_games']} games analyzed "
                 f"({aggregate['wins']}W, {aggregate['losses']}L, {aggregate['ties']}T)")
    lines.append(f"Avg win margin: ${aggregate['avg_margin_wins']:+,} | "
                 f"Avg loss margin: ${aggregate['avg_margin_losses']:+,}")
    lines.append("")

    if not losses:
        lines.append("NO LOSSES — agent won or tied all analyzed games.")
        lines.append("Focus on maximizing absolute score rather than fixing losses.")
        return "\n".join(lines)

    # Rank patterns by count (frequency)
    patterns = aggregate.get("loss_patterns", {})
    ranked = sorted(patterns.items(), key=lambda x: x[1]["count"], reverse=True)

    for rank, (name, pat) in enumerate(ranked, 1):
        severity = "HIGH" if pat["count"] >= len(losses) * 0.5 else "MEDIUM" if pat["count"] >= 2 else "LOW"
        lines.append(f"PROBLEM #{rank} (severity: {severity}, frequency: {pat['frequency']}):")
        lines.append(f"  {name.replace('_', ' ').title()}")
        lines.append(f"  Evidence: {pat['detail']}")

        # Add specific recommendation
        if name == "shed_overflow":
            lines.append(f"  Fix: Add reactive sell orders when shed > 85 items. Sell cheapest items first.")
        elif name == "se_unused":
            lines.append(f"  Fix: Invest in SE quadrant (tomatoes or sheep) when tape doesn't use it.")
        elif name == "animal_deaths":
            lines.append(f"  Fix: Strengthen animal rescue logic — redirect workers to feed at-risk animals earlier.")
        elif name == "worker_deficit":
            lines.append(f"  Fix: Hire more workers earlier. Check if Fibonacci cost allows additional hires.")
        elif name == "sell_revenue_gap":
            # Find which items differ most
            item_gaps = {}
            for a in losses:
                for item in set(list(a["sells"]["us"]["by_item"].keys()) + list(a["sells"]["opp"]["by_item"].keys())):
                    our_qty = a["sells"]["us"]["by_item"].get(item, {}).get("qty", 0)
                    opp_qty = a["sells"]["opp"]["by_item"].get(item, {}).get("qty", 0)
                    item_gaps[item] = item_gaps.get(item, 0) + (opp_qty - our_qty)
            top_gaps = sorted(item_gaps.items(), key=lambda x: x[1], reverse=True)[:3]
            gap_str = ", ".join(f"{item}: opponent sells {gap:+} more" for item, gap in top_gaps if gap > 0)
            lines.append(f"  Fix: Increase production/selling of: {gap_str}")
        elif name == "idle_workers":
            lines.append(f"  Fix: Assign idle workers to productive tasks (CARE, HARVEST, WATER).")
        lines.append("")

    # Add loss details
    lines.append("=" * 60)
    lines.append("LOSS DETAILS (worst first):")
    lines.append("")
    for a in sorted(losses, key=lambda x: x["margin"]):
        lines.append(f"  Episode {a['episode_id']} vs {a['opponent_name']}:")
        lines.append(f"    Margin: ${a['margin']:+,.0f} | Shops: {a['shop_combo']}")
        if a["turning_point_day"] is not None:
            lines.append(f"    Turning point: day {a['turning_point_day']}")
        if a["shed"]["us"]["days_at_100"]:
            lines.append(f"    Shed at 100: days {a['shed']['us']['days_at_100']}")
        if a["animal_deaths"]["us"]:
            deaths_str = ", ".join(f"{d['animal']} day {d['day']}" for d in a["animal_deaths"]["us"])
            lines.append(f"    Animal deaths: {deaths_str}")
        sell_gap = a["sells"]["opp"]["estimated_revenue"] - a["sells"]["us"]["estimated_revenue"]
        if abs(sell_gap) > 1000:
            lines.append(f"    Sell revenue gap: ${sell_gap:+,.0f} (opponent {'ahead' if sell_gap > 0 else 'behind'})")
        lines.append("")

    return "\n".join(lines)


def write_outputs(analyses, aggregate, recommendations):
    """Write the three output files."""
    DIAGNOSIS_DIR.mkdir(parents=True, exist_ok=True)

    # replay_summary.json — full data
    summary = {
        "aggregate": aggregate,
        "games": analyses,
    }
    with open(DIAGNOSIS_DIR / "replay_summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=str)

    # losses.json — just losses with key fields
    losses = [a for a in analyses if a["result"] == "LOSS"]
    loss_data = []
    for a in sorted(losses, key=lambda x: x["margin"]):
        loss_data.append({
            "episode_id": a["episode_id"],
            "opponent": a["opponent_name"],
            "margin": a["margin"],
            "shop_combo": a["shop_combo"],
            "turning_point_day": a["turning_point_day"],
            "money_curve_us": a["money_curve_us"],
            "money_curve_opp": a["money_curve_opp"],
            "shed_days_at_100": a["shed"]["us"]["days_at_100"],
            "animal_deaths_us": a["animal_deaths"]["us"],
            "sell_revenue_us": a["sells"]["us"]["estimated_revenue"],
            "sell_revenue_opp": a["sells"]["opp"]["estimated_revenue"],
            "workers_us_day15": a["workers_us"][14] if len(a["workers_us"]) > 14 else None,
            "workers_opp_day15": a["workers_opp"][14] if len(a["workers_opp"]) > 14 else None,
            "se_used_us": a["se_used_us"],
            "se_used_opp": a["se_used_opp"],
        })
    with open(DIAGNOSIS_DIR / "losses.json", "w") as f:
        json.dump(loss_data, f, indent=2, default=str)

    # recommendations.txt — plain text for Claude
    with open(DIAGNOSIS_DIR / "recommendations.txt", "w") as f:
        f.write(recommendations)

    log(f"  Output: replay_summary.json ({len(analyses)} games), "
        f"losses.json ({len(losses)} losses), "
        f"recommendations.txt ({len(recommendations.splitlines())} lines)")


# ── Main ──────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Replay Analyzer: diagnose LB losses")
    parser.add_argument("--submission-id", type=int, help="Kaggle submission ID")
    parser.add_argument("--episodes", type=int, nargs="+", help="Specific episode IDs")
    parser.add_argument("--from-state", action="store_true", help="Get submission ID from state.json")
    parser.add_argument("--max-episodes", type=int, default=10)
    args = parser.parse_args()

    log("=== REPLAY ANALYZER START ===")

    # Determine episode IDs
    episode_ids = []
    if args.episodes:
        episode_ids = args.episodes
    else:
        sub_id = args.submission_id
        if args.from_state or not sub_id:
            sub_id = get_latest_submission_id()
        if not sub_id:
            log("No submission ID found")
            return
        log(f"  Submission ID: {sub_id}")
        episode_ids = discover_episodes(sub_id, args.max_episodes)

    if not episode_ids:
        log("No episodes to analyze")
        return

    # Download replays
    log(f"  Downloading {len(episode_ids)} replays...")
    replay_paths = []
    for ep_id in episode_ids:
        path = download_replay(ep_id)
        if path:
            replay_paths.append(path)
    log(f"  Downloaded/cached: {len(replay_paths)}/{len(episode_ids)}")

    prune_cache()

    # Analyze each game
    log(f"  Analyzing {len(replay_paths)} games...")
    analyses = []
    for path in replay_paths:
        try:
            result = analyze_game(path)
            if result:
                tag = result["result"]
                log(f"    {path.stem}: {tag} (${result['margin']:+,.0f}) vs {result['opponent_name']}")
                analyses.append(result)
        except Exception as e:
            log(f"    {path.stem}: ERROR — {e}")

    if not analyses:
        log("No games analyzed successfully")
        return

    # Aggregate
    aggregate = aggregate_results(analyses)
    log(f"  Summary: {aggregate['wins']}W-{aggregate['losses']}L-{aggregate['ties']}T")

    if aggregate["loss_patterns"]:
        log(f"  Loss patterns found: {list(aggregate['loss_patterns'].keys())}")

    # Generate outputs
    recommendations = generate_recommendations(aggregate, analyses)
    write_outputs(analyses, aggregate, recommendations)

    log("=== REPLAY ANALYZER DONE ===")


if __name__ == "__main__":
    main()
