#!/usr/bin/env python3
"""Autoloop v2: DAG Pipeline for pipe-N Agent Generation.

A strict 6-step DAG that discovers what makes superior agents win,
finds statistically significant mechanisms, and validates fixes.

Every pipe-N comes from this pipeline, not from eyeballing.

Usage:
    python autoloop.py                           # full run (steps 1-4, then pauses)
    python autoloop.py --dry-run                 # show what would happen
    python autoloop.py --from-step 4             # resume from step 4
    python autoloop.py --candidate pipe6/main.py # run steps 5-6 with candidate
    python autoloop.py --parallel 10             # game workers
"""
import argparse
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

WORK_DIR = Path("/Users/nathanjacob/Documents/kaggle/kaggriculture")
AUTOLOOP_DIR = WORK_DIR / "autoloop"
AGENTS_DIR = AUTOLOOP_DIR / "agents"
CORPUS_DIR = AUTOLOOP_DIR / "corpus"
REPLAY_DIR = AUTOLOOP_DIR / "replays"
STATE_FILE = CORPUS_DIR / "autoloop_state.json"

# Add autoloop to path for imports
sys.path.insert(0, str(AUTOLOOP_DIR))

OUR_TEAM = "Nathan Jacob"


def log(msg):
    print(f"[autoloop] {msg}", flush=True)


# ═══════════════════════════════════════════════════════════
# EXCEPTIONS
# ═══════════════════════════════════════════════════════════

class AutoloopError(Exception):
    pass

class StepSkipError(AutoloopError):
    """Step should be skipped (not fatal)."""
    pass

class StepFailError(AutoloopError):
    """Step failed (fatal, stop DAG)."""
    pass


# ═══════════════════════════════════════════════════════════
# STATE MANAGEMENT
# ═══════════════════════════════════════════════════════════

DEFAULT_STATE = {
    "version": 2,
    "last_completed_step": 0,
    "last_run_start": None,
    "last_run_end": None,
    "step_timings": {},
    "last_error": None,
    # Step 1
    "bases": [],
    "anti_targets": [],
    "tournament_source": None,
    # Step 2
    "our_cluster_id": None,
    "cluster_refresh_time": None,
    "team_to_cluster": {},
    # Step 3
    "superior_twins": [],
    "twin_graph_time": None,
    # Step 4
    "mechanism_analysis_path": None,
    "top_mechanisms_intra": [],
    "top_mechanisms_inter": [],
    # Step 5
    "prescreen_passed": None,
    "regressions": [],
    # Step 6
    "tournament_results_path": None,
    "tournament_report_path": None,
}


def load_state():
    if STATE_FILE.exists():
        try:
            return json.load(open(STATE_FILE))
        except Exception:
            pass
    return dict(DEFAULT_STATE)


def save_state(state):
    CORPUS_DIR.mkdir(exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2, default=str)


# ═══════════════════════════════════════════════════════════
# STEP 1: TOURNAMENT INPUT
# ═══════════════════════════════════════════════════════════

def step_tournament_input(state, args):
    """Read previous tournament results, select top 3 bases + bottom 3 anti-targets."""
    if args.dry_run:
        log("  [DRY] Would read most recent tournament_results_*.json")
        log("  [DRY] Would select top 3 as bases, bottom 3 as anti-targets")
        return state

    # Find most recent tournament results
    result_files = sorted(CORPUS_DIR.glob("tournament_results_*.json"), reverse=True)
    if not result_files:
        raise StepFailError("No tournament results found in corpus/. Run tournament_report.py first.")

    results_path = result_files[0]
    log(f"  Reading {results_path.name}")

    data = json.load(open(results_path))
    matchups = data.get("matchups", {})
    roster = data.get("roster", [])

    if not matchups or not roster:
        raise StepFailError(f"Tournament results at {results_path} has no matchups or roster")

    # Compute Elo from round-robin
    elos = {a: 1500.0 for a in roster}
    K = 32
    for _ in range(10):  # iterate for convergence
        for key, m in matchups.items():
            a, b = m["agent_a_name"], m["agent_b_name"]
            w, l, t = m["wins"], m["losses"], m["ties"]
            total = w + l + t
            if total == 0:
                continue
            actual = (w + 0.5 * t) / total
            expected = 1 / (1 + 10 ** ((elos[b] - elos[a]) / 400))
            elos[a] += K * (actual - expected)
            elos[b] += K * ((1 - actual) - (1 - expected))

    ranked = sorted(elos.items(), key=lambda x: -x[1])

    # Top 3 = bases, bottom 3 = anti-targets
    bases = [name for name, _ in ranked[:3]]
    anti_targets = [name for name, _ in ranked[-3:]]

    # Verify agents exist
    for agent in bases + anti_targets:
        agent_path = AGENTS_DIR / agent / "main.py"
        if not agent_path.exists():
            log(f"  WARNING: agent {agent} not found at {agent_path}")

    state["bases"] = bases
    state["anti_targets"] = anti_targets
    state["tournament_source"] = str(results_path)

    log(f"  Bases: {[b[:30] for b in bases]}")
    log(f"  Anti-targets: {[a[:30] for a in anti_targets]}")

    return state


# ═══════════════════════════════════════════════════════════
# STEP 2: CLUSTER ENGINE
# ═══════════════════════════════════════════════════════════

def step_cluster_engine(state, args):
    """Refresh clusters with freshness filter."""
    if args.dry_run:
        cluster_file = CORPUS_DIR / "clusters.json"
        if cluster_file.exists():
            data = json.load(open(cluster_file))
            log(f"  [DRY] Current clusters: {data.get('meta', {}).get('clusters_found', '?')}")
            log(f"  [DRY] Last built: {data.get('meta', {}).get('timestamp', '?')}")
        log(f"  [DRY] Would refresh with {args.freshness_hours}h freshness filter")
        return state

    cluster_file = CORPUS_DIR / "clusters.json"

    # Skip rebuild if clusters.json is fresh enough
    if cluster_file.exists():
        age_hours = (time.time() - cluster_file.stat().st_mtime) / 3600
        if age_hours < args.freshness_hours:
            log(f"  clusters.json is {age_hours:.1f}h old (< {args.freshness_hours}h), reusing")
        else:
            log(f"  clusters.json is {age_hours:.1f}h old, rebuilding...")
            from cluster_engine import build_clusters
            build_clusters(
                top_n=args.top_n_clusters,
                our_team=args.our_team,
                freshness_hours=args.freshness_hours,
            )
    else:
        log(f"  No clusters.json found, building from scratch...")
        from cluster_engine import build_clusters
        build_clusters(
            top_n=args.top_n_clusters,
            our_team=args.our_team,
            freshness_hours=args.freshness_hours,
        )

    # Extract our cluster ID
    if cluster_file.exists():
        clusters_data = json.load(open(cluster_file))

        # Check if team_to_cluster was pre-built by cluster_engine
        if "team_to_cluster" in clusters_data:
            team_to_cluster = clusters_data["team_to_cluster"]
        else:
            # Build it from clusters dict
            team_to_cluster = {}
            clusters = clusters_data.get("clusters", {})
            if isinstance(clusters, dict):
                for cid, cdata in clusters.items():
                    for member in cdata.get("members", []):
                        team_to_cluster[member] = cid
            elif isinstance(clusters, list):
                for cdata in clusters:
                    cid = cdata.get("id", cdata.get("cluster_id", ""))
                    for member in cdata.get("members", []):
                        team_to_cluster[member] = cid

        # Find our cluster
        our_cluster = team_to_cluster.get(args.our_team, "unknown")

        state["our_cluster_id"] = our_cluster
        state["team_to_cluster"] = team_to_cluster
        state["cluster_refresh_time"] = datetime.now().isoformat()

        # Show top clusters
        clusters = clusters_data.get("clusters", {})
        if isinstance(clusters, dict):
            sorted_clusters = sorted(clusters.items(),
                                     key=lambda x: -x[1].get("avg_elo", 0))
            log(f"  Our cluster: {our_cluster} (size={clusters.get(our_cluster, {}).get('size', '?')})")
            log(f"  Total clusters: {len(clusters)}")
            log(f"  Total teams mapped: {len(team_to_cluster)}")
            for cid, cdata in sorted_clusters[:8]:
                us = " <-- US" if cdata.get("contains_us") else ""
                log(f"    {cid}: size={cdata['size']}, "
                    f"avg_elo={cdata.get('avg_elo', 0):.0f}, "
                    f"rep={cdata.get('representative', '?')[:25]}{us}")
    else:
        raise StepFailError("clusters.json not generated")

    return state


# ═══════════════════════════════════════════════════════════
# STEP 3: TWIN GRAPH (×3 bases, parallel)
# ═══════════════════════════════════════════════════════════

def _find_twins_from_fingerprints(base_fp, base_elo, fingerprints, team_elos,
                                   cluster_map, threshold=0.90):
    """Find superior twins using pre-computed fingerprints. No API calls."""
    twins = []
    for team_name, fp in fingerprints.items():
        team_elo = team_elos.get(team_name, 0)
        if team_elo <= base_elo:
            continue
        if not fp or not base_fp:
            continue

        # Compare fingerprints
        window = min(len(base_fp), len(fp), 144)
        if window == 0:
            continue
        matches = sum(1 for a, b in zip(base_fp[:window], fp[:window]) if a == b)
        similarity = matches / window

        if similarity >= threshold:
            twins.append({
                "name": team_name,
                "elo": team_elo,
                "similarity": round(similarity, 3),
                "cluster_id": cluster_map.get(team_name, ""),
                "replay_episode_ids": [],
                "loss_episode_ids": [],
            })

    twins.sort(key=lambda x: -x["elo"])
    return twins


def step_twin_graph(state, args):
    """For each base, find superior twins using cached fingerprints."""
    if args.dry_run:
        log(f"  [DRY] Would find twins for {len(state['bases'])} bases")
        for b in state["bases"]:
            log(f"    [DRY] Base: {b[:40]}")
        return state

    bases = state["bases"]
    if not bases:
        raise StepFailError("No bases selected. Run step 1 first.")

    # Load pre-computed fingerprints (fast — no API calls)
    fp_file = CORPUS_DIR / "fingerprints.json"
    if not fp_file.exists():
        raise StepFailError("fingerprints.json not found. Run cluster_engine first.")

    fingerprints = json.load(open(fp_file))
    log(f"  Loaded {len(fingerprints)} pre-computed fingerprints")

    # Load leaderboard for Elo data
    import glob
    csvs = sorted(glob.glob("/tmp/kaggriculture-publicleaderboard-*.csv"), reverse=True)
    if not csvs:
        log("  Downloading fresh leaderboard...")
        import subprocess
        subprocess.run([
            "/Users/nathanjacob/opt/miniconda3/bin/kaggle",
            "competitions", "leaderboard", "kaggriculture", "--download",
            "-p", "/tmp"
        ], capture_output=True)
        csvs = sorted(glob.glob("/tmp/kaggriculture-publicleaderboard-*.csv"), reverse=True)

    team_elos = {}
    if csvs:
        import csv
        with open(csvs[0]) as f:
            for row in csv.DictReader(f):
                team_elos[row.get("TeamName", "")] = float(row.get("Score", 0))
        log(f"  Loaded {len(team_elos)} team Elo scores")

    cluster_map = state.get("team_to_cluster", {})

    # For each base, get its fingerprint and find superior twins
    all_twins = {}

    for base in bases:
        # Get base fingerprint — try matching to a team in fingerprints
        base_fp = None
        base_elo = 2700  # default

        # For our agent, use our team name
        if "pipe" in base or base.startswith("_"):
            base_fp = fingerprints.get(args.our_team)
            base_elo = team_elos.get(args.our_team, 2700)
            log(f"  Base: {base[:35]} → fingerprint from '{args.our_team}' (Elo {base_elo:.0f})")
        else:
            # For public agents, try to find the notebook author's LB team
            # Extract username from agent dir name (e.g., "ahmedberatozer__..." → "Ahmed Berat Özer")
            # Search fingerprints for best match
            for team_name in fingerprints:
                # Check if agent dir name contains the team name or vice versa
                agent_lower = base.lower().replace("_", " ").replace("-", " ")
                team_lower = team_name.lower().replace("_", " ").replace("-", " ")
                # Simple heuristic: check if first word of team matches agent username
                agent_user = base.split("__")[0].replace("_", "") if "__" in base else base
                if agent_user.lower() in team_lower.replace(" ", ""):
                    base_fp = fingerprints[team_name]
                    base_elo = team_elos.get(team_name, 2700)
                    log(f"  Base: {base[:35]} → matched to '{team_name}' (Elo {base_elo:.0f})")
                    break

            if not base_fp:
                log(f"  Base: {base[:35]} → NO FINGERPRINT MATCH, skipping")
                continue

        twins = _find_twins_from_fingerprints(
            base_fp, base_elo, fingerprints, team_elos, cluster_map)

        log(f"    Found {len(twins)} superior twins")
        for twin in twins:
            name = twin["name"]
            if name not in all_twins or twin["elo"] > all_twins[name].get("elo", 0):
                all_twins[name] = twin

    # Deduplicate and save
    superior_twins = list(all_twins.values())
    superior_twins.sort(key=lambda x: -x.get("elo", 0))

    state["superior_twins"] = superior_twins
    state["twin_graph_time"] = datetime.now().isoformat()

    # Save
    twins_file = CORPUS_DIR / "twin_targets.json"
    with open(twins_file, "w") as f:
        json.dump(superior_twins, f, indent=2, default=str)

    log(f"  Total unique superior twins: {len(superior_twins)}")
    for t in superior_twins[:10]:
        log(f"    {t['name'][:35]:<35} Elo={t.get('elo', 0):>6.0f} "
            f"sim={t.get('similarity', 0):.1%} cluster={t.get('cluster_id', '?')}")

    return state


# ═══════════════════════════════════════════════════════════
# STEP 4: MECHANISM TRACER
# ═══════════════════════════════════════════════════════════

def step_mechanism_tracer(state, args):
    """Run tape diff analysis: compare our agent's tape against target agents.

    Primary mode: tape-to-tape comparison (import agents, diff _ROUTES directly).
    Fallback: replay-based comparison for twins without local code.
    Replaces the old mechanism_tracer (Fisher's test on abstract mechanisms).
    """
    if args.dry_run:
        log(f"  [DRY] Would run tape_diff_tracer against target agent(s)")
        return state

    from tape_diff_tracer import extract_routes, diff_tapes, tape_report

    our_agent = args.candidate or str(AGENTS_DIR / "_pipe7_candidate" / "main.py")
    our_name = Path(our_agent).parent.name

    # Primary: tape-to-tape against v45 + other high-value agents
    targets = [
        "ahmedberatozer__kaggriculture-v45-first-turn-wheat-round-trip",
        "ahmedberatozer__kaggriculture-v45-smarter-same-turn-sales",
        "alperen5252525__turn-one-market-advantage-kaggriculture",
        "nusrati__2650-score",
        "degnonguidi__kaggriculture-cloning-agent",
        "yhay81__shop-router-0913",
    ]

    log(f"  Loading our agent: {our_name}")
    our_routes, our_shops = extract_routes(our_agent)

    all_diffs = []
    for target in targets:
        target_path = AGENTS_DIR / target / "main.py"
        if not target_path.exists():
            log(f"  SKIP: {target} (not found)")
            continue
        try:
            tgt_routes, tgt_shops = extract_routes(str(target_path))
        except (ValueError, Exception) as e:
            log(f"  SKIP: {target} ({e})")
            continue

        diffs = diff_tapes(our_routes, tgt_routes)
        log(f"  vs {target[:50]}: {len(diffs)} diffs")
        all_diffs.extend(diffs)

        if diffs:
            tape_report(diffs, our_name, target, our_routes, tgt_routes)

    state["tape_diff_count"] = len(all_diffs)
    state["tape_diff_path"] = str(CORPUS_DIR / "tape_diff_proposals.json")

    if not all_diffs:
        log(f"  No tape diffs found — agent matches all targets.")

    return state


# ═══════════════════════════════════════════════════════════
# STEP 5: TARGETED REPLAY (pre-screen)
# ═══════════════════════════════════════════════════════════

def step_targeted_replay(state, args):
    """Fast pre-screen with anti-target regression checks."""
    if not args.candidate:
        log("  SKIP: No --candidate specified. Steps 1-4 complete.")
        log("  Review mechanism_analysis.json, implement fix, then run:")
        log(f"    python autoloop.py --from-step 5 --candidate path/to/pipe6/main.py")
        raise StepSkipError("No candidate specified")

    if args.dry_run:
        log(f"  [DRY] Would pre-screen {args.candidate}")
        log(f"  [DRY] Anti-targets: {state.get('anti_targets', [])}")
        return state

    from targeted_replay import run_targeted_replay
    from colosseum import run_h2h

    candidate_path = Path(args.candidate)
    baseline_path = AGENTS_DIR / "_pipe5_candidate" / "main.py"  # current best

    if args.baseline:
        baseline_path = Path(args.baseline)

    if not candidate_path.exists():
        raise StepFailError(f"Candidate not found: {candidate_path}")
    if not baseline_path.exists():
        raise StepFailError(f"Baseline not found: {baseline_path}")

    # Build anti-target list
    anti_targets = []
    for at_name in state.get("anti_targets", []):
        at_path = AGENTS_DIR / at_name / "main.py"
        if at_path.exists():
            anti_targets.append((at_name, str(at_path)))

    log(f"  Candidate: {candidate_path}")
    log(f"  Baseline: {baseline_path}")
    log(f"  Anti-targets: {len(anti_targets)}")

    # Run pre-screen
    result = run_targeted_replay(
        candidate_path=str(candidate_path),
        baseline_path=str(baseline_path),
        games_per_opponent=10,
        parallel=args.parallel,
        anti_targets=anti_targets,
        anti_target_threshold=0.80,
    )

    state["prescreen_passed"] = result.get("passed", False)
    state["regressions"] = result.get("regressions", [])

    if state["regressions"]:
        log(f"  WARNING: {len(state['regressions'])} regressions detected:")
        for reg in state["regressions"]:
            log(f"    {reg['anti_target']}: {reg['detail']} (rate={reg['win_rate']:.0%})")

    if state["prescreen_passed"]:
        log("  PRE-SCREEN PASSED — proceeding to full tournament")
    else:
        log("  PRE-SCREEN FAILED — candidate does not improve on baseline")
        log("  Continuing to tournament anyway for data collection")

    return state


# ═══════════════════════════════════════════════════════════
# STEP 6: COLOSSEUM + TOURNAMENT
# ═══════════════════════════════════════════════════════════

def step_colosseum_tournament(state, args):
    """Run full round-robin tournament. Generate .docx report."""
    if args.dry_run:
        log(f"  [DRY] Would run 10x10 tournament with {args.games_per_matchup} games/matchup")
        log(f"  [DRY] Parallel: {args.parallel}")
        return state

    from tournament_report import run_full_tournament

    # Build roster: 6-1-3 structure
    # 5 worthy public notebooks (source code available from LB)
    public_notebooks = [
        "ahmedberatozer__kaggriculture-v45-first-turn-wheat-round-trip",
        "ahmedberatozer__kaggriculture-v44-winning-the-same-turn-sale-race",
        "reyhanksatria__kaggriculture-dynamic-route-agent",
        "guruprasaathas111__kaggriculture-master-engine-v3",
        "degnonguidi__kaggriculture-cloning-agent",
    ]

    # Top 4 from last colosseum (excluding v44, v45 already above)
    prev_results = sorted(CORPUS_DIR.glob("tournament_results_*.json"), reverse=True)
    colosseum_top = []
    if prev_results:
        import csv as _csv
        prev = json.load(open(prev_results[0]))
        prev_roster = prev.get("roster", [])
        prev_matchups = prev.get("matchups", {})
        elos = {a: 1500.0 for a in prev_roster}
        for _ in range(10):
            for key, m in prev_matchups.items():
                a, b = m["agent_a_name"], m["agent_b_name"]
                w, l, t = m["wins"], m["losses"], m["ties"]
                total = w + l + t
                if total == 0:
                    continue
                actual = (w + 0.5 * t) / total
                expected = 1 / (1 + 10 ** ((elos[b] - elos[a]) / 400))
                elos[a] += 32 * (actual - expected)
                elos[b] += 32 * ((1 - actual) - (1 - expected))
        ranked = [name for name, _ in sorted(elos.items(), key=lambda x: -x[1])]
        already = set(public_notebooks)
        for name in ranked:
            if name not in already and len(colosseum_top) < 4:
                colosseum_top.append(name)

    # 1 local hero (candidate)
    candidate_name = Path(args.candidate).parent.name if args.candidate else None

    # Assemble roster
    roster = list(public_notebooks)
    for agent in colosseum_top:
        if agent not in roster and len(roster) < 10:
            roster.append(agent)
    if candidate_name and candidate_name not in roster and len(roster) < 10:
        roster.append(candidate_name)

    # Verify all agents exist, remove missing
    valid_roster = []
    for agent in roster:
        if (AGENTS_DIR / agent / "main.py").exists():
            valid_roster.append(agent)
        else:
            log(f"  WARNING: Skipping {agent[:30]} (not found)")
    roster = valid_roster[:10]

    log(f"  Tournament roster ({len(roster)} agents):")
    for i, a in enumerate(roster):
        log(f"    {i+1}. {a[:50]}")

    result = run_full_tournament(
        roster=roster,
        games_per_matchup=args.games_per_matchup,
        parallel=args.parallel,
    )

    state["tournament_results_path"] = result.get("results_path")
    state["tournament_report_path"] = result.get("report_path")

    log(f"  Results: {result.get('results_path')}")
    log(f"  Report: {result.get('report_path')}")

    return state


# ═══════════════════════════════════════════════════════════
# DAG ORCHESTRATOR
# ═══════════════════════════════════════════════════════════

STEPS = {
    1: ("TOURNAMENT_INPUT", step_tournament_input),
    2: ("CLUSTER_ENGINE", step_cluster_engine),
    3: ("TWIN_GRAPH", step_twin_graph),
    4: ("TAPE_DIFF_TRACER", step_mechanism_tracer),
    5: ("TARGETED_REPLAY", step_targeted_replay),
    6: ("COLOSSEUM_TOURNAMENT", step_colosseum_tournament),
}


def run_dag(args):
    """Execute the DAG from args.from_step onward."""
    state = load_state()
    state["last_run_start"] = datetime.now().isoformat()

    log(f"Autoloop v2 — starting from step {args.from_step}")
    log(f"  Our team: {args.our_team}")
    log(f"  Freshness: {args.freshness_hours}h")
    log(f"  Parallel: {args.parallel}")
    if args.dry_run:
        log("  MODE: DRY RUN (no API calls, no games)")

    success = True
    for step_num in range(args.from_step, 7):
        step_name, step_fn = STEPS[step_num]
        log(f"\n{'=' * 60}")
        log(f"Step {step_num}/6: {step_name}")
        log(f"{'=' * 60}")

        t0 = time.time()
        try:
            state = step_fn(state, args)
            elapsed = round(time.time() - t0, 1)
            state["last_completed_step"] = step_num
            state["step_timings"][step_name] = elapsed
            log(f"  Done ({elapsed}s)")
            save_state(state)
        except StepSkipError as e:
            log(f"  SKIP: {e}")
            save_state(state)
            break
        except StepFailError as e:
            log(f"  FAIL: {e}")
            state["last_error"] = {
                "step": step_num,
                "step_name": step_name,
                "error": str(e),
                "timestamp": datetime.now().isoformat(),
            }
            save_state(state)
            success = False
            break
        except Exception as e:
            log(f"  ERROR: {e}")
            import traceback
            traceback.print_exc()
            state["last_error"] = {
                "step": step_num,
                "step_name": step_name,
                "error": str(e),
                "timestamp": datetime.now().isoformat(),
            }
            save_state(state)
            success = False
            break

    state["last_run_end"] = datetime.now().isoformat()
    save_state(state)

    # Summary
    log(f"\n{'=' * 60}")
    log(f"Autoloop v2 {'COMPLETE' if success else 'STOPPED'}")
    log(f"  Last completed step: {state['last_completed_step']}")
    log(f"  Timings: {state['step_timings']}")
    if state.get("last_error"):
        log(f"  Last error: {state['last_error']}")
    log(f"{'=' * 60}")

    return success


# ═══════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Autoloop v2: DAG Pipeline for pipe-N Agent Generation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Steps:
  1. TOURNAMENT_INPUT   — Read previous tournament, select bases + anti-targets
  2. CLUSTER_ENGINE     — Refresh LB clusters (Union-Find, <36h freshness)
  3. TWIN_GRAPH         — Find superior twins for each base (bot-level, parallel)
  4. MECHANISM_TRACER   — Fisher's test, intra/inter cluster, twin loss analysis
  5. TARGETED_REPLAY    — Pre-screen candidate fix (requires --candidate)
  6. COLOSSEUM_TOURNAMENT — Full 10x10 round-robin + .docx report

Without --candidate, the DAG runs steps 1-4 (analysis) then pauses.
With --candidate, it runs all 6 steps.
        """)

    parser.add_argument("--dry-run", action="store_true",
                        help="Show what would happen without running")
    parser.add_argument("--from-step", type=int, default=1, choices=[1, 2, 3, 4, 5, 6],
                        help="Resume from step N (default: 1)")
    parser.add_argument("--our-team", type=str, default=OUR_TEAM,
                        help=f"Our team name (default: {OUR_TEAM})")
    parser.add_argument("--freshness-hours", type=float, default=36.0,
                        help="Max age of cached replays in hours (default: 36)")
    parser.add_argument("--parallel", type=int, default=10,
                        help="Parallel workers for games (default: 10)")
    parser.add_argument("--games-per-matchup", type=int, default=20,
                        help="Games per matchup in tournament (default: 20)")
    parser.add_argument("--top-n-clusters", type=int, default=200,
                        help="Top N teams for cluster engine (default: 200)")
    parser.add_argument("--candidate", type=str, default=None,
                        help="Path to candidate agent for steps 5-6")
    parser.add_argument("--baseline", type=str, default=None,
                        help="Path to baseline agent (default: _pipe5_candidate)")

    args = parser.parse_args()
    run_dag(args)


if __name__ == "__main__":
    main()
