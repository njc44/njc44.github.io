# Kaggriculture Competition — Full Strategy Context

> **Purpose**: This document gives an expert everything they need to advise on our next move.
> It covers: game rules, the current meta, our agent code, leaderboard data, loss analysis, and all resources we have to improve.

---

## 1. Competition Overview

- **Competition**: Kaggriculture (Featured, $50K prize)
- **URL**: https://www.kaggle.com/competitions/kaggriculture
- **Teams**: ~8,300
- **Deadline**: Sep 30, 2026
- **Scoring**: Elo-style matchmaking, final money = reward
- **Submission limit**: 5/day total, 2 scored. Resets midnight UTC.
- **Our goal**: Bronze medal (top 800 = top ~9.6%)
- **Bronze Elo estimate**: ~2400+
- **Top LB**: ~3073 (SpaTaro)
- **Our best**: Shop Router at 2481 (Elo converged, 172 games), Hybrid V1 at 2240 (still converging, 48 games)

---

## 2. Game Rules (Complete)

### 2.1 Overview
Two players each tend a **10×10 farm** divided into four 5×5 quadrants. The game runs for **720 turns** (30 days × 24 turns/day). Players grow crops, raise animals, hire farm hands, and trade with a **dynamic shared market**. The player with the most **money** at the end wins.

### 2.2 Farm Layout
- 10×10 grid, four 5×5 quadrants: NW (unlocked at start), NE, SW, SE.
- The **shed** is at the center (tiles [4,4], [5,4], [4,5], [5,5]). Workers must be adjacent to the shed to DROP/PICKUP/PLACE items.
- Additional quadrants cost: NE=1000, SW=2000, SE=4000.
- Starting money: 3000.
- Each player has 1 farmer at start. Additional **farm hands** are hired via market orders.

### 2.3 Timing
- **720 total turns** (steps 0–719), 24 turns per day, 30 days.
- Agent timeout: **1 second per step**, 60 seconds overage bank.
- End-of-day: last turn of each day (step % 24 == 23) triggers automatic inventory drop, plant/animal refresh, weed spawning, hand dismissal.
- **All hands are dismissed at end of each day.** Workers must be re-hired each morning.

### 2.4 Worker Actions (per turn)
Each worker (farmer + hired hands) executes exactly one action per turn:
| Action | Effect |
|--------|--------|
| NORTH/SOUTH/EAST/WEST | Move 1 tile (can move onto LOCKED tiles) |
| PASS | Do nothing |
| PLANT \<crop\> | Plant a crop on current empty tile (consumes 1 seed) |
| WATER | Water current plant tile (once/day, prevents death, +yield for non-ongoing crops) |
| HARVEST | Collect yield_units from mature plant or animal into inventory |
| FERTILIZE | Apply fertilizer from inventory to plant (doubles yield for 3 days) |
| DIG | Remove weed/plant/empty structure (not animals) |
| BUILD_COOP | Build coop on empty tile (for geese) |
| BUILD_PASTURE | Build pasture on empty tile (for cows/sheep) |
| FEED | Feed 1 wheat to animal (prevents escape, enables production) |
| CARE | Care for animal (earns bonus yield on next production) |
| COLLECT_FERTILIZER | Pick up fertilizer from fed animal |
| DROP | At shed: dump all inventory into shed (up to capacity) |
| PICKUP \<item\> [n] | At shed: take items from shed |
| PLACE \<item\> [n] | At shed: put specific items into shed. On structure: place animal. |

### 2.5 Crops

| Crop | Seed Cost | First Yield Day | Max Yield Day | Max Yield | Ongoing | Notes |
|------|-----------|----------------|---------------|-----------|---------|-------|
| WHEAT | 10 | 2 | 4 | 6 | No | Cheap, fast. Also used to FEED animals. |
| CARROT | 20 | 2 | 3 | 4 | No | Fast, moderate value. |
| TOMATO | 50 | 8 | 8 | 4 | Yes | Ongoing: produces every 1 day after first yield. |
| STRAWBERRY | 100 | 10 | 10 | 4 | Yes | Ongoing: produces every 2 days. High base price. |
| MELON | 80 | 10 | 12 | 6 | No | High base price, one-time harvest. |

**Crop lifecycle:**
- Plant → Water daily (2 consecutive unwatered days = weed).
- Non-ongoing: yield_units accumulate from watering during [max_yield_day/2 .. max_yield_day]. After max_yield_day, yield decays every 2 steps.
- Ongoing: produce 1 yield_unit on each interval day after first_yield_day (max 4 total production events).
- Fertilizer: doubles yield accumulation for 3 days (only on watered days).

### 2.6 Animals

| Animal | Cost | Structure | Product | First Yield Day | Interval | Max Held |
|--------|------|-----------|---------|----------------|----------|----------|
| GOOSE | 300 | COOP | EGG | 4 | 1 day | 4 |
| COW | 400 | PASTURE | MILK | 8 | 2 days | 6 |
| SHEEP | 500 | PASTURE | WOOL | 6 | 3 days | 6 |

**Animal lifecycle:**
- Build structure (COOP/PASTURE) → Buy animal (market) → PLACE on structure → FEED daily (1 wheat each) → COLLECT_FERTILIZER → CARE for bonus yield.
- 2 consecutive unfed days = animal escapes (structure remains).
- CARE on a fed day adds +1 pending_care_bonus, consumed on next production day.
- Fertilizer is available every day if the animal was fed.

### 2.7 Market System

The market is **shared** between both players. Key mechanics:

**Pricing model:**
```
price(inventory) = base + sign × amp × f(|inventory - I0|)
```
- `I0 = 10000` (equilibrium point for all products)
- Below I0 (scarcity): price rises. Above I0 (glut): price drops.
- `T` = reference production capacity. `amp = target × base / f(T)`.
- Floor: every price is at least 1.

**Price parameters:**
| Product | Base | T | Below (func/target) | Above (func/target) |
|---------|------|---|---------------------|---------------------|
| WHEAT | 25 | 400 | sqrt / 0.80 | log / 0.20 |
| CARROT | 35 | 450 | hinge / 1.00 | sqrt / 0.70 |
| TOMATO | 60 | 200 | hinge / 0.40 | sqrt / 0.60 |
| STRAWBERRY | 120 | 100 | sqrt / 0.70 | linear / 1.60 |
| MELON | 250 | 300 | log / 0.20 | sq / 3.60 |
| EGG | 50 | 332 | hinge / 0.40 | log / 0.20 |
| MILK | 160 | 122 | sqrt / 0.60 | linear / 1.60 |
| WOOL | 200 | 105 | log / 0.20 | sq / 3.20 |
| FERTILIZER | 100 | 200 | linear / 0.40 | linear / 0.40 |

**Shape functions:** linear(x)=x, sq(x)=x², sqrt(x)=√x, log(x)=ln(1+x), hinge(x/T) = x/T + 8×max(0, x/T-1)²

**Critical insight:** WOOL and MELON use `sq` above-function with high targets (3.2, 3.6). This means **overselling crashes their price exponentially**. STRAWBERRY and MILK use `linear` above with 1.6 target — prices drop steadily but not catastrophically.

**Market orders** (max 10 per turn per player):
- `SELL <item> <n>`: Sell n units at current price (per-unit lockstep — price changes after each unit).
- `BUY_SEED <crop> <n>`: Buy seeds at fixed cost.
- `BUY_PRODUCT <item> <n>`: Buy wheat/fertilizer from market.
- `BUY_ANIMAL <animal> <n>`: Buy animal at fixed cost.
- `HIRE`: Hire a farm hand (cost = farmHandCostMult × fib(n), where n is hires today).
- `BUY_LAND`: Buy next quadrant.

**Sell mechanics (important):** Both players' orders at the same market-slot index are processed in per-unit lockstep. Player 0 and Player 1 both see the same pre-commit price for each unit. Sales at $1 do NOT increase market inventory (prevents death-spiral).

### 2.8 Town & Shops

- Shops unlock every 3 days (days 3, 6, 9, 12, 15, 18, 21, 24, 27 → max 8 instances).
- Shops are drawn **with replacement** from the pool (same shop can appear multiple times).
- Each shop instance consumes its products every 4 turns (single-product shops consume 2x).
- Town center consumes 1 of every non-fertilizer product every 24 turns.
- **Shop consumption reduces market inventory → raises prices.** This is the core economic driver.

**Shop products:**
| Shop | Products |
|------|----------|
| BAKERY | EGG, WHEAT |
| PIZZA_SHOP | MILK, TOMATO, WHEAT |
| BRUNCH_SPOT | EGG, WHEAT, STRAWBERRY |
| YARN_STORE | WOOL (single-product → 2x consumption) |
| ICE_CREAM_SHOP | STRAWBERRY, MILK, WHEAT |
| PET_CAFE | CARROT (single-product → 2x consumption) |
| SMOOTHIE_SHOP | STRAWBERRY, MILK |
| FARMERS_MARKET | WHEAT, CARROT, TOMATO, STRAWBERRY |

**Why YARN_STORE is king:** It's the only shop that consumes WOOL, a product with a `sq` above-function (price crashes exponentially on oversupply). When Yarn Store unlocks, WOOL prices spike dramatically because the shop pulls 2 units every 4 turns. The same logic applies to PET_CAFE for CARROT.

### 2.9 End-of-Day Processing (step % 24 == 23)
1. Refresh plants: watered→reset, unwatered→increment counter (2 consecutive = weed), ongoing crops produce.
2. Refresh animals: fed→reset, unfed→increment (2 consecutive = escape), produce on schedule, care bonus.
3. Spawn weeds: 0.5% chance per empty unlocked tile.
4. **Drop ALL inventories into shed** (overflow discarded!). This is critical — shed cap is 100.
5. Farmer teleports home, all hands dismissed (empty hands array).
6. Reset hires_today to 0.
7. Possibly unlock a new shop.

### 2.10 Hiring Economics
Hands are hired via HIRE market order. Cost is fibonacci-based:
- 1st hire/day: 1, 2nd: 1, 3rd: 2, 4th: 3, 5th: 5, 6th: 8, 7th: 13, 8th: 21...
- **All hands are dismissed at end of each day** and must be re-hired.
- Top agents hire 11-13 hands per day (total 12-14 workers including farmer).
- Total daily hire cost for 11 hands: 1+1+2+3+5+8+13+21+34+55+89 = 232.

---

## 3. The Meta (Current State of Competition)

### 3.1 Dominant Strategy: Pre-Recorded Tape Replay
The top of the leaderboard is dominated by agents that use **pre-recorded action tapes** — complete 720-turn action sequences optimized offline, then replayed during games.

**Why tapes work:** The game is largely deterministic. Each player's farm is independent (no opponent interaction except shared market prices). A near-optimal sequence of worker actions can be computed offline and replayed. The only variance comes from:
1. Which shops unlock (random, determines prices)
2. Weed spawns (0.5%, minor)
3. Market price changes from opponent selling

**How tapes are generated:**
1. Record an optimal game locally against a known opponent
2. Extract the action sequence for all 720 turns
3. Create multiple tapes for different shop combinations
4. At runtime, observe which shops unlock and select the matching tape

**Why RL isn't working:** Many players report that reinforcement learning approaches underperform tape-replay. The action space is too large (20+ worker types × 100 tiles × 9 products) and the game is too long (720 turns) for RL to find good policies. Pre-recorded tapes from expert play or brute-force search are much stronger.

### 3.2 The Competitive Edge: Reactive Layers
Since most agents use the same (or similar) tapes, the differentiation comes from **reactive layers** — small modifications to the tape based on observed game state:

| Layer | What it does | Impact |
|-------|-------------|--------|
| Shop routing | Select different tapes based on which shops unlock | Huge — wrong tape loses 50K+ |
| Weed repair | DIG when a worker is blocked by a weed | Small but prevents cascading failures |
| Advance sales | Sell items 1 turn early when stock is available | Moderate — captures higher prices |
| Room guard | At day-close, sell excess if shed > 99 items | Prevents overflow loss |
| Terminal planner | Monte Carlo search for last 7 turns | +5 coins/game (within-tape optimization) |
| Clone preemption | Detect identical opponent, alter sell timing | Marginal — affects ~10% of games |

### 3.3 Top Leaderboard (Sep 10, 2026)
| Rank | Team | Elo |
|------|------|-----|
| 1 | SpaTaro | 3073 |
| 2 | Himanshu Kumar | 3010 |
| 3 | Otter Vibe | 3010 |
| 4 | binghua | 2989 |
| 5 | feel the agi | 2976 |
| 8 | Yusuke Hayashi | 2968 |
| ~800 | Bronze cutoff | ~2400 est. |

Yusuke Hayashi (rank 8) is the author of the Shop Router 0909 notebook that our agents are forked from. His current LB agent (2968) is significantly better than the public notebook version (our fork scores 2481). He has unpublished improvements.

---

## 4. Our Agents

### 4.1 Agent Hierarchy

All our agents share the same base: **13 pre-recorded action tapes** from Yusuke Hayashi's "Shop Router 0909" public notebook. The tapes are stored in `actions.json` (5MB). Each tape is a 719-step sequence of `{farmer, hands, market}` actions.

| Agent | Shop Routing | Weed Repair | Advance Sales | Room Guard | Terminal Planner | LB Elo |
|-------|-------------|------------|---------------|------------|-----------------|--------|
| **Shop Router** | 13-tape | ✅ | ✅ | ❌ | ❌ | **2481** |
| **Room Guard Only** | 13-tape | ✅ | ✅ | ✅ | ❌ | not submitted |
| **Hybrid V1** | 13-tape | ✅ | ✅ | ✅ | ✅ | **2240** (still climbing) |
| Reactive V2 | 13-tape | ✅ | ✅ | ✅ | ❌ | 1915 |
| Base | 4-tape | ✅ | ❌ | ❌ | ❌ | 1891 |

### 4.2 Shop Routing (Core Logic)
At step 144 (day 6, hour 0), the first two shops are revealed. Our agent maps the shop pair to one of 13 tapes:

```python
SHOP_PLANS = {
    ("BAKERY", "YARN_STORE"): 3,
    ("BRUNCH_SPOT", "YARN_STORE"): 4,
    ("FARMERS_MARKET", "YARN_STORE"): 5,
    ("ICE_CREAM_SHOP", "YARN_STORE"): 6,
    ("PET_CAFE", "YARN_STORE"): 5,
    ("PIZZA_SHOP", "YARN_STORE"): 7,
    ("SMOOTHIE_SHOP", "YARN_STORE"): 8,
    ("YARN_STORE", "BAKERY"): 9,
    ("YARN_STORE", "BRUNCH_SPOT"): 9,
    ("YARN_STORE", "FARMERS_MARKET"): 1,
    ("YARN_STORE", "ICE_CREAM_SHOP"): 9,
    ("YARN_STORE", "PET_CAFE"): 10,
    ("YARN_STORE", "PIZZA_SHOP"): 6,
    ("YARN_STORE", "SMOOTHIE_SHOP"): 11,
    ("YARN_STORE", "YARN_STORE"): 12,
}
```

**Critical weakness:** Only YARN_STORE combinations have dedicated tapes. ALL other shop pairs (FARMERS_MARKET+BAKERY, PIZZA_SHOP+PIZZA_SHOP, etc.) fall back to **plan 0** — our weakest tape. With 8 shops and replacement drawing, ~50% of games don't include YARN_STORE in the first two shops.

At step 648 (day 27), all agents switch to plan 2 for endgame.

### 4.3 Full Agent Code: Shop Router (Our Best LB Agent — 2481 Elo)

This is the complete `main.py` that scores 2481 on the leaderboard:

```python
"""Shop plans with small, observation-based repairs. Python standard library only.

The 13 complete action tapes live in actions.json. This file contains every rule:
choose a plan after two shops, delay weed-blocked work within the current day,
bring some planned sales forward one turn, and liquidate on the final turn.

Sell timing and shed projection follow aurax7's public Reactive Router:
https://www.kaggle.com/code/aurax7/kaggriculture-reactive-router
The shop-pair routes and worker-local, same-day queues were developed here.
"""

import copy
import json
from collections import deque
from pathlib import Path

TURNS_PER_DAY = 24
ROUTE_STEP = 144
FINAL_PLAN_STEP = 648
LAST_STEP = 718
SHED_CAPACITY = 100
MAX_ORDERS = 10
PRODUCTS = (
    "WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON",
    "EGG", "MILK", "WOOL", "FERTILIZER",
)
WEED_BLOCKED_WORK = {"PLANT", "BUILD_COOP", "BUILD_PASTURE"}
ANIMALS = {"GOOSE", "COW", "SHEEP"}

SHOP_PLANS = {
    ("BAKERY", "YARN_STORE"): 3,
    ("BRUNCH_SPOT", "YARN_STORE"): 4,
    ("FARMERS_MARKET", "YARN_STORE"): 5,
    ("ICE_CREAM_SHOP", "YARN_STORE"): 6,
    ("PET_CAFE", "YARN_STORE"): 5,
    ("PIZZA_SHOP", "YARN_STORE"): 7,
    ("SMOOTHIE_SHOP", "YARN_STORE"): 8,
    ("YARN_STORE", "BAKERY"): 9,
    ("YARN_STORE", "BRUNCH_SPOT"): 9,
    ("YARN_STORE", "FARMERS_MARKET"): 1,
    ("YARN_STORE", "ICE_CREAM_SHOP"): 9,
    ("YARN_STORE", "PET_CAFE"): 10,
    ("YARN_STORE", "PIZZA_SHOP"): 6,
    ("YARN_STORE", "SMOOTHIE_SHOP"): 11,
    ("YARN_STORE", "YARN_STORE"): 12,
}


class FarmView:
    """Only the current own farm, private inventory, and public prices."""

    def __init__(self, observation):
        farm = observation["farms"][observation["player"]]
        private = observation["private"]
        self.tiles = farm["tiles"]
        self.positions = [farm["farmer"], *farm["hands"]]
        self.inventories = private["inventories"]
        self.shed = {item: max(0, int(qty)) for item, qty in private["shed"].items()}
        self.prices = observation["market"]["prices"]

    def inventory(self, worker):
        return self.inventories[worker] if worker < len(self.inventories) else {}

    def beside_shed(self, position):
        center = len(self.tiles) // 2
        return position[0] in (center - 1, center) and position[1] in (center - 1, center)


class DayState:
    """Per-player memory; queues expire at dawn and sales expire next turn."""

    def __init__(self):
        self.plan = 0
        self.last_step = -1
        self.day = -1
        self.queues = {}
        self.sale_due_step = -1
        self.advanced_sales = {}


def repair_weeds(action, view, state, step):
    """Insert DIG without consuming the blocked action; shift only this worker."""
    day = step // TURNS_PER_DAY
    if day != state.day:
        state.day = day
        state.queues.clear()

    workers = [action.get("farmer") or ["PASS"], *(action.get("hands") or [])]
    for worker in range(min(len(workers), len(view.positions))):
        queue = state.queues.setdefault(worker, deque())
        queue.append(list(workers[worker]))
        x, y = view.positions[worker]
        tile = view.tiles[y][x]
        blocked = (queue[0][0] in WEED_BLOCKED_WORK
                   and isinstance(tile, dict) and tile.get("kind") == "WEED")
        workers[worker] = ["DIG"] if blocked else queue.popleft()
    action["farmer"], action["hands"] = workers[0], workers[1:]


def projected_shed(action, view):
    """Estimate stock after this turn's nearby PICKUP, DROP and PLACE actions."""
    stock = {item: view.shed.get(item, 0) for item in PRODUCTS}
    stock.update(view.shed)
    total = sum(stock.values())
    workers = [action.get("farmer") or ["PASS"], *(action.get("hands") or [])]
    for worker in range(min(len(workers), len(view.positions))):
        if not view.beside_shed(view.positions[worker]):
            continue
        work = workers[worker]
        operation = work[0] if work else "PASS"
        inventory = view.inventory(worker)
        if operation == "PICKUP" and len(work) >= 2 and work[1] in stock:
            quantity = max(0, int(work[2]) if len(work) >= 3 else 1)
            taken = min(stock[work[1]], quantity)
            stock[work[1]] -= taken
            total -= taken
        elif operation == "DROP":
            for item, held in inventory.items():
                added = min(max(0, int(held)), max(0, SHED_CAPACITY - total))
                if added > 0:
                    stock[item] = stock.get(item, 0) + added
                    total += added
        elif operation == "PLACE" and len(work) >= 2 and work[1] not in ANIMALS:
            item = work[1]
            quantity = max(0, int(work[2]) if len(work) >= 3 else 1)
            added = min(quantity, max(0, int(inventory.get(item, 0))),
                        max(0, SHED_CAPACITY - total))
            if added > 0:
                stock[item] = stock.get(item, 0) + added
                total += added
    return stock


def subtract_advanced_sales(action, state, step):
    """Remove quantities already requested one turn early."""
    if state.sale_due_step == step:
        remaining = dict(state.advanced_sales)
        for order in action["market"]:
            if order and order[0] == "SELL" and len(order) >= 3:
                item = order[1]
                removed = min(max(0, int(order[2])), remaining.get(item, 0))
                if removed > 0:
                    order[2] = int(order[2]) - removed
                    remaining[item] -= removed
    state.advanced_sales = {}
    state.sale_due_step = -1


def advance_sales(action, view, state, tape, step):
    """Bring eligible sales from next planned action forward by one turn."""
    next_step = step + 1
    if next_step > LAST_STEP or next_step % 72 == 0 or step % 4 == 0:
        return
    planned = {}
    for order in tape[next_step].get("market") or []:
        if order and order[0] == "SELL" and len(order) >= 3 and order[1] in PRODUCTS:
            item = order[1]
            planned[item] = planned.get(item, 0) + max(0, int(order[2]))
    already_selling = {order[1] for order in action["market"]
                       if order and order[0] == "SELL" and len(order) > 1}
    stock = projected_shed(action, view)
    for item in PRODUCTS:
        if item in ("WHEAT", "FERTILIZER") or item in already_selling:
            continue
        quantity = min(stock.get(item, 0), planned.get(item, 0))
        if quantity <= 0 or int(view.prices.get(item, 0)) < 2:
            continue
        if len(action["market"]) >= MAX_ORDERS:
            break
        action["market"].append(["SELL", item, quantity])
        state.advanced_sales[item] = quantity
    if state.advanced_sales:
        state.sale_due_step = next_step


def liquidate(view):
    """On the last turn, drop reachable inventory and sell the projected shed."""
    workers = [["DROP"] if view.beside_shed(pos) and view.inventory(worker) else ["PASS"]
               for worker, pos in enumerate(view.positions)]
    action = {"farmer": workers[0], "hands": workers[1:], "market": []}
    stock = projected_shed(action, view)
    action["market"] = [["SELL", item, stock[item]] for item in PRODUCTS if stock[item] > 0]
    action["market"].sort(key=lambda order: -int(view.prices.get(order[1], 0)) * order[2])
    return action


class Policy:
    def __init__(self, folder):
        self.tapes = json.loads((Path(folder) / "actions.json").read_text())
        if len(self.tapes) != 13 or any(len(tape) != LAST_STEP + 1 for tape in self.tapes):
            raise ValueError("Expected 13 complete, 719-turn action tapes")
        self.players = {}

    def act(self, observation):
        step, player = int(observation["step"]), int(observation["player"])
        state = self.players.get(player)
        if state is None or step <= state.last_step:
            state = self.players[player] = DayState()
        state.last_step = step

        if step == ROUTE_STEP:
            shops = observation["town"]["unlocked_shops"]
            state.plan = SHOP_PLANS.get(tuple(shops[:2]), 0)
        if step == FINAL_PLAN_STEP:
            state.plan = 2

        view = FarmView(observation)
        tape = self.tapes[state.plan]
        action = copy.deepcopy(tape[step])
        repair_weeds(action, view, state, step)
        subtract_advanced_sales(action, state, step)
        advance_sales(action, view, state, tape, step)
        action["market"] = action["market"][:MAX_ORDERS]
        return liquidate(view) if step == LAST_STEP else action


_POLICY = None

def agent(observation, configuration=None):
    global _POLICY
    if _POLICY is None:
        folder = Path(agent.__code__.co_filename).resolve().parent
        _POLICY = Policy(folder)
    return _POLICY.act(observation)
```

### 4.4 Room Guard Addition (Not Yet Submitted)

This is the one function added to make "Room Guard Only" — inserted into `Policy.act()` after `advance_sales()`:

```python
def room_guard(action, view, step):
    """At day-close, sell excess items to prevent shed overflow (target <=99)."""
    if step % TURNS_PER_DAY != TURNS_PER_DAY - 1:
        return
    carried = sum(max(0, int(n)) for inv in view.inventories for n in inv.values())
    shed_total = sum(view.shed.values())
    total = shed_total + carried
    if total <= 99:
        return
    needed = total - 99
    planned_sells = {}
    for o in action.get("market", []):
        if o and o[0] == "SELL" and len(o) >= 3:
            planned_sells[o[1]] = planned_sells.get(o[1], 0) + max(0, int(o[2]))

    priority = sorted(PRODUCTS, key=lambda it: -int(view.prices.get(it, 0)))
    for item in priority:
        avail = max(0, view.shed.get(item, 0) - planned_sells.get(item, 0))
        qty = min(needed, avail)
        if qty <= 0:
            continue
        if len(action["market"]) >= MAX_ORDERS:
            break
        action["market"].append(["SELL", item, qty])
        planned_sells[item] = planned_sells.get(item, 0) + qty
        needed -= qty
        if needed <= 0:
            break
```

### 4.5 Terminal Planner (In Hybrid V1)

The terminal planner runs a Monte Carlo search over the last 7 turns (steps 712–718) to optimize worker routing for maximum deposit value. It:
1. At step 712, creates a "shadow" baseline by running the parent policy through steps 712–718
2. For each worker, generates candidate routes (harvest nearby resources, return to shed, drop)
3. Evaluates up to 128 simulations, selecting the plan that dominates the baseline
4. Replays the optimized plan on steps 713–718

**Files:** `policy.py` (ShopClosure wrapper), `terminal_planner.py` (search logic), `unit_model.py` (game state simulator).

In local testing, this adds a consistent +5 coins per game. On LB, it hasn't shown clear benefit — possibly because the agent plays fewer games/hour due to computation overhead at step 712.

---

## 5. Loss Analysis (From 48 Real LB Games)

### 5.1 Overall Record
- **36 wins, 6 ties, 6 real losses** out of 48 games (75% WR)
- Elo converging slowly due to playing in the ~2200 bracket

### 5.2 Loss Categories

**Category 1: Clone Matches (10 games — 6 ties + 4 narrow losses)**
Opponent runs identical or near-identical Shop Router code. Sell totals match within ±5 units per product. Margins are ±500–5000 coins. These are essentially coin flips determined by:
- Microsecond timing differences in market order processing
- Which player is seat 0 vs seat 1 (affects per-unit lockstep ordering)
- Slight tape variant differences

**Category 2: Bad Tape (1 game — our biggest loss at -61,218)**
- Shops: FARMERS_MARKET + BAKERY (no YARN_STORE)
- Our agent fell back to plan 0 (default tape, weakest)
- Opponent had optimized tape for this combination
- We scored 44,621 vs opponent's 105,839

**Category 3: More Workers (4 games — losses of -605 to -18,509)**
- Opponents had 13–14 workers vs our 12
- More workers = more production capacity = more items to sell
- These opponents likely have tapes that hire more hands earlier

**Category 4: Other (2 games — losses of -177 to -3,820)**
- Slightly better tape or selling timing from opponent

### 5.3 Key Insight
**We are NOT losing because of strategy.** We're losing because:
1. **Coverage gap:** ~50% of shop combinations have no dedicated tape (fall back to plan 0)
2. **Worker count:** Our tapes max at 12 workers; some opponents run 14
3. **Clone battles:** When both players use the same tapes, the winner is essentially random

---

## 6. What We Have Access To (Resources for Improvement)

### 6.1 Local Simulation
- **kaggle-environments** package installed (`/Users/nathanjacob/opt/miniconda3/`)
- Can run full 720-turn games locally in ~2.5 seconds
- Full game engine source code at `/Users/nathanjacob/opt/miniconda3/lib/python3.12/site-packages/kaggle_environments/envs/kaggriculture/kaggriculture.py`
- Can modify engine for debugging/analysis

### 6.2 Kaggle CLI & API
- `kaggle competitions submissions` — check submission scores
- `kaggle competitions episodes <submission_id>` — list all episodes
- `kaggle competitions replay <episode_id>` — download full replay JSON (all 720 steps, both players' actions + observations)
- `kaggle competitions logs <episode_id> <agent_index>` — download per-step timing/error logs
- `kaggle kernels pull <notebook_ref>` — download public notebook source
- 5 submissions/day (2 scored), resets midnight UTC

### 6.3 Real Opponent Data
- **48 replays** from our Hybrid V1 submission (opponents at ~2200 Elo)
- **50 replays** from our Shop Router submission (opponents at ~2400 Elo)
- Can download replays from any of our submissions
- **Cannot** download replays from other players' submissions (only our own)

### 6.4 Public Agent Code (Downloaded & Tested Locally)
| Agent | Source | Status |
|-------|--------|--------|
| aurax7 Reactive Router | 63 votes, extracted main.py (51KB) | ✅ Works locally |
| boatlee V16 Premium Market | 311 votes, extracted main.py (19KB) | ✅ Works locally |
| tetsu Shape Shop Value-Aware | 125 votes, extracted main.py (45KB) | ✅ Works locally |
| Yusuke Hayashi Shop Router 0909 | 121 votes, our base fork | ✅ Works locally |
| Thomas Tschinkel Public State Router | 99 votes, extracted main.py (45KB) | ✅ Works locally |
| Pilkwang Structured Economic Policy | 103 votes, multi-agent (317KB cell) | Partial extraction |
| Kaito v48 Fast Routes | 132 votes, 110KB compressed | Not extracted |

All tested public agents score below our agents locally (we beat them 90–100%). They represent older meta and are too weak for meaningful testing.

### 6.5 Our Testing Frameworks
| Framework | File | Purpose |
|-----------|------|---------|
| Vet Agent | `vet_agent.py` | H2H candidate vs our own agents (self-play, biased) |
| Tournament | `tournament.py` | Full round-robin league (self-play, biased) |
| LB Sim V2 | `lb_sim_v2.py` | Candidate vs real public agents (too weak to discriminate) |
| Extract Opponents | `extract_opponents.py` | Extract opponent tapes from replays |

### 6.6 Our Files & Agents
| Path | Description |
|------|-------------|
| `/tmp/kaggriculture_latest/hybrid_v1/` | Hybrid V1 (submitted, 2240 Elo). Files: main.py, policy.py, terminal_planner.py, unit_model.py, router_parent.py, actions.json, settings.json |
| `/tmp/kaggriculture_latest/room_guard_only/` | Room Guard Only (not submitted). Files: main.py, actions.json |
| `/tmp/kaggriculture_latest/shop_router_0909_ext/` | Shop Router (2481 Elo). Files: main.py, actions.json |
| `/tmp/kaggriculture_latest/reactive_v2_ext/` | Reactive V2. Files: main.py, actions.json |
| `/tmp/kaggriculture_latest/seven_turn_ext/` | Seven-Turn. Files: main.py, actions.json |
| `/Users/nathanjacob/Documents/kaggle/kaggriculture/` | Working directory with all scripts |
| `/tmp/kaggriculture_opponents/real_agents/` | Downloaded public agent notebooks (extracted .py files) |
| `/tmp/ep_replays/` | ~50 downloaded replay JSONs |

### 6.7 Key Constraint
- **actions.json** (the 13 tapes) comes from Yusuke Hayashi's public notebook. We cannot easily generate new tapes — they were created by offline optimization/expert play that we don't have.
- Yusuke Hayashi's own agent is at 2968 Elo, ~487 points above our fork of his public code. His unpublished improvements likely include: more tapes, better tapes for non-Yarn combos, more workers per tape, and additional reactive layers.

---

## 7. Specific Questions for the Expert

1. **Tape generation**: How can we create our own action tapes? The current 13 tapes only cover YARN_STORE combinations. We need tapes for all ~64 shop-pair combinations. Is there a tractable offline search or self-play approach?

2. **Clone-battle edge**: When playing against near-identical opponents (same tapes), what reactive modifications would give us a consistent edge? The margins are ±500 coins. Ideas: sell timing manipulation, price-aware selling, opponent observation.

3. **Worker optimization**: Our tapes use 12 workers. Top opponents use 14. Is there a way to modify our existing tapes to hire more workers, or does this require entirely new tapes?

4. **Testing methodology**: Public agents are too weak, and self-play is biased. What's the right way to evaluate modifications before submitting to the LB?

5. **Quick wins**: Given our current 2481 Elo and the 2400 bronze target, what's the single highest-impact change we can make with the resources we have?

6. **Market exploitation**: The pricing model has specific curve shapes per product. Are there selling patterns that exploit the math (e.g., sell WOOL early before price crashes, hold CARROT when PET_CAFE opens)?

---

## 8. Appendix: Full Game Engine Source

The complete game engine is at:
```
/Users/nathanjacob/opt/miniconda3/lib/python3.12/site-packages/kaggle_environments/envs/kaggriculture/kaggriculture.py
```

Key functions:
- `_apply_unit_action()` — processes one worker's action
- `_process_market()` — per-unit lockstep sell/buy resolution
- `market_price()` — the pricing formula
- `_town_consume()` — shop demand reduces inventory, raises prices
- `_end_of_day()` — daily reset, weed spawn, hand dismissal
- `_daily_refresh_plants()` / `_daily_refresh_animals()` — production logic
- `interpreter()` — main game loop

The full source (1087 lines) is included in Section 2 references and can be read directly from the path above.
