"""Kaggriculture submission — Enhanced State Router agent.
Writes main.py and packages as submission.tar.gz.
"""
import os
import tarfile
import hashlib

# Write agent code to main.py
AGENT_CODE = open("/kaggle/input/kaggriculture/main.py", "r").read() if os.path.exists("/kaggle/input/kaggriculture/main.py") else ""

# If running locally or agent code not found via input, use inline
if not AGENT_CODE:
    print("NOTE: Agent code should be attached as a dataset or written inline")

# The actual main.py is uploaded alongside this notebook as a utility script.
# For Kaggle submission, we write main.py and package it.

# Read our main.py from the working directory
agent_path = "/kaggle/working/main.py"
if not os.path.exists(agent_path):
    # If main.py isn't in working dir, it should be the notebook output
    print("ERROR: main.py not found in working directory")
else:
    print(f"main.py found: {os.path.getsize(agent_path)} bytes")

# Package submission
with tarfile.open("submission.tar.gz", "w:gz") as tar:
    tar.add(agent_path, arcname="main.py")

size = os.path.getsize("submission.tar.gz")
with open("submission.tar.gz", "rb") as f:
    sha = hashlib.sha256(f.read()).hexdigest()

print(f"Generated Archive: submission.tar.gz")
print(f"File Size: {size / 1024:.1f} KB")
print(f"SHA256: {sha}")

# List contents
with tarfile.open("submission.tar.gz", "r:gz") as tar:
    print(f"Archive Contents: {tar.getnames()}")

print("Ready to submit!")
