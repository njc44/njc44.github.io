"""Drop-in reactive layers for the Shop Router policy. Standard library only.

Call order inside Policy.act(), after advance_sales():
    drop_guard(action, view)
    purchase_guard(action, view)
    opportunistic_work(action, view)
    early_liquidate(action, view, step)
    order_sells_steep_first(action, view)
Each one is a no-op unless its trigger condition is met, so they can be A/B'd independently.
`view` is the policy's FarmView (tiles, positions, inventories, shed, prices).
"""

PRODUCTS = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER")
ANIMALS = {"GOOSE", "COW", "SHEEP"}
SHED_CAPACITY = 100
MAX_ORDERS = 10
TURNS_PER_DAY = 24
LAST_STEP = 718
# Glut steepness: units above equilibrium before price drops below 50% of base (from the engine's curves).
# Lower = sell first. Wheat/egg are effectively glut-immune (log curve).
STEEPNESS = {"STRAWBERRY": 32, "MILK": 39, "WOOL": 42, "MELON": 113, "TOMATO": 144, "CARROT": 230,
             "FERTILIZER": 253, "EGG": 9999, "WHEAT": 9999}
# Turns before the end at which steep items are dumped so a 718-dumping clone sells into our glut, not us into theirs.
EARLY_LIQUIDATE_STEP = 717


def _workers(action):
    return [action.get("farmer") or ["PASS"], *(action.get("hands") or [])]


def _set_workers(action, workers):
    action["farmer"], action["hands"] = workers[0], workers[1:]


def _shed_total(view):
    return sum(max(0, int(v)) for v in view.shed.values())


def _cheapest_first(view, exclude=()):
    return sorted((p for p in PRODUCTS if p not in exclude), key=lambda p: int(view.prices.get(p, 0)))


def _cap_orders(sells, others):
    """Keep every non-SELL (HIRE/BUY_LAND/BUY_* are load-bearing for the tape); fill remaining slots with SELLs,
    dropping the lowest-value SELLs if the 10-order cap binds."""
    room = MAX_ORDERS - len(others)
    if room < 0:
        return others[:MAX_ORDERS]
    return sells[:room] + others


def order_sells_steep_first(action, view=None):
    """SELLs first (steep items at index 0), then the tape's other orders in original order.

    A SELL never moves ahead of a same-item BUY_PRODUCT (preserves the tape's round-trip semantics), and the
    cap is applied to SELLs only: a truncated HIRE shifts every later hand's route by one turn."""
    market = action.get("market") or []
    is_sell = lambda o: bool(o) and o[0] == "SELL" and len(o) >= 3
    others = [o for o in market if not is_sell(o)]
    bought = {o[1] for o in others if o and o[0] == "BUY_PRODUCT" and len(o) > 1}
    movable = [o for o in market if is_sell(o) and o[1] not in bought]
    pinned = [o for o in market if is_sell(o) and o[1] in bought]
    value = lambda o: int(o[2]) * (int(view.prices.get(o[1], 1)) if view is not None else 1)
    movable.sort(key=lambda o: (STEEPNESS.get(o[1], 9999), -value(o)))
    sells = movable + pinned
    action["market"] = _cap_orders(sells, others)


def early_liquidate(action, view, step):
    """From EARLY_LIQUIDATE_STEP, sell everything already in the shed (steep items first).

    Prices never recover within the last day except by tiny shop ticks, so selling a turn early costs
    nothing, while a clone that dumps on 718 then sells into the glut we created. The existing liquidate()
    still runs on 718 for anything dropped after this."""
    if step < EARLY_LIQUIDATE_STEP or step >= LAST_STEP:
        return
    already = {o[1] for o in action.get("market") or [] if o and o[0] == "SELL" and len(o) > 1}
    for item in sorted(PRODUCTS, key=lambda p: STEEPNESS.get(p, 9999)):
        qty = int(view.shed.get(item, 0))
        if qty <= 0 or item in already or int(view.prices.get(item, 0)) < 2:
            continue
        if len(action["market"]) >= MAX_ORDERS:
            break
        action["market"].append(["SELL", item, qty])


def drop_guard(action, view):
    """DROP into a full shed destroys whatever doesn't fit (engine deletes the inventory entry regardless).
    PLACE only moves what fits. Convert unsafe DROPs to PLACE of the most valuable carried item, and queue a
    SELL of the cheapest shed stock so there is room next turn."""
    workers = _workers(action)
    total = _shed_total(view)
    changed = False
    for w in range(min(len(workers), len(view.positions))):
        if workers[w][0] != "DROP" or not view.beside_shed(view.positions[w]):
            continue
        inv = {k: int(v) for k, v in view.inventory(w).items() if int(v) > 0 and k not in ANIMALS}
        carried = sum(inv.values())
        room = max(0, SHED_CAPACITY - total)
        if carried <= room:
            total += carried
            continue
        if inv:
            best = max(inv, key=lambda k: int(view.prices.get(k, 0)) * inv[k])
            workers[w] = ["PLACE", best, inv[best]] if room > 0 else ["PASS"]
            total += min(room, inv[best])
        changed = True
    if changed:
        _set_workers(action, workers)
        _free_room(action, view, needed=20)


def purchase_guard(action, view):
    """BUY_ANIMAL / BUY_PRODUCT silently fail when the shed is full, which orphans the tape's whole
    PICKUP/PLACE line for that animal. Free room with SELLs at lower indices than the buy."""
    market = action.get("market") or []
    buys = sum(int(o[2]) if len(o) > 2 else 1 for o in market if o and o[0] in ("BUY_ANIMAL", "BUY_PRODUCT"))
    if buys <= 0:
        return
    planned_sells = sum(int(o[2]) for o in market if o and o[0] == "SELL" and len(o) > 2)
    shortfall = _shed_total(view) - planned_sells + buys - SHED_CAPACITY
    if shortfall > 0:
        _free_room(action, view, needed=shortfall, front=True)


def _free_room(action, view, needed, front=False):
    market = action.get("market") or []
    planned = {}
    for o in market:
        if o and o[0] == "SELL" and len(o) > 2:
            planned[o[1]] = planned.get(o[1], 0) + int(o[2])
    extra = []
    for item in _cheapest_first(view, exclude=("WHEAT",)):  # keep wheat: it's feed
        avail = int(view.shed.get(item, 0)) - planned.get(item, 0)
        if avail <= 0 or int(view.prices.get(item, 0)) < 1:
            continue
        qty = min(avail, needed)
        extra.append(["SELL", item, qty])
        needed -= qty
        if needed <= 0:
            break
    is_sell = lambda o: bool(o) and o[0] == "SELL" and len(o) >= 3
    others = [o for o in market if not is_sell(o)]
    sells = [o for o in market if is_sell(o)]
    action["market"] = _cap_orders((extra + sells) if front else (sells + extra), others)


def opportunistic_work(action, view):
    """When the tape action is a guaranteed no-op on the tile the worker stands on, do the most valuable
    legal thing there instead. Never overrides an action that could have an effect."""
    workers = _workers(action)
    changed = False
    for w in range(min(len(workers), len(view.positions))):
        op = workers[w][0]
        x, y = view.positions[w]
        tile = view.tiles[y][x]
        if not isinstance(tile, dict):
            continue
        noop = (
            op == "PASS"
            or (op == "WATER" and (tile.get("kind") != "PLANT" or tile.get("watered_today")))
            or (op == "HARVEST" and tile.get("yield_units", 0) <= 0)
            or (op == "FEED" and (tile.get("fed_today") or "animal" not in tile))
            or (op == "CARE" and (tile.get("cared_today") or "animal" not in tile))
            or (op == "COLLECT_FERTILIZER" and not tile.get("fertilizer_available"))
        )
        if not noop:
            continue
        inv = view.inventory(w)
        sub = None
        if "animal" in tile:
            if not tile.get("cared_today"):
                sub = ["CARE"]              # bonus accrues if the animal gets fed at any point today
            elif not tile.get("fed_today") and int(inv.get("WHEAT", 0)) > 0:
                sub = ["FEED"]
            elif tile.get("fertilizer_available"):
                sub = ["COLLECT_FERTILIZER"]
            elif tile.get("yield_units", 0) > 0:
                sub = ["HARVEST"]
        elif tile.get("kind") == "PLANT" and not tile.get("watered_today"):
            sub = ["WATER"]
        if sub and sub != workers[w]:
            workers[w] = sub
            changed = True
    if changed:
        _set_workers(action, workers)
