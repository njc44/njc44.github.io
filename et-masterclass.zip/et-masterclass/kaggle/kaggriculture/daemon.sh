#!/bin/bash
# ──────────────────────────────────────────────────────────────
# Kaggriculture Pattern Mining Daemon
#
# Runs in a loop:
#   1. Scrape latest top notebooks from Kaggle
#   2. Extract agents from any new notebooks
#   3. Mine routing patterns from top agents
#   4. Benchmark our planning agent
#   5. Generate improvement insights
#   6. Sleep, repeat
#
# Usage:
#   ./daemon.sh                    # foreground
#   nohup ./daemon.sh &            # background, survives logout
#   ./daemon.sh --once             # single run, no loop
#
# Logs: kaggriculture/daemon_logs/
# Patterns: kaggriculture/patterns/
# ──────────────────────────────────────────────────────────────

set -euo pipefail

PYTHON="/Users/nathanjacob/opt/miniconda3/bin/python"
WORK_DIR="/Users/nathanjacob/Documents/kaggle/kaggriculture"
LOG_DIR="$WORK_DIR/daemon_logs"
PATTERN_DIR="$WORK_DIR/patterns"
NOTEBOOK_DIR="/tmp/kaggriculture_notebooks"
OPPONENT_DIR="/tmp/kaggriculture_opponents"

INTERVAL_HOURS=4  # How often to run (in hours)
GAMES_PER_AGENT=3
AGENTS_TO_MINE="prvsiyan_soil,prvsiyan_moon,shop_router"

mkdir -p "$LOG_DIR" "$PATTERN_DIR" "$NOTEBOOK_DIR" "$OPPONENT_DIR"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_DIR/daemon.log"
}

# ── Step 1: Scrape latest notebooks ──────────────────────────

scrape_notebooks() {
    log "STEP 1: Scraping latest top notebooks..."

    # Get top 10 by votes
    local top_by_votes
    top_by_votes=$(kaggle kernels list --competition kaggriculture \
        --sort-by voteCount --page-size 10 2>/dev/null || echo "")

    # Get newest 10
    local newest
    newest=$(kaggle kernels list --competition kaggriculture \
        --sort-by dateCreated --page-size 10 2>/dev/null || echo "")

    # Combine and deduplicate refs
    local all_refs
    all_refs=$(echo "$top_by_votes" "$newest" | \
        grep -oE '^[a-zA-Z0-9_-]+/[a-zA-Z0-9_-]+' | sort -u)

    local new_count=0
    while IFS= read -r ref; do
        [ -z "$ref" ] && continue
        local slug
        slug=$(echo "$ref" | tr '/' '_')
        local dest="$NOTEBOOK_DIR/$slug"

        if [ -d "$dest" ]; then
            continue  # already downloaded
        fi

        log "  Downloading: $ref"
        mkdir -p "$dest"
        if kaggle kernels pull "$ref" -p "$dest" 2>/dev/null; then
            new_count=$((new_count + 1))
        else
            rmdir "$dest" 2>/dev/null || true
        fi
    done <<< "$all_refs"

    log "  Downloaded $new_count new notebooks"
    return $new_count
}

# ── Step 2: Extract agents from new notebooks ────────────────

extract_agents() {
    log "STEP 2: Extracting agents from notebooks..."

    local extracted=0
    for nb_dir in "$NOTEBOOK_DIR"/*/; do
        local slug
        slug=$(basename "$nb_dir")
        local opp_dir="$OPPONENT_DIR/${slug}"

        # Skip if already extracted
        [ -f "$opp_dir/main.py" ] && continue

        # Find the notebook file
        local nb_file
        nb_file=$(find "$nb_dir" -name "*.ipynb" -o -name "*.py" | head -1)
        [ -z "$nb_file" ] && continue

        log "  Extracting: $slug"
        mkdir -p "$opp_dir"

        # Try to extract agent code using Python
        $PYTHON -c "
import json, sys, os, base64, zlib, tarfile, io

nb_file = '$nb_file'
out_dir = '$opp_dir'

try:
    if nb_file.endswith('.ipynb'):
        with open(nb_file) as f:
            nb = json.load(f)
        cells = nb.get('cells', [])

        # Strategy 1: Look for %%writefile main.py cell
        for cell in cells:
            src = ''.join(cell.get('source', []))
            if '%%writefile main.py' in src:
                code = src.replace('%%writefile main.py', '').strip()
                with open(os.path.join(out_dir, 'main.py'), 'w') as f:
                    f.write(code)
                print('Extracted via %%writefile')
                sys.exit(0)

        # Strategy 2: Look for base64/tar.gz archive
        for cell in cells:
            src = ''.join(cell.get('source', []))
            if 'ARCHIVE_BYTES' in src or 'b64decode' in src:
                # Try to exec and extract
                try:
                    exec(src, {'__builtins__': __builtins__})
                except:
                    pass

        # Strategy 3: Look for large code cells with agent function
        for cell in reversed(cells):
            src = ''.join(cell.get('source', []))
            if 'def agent(' in src or 'def my_agent(' in src:
                with open(os.path.join(out_dir, 'main.py'), 'w') as f:
                    f.write(src)
                print('Extracted via agent function')
                sys.exit(0)

    elif nb_file.endswith('.py'):
        import shutil
        shutil.copy(nb_file, os.path.join(out_dir, 'main.py'))
        print('Copied .py file')
        sys.exit(0)

    print('No agent found')
    sys.exit(1)
except Exception as e:
    print(f'Error: {e}')
    sys.exit(1)
" 2>&1 | while read -r line; do log "    $line"; done

        if [ -f "$opp_dir/main.py" ]; then
            extracted=$((extracted + 1))
        else
            rm -rf "$opp_dir"
        fi
    done

    log "  Extracted $extracted new agents"
}

# ── Step 3: Mine patterns ────────────────────────────────────

mine_patterns() {
    log "STEP 3: Mining patterns..."

    $PYTHON "$WORK_DIR/pattern_miner.py" \
        --agents "$AGENTS_TO_MINE" \
        --games "$GAMES_PER_AGENT" \
        --output "$PATTERN_DIR" \
        2>&1 | while IFS= read -r line; do log "  $line"; done
}

# ── Step 4: Benchmark our agent ──────────────────────────────

benchmark() {
    log "STEP 4: Quick benchmark..."

    local v4="/tmp/kaggriculture_latest/v4_agent/planning_agent.py"
    [ ! -f "$v4" ] && { log "  V4 agent not found, skipping"; return; }

    local result
    result=$($PYTHON -c "
from kaggle_environments import make
import time

v4 = '$v4'
opps = [
    ('prvsiyan_soil', '/tmp/kaggriculture_opponents/prvsiyan_soil/main.py'),
    ('shop_router', '/tmp/kaggriculture_latest/shop_router_0909_ext/main.py'),
]

for name, path in opps:
    scores = []
    for i in range(3):
        env = make('kaggriculture')
        r = env.run([v4, path] if i < 2 else [path, v4])
        f = r[-1]
        ra = f[0]['reward'] if i < 2 else f[1]['reward']
        scores.append(ra)
    avg = sum(scores)/len(scores)
    print(f'{name}: \${avg:,.0f}')
" 2>&1)

    log "  Benchmark results:"
    echo "$result" | while IFS= read -r line; do log "    $line"; done

    # Save to log
    echo "$(date '+%Y-%m-%d %H:%M:%S') $result" >> "$LOG_DIR/benchmark_history.log"
}

# ── Step 5: Generate report ──────────────────────────────────

generate_report() {
    log "STEP 5: Generating report..."

    local latest_comparison
    latest_comparison=$(ls -t "$PATTERN_DIR"/comparison_*.json 2>/dev/null | head -1)
    local latest_insights
    latest_insights=$(ls -t "$PATTERN_DIR"/insights_*.txt 2>/dev/null | head -1)

    if [ -n "$latest_comparison" ]; then
        log "  Latest comparison: $latest_comparison"
        $PYTHON -c "
import json
with open('$latest_comparison') as f:
    data = json.load(f)
print(f'Our score: \${data[\"our_score\"]:,.0f}')
for name, comp in data.get('comparisons', {}).items():
    print(f'{name}: \${comp[\"their_score\"]:,.0f} (gap: \${comp[\"score_gap\"]:+,.0f})')
" 2>&1 | while IFS= read -r line; do log "    $line"; done
    fi

    if [ -n "$latest_insights" ]; then
        log "  Latest insights:"
        head -15 "$latest_insights" | while IFS= read -r line; do log "    $line"; done
    fi
}

# ── Main loop ────────────────────────────────────────────────

main() {
    local once=false
    [[ "${1:-}" == "--once" ]] && once=true

    log "════════════════════════════════════════════════════════════"
    log "  KAGGRICULTURE PATTERN MINING DAEMON"
    log "  Interval: ${INTERVAL_HOURS}h"
    log "  Mode: $([ "$once" = true ] && echo 'single run' || echo 'continuous')"
    log "  PID: $$"
    log "════════════════════════════════════════════════════════════"

    while true; do
        local run_start
        run_start=$(date +%s)

        log "── Run started ──"

        scrape_notebooks || true
        extract_agents || true
        mine_patterns || true
        benchmark || true
        generate_report || true

        local run_end
        run_end=$(date +%s)
        local elapsed=$(( run_end - run_start ))
        log "── Run completed in ${elapsed}s ──"

        if [ "$once" = true ]; then
            log "Single run complete. Exiting."
            break
        fi

        local sleep_secs=$(( INTERVAL_HOURS * 3600 ))
        log "Sleeping ${INTERVAL_HOURS}h until next run..."
        sleep "$sleep_secs"
    done
}

main "$@"
