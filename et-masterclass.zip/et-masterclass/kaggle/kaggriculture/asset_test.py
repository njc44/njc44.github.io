"""Asset return analysis using the fluid model.

Reproduces the expected $/tile-day and $/action returns for each asset type,
and validates the fluid model against known engine economics.

Standard library + numpy only.
"""

from __future__ import annotations

import numpy as np

from fluid_model import (
    ANIMALS,
    CROPS,
    PRODUCTS,
    MARKET_I0,
    MARKET_PARAMS,
    TOTAL_DAYS,
    PRICE_FLOOR,
    SHOPS,
    FluidModel,
    market_price,
    sell_n_units,
    hire_cost_for_n,
    animal_total_yield,
    crop_total_yield,
    shop_consumption_per_day,
    simulate_allocation,
)


def divider(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


# ---------------------------------------------------------------------------
# Test 1: Price curves at equilibrium and with displacement
# ---------------------------------------------------------------------------

def test_price_curves():
    divider("Price Curve Validation")
    print(f"{'Product':>12}  {'Base':>5}  {'@eq':>5}  {'@-50':>5}  {'@+50':>5}  {'@+T':>5}  "
          f"{'Above':>6}  {'Floor@':>7}")

    for prod in PRODUCTS:
        p = MARKET_PARAMS[prod]
        base = p["base"]
        T = p["T"]

        p_eq = market_price(prod, MARKET_I0)
        p_lo = market_price(prod, MARKET_I0 - 50)
        p_hi = market_price(prod, MARKET_I0 + 50)
        p_at_T = market_price(prod, MARKET_I0 + T)

        # Find units above equilibrium where price hits floor
        floor_at = None
        for delta in range(1, 10000):
            if market_price(prod, MARKET_I0 + delta) <= PRICE_FLOOR:
                floor_at = delta
                break

        floor_str = f"{floor_at}" if floor_at else ">10k"
        print(f"{prod:>12}  {base:5d}  {p_eq:5d}  {p_lo:5d}  {p_hi:5d}  {p_at_T:5d}  "
              f"{p['above_func']:>6}  {floor_str:>7}")


# ---------------------------------------------------------------------------
# Test 2: Animal returns
# ---------------------------------------------------------------------------

def test_animal_returns():
    divider("Animal Returns (single animal, placed day 0, 30-day game)")

    print(f"\n{'Animal':>8}  {'Cost':>5}  {'Product':>8}  {'1st Yield':>9}  "
          f"{'Prod Units':>10}  {'Fert':>5}  {'$/tile':>7}  {'$/action':>8}  {'Tiles':>5}")

    for atype in ("SHEEP", "COW", "GOOSE"):
        a = ANIMALS[atype]
        cost = a["cost"]
        product = a["product"]
        prod_yield, fert_yield, first_day = animal_total_yield(atype, place_day=0, care=True)

        # Revenue from product (sold at equilibrium price)
        prod_price = MARKET_PARAMS[product]["base"]
        prod_revenue = prod_yield * prod_price

        # Revenue from fertilizer (sold at base price)
        fert_price = MARKET_PARAMS["FERTILIZER"]["base"]
        fert_revenue = fert_yield * fert_price

        total_revenue = prod_revenue + fert_revenue

        # Wheat cost for feeding (1 wheat/day for the animal's lifetime)
        wheat_price = MARKET_PARAMS["WHEAT"]["base"]
        wheat_cost = TOTAL_DAYS * wheat_price

        net_profit = total_revenue - cost - wheat_cost

        # $/tile-day: net profit / (30 days * 1 tile)
        dollar_per_tile_day = net_profit / TOTAL_DAYS

        # $/action: each animal needs ~3 actions/day (FEED, CARE, HARVEST/COLLECT_FERTILIZER)
        # Plus setup actions (BUILD_PASTURE/COOP, PLACE).
        # Approximate: 2.5 worker-actions/day for the productive period
        actions_per_day = 3.0  # FEED + CARE + (HARVEST or COLLECT_FERT)
        total_actions = actions_per_day * TOTAL_DAYS + 3  # +3 for setup
        dollar_per_action = net_profit / total_actions

        print(f"{atype:>8}  {cost:5d}  {product:>8}  day {first_day:2d}     "
              f"{prod_yield:6d}      {fert_yield:3d}   "
              f"${dollar_per_tile_day:6.0f}   ${dollar_per_action:7.0f}     1")


def test_animal_returns_with_market():
    """More realistic: actually sell into the market and track price impact."""
    divider("Animal Returns (with market price impact, CARE=True)")

    print(f"\n{'Animal':>8}  {'Cost':>5}  {'Prod':>5}  {'Fert':>5}  "
          f"{'Prod Rev':>9}  {'Fert Rev':>9}  {'Feed Cost':>9}  "
          f"{'Net':>8}  {'$/tile-day':>10}")

    for atype in ("SHEEP", "COW", "GOOSE"):
        a = ANIMALS[atype]
        cost = a["cost"]
        product = a["product"]
        prod_yield, fert_yield, first_day = animal_total_yield(atype, place_day=0, care=True)

        # Sell product into market starting at equilibrium
        prod_rev, _ = sell_n_units(product, prod_yield, MARKET_I0)

        # Sell fertilizer
        fert_rev, _ = sell_n_units("FERTILIZER", fert_yield, MARKET_I0)

        # Buy wheat to feed (1/day)
        feed_cost = TOTAL_DAYS * MARKET_PARAMS["WHEAT"]["base"]

        net = prod_rev + fert_rev - cost - feed_cost
        per_tile_day = net / TOTAL_DAYS

        print(f"{atype:>8}  {cost:5d}  {prod_yield:5d}  {fert_yield:5d}  "
              f"${prod_rev:8,d}  ${fert_rev:8,d}  ${feed_cost:8,d}  "
              f"${net:7,d}  ${per_tile_day:9.0f}")


# ---------------------------------------------------------------------------
# Test 3: Crop returns
# ---------------------------------------------------------------------------

def test_crop_returns():
    divider("Crop Returns (single crop, planted day 0, 30-day game)")

    print(f"\n{'Crop':>12}  {'Seed':>5}  {'Harvest':>7}  {'Yield':>6}  "
          f"{'Revenue':>8}  {'Net':>7}  {'$/tile-day':>10}  {'$/action':>8}")

    for ctype in ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON"):
        cd = CROPS[ctype]
        seed_cost = cd["seed"]
        total_yield, harvest_day = crop_total_yield(ctype, plant_day=0)

        # Revenue at base price (sell into equilibrium market)
        revenue, _ = sell_n_units(ctype, total_yield, MARKET_I0)

        net = revenue - seed_cost

        # Tile occupancy: from plant day to harvest day
        if cd["ongoing"]:
            last_prod_day = cd["first_yield_day"] + (cd["max_yield"] - 1) * cd["interval"]
            tile_days = last_prod_day
        else:
            tile_days = cd["max_yield_day"]  # harvested at max_yield_day
        tile_days = max(1, tile_days)
        per_tile_day = net / tile_days

        # Actions: PLANT(1) + WATER(daily during growth) + HARVEST(1 or multiple)
        water_days = min(cd["max_yield_day"], TOTAL_DAYS)
        n_harvests = cd["max_yield"] if cd["ongoing"] else 1
        total_actions = 1 + water_days + n_harvests
        per_action = net / max(1, total_actions)

        print(f"{ctype:>12}  {seed_cost:5d}  day {harvest_day:2d}   {total_yield:5d}  "
              f"${revenue:7,d}  ${net:6,d}  ${per_tile_day:9.0f}    ${per_action:7.0f}")


# ---------------------------------------------------------------------------
# Test 4: Shop consumption impact
# ---------------------------------------------------------------------------

def test_shop_consumption():
    divider("Shop Consumption per Day")

    # Test with various shop combos
    configs = [
        ("No shops", []),
        ("1x YARN_STORE", ["YARN_STORE"]),
        ("2x YARN_STORE", ["YARN_STORE", "YARN_STORE"]),
        ("PIZZA+YARN", ["PIZZA_SHOP", "YARN_STORE"]),
        ("All 8 distinct", list(SHOPS.keys())),
    ]

    for name, shops in configs:
        cons = shop_consumption_per_day(shops)
        non_zero = {k: v for k, v in cons.items() if v > 0}
        print(f"\n  {name}:")
        for prod, n in sorted(non_zero.items(), key=lambda x: -x[1]):
            print(f"    {prod:>12}: {n:3d} units/day consumed")


# ---------------------------------------------------------------------------
# Test 5: Demand caps (how many units can be sold before price hits floor)
# ---------------------------------------------------------------------------

def test_demand_caps():
    divider("Demand Caps (units above equilibrium before price=$1)")

    print(f"\n{'Product':>12}  {'Base':>5}  {'Above Func':>10}  {'Floor@':>7}  "
          f"{'Total Rev':>10}  {'Avg Price':>9}")

    for prod in PRODUCTS:
        p = MARKET_PARAMS[prod]

        # Find floor point
        floor_at = None
        for delta in range(1, 20000):
            if market_price(prod, MARKET_I0 + delta) <= PRICE_FLOOR:
                floor_at = delta
                break

        # Revenue from selling floor_at units (or 200 if no floor found)
        sell_count = floor_at if floor_at else 200
        total_rev, _ = sell_n_units(prod, sell_count, MARKET_I0)
        avg_price = total_rev / max(1, sell_count)

        floor_str = f"{floor_at}" if floor_at else ">20k"
        print(f"{prod:>12}  {p['base']:5d}  {p['above_func']:>10}  {floor_str:>7}  "
              f"${total_rev:9,d}  ${avg_price:8.1f}")


# ---------------------------------------------------------------------------
# Test 6: Asset return table (the target table)
# ---------------------------------------------------------------------------

def test_asset_return_table():
    divider("Asset Return Table (Target Reproduction)")

    print(f"\n{'Asset':>10}  {'Cost':>5}  {'1st Yield':>9}  {'$/tile-day':>10}  "
          f"{'$/action':>8}  {'Demand Cap':>10}  {'Notes':>30}")

    # --- SHEEP ---
    a = ANIMALS["SHEEP"]
    prod_yield, fert_yield, first_day = animal_total_yield("SHEEP", 0, care=True)
    prod_rev, _ = sell_n_units("WOOL", prod_yield, MARKET_I0)
    fert_rev, _ = sell_n_units("FERTILIZER", fert_yield, MARKET_I0)
    feed_cost = TOTAL_DAYS * MARKET_PARAMS["WHEAT"]["base"]
    net = prod_rev + fert_rev - a["cost"] - feed_cost
    ptd = net / TOTAL_DAYS
    # ~3 actions/day * 30 days = 90
    pa = net / 93
    # Demand cap for wool: per Yarn Store
    yarn_cons = shop_consumption_per_day(["YARN_STORE"])
    wool_per_day = yarn_cons.get("WOOL", 0)
    print(f"{'SHEEP':>10}  {a['cost']:5d}  day {first_day:2d}     ${ptd:9.0f}  ${pa:7.0f}  "
          f"{wool_per_day:3d}/day/Yarn   "
          f"prod={prod_yield}, fert={fert_yield}")

    # --- COW ---
    a = ANIMALS["COW"]
    prod_yield, fert_yield, first_day = animal_total_yield("COW", 0, care=True)
    prod_rev, _ = sell_n_units("MILK", prod_yield, MARKET_I0)
    fert_rev, _ = sell_n_units("FERTILIZER", fert_yield, MARKET_I0)
    net = prod_rev + fert_rev - a["cost"] - feed_cost
    ptd = net / TOTAL_DAYS
    pa = net / 93
    milk_shops = ["PIZZA_SHOP", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP"]
    milk_cons = {s: shop_consumption_per_day([s]).get("MILK", 0) for s in milk_shops}
    print(f"{'COW':>10}  {a['cost']:5d}  day {first_day:2d}     ${ptd:9.0f}  ${pa:7.0f}  "
          f"varies/shop  "
          f"prod={prod_yield}, fert={fert_yield}")

    # --- GOOSE ---
    a = ANIMALS["GOOSE"]
    prod_yield, fert_yield, first_day = animal_total_yield("GOOSE", 0, care=True)
    prod_rev, _ = sell_n_units("EGG", prod_yield, MARKET_I0)
    fert_rev, _ = sell_n_units("FERTILIZER", fert_yield, MARKET_I0)
    net = prod_rev + fert_rev - a["cost"] - feed_cost
    ptd = net / TOTAL_DAYS
    pa = net / 93
    print(f"{'GOOSE':>10}  {a['cost']:5d}  day {first_day:2d}     ${ptd:9.0f}  ${pa:7.0f}  "
          f"glut-immune  "
          f"prod={prod_yield}, fert={fert_yield}")

    # --- MELON ---
    cd = CROPS["MELON"]
    total_yield, harvest_day = crop_total_yield("MELON", 0)
    rev, _ = sell_n_units("MELON", total_yield, MARKET_I0)
    net = rev - cd["seed"]
    tile_days = cd["max_yield_day"]
    ptd = net / max(1, tile_days)
    actions = 1 + cd["max_yield_day"] + 1  # PLANT + WATER days + HARVEST
    pa = net / max(1, actions)
    # Melon floor
    melon_floor = None
    for d in range(1, 20000):
        if market_price("MELON", MARKET_I0 + d) <= PRICE_FLOOR:
            melon_floor = d
            break
    print(f"{'MELON':>10}  {cd['seed']:5d}  day {cd['first_yield_day']:2d}     ${ptd:9.0f}  ${pa:7.0f}  "
          f"~{melon_floor} pool    "
          f"yield={total_yield}")


# ---------------------------------------------------------------------------
# Test 7: Full fluid model sim
# ---------------------------------------------------------------------------

def test_full_sim():
    divider("Full Fluid Model Simulations")

    # Scenario 1: Pure sheep farm with YARN_STORE
    print("\n--- Scenario 1: 10 sheep, YARN_STORE in shops ---")
    shops = ["YARN_STORE", "BAKERY", "PIZZA_SHOP", "FARMERS_MARKET",
             "BRUNCH_SPOT", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP", "PET_CAFE"]
    alloc = np.array([10, 0, 0, 0, 0, 0, 0, 0, 12, 2, 5, 10, 0, 0, 15])
    score = simulate_allocation(alloc, shops)
    print(f"  Final money: ${score:,.0f}")

    # Scenario 2: Pure sheep farm WITHOUT YARN_STORE
    print("\n--- Scenario 2: 10 sheep, NO YARN_STORE ---")
    shops2 = ["PIZZA_SHOP", "BAKERY", "FARMERS_MARKET", "BRUNCH_SPOT",
              "ICE_CREAM_SHOP", "SMOOTHIE_SHOP", "PET_CAFE", "PIZZA_SHOP"]
    score2 = simulate_allocation(alloc, shops2)
    print(f"  Final money: ${score2:,.0f}")
    print(f"  YARN_STORE premium: ${score - score2:,.0f}")

    # Scenario 3: Mixed farm
    print("\n--- Scenario 3: Mixed farm (6 sheep, 4 cow, 3 goose, some crops) ---")
    alloc3 = np.array([6, 4, 3, 5, 3, 2, 2, 2, 12, 2, 5, 10, 0, 0, 10])
    score3 = simulate_allocation(alloc3, shops)
    print(f"  Final money: ${score3:,.0f}")

    # Scenario 4: Pure crop farm
    print("\n--- Scenario 4: Crop-only farm ---")
    alloc4 = np.array([0, 0, 0, 10, 8, 4, 4, 4, 12, 2, 5, 10, 0, 0, 0])
    score4 = simulate_allocation(alloc4, shops)
    print(f"  Final money: ${score4:,.0f}")

    # Scenario 5: Goose spam (glut-immune)
    print("\n--- Scenario 5: 15 geese, no crops ---")
    alloc5 = np.array([0, 0, 15, 0, 0, 0, 0, 0, 12, 2, 5, 10, 0, 0, 10])
    score5 = simulate_allocation(alloc5, shops2)  # No yarn
    print(f"  Final money: ${score5:,.0f}")


# ---------------------------------------------------------------------------
# Test 8: Speed benchmark
# ---------------------------------------------------------------------------

def test_speed():
    import time
    divider("Speed Benchmark")

    shops = ["YARN_STORE", "BAKERY", "PIZZA_SHOP", "FARMERS_MARKET",
             "BRUNCH_SPOT", "ICE_CREAM_SHOP", "SMOOTHIE_SHOP", "PET_CAFE"]
    alloc = np.array([10, 4, 3, 5, 3, 2, 2, 2, 12, 2, 5, 10, 0, 0, 15])

    # Warmup
    for _ in range(10):
        simulate_allocation(alloc, shops)

    N = 5000
    t0 = time.perf_counter()
    for _ in range(N):
        simulate_allocation(alloc, shops)
    elapsed = time.perf_counter() - t0

    ms_per_sim = elapsed / N * 1000
    sims_per_sec = N / elapsed
    print(f"\n  {N} simulations in {elapsed:.2f}s")
    print(f"  {ms_per_sim:.3f} ms/sim")
    print(f"  {sims_per_sec:,.0f} sims/sec")
    if ms_per_sim < 1.0:
        print(f"  TARGET MET: <1ms per sim")
    else:
        print(f"  TARGET MISSED: {ms_per_sim:.2f}ms > 1ms target")


# ---------------------------------------------------------------------------
# Run all tests
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    test_price_curves()
    test_animal_returns()
    test_animal_returns_with_market()
    test_crop_returns()
    test_shop_consumption()
    test_demand_caps()
    test_asset_return_table()
    test_full_sim()
    test_speed()
