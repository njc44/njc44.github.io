"""Extract opponent action tapes from Kaggle replay JSONs.

Parses replay files, identifies which agent is ours (via step-712 duration
fingerprint), and extracts the opponent's complete 720-action tape.

Each extracted opponent becomes a replay-agent we can test against locally.
"""
import json
import os
from pathlib import Path

REPLAY_DIR = Path("/tmp/ep_replays")
LOG_DIR = Path("/tmp/ep_logs")
OUTPUT_DIR = Path("/tmp/kaggriculture_opponents")

# Our submission IDs
OUR_SUBMISSIONS = {
    56134583: "hybrid_v1",
    56126656: "shop_router",
}


def identify_our_seat(ep_id):
    """Use agent-0 step-712 duration to identify which seat is ours.

    Our agents (Hybrid V1 / Shop Router) have reactive layers that take
    measurable time at step 712. Pure tape-replay opponents are near-zero.

    Returns 0 if we're agent 0, 1 if we're agent 1, -1 if unknown.
    """
    log_path = LOG_DIR / f"episode-{ep_id}-agent-0-logs.json"
    if not log_path.exists():
        return -1
    try:
        with open(log_path) as f:
            logs = json.load(f)
        if isinstance(logs, list) and len(logs) > 712:
            entry = logs[712]
            if isinstance(entry, list) and entry:
                dur = entry[0].get("duration", 0)
                # Our agents take 0.01-0.15s at step 712; tape agents ~0
                return 0 if dur > 0.005 else 1
    except Exception:
        pass
    return -1


def extract_opponent_tape(replay_path, our_seat):
    """Extract the opponent's 720-step action sequence from a replay."""
    with open(replay_path) as f:
        replay = json.load(f)

    steps = replay.get("steps", [])
    if len(steps) != 720:
        return None

    opp_seat = 1 - our_seat
    actions = []
    for step_data in steps:
        action = step_data[opp_seat].get("action", {})
        actions.append(action)

    # Extract metadata
    final = steps[-1]
    our_reward = final[our_seat].get("reward", 0)
    opp_reward = final[opp_seat].get("reward", 0)
    our_status = final[our_seat].get("status", "")
    opp_status = final[opp_seat].get("status", "")

    # Get shop info from step 144
    obs144 = steps[144][opp_seat].get("observation", {})
    shops = obs144.get("town", {}).get("unlocked_shops", [])

    # Count sell activity
    sell_steps = sum(1 for a in actions if a.get("market"))

    # Get opponent's number of workers from first action with hands
    max_hands = 0
    for a in actions:
        hands = a.get("hands", [])
        if len(hands) > max_hands:
            max_hands = len(hands)

    return {
        "actions": actions,
        "opp_reward": opp_reward,
        "our_reward": our_reward,
        "we_won": our_reward > opp_reward,
        "shops": shops[:2] if shops else [],
        "sell_steps": sell_steps,
        "max_workers": 1 + max_hands,
        "opp_status": opp_status,
    }


def extract_all():
    """Extract opponent tapes from all downloaded replays."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    opponents = []

    for replay_file in sorted(REPLAY_DIR.glob("episode-*-replay.json")):
        ep_id = int(replay_file.stem.split("-")[1])
        our_seat = identify_our_seat(ep_id)

        if our_seat == -1:
            continue

        result = extract_opponent_tape(replay_file, our_seat)
        if result is None:
            continue

        # Skip if opponent errored
        if result["opp_status"] not in ("DONE", "ACTIVE"):
            continue

        opp_entry = {
            "episode_id": ep_id,
            "our_seat": our_seat,
            "opp_reward": result["opp_reward"],
            "our_reward": result["our_reward"],
            "we_won": result["we_won"],
            "shops": result["shops"],
            "sell_steps": result["sell_steps"],
            "max_workers": result["max_workers"],
        }
        opponents.append(opp_entry)

        # Save the action tape
        tape_path = OUTPUT_DIR / f"opp_{ep_id}.json"
        with open(tape_path, "w") as f:
            json.dump(result["actions"], f)

    # Save index
    index_path = OUTPUT_DIR / "index.json"
    with open(index_path, "w") as f:
        json.dump(opponents, f, indent=2)

    # Print summary
    print(f"Extracted {len(opponents)} opponent tapes")
    print(f"\nWin/Loss against our agents:")
    wins = sum(1 for o in opponents if o["we_won"])
    losses = len(opponents) - wins
    print(f"  Our wins: {wins}, Our losses: {losses}")

    print(f"\nOpponent strength distribution:")
    rewards = sorted([o["opp_reward"] for o in opponents])
    print(f"  Min reward: {min(rewards):.0f}")
    print(f"  Median reward: {rewards[len(rewards)//2]:.0f}")
    print(f"  Max reward: {max(rewards):.0f}")

    print(f"\nShop pairs seen:")
    from collections import Counter
    shop_counts = Counter(tuple(o["shops"]) for o in opponents)
    for shops, count in shop_counts.most_common(10):
        print(f"  {shops}: {count}")

    print(f"\nWorker counts:")
    worker_counts = Counter(o["max_workers"] for o in opponents)
    for workers, count in sorted(worker_counts.items()):
        print(f"  {workers} workers: {count}")

    print(f"\nSelling intensity (steps with sells):")
    sell_intensities = sorted([o["sell_steps"] for o in opponents])
    print(f"  Min: {min(sell_intensities)}, Median: {sell_intensities[len(sell_intensities)//2]}, Max: {max(sell_intensities)}")

    # Flag opponents that beat us badly (good test cases)
    hard_opponents = [o for o in opponents if not o["we_won"] and o["opp_reward"] - o["our_reward"] > 10000]
    print(f"\nHard opponents (beat us by >10K): {len(hard_opponents)}")
    for o in hard_opponents:
        print(f"  Ep {o['episode_id']}: {o['opp_reward']:.0f} vs {o['our_reward']:.0f} (margin: {o['opp_reward']-o['our_reward']:+.0f})")


if __name__ == "__main__":
    extract_all()
