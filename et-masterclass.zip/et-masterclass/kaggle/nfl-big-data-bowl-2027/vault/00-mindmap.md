# NFL BDB 2027 — Master Mindmap

## The Game → The Data → The Scout → The Submission

```
AMERICAN FOOTBALL
├── SCORING
│   ├── Touchdown (6 pts) — 3.9% of plays
│   │   ├── Completed pass into end zone (66% of TDs)
│   │   ├── Rush into end zone
│   │   └── Turnover return (INT/fumble)
│   ├── Extra Point (1 pt) — kick after TD, 94% success
│   ├── 2-Point Conversion (2 pts) — run/pass from 2-yd line, ~50% success
│   ├── Field Goal (3 pts) — kick through uprights, range ~50 yards
│   └── Safety (2 pts) — defense tackles offense in own end zone (rare)
│
├── PLAY STRUCTURE
│   ├── 4 downs to gain 10 yards
│   │   ├── 1st & 10 → exploratory (3.3% TD rate)
│   │   ├── 2nd down → adjust based on 1st down result
│   │   ├── 3rd down → CRITICAL conversion play (4.7% TD rate)
│   │   └── 4th down → punt/FG/go-for-it (9.5% TD rate if attempted)
│   ├── Pass plays: avg 5.9 yards, -0.015 EPA
│   └── Run plays: avg 3.6 yards, -0.116 EPA (passing is more efficient)
│
├── PASS OUTCOMES (the currency of the passing game)
│   ├── Complete (C): 10.4 yards, +0.74 EPA ← THE GOAL
│   ├── Incomplete (I): 0.7 yards, -0.77 EPA ← wasted down
│   ├── Scramble (R): 6.8 yards, +0.39 EPA ← QB runs instead
│   ├── Sack (S): -6.2 yards, -1.78 EPA ← OL failed
│   └── Interception (IN): 0.0 yards, -4.40 EPA ← catastrophe
│
├── POSITION GROUPS & THEIR JOBS
│   ├── OFFENSE
│   │   ├── WR (Wide Receiver) — run routes, create separation, catch
│   │   │   ├── Success metric: SEPARATION at the throw
│   │   │   │   ├── <1.5 yd sep → 34% catch rate
│   │   │   │   ├── 3-4.5 yd sep → 72% catch rate
│   │   │   │   └── 6+ yd sep → 84% catch rate
│   │   │   ├── Route types and their demands:
│   │   │   │   ├── GO (33% catch, 27.9 yd) → pure straight-line speed
│   │   │   │   ├── POST (51% catch, 25.6 yd) → speed + angle change
│   │   │   │   ├── CROSS (68% catch, 12.0 yd) → change of direction
│   │   │   │   ├── HITCH (70% catch, 9.7 yd) → deceleration quality
│   │   │   │   ├── SLANT (66% catch, 10.5 yd) → burst off the line
│   │   │   │   └── SCREEN (91% catch, 5.6 yd) → scheme, not athleticism
│   │   │   └── Combine connection: route drills, agility, 40-yard dash
│   │   │
│   │   ├── OL (Offensive Line: T, G, C) — protect the QB
│   │   │   ├── Success metric: PRESSURE ALLOWED rate (8.2% avg)
│   │   │   ├── Clean pocket → 6.4 yards, 0.00 EPA
│   │   │   ├── Pressure allowed → 2.5 yards, -0.61 EPA
│   │   │   ├── Sack allowed rate: 0.97%
│   │   │   └── Combine connection: shuttle, 3-cone, pass-pro mirror drill
│   │   │
│   │   ├── TE (Tight End) — hybrid blocker/receiver
│   │   │   └── Combine connection: mix of OL and WR drill traits
│   │   │
│   │   └── RB (Running Back) — carry the ball on run plays
│   │       └── Only 1 RB in this dataset (not viable for analysis)
│   │
│   └── DEFENSE
│       ├── DL/EDGE (Defensive Line) — rush the QB, stop the run
│       │   ├── Success metric: GET-OFF TIME → sacks/pressures
│       │   │   ├── <0.6s get-off → 2.4% sack rate
│       │   │   ├── 0.9-1.2s get-off → 1.0% sack rate
│       │   │   └── Quick pressure (<2.5s): 31% of pressures
│       │   └── Combine connection: 10-yd split, first-step burst
│       │
│       ├── CB/DB (Cornerbacks/Defensive Backs) — cover receivers
│       │   ├── Success metric: limiting separation (mirroring WR)
│       │   └── Combine connection: backpedal drills, shuttle, 40-yd dash
│       │
│       └── LB (Linebackers) — versatile (rush/cover/tackle)
│           └── Only 3 in dataset (not viable)
│
├── COVERAGE SCHEMES (defensive strategy)
│   ├── COVER_3_ZONE (35K plays) — 3 deep defenders, 4 underneath
│   ├── COVER_1_MAN (20K plays) — man-to-man + 1 deep safety
│   ├── COVER_4_ZONE (15K plays) — 4 deep defenders (prevent big plays)
│   ├── COVER_0_MAN (7K plays) — all-out man coverage, no safety help
│   │   └── Lowest avg yards (2.8) but risky — if beaten, it's a TD
│   └── Others: COVER_2_ZONE, COVER_6_ZONE, COVER_2_MAN, PREVENT
│
└── FORMATIONS (offensive pre-snap alignment)
    ├── SHOTGUN (64K) — QB stands 5 yards back, 3.8% TD rate
    ├── SINGLEBACK (27K) — 1 RB behind QB, balanced
    ├── EMPTY (8K) — no RB, all receivers, 4.6% TD rate
    ├── I_FORM (6K) — fullback + halfback, power running
    ├── PISTOL (6K) — hybrid shotgun/under-center
    └── JUMBO (1K) — extra OL, goal-line package, 21.9% TD rate
```

## The Combine → NFL Pipeline

```
NFL SCOUTING COMBINE (Indianapolis, every spring)
│
├── TRADITIONAL TESTS (stopwatch numbers)
│   ├── 40-yard dash — straight-line speed
│   │   ├── 83% of players tested
│   │   └── 10-yard split — first-step explosiveness
│   ├── 3-cone drill — agility (only 35% tested!)
│   ├── Short shuttle — lateral quickness (39% tested)
│   ├── Vertical jump — lower body power (86% tested)
│   ├── Broad jump — explosive power (83% tested)
│   └── Bench press — upper body strength (38% tested)
│
├── TRACKING DATA (NEW — 10 Hz sensors)
│   ├── 463K frames across 6,310 drill attempts
│   ├── 56 unique drill names across 9 categories
│   ├── Columns: x, y, speed, acceleration, distance, direction
│   ├── Position-specific drills:
│   │   ├── WR: gauntlet, route drills (go, post, comeback, curl, slant)
│   │   ├── DB: backpedal, zone breaks, transition drills
│   │   ├── DL: pass rush, contain, speed-to-power
│   │   ├── OL: pull drill, pass-pro mirror, kick-slide
│   │   └── TE: hybrid drills
│   └── DATA QUALITY WARNINGS (from Darius audit):
│       ├── First 10 yards tracking unreliable (r=0.28 vs official)
│       ├── 10-to-40 split is reliable (r=0.95)
│       ├── `dis` column is step-squared in combine (not distance!)
│       ├── Ball entities carry player nfl_ids (bug)
│       └── Preseason games included but undocumented
│
├── NGS SCORES (composite evaluations)
│   ├── Athleticism score: mean=72.5 (0-100 scale)
│   ├── College production score: mean=67.5
│   └── Final score: mean=70.3
│
└── CAREER OUTCOMES (what we're predicting)
    ├── 510 players across 2023-2025 draft classes
    ├── 127 UDFAs (25%)
    ├── Only 11 Pro Bowlers, 6 All-Pro 1st team
    ├── Median games started = 2 (most players barely play)
    └── KEY CONSTRAINT: only ~243 have BOTH tracked combine
        data AND enough NFL snaps for meaningful analysis
```
