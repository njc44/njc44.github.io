# Defensive Coverage Schemes

## Coverage Types and Their Effectiveness
| Scheme | Plays | Avg EPA | Avg Yards | Philosophy |
|---|---|---|---|---|
| COVER_3_ZONE | 35,811 | -0.069 | 5.6 | 3 deep, 4 under — balanced |
| COVER_1_MAN | 19,970 | -0.053 | 5.5 | Man-to-man + 1 safety — aggressive |
| COVER_4_ZONE | 15,168 | -0.042 | 5.4 | 4 deep — prevent big plays |
| COVER_2_ZONE | 11,396 | -0.055 | 6.1 | 2 deep, 5 under — vulnerable middle |
| COVER_6_ZONE | 7,939 | -0.016 | 6.2 | Hybrid (Cover 2 one side, Cover 4 other) |
| COVER_0_MAN | 7,133 | -0.062 | 2.8 | All-out man, NO safety — high risk/reward |
| COVER_2_MAN | 948 | -0.013 | 5.9 | Man coverage + 2 deep safeties |
| PREVENT | 214 | -0.395 | 6.0 | Late-game prevent — give up yards, burn clock |

## Key Insight
- MAN coverage (COVER_0, COVER_1) → lower yards allowed but higher variance
  - COVER_0 allows only 2.8 yards avg but if the WR beats man coverage, it's a TD
- ZONE coverage → more consistent but gives up more yards
- Negative EPA across ALL coverages → defense slightly favored on average

## Why This Matters for the Competition
- The `coverage_assignment` column tells us what each DB is doing
- WR separation metrics can be split by man vs zone coverage
- A WR who creates separation in COVER_0_MAN (no safety help) is elite
- Combine agility drills may predict man-coverage separation differently
  than zone-coverage separation
