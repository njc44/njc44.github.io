# NFL BDB 2027 Vault — Index

## Knowledge Base
| File | Contents |
|---|---|
| [00-mindmap.md](00-mindmap.md) | Master mindmap — game → data → scout → submission |
| [01-scoring-mechanics.md](01-scoring-mechanics.md) | Scoring types, EPA economics, down/distance context |
| [02-receiver-separation.md](02-receiver-separation.md) | WR separation ladder, route demands, combine connection |
| [03-pass-rush.md](03-pass-rush.md) | DL get-off → sacks, time to pressure, combine pipeline |
| [04-ol-protection.md](04-ol-protection.md) | OL pressure rates, available metrics, unclaimed territory |
| [05-coverage-schemes.md](05-coverage-schemes.md) | Man vs zone coverage, EPA by scheme |
| [06-data-constraints.md](06-data-constraints.md) | Sample sizes, tracking quality, confounders |
| [07-competitor-landscape.md](07-competitor-landscape.md) | 3 competitor notebooks analyzed |
| [08-scout-decision-points.md](08-scout-decision-points.md) | 5 scout decisions, reverse-engineered analysis targets |
