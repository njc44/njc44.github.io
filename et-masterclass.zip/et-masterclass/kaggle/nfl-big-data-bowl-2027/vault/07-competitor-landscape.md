# Competitor Landscape (as of Oct 8, 2026)

## Published Notebooks

### 1. mpwolke — "NFL Big Data Bowl 2027"
- **Quality**: Low. Copy-paste EDA, value_counts() bar charts
- **Approach**: Loads data, plots frequencies, no combine→NFL linkage
- **Threat**: None. Career data loaded but never used
- **Gap**: Everything

### 2. jek1wantaufik — "Combine Movement to NFL Performance"
- **Quality**: High. 66 sections, rigorous methodology
- **Approach**: WR-focused. Engineers movement traits from Gauntlet drill
  - Burst, braking, movement efficiency from 10 Hz tracking
  - Partial correlations beyond 40-yard dash
  - LODCO cross-val, bootstrap CIs, permutation tests
- **Finding**: Movement rate (distance/duration in Gauntlet) adds signal beyond 40 time for predicting route-adjusted NFL speed
- **Status**: Code-complete but UNEXECUTED — no outputs yet
- **Threat**: High for WR angle. But hasn't proven results run cleanly
- **Gap**: Only WR, only Gauntlet drill, no OL/DL

### 3. dariushafshar — "Combine Tracking Audit"
- **Quality**: Grandmaster-level. Self-verifying, color-blind safe
- **Approach**: Measurement-quality audit before any modeling
  - Discovers tracking first-10-yard unreliability (r=0.28)
  - Permutation noise floors per position group
  - Reliability ceilings from test-retest
  - DL burst case study (confounded by weight)
- **Finding**: Most naive combine→NFL correlations are noise at these n's
- **Threat**: Very high — sets the methodological bar
- **Gap**: Audit only, no actionable scouting recommendation

### 4. Our starter — "NFL BDB 2027 Starter"
- **Quality**: Solid starter. Comprehensive data overview
- **Status**: Published and running on Kaggle
- **URL**: https://www.kaggle.com/code/nathanjacob/nfl-bdb-2027-starter-combine-to-nfl

### 5. Our submission — "Beyond the 40: OL Pass Protection"
- **Quality**: High. 8 figures, bootstrap CIs, permutation tests, partial correlations
- **Approach**: OL-focused. Shows 40 is useless (r=0.01), 5-Yard Wave max_accel predicts pressure rate (r=-0.29, p<0.05), survives draft/size controls. PPR composite score with case studies.
- **Status**: Published and running on Kaggle
- **URL**: https://www.kaggle.com/code/nathanjacob/nfl-bdb-2027-beyond-the-40-ol-pass-protection
- **Unique angle**: Only OL analysis in the competition

## Unclaimed Territory
- OL pass protection (nobody touching this)
- DB coverage metrics
- Cross-position deceleration quality
- Route-specific combine drill mapping
- In-game vs combine movement signature comparison
