# Data Constraints & Quality Issues

## Sample Size Problem (from Darius audit)
- 510 total prospects
- Only ~243 have BOTH combine tracking AND enough NFL snaps
- Per-position n: 18 (TE) to 62 (DB)
- At n=50, need |r| > 0.28 for p<0.05 on a SINGLE pre-chosen test
- If searching 18 metrics, permutation threshold is |r| > 0.36-0.68

## Tracking Data Quality
| Issue | Detail | Impact |
|---|---|---|
| First 10 yards unreliable | r=0.28 vs official 10-yd split | Avoid burst metrics from first frames |
| 10-to-40 split reliable | r=0.95 vs official | Use mid-sprint metrics safely |
| `dis` column is squared | Sums to 36.7 yd over 40-yd dash | Do NOT use raw — recompute from x,y |
| Ball entities have player IDs | Bug in data | Filter entity_type == 'PLAYER' |
| Preseason included | Undocumented 16% of plays | Filter season_type == 'REG' |
| Game tracking 2.6x documented | More rows than spec says | Not a problem, just unexpected |

## Drill Coverage Gaps
| Drill | Coverage | Problem |
|---|---|---|
| 40-yard dash | 83% | Solid |
| Vertical jump | 86% | Solid |
| Broad jump | 83% | Solid |
| 3-cone drill | 35% | Most players skip it |
| Short shuttle | 39% | Most players skip it |
| Bench press | 38% | Most players skip it |

The agility drills (3-cone, shuttle) have the lowest coverage — which is
ironic because they're the most relevant for route-running and pass protection.

## Career Outcome Limitations
- Only 3 draft classes (2023-2025) — max 3 NFL seasons of data
- 2025 class has only ~1 season of data
- Median games started = 2 — most players barely played
- Only 11 Pro Bowlers, 6 All-Pro — too few for binary outcome analysis
- Career snaps is a better continuous outcome than honors

## Confounders
- Weight confounds DL burst (r=0.67 raw → r=0.35 partial)
- Draft position confounds playing time (high picks get more chances)
- Team context matters (a WR on a bad team gets fewer targets)
- Year-of-entry bias (2023 class has more NFL data than 2025)
