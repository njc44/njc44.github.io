# Scoring Mechanics & What Drives Points

## Scoring Types
| Play | Points | Frequency | Key driver |
|---|---|---|---|
| Touchdown | 6 | 3.9% of plays | Completed pass or rush into end zone |
| Extra Point | 1 | After every TD | Specialist kicker, 94% auto |
| 2-Point Conversion | 2 | Rare choice after TD | Risky (~50%), used when trailing |
| Field Goal | 3 | When stalled near opponent | Kicker range ~50 yards |
| Safety | 2 | Very rare | Defense tackles offense in own end zone |

## Play Outcome Economics (EPA = Expected Points Added)
| Outcome | Avg Yards | Avg EPA | Meaning |
|---|---|---|---|
| Complete pass | +10.4 | +0.74 | Good — drive continues |
| Scramble | +6.8 | +0.39 | OK — QB runs, less ideal |
| Incomplete | +0.7 | -0.77 | Bad — wasted down |
| Sack | -6.2 | -1.78 | Very bad — lost yardage + down |
| Interception | 0.0 | -4.40 | Catastrophic — turnover |

## Down-and-Distance Context
- 1st & 10: exploratory play, 3.3% TD rate
- 3rd down: critical conversion, 4.7% TD rate
- 4th down: desperation/confidence, 9.5% TD rate
- 1-3 yards to go: 10.5% TD rate (close to goal line)
- 21+ yards to go: 1.2% TD rate

## Formation Impact
- JUMBO: 21.9% TD rate — goal-line power package
- EMPTY: 4.6% TD rate — max receivers, aggressive passing
- SHOTGUN: 3.8% — standard passing formation (64K plays)
- Pass plays average 5.9 yards vs run plays 3.6 yards
