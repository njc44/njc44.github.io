# WR Separation — The #1 Receiver Metric

## The Core Finding
Separation at the moment of the throw is the strongest single predictor of pass completion.
Going from tight coverage to open doubles the catch rate.

## Separation → Outcome Ladder
| Separation | Catch Rate | Avg Rec Yards | Avg YAC | Interpretation |
|---|---|---|---|---|
| 0-1.5 yd | 34% | 16.4 | 3.2 | Tight coverage — contested catch |
| 1.5-3.0 yd | 57% | 14.5 | 3.6 | Moderate window |
| 3.0-4.5 yd | 72% | 11.4 | 4.1 | Open enough for reliable catches |
| 4.5-6.0 yd | 79% | 10.1 | 5.0 | Wide open |
| 6.0+ yd | 84% | 9.8 | 6.5 | Schematic or elite separation |

Note: yards DECREASE with more separation because deep routes (GO, POST) have
low separation but huge yardage when caught. Short routes (SCREEN, FLAT) have
high separation but fewer yards.

## Pre-Snap Cushion (distance between WR and DB before the play starts)
| Cushion | Catch Rate |
|---|---|
| 0-3 yd (press coverage) | 50% |
| 3-5 yd | 62% |
| 5-7 yd | 65% |
| 7-10 yd | 65% |
| 10-20 yd (off coverage) | 72% |

Cushion helps but plateaus — the real separation is created DURING the route.

## Route-Specific Separation Demands
| Route | Catch% | Yards | Separation | What physical trait matters |
|---|---|---|---|---|
| SCREEN | 91% | 5.6 | 6.2 yd | Scheme-created — not athleticism |
| FLAT | 82% | 7.2 | 5.7 yd | Scheme — short outlet |
| HITCH | 70% | 9.7 | 3.8 yd | DECELERATION — stop on a dime |
| CROSS | 68% | 12.0 | 3.8 yd | CHANGE OF DIRECTION across field |
| SLANT | 66% | 10.5 | 3.0 yd | BURST off the line + quick cut |
| OUT | 66% | 9.4 | 3.5 yd | Sharp break to sideline |
| IN | 57% | 14.3 | 3.2 yd | Sharp break inside |
| POST | 51% | 25.6 | 3.0 yd | SPEED + angle change at depth |
| CORNER | 42% | 23.3 | 3.1 yd | Speed + break to sideline |
| GO | 33% | 27.9 | 2.0 yd | PURE STRAIGHT-LINE SPEED |

## Combine Connection
- GO route separation → 40-yard dash speed
- HITCH separation → deceleration quality (measurable in tracking)
- CROSS/SLANT separation → change-of-direction (3-cone, shuttle, drill tracking)
- Overall separation → combine route drill movement patterns

## Competition Opportunity
106 WRs in dataset. Rich combine drill tracking (gauntlet, route drills).
Can we find a tracking-derived metric that predicts route-specific separation
BETTER than the raw 40 time?
