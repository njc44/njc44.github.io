# OL Pass Protection — The Invisible War

## Why It Matters
- OL pressure allowed rate: 8.2% of pass-blocking snaps
- Sack allowed rate: 0.97%
- Clean pocket: 6.4 yards, 0.00 EPA
- Pressure allowed: 2.5 yards, -0.61 EPA
- Every pressure costs the offense ~4 yards and 0.6 expected points

## The OL in This Dataset
- 121 total OL (51 G, 50 T, 20 C)
- Highest games-started rate of any position (G=11.6, T=11.2 avg)
- OL start faster than anyone — clear path to playing time
- 108K combined player-play rows — most of any position group

## Play-Level Metrics Available
- `pressure_allowed` — boolean, did this OL let a defender through?
- `sack_allowed` — did the pressure result in a sack?
- `peak_pressure_probability_allowed` — model-estimated pressure prob
- `time_to_pressure_allowed` — how long did the OL hold?
- `pass_rushers_encountered` — how many defenders attacked this gap?
- `extended_sack_allowed` — sack on long dropbacks (>4s)
- `dropback_duration` — total time from snap to throw/pressure

## Combine Connection
- Short shuttle (39% coverage) → lateral agility
- 3-cone drill (35% coverage) → change of direction
- Pass-Pro Mirror drill (OL-specific combine tracking) → direct simulation of pass blocking
- Kick-slide drill — lateral movement technique
- Pull drill — moving in space

## Competition Opportunity
NOBODY is analyzing this angle yet. The data is rich:
- 121 OL × 60K pass-blocking snaps × position-specific combine drills
- Clear binary outcome (pressure allowed: yes/no)
- Direct drill→NFL mapping (pass-pro mirror drill → pass protection)
- Scouts NEED this — OL evaluation is notoriously subjective

## Key Question
Can OL combine tracking movement patterns (lateral speed, change of direction
efficiency in mirror/shuttle drills) predict who will allow fewer pressures?
