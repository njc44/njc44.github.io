# The Scout's Decision Framework

## Context: What a Scout Actually Does

An NFL scout's job is to answer ONE question for the front office:
**"Should we spend a draft pick (or free agent money) on this player?"**

That breaks into sub-questions at each stage of evaluation:

---

## DECISION POINT 1: "Is this player athletic enough for the NFL?"

**When**: Pre-combine. Scout watches college film.
**What they're looking for**: Does the player move like an NFL player?
**Current tools**: Eye test from film. Subjective.

**At the Combine**: Stopwatch numbers provide objective baseline.
- 40-yard dash: "Is he fast enough?"
- Vertical/broad jump: "Is he explosive enough?"
- Bench press: "Is he strong enough?"
- Height/weight/arm length: "Does he have the body?"

**What tracking data could add**:
- "He ran a 4.45 forty, but HOW did he run it?"
- Two players with identical 40 times can have completely different
  acceleration profiles — one explodes off the line, the other builds gradually
- The SHAPE of the speed curve matters, not just the endpoint

### Data we have to answer this:
- `combine_tracking.csv`: 10 Hz speed, accel, direction during every drill
- `combine_results.csv`: official stopwatch times + NGS scores
- Can derive: acceleration profiles, peak speed timing, speed curve shape

---

## DECISION POINT 2: "Can this player do the specific job we need?"

**When**: Combine and pro days. Position-specific evaluation.
**What they're looking for**: Position-specific movement quality.

### For WR: "Can he get open?"
- **Sub-question**: Can he create separation on routes?
- **Combine signals**: Route drill tracking (gauntlet, curl, post-corner, slant)
- **NFL validation**: `separation_at_pass_forward`, `yards_after_catch`
- **Key physical traits**:
  - Deceleration into breaks (HITCH route demands)
  - Acceleration out of cuts (SLANT, CROSS demands)
  - Top-end speed maintenance (GO, POST demands)
  - Change-of-direction efficiency (speed retained through turns)

### For OL: "Can he protect the QB?"
- **Sub-question**: Can he mirror a pass rusher's moves?
- **Combine signals**: Pass-pro mirror drill, shuttle, 3-cone tracking
- **NFL validation**: `pressure_allowed`, `sack_allowed`, `time_to_pressure_allowed`
- **Key physical traits**:
  - Lateral slide speed and stability
  - Recovery quickness after being beaten
  - Anchor strength (holding position under force)

### For DL/EDGE: "Can he get to the QB?"
- **Sub-question**: How fast is his first step? Can he bend around the edge?
- **Combine signals**: 10-yard split tracking, DL-specific drills
- **NFL validation**: `player_get_off`, `time_to_pressure`, `sack`
- **Key physical traits**:
  - Initial burst (first 0.5 seconds)
  - Bend/flexibility at speed
  - Speed-to-power conversion

### For CB/DB: "Can he stay with receivers?"
- **Sub-question**: Can he mirror routes and close on the ball?
- **Combine signals**: Backpedal drills, transition drills, shuttle
- **NFL validation**: separation allowed (inverse of WR separation)
- **Key physical traits**:
  - Backpedal speed → forward transition
  - Hip fluidity (turning without losing speed)
  - Closing speed on the ball

---

## DECISION POINT 3: "How does he compare to other prospects at his position?"

**When**: Draft board construction (Feb-April)
**What they're looking for**: Relative ranking within position group

**Current tools**:
- Percentile ranks on combine tests (vs position group)
- College production stats
- NGS composite scores

**What tracking data could add**:
- Position-specific movement archetypes (clusters of movement patterns)
- "This WR moves like [successful NFL WR X]"
- Movement traits that separate All-Pro from replacement-level at this position

### Data we have to answer this:
- Can cluster players by movement signatures in drill tracking
- Compare to career outcomes to see which clusters succeed
- BUT: n is small (~50 per position), so clustering may be noisy

---

## DECISION POINT 4: "Is the combine performance real, or is it a workout warrior?"

**When**: Post-combine evaluation
**What they're looking for**: Does combine athleticism translate to game production?

**The classic trap**: Players who test elite at the combine but can't play.
- "He ran a 4.3 forty but can't run a route"
- "Great shuttle time but gets pushed around at the point of attack"

**What tracking data could add**:
- Compare combine movement patterns to in-game movement patterns
- Does the player move the same way in games as in drills?
- Combine top speed vs in-game top speed (Darius confirmed r=0.59-0.62 for WR/DL)
- If a player's combine drill movement DOESN'T show up in games → red flag

### Data we have to answer this:
- `combine_tracking.csv` vs `game_tracking_*.csv` for same players
- Can compute same metrics (peak speed, accel, decel) in both contexts
- "Movement transfer rate" — does drill performance predict game movement?

---

## DECISION POINT 5: "Where should we draft him?" (Draft capital allocation)

**When**: Draft day
**What they're looking for**: Is he worth a 1st round pick? 3rd? 7th?

**Current tools**:
- Composite rankings (big boards)
- Team need + scheme fit
- Risk tolerance

**What tracking data could add**:
- Movement-based ceiling/floor estimates
- "Players with this combine movement profile historically become starters
   X% of the time vs Y% for players without it"
- Incremental information beyond what the stopwatch already tells you

### Data we have to answer this:
- `draft_round`, `draft_overall_pick` in players.csv
- `career_games_started`, `total_snaps`, `pro_bowl` in career data
- Can model: P(starter | combine tracking features) vs P(starter | stopwatch only)

---

## REVERSE ENGINEERING: What Analysis Answers Multiple Decision Points?

| Analysis | Decision Points Addressed | Data Available? | Competitors Doing It? |
|---|---|---|---|
| WR decel quality → separation by route | 2, 4 | Yes (rich) | jek1 (partial) |
| OL mirror drill movement → pressure rate | 2, 3, 5 | Yes (rich) | NO |
| DL burst profile → get-off (weight-controlled) | 2, 3 | Yes (but confounded) | Darius (partial) |
| Movement transfer: combine vs game tracking | 4 | Yes (compute-heavy) | NO |
| Position-specific movement archetypes | 3, 5 | Maybe (small n) | NO |
| Reliability-adjusted predictive ceiling | 1, 5 | Yes | Darius (done) |

## THE HIGHEST-VALUE UNCLAIMED ANGLE

**OL Pass Protection** addresses 3 decision points, has rich data (121 players,
60K blocking snaps, position-specific combine drills), and NO competitor is
touching it. The scout question is simple:

> "Can this offensive lineman's combine movement predict whether he'll
> protect the quarterback in the NFL?"

This is actionable (scouts need to evaluate OL every year), novel (tracking
data in combine drills is new), and testable with the data we have.
