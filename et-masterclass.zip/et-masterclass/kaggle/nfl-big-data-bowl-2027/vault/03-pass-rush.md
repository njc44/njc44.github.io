# DL/EDGE Pass Rush — Speed to the QB

## Why It Matters
- Pressured plays: 2.5 yards, -0.61 EPA
- Clean pocket plays: 6.4 yards, 0.00 EPA
- Pressure flips a play from neutral to disaster (-0.61 point swing)

## Get-Off Time → Sack Rate
| Get-off Time | Sack Rate | n |
|---|---|---|
| <0.6s (elite) | 2.4% | 1,625 |
| 0.6-0.7s | 2.2% | 3,357 |
| 0.7-0.8s | 1.5% | 5,795 |
| 0.8-0.9s | 1.7% | 7,149 |
| 0.9-1.2s (slow) | 1.0% | 16,511 |

Elite get-off = 2.4x the sack rate of slow get-off.

## Time to Pressure
- Mean: 2.98 seconds
- Median: 2.80 seconds
- Quick pressure (<2.5s): 31% of all pressures
- A pass rusher who consistently gets there in <2.5s is a game-wrecker

## Combine Connection
- 10-yard split → first-step explosiveness → get-off time
- Darius found: raw r=0.67 for 10-yd split vs NFL get-off
- BUT: drops to r=0.35 after controlling for weight
- 84% of the variance is shared with weight (bigger = slower start, but also different role)
- DL tracking data: peak acceleration in first 1-2 seconds of drill

## Data Quality Warning
- Combine tracking first 10 yards only r=0.28 vs official time
- The 10-to-40 segment is much more reliable (r=0.95)
- Any burst metric from tracking needs to avoid the noisy first frames

## Competition Opportunity
113 DL/EDGE players. Direct combine→NFL pipeline exists but is confounded.
Could a tracking-derived burst metric (that controls for body mass) do better
than raw 10-yd split?
