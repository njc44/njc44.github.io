# Kaggle Profile

**Username**: `nathanjacob`
**Current tier**: Novice
**Target**: Expert by Oct 4, 2026

---

## Technical Background
- CV / CNN experience (classification, object detection)
- PyTorch (primary framework)
- Comfortable with DICOM, medical imaging, ViTs
- Familiar with DINOv2, transfer learning

## Existing Notebooks (all 0 upvotes)
1. Cotton Weed Detection Challenge — Starter Notebook (Oct 2025)
2. Abstraction and Reasoning Challenge (ARC) (Aug 2024)
3. Image Classification using CNN (94%+ Accuracy) (Feb 2022)
4. Object Detection — PyTorch (Jan 2022)

## Gap Analysis
- **Has**: Deep technical skills, PyTorch fluency, CV domain knowledge
- **Missing**: Kaggle engagement formula — titles, narrative, forkability, unique angles
- **Fix**: Apply the patterns from [[Upvote Patterns]] to every notebook

## Access
- Kaggle API via Composio
- Can pull notebooks, submit, check leaderboard programmatically

#kaggle #profile
