# NB3 — Lightweight Efficient Model

**Status**: Planned
**Target publish**: Sep 20, 2026
**Priority**: HIGH — underserved niche with prize-motivated audience

---

## Concept
A competitive model optimized for the **efficiency track** — first-ever RSNA prizes for low inference time and minimal hardware.

## Why This Will Get Upvotes
- Efficiency track has dedicated prize money but few community notebooks
- Ryan Holbrook's "Efficiency LB" (332 votes) provides tooling but no model — we provide the model
- Many competitors run on free Kaggle GPUs — a lightweight model is directly useful
- Fills a clear gap ([[Top Notebooks Analysis]] gap #2)

## Planned Approach
- **Backbone**: EfficientNet-B0 or distilled DINOv2-tiny
- **Optimization**: Knowledge distillation from the full DINOv2 baseline
- **Inference tricks**: TTA-lite (only 2 augmentations), INT8 quantization, ONNX export
- Show accuracy vs inference time tradeoff curve
- Benchmark on Kaggle T4 GPU

## Sections
1. Why efficiency matters (prize structure, real-world deployment)
2. Backbone comparison — DINOv2-S vs EfficientNet-B0 vs MobileNetV3
3. Knowledge distillation from the winning baseline
4. Quantization and ONNX export
5. Inference time benchmarking
6. Accuracy vs speed Pareto frontier
7. Submittable efficient pipeline

## Title Ideas
- "Fast Knee — Winning the Efficiency Track"
- "Small Model, Big Results — RSNA Knee Efficiency Baseline"
- "The Diet DINOsaur — Lightweight Knee Abnormality Detection"

#kaggle #notebook #efficiency #status/planned
