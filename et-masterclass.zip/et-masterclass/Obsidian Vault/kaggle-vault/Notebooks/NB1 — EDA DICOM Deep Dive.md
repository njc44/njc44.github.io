# NB1 — EDA DICOM Deep Dive

**Status**: ✅ PUBLISHED (v11, Sep 7 2026)
**AUC**: 0.672 (up from 0.554 in v10)
**Votes**: 1 (monitoring)
**File**: `rsna-knee-eda-dicom-deep-dive.ipynb`
**Kaggle URL**: https://www.kaggle.com/code/nathanjacob/know-your-knee-eda-dicom-deep-dive-and-baseline
**Kernel ID**: 133394167

---

## What's In v11 (56 cells)

### EDA Sections
- Full label distributions, co-occurrence heatmap, correlation matrix (12 binary targets)
- **Labeling bias warning** — 58 gold studies avg 4.14 abnormalities, not representative
- **Radiology report analysis** — sample reports, report length distribution, clinical term frequency chart
- DICOM metadata mining (300 studies): pixel spacing, slice thickness, manufacturers, field strength
- Image visualization: multi-plane views, windowing effects, normal vs abnormal, montages
- Slice-level analysis, train vs test comparison, full DICOM header reference

### NLP Label Extraction (the big v11 addition)
- `NLP_PATTERNS` dict: 12 targets × pos/neg regex patterns (English only)
- `extract_labels_from_report()` with sentence-boundary-aware negation handling
- Validated against 58 gold labels (~82% agreement)
- Merge: gold overrides NLP, NaN→0 conservative fill
- **Expansion: 58 → ~4,000+ labeled studies (75x)**

### Baseline Model
- 2.5D ResNet18, sagittal-only, 3 middle slices as RGB
- Trained on expanded NLP labels (8 epochs, 10% val split)
- AUC: 0.672 (was 0.554 with 58 gold-only)
- Produces submittable CSV

---

## What Was Fixed in v11 (from v10)
1. ✅ NLP regex label extraction from Report column (58 → 4,000+ studies)
2. ✅ Labeling bias warning added
3. ✅ Report analysis section (sample reports, clinical term frequency)
4. ✅ Chart title fix: "Top 20 Series Descriptions" → "Anatomical Plane Distribution"
5. ✅ DICOM dict key fix: `Anatomical_Plane` → `series_description`
6. ✅ Sentence-boundary fix for negation patterns (prevents cross-sentence bleed)
7. ✅ Training pipeline uses expanded labels, EPOCHS 5→8, val_split 0.15→0.10
8. ✅ Fixed model save bug (was saving every epoch regardless of improvement)
9. ✅ Updated TOC, takeaways, and what's next sections

## What Was NOT Done (deferred to NB2)
- Multilingual regex patterns (kept English-only)
- `Fluid_Sensitive` / `Fat_Suppression` analysis
- Venn diagram fix (kept as-is, cosmetic)
- Language detection

---

## Push Method
```python
# REST API push (kaggle CLI has double-encoding bug)
payload = {
    'id': 133394167,
    'title': 'Know Your Knee — EDA, DICOM Mining & Baseline',
    'text': json.dumps(nb),
    'language': 'python',
    'kernelType': 'notebook',
    'isPrivate': False,
    'enableGpu': True,
    'enableInternet': True,
    'competitionDataSources': ['rsna-knee-abnormality-detection'],
}
# POST to https://www.kaggle.com/api/v1/kernels/push
# Auth: Bearer KGAT_REDACTED
```

#kaggle #notebook #eda #status/published
