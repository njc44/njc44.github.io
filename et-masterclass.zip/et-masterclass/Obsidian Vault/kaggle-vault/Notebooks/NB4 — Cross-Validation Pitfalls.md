# NB4 — Cross-Validation Pitfalls

**Status**: Planned
**Target publish**: Sep 24, 2026
**Priority**: MEDIUM — educational, gets shared in discussions

---

## Concept
Demonstrate the +0.05 AUC gap between random folds and site-grouped folds. Show competitors their validation is broken and how to fix it.

## Why This Will Get Upvotes
- Validation strategy notebooks are rare but extremely high-signal
- The +0.05 AUC inflation from scanner memorization is a "wake-up call" insight
- Gets shared in discussion threads (secondary discovery channel)
- Educational value drives long-tail upvotes over weeks

## Key Insight
Multi-institutional data (16 sites) means different scanners, protocols, and patient populations per site. Random folds leak site identity through:
- Pixel spacing patterns
- Noise profiles
- Manufacturer-specific artifacts
- Slice thickness distributions

A model can "cheat" by recognizing which scanner took the image rather than learning pathology.

## Planned Sections
1. The problem — why random CV lies in multi-site data
2. Visualize site-level differences (pixel spacing, manufacturer, slice counts)
3. Train with random folds — show inflated AUC
4. Train with site-grouped folds — show realistic AUC
5. The gap: quantify the delta
6. Bonus: stratified-by-prevalence within site groups
7. Practical: `GroupKFold` implementation with site mapping
8. Impact on leaderboard correlation (CV vs LB scatter)

## Title Ideas
- "Your Validation Is Lying to You — CV Pitfalls in Multi-Site MRI"
- "Don't Trust Your AUC — Cross-Validation Done Right for RSNA"
- "The 0.05 AUC Lie — Why Random Folds Don't Work Here"

#kaggle #notebook #validation #status/planned
