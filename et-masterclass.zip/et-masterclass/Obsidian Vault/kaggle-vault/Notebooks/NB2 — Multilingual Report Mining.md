# NB2 — Multilingual Report Mining

**Status**: In Progress
**Target publish**: Sep 14, 2026
**Priority**: HIGH — unique angle, biggest underserved niche
**Title**: "Lost in Translation — Mining 12 Languages of Knee Reports"
**File**: `rsna-knee-multilingual-report-mining.ipynb` (to be created)

---

## Concept
Deep exploration of the multilingual radiology report dimension — the core differentiator of this competition that nobody has fully tackled. Builds directly on NB1's English-only NLP extraction (AUC 0.672).

## Why This Will Get Upvotes
- Only 1 notebook (#3, "Read the report", 251 votes) touched the NLP angle, and it didn't go deep on multilingual
- RSNA's first multimodal challenge — the audience wants to understand the text data
- Addresses the weak supervision problem (only 58 gold labels vs 4,407 report-derived labels)
- Unique angle = less competition for visibility ([[Upvote Patterns]] rule #2)
- Catchy title with pop-culture reference ([[Upvote Patterns]] rule #3)

## Key Design Decisions
1. **Language detection**: `langdetect` + character-set fallback (pure Python, <1MB)
2. **Per-language patterns, NOT translation** — translation requires large models or API calls; per-language regex is more educational and the unique differentiator
3. **English patterns always checked as fallback** — medical abbreviations (ACL, MCL) are international
4. **Confidence-weighted labels** — track pattern match count → smooth low-confidence labels toward 0.5

## Notebook Sections (~35-40 cells)
1. Title + Setup (install langdetect, load data)
2. The Problem Recap (58 vs 4,407, link to NB1)
3. **Language Detection + Distribution** — hero section, the screenshot-worthy visualization
4. English-Only Baseline (reproduce NB1 as baseline to beat)
5. **Multilingual Pattern Engine** — patterns for en/fr/de/es/pt/it/nl/ja/zh/ko/tr
6. Evaluation + Comparison (English-only vs multilingual, per-target F1, coverage gain)
7. Improved Label Merging + Submission (confidence weighting, model retraining)
8. Analysis + Wrap-up (findings, future directions, CTA)

## Languages to Cover (prioritized)
| Language | Negation | ACL term | Key vocabulary |
|----------|----------|----------|---------------|
| French | pas de, sans | LCA, ligament croisé antérieur | déchirure, rupture, intact |
| German | kein(e), ohne | VKB, vorderes Kreuzband | Riss, Ruptur, intakt |
| Spanish | sin, no se observa | LCA, ligamento cruzado anterior | rotura, desgarro, íntegro |
| Portuguese | sem, ausência de | LCA, ligamento cruzado anterior | rotura, ruptura, intacto |
| Italian | nessun, senza | LCA, legamento crociato anteriore | rottura, lesione, integro |
| Dutch | geen, zonder | VKB, voorste kruisband | scheur, ruptuur, intact |
| Japanese | なし, 認めず | 前十字靭帯, ACL | 断裂, 損傷, 正常 |
| Chinese | 未见, 无 | 前交叉韧带, ACL | 撕裂, 断裂, 正常 |

## Code Reuse from NB1
- NLP_PATTERNS (English) → becomes `en` sub-dict in MULTILINGUAL_PATTERNS
- extract_labels_from_report() → used as English-only baseline
- Gold-label validation table → add side-by-side comparison
- KneeDataset, KneeModel → same architecture, add sample weights

## Expected Results
- **AUC**: 0.69-0.72 (up from 0.672)
- **Coverage gain**: Hundreds of additional labeled studies from non-English reports
- **Per-target improvement**: Targets with low English coverage should see biggest gains

## Risks
- If >90% reports are English → frame as "even small % = hundreds of lost studies"
- langdetect misclassifies short reports → character-set fallback + English always checked
- AUC doesn't cross 0.70 → report honestly, focus on coverage gain as value-add

## Dependencies
- `langdetect` (pip install on Kaggle)
- NB1 published (done ✅)
- Competition data access (done ✅)

#kaggle #notebook #nlp #multilingual #status/in-progress
