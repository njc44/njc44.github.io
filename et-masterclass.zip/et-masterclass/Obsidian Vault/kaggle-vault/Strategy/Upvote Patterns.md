# Upvote Patterns

> 5 rules for what drives Kaggle notebook upvotes — distilled from [[Top Notebooks Analysis]] and cross-competition research

---

## The 5 Rules

### 1. "Fork it and submit" value is king
The #1 notebook (524 votes) is a complete pipeline. **Every notebook with 100+ votes produces a submittable output.** A beautiful EDA with no model caps out around 100-120 votes.

> Always end with either a working submission CSV or a reusable component.

### 2. Unique angle > incremental improvement
"Read the report, then the knee" (251 votes) beat dozens of vision-only notebooks by being the first to tackle NLP. The 10th baseline adds zero marginal value.

> Before writing, check existing notebooks. If someone already did it, skip it.

### 3. Catchy, memorable titles
**High votes**: "Bend the Knee to DinoV3", "Head and shoulders, knees and toes", "DINOsaur"
**Low votes**: "rsna-base", "RSNA Knee infer"

> Spend 5 minutes on the title. Puns, pop culture, or descriptive-but-fun phrasing.

### 4. Early publication captures the wave
Top notebooks published in the first 2 weeks (competition launched Aug 5, 2026). Late notebooks compete for a shrinking audience.

> Since we're past first-mover (week 5), target **underserved niches** where no good notebook exists yet.

### 5. EDA + baseline combo > pure EDA
"Data structure, EDA, baseline" (121 votes) outperforms pure-EDA notebooks. One notebook that explains AND gives a starting point beats two separate ones.

> If writing an EDA, always append a minimal baseline at the end.

---

## Anti-Patterns (what to avoid)

- **Inference-only notebooks** — no training code, no explanation, no upvotes
- **Incremental V2/V3/V4** — low marginal value unless there's a clear score jump
- **Pure DICOM exploration** — too narrow without a model
- **Code dumps** — no markdown narrative = no engagement
- **Late duplicates** — a baseline published after 5 already exist
- **Broken code** — errors kill trust and forks

---

## Structural Best Practices

- Table of contents for longer notebooks
- Clinical context for medical imaging (explain what ACL tear looks like)
- Professional Seaborn/Plotly styling
- Random seeds + documented versions for reproducibility
- Runs on Kaggle's free T4 GPU (don't require P100/A100)
- End with clear "Next Steps" and upvote CTA

#kaggle #strategy #patterns
