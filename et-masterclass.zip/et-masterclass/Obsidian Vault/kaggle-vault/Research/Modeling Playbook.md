# Modeling Playbook

> Winning architectures and technical insights for [[RSNA Knee Abnormality Detection]]

---

## Dominant Architecture (Pilkwang Kim, 524 votes)

```
DICOM slices → 3 slices/plane stacked as RGB → DINOv2-small → SlotHead → 12 binary outputs
```

### Pipeline
1. **Label extraction**: Regex NLP parses multilingual radiology reports → detect 12 targets + negation handling ("no ACL tear" → negative)
2. **Data pipeline**: Read DICOM headers → map series to plane → pick best series per slot (sag/cor/ax) → sample 3 slices → stack as RGB → cache as uint8
3. **Model**: DINOv2-small backbone (last N blocks unfrozen) → SlotHead with per-diagnosis attention over anatomical slots → learnable anatomical priors
4. **Training**: 10 epochs, batch 8, LR 8e-6 backbone / 1e-3 head, OneCycleLR (pct_start=0.15), rigid augmentation only (no flips — laterality matters)
5. **Inference**: Predictions → per-column rank conversion for submission

### Key Hyperparameters
```
GROUP = 3           # slices per encoder input
EPOCHS = 10
BATCH_STUDIES = 8
LR_HEAD = 1e-3
LR_BACKBONE = 8e-6
```

---

## Cross-Competition Winning Patterns (RSNA 2022-2026)

| Pattern | Details |
|---------|---------|
| **2.5D CNN** | Treat 3D volumes as sequences of 2D slices with neighbor context — wins every RSNA competition |
| **DINOv2 backbone** | Self-supervised ViT features transfer well to medical imaging |
| **Multi-plane fusion** | Different abnormalities visible in different planes |
| **Anatomical priors** | ACL/Meniscus → Sagittal, OA → Coronal, Effusion → all |
| **Site-grouped CV** | Random folds leak scanner signatures → +0.05 AUC inflation |
| **Weak supervision** | 82% report-image agreement → label noise is real |
| **No horizontal flips** | Laterality (left vs right knee) is clinically meaningful |
| **Percentile normalization** | 1st-99th percentile safer than DICOM window metadata |

---

## Validation Strategy

**Critical insight**: Site-grouped cross-validation is mandatory.

Random folds allow the model to memorize scanner-specific artifacts (pixel spacing patterns, noise profiles, manufacturer quirks) and inflate AUC by 0.05-0.136. Grouped-by-site folds simulate the test set's multi-institutional nature.

This is worth a standalone notebook — see [[NB4 — Cross-Validation Pitfalls]].

---

## Alternative Approaches Worth Exploring

| Approach | Why | Risk |
|----------|-----|------|
| **EfficientNet-B0/B2** | Lightweight, good for efficiency track | Lower accuracy ceiling |
| **ConvNeXt** | CNN with modern tricks, no ViT complexity | Less community momentum |
| **Multi-task with report text** | Jointly predict from image + text | Complex, few examples |
| **Label smoothing / mixup** | Handle weak-label noise | May hurt on gold-labeled subset |
| **Progressive resizing** | Train small → fine-tune large | Standard but effective |

#kaggle #modeling #technical
