# Kaggle Dashboard

> **Goal**: Reach **Kaggle Expert** by Oct 4, 2026 (4-week sprint starting Sep 6)

---

## Status

| Track | Requirement | Progress |
|-------|------------|----------|
| **Notebooks** | 5 bronze medals (5+ upvotes) | 0 / 5 |
| **Competitions** | 2 bronze medals (top 40%) | 0 / 2 |
| Datasets | 3 bronze medals (3+ upvotes) | -- |
| Discussions | 50 bronze medals (1+ upvote) | -- |

**Primary path**: Notebooks (most controllable)
**Parallel path**: Competition medal via RSNA Knee submission

---

## Active Competition

[[RSNA Knee Abnormality Detection]]

---

## Notebook Pipeline

| # | Notebook | Angle | Status | Target Publish |
|---|----------|-------|--------|----------------|
| 1 | [[NB1 — EDA DICOM Deep Dive]] | EDA + DICOM mining + NLP labels + baseline | **Live v10**, needs NLP expansion | Sep 8 |
| 2 | [[NB2 — Multilingual Report Mining]] | NLP on 9-12 language radiology reports | Planned | Sep 14 |
| 3 | [[NB3 — Lightweight Efficient Model]] | Efficiency track baseline | Planned | Sep 20 |
| 4 | [[NB4 — Cross-Validation Pitfalls]] | Site-grouped folds vs random | Planned | Sep 24 |
| 5 | [[NB5 — 2.5D CNN from Scratch]] | PyTorch tutorial, alternative to DINOv2 | Planned | Sep 30 |

---

## Key Resources

- [[Upvote Patterns]] — What drives notebook engagement
- [[Top Notebooks Analysis]] — Breakdown of the top 10 competition notebooks
- [[Modeling Playbook]] — Winning architectures and technical insights
- [[Profile]] — My Kaggle background and gaps

---

## Weekly Plan

### Week 1 (Sep 6-12)
- [x] Build NB1 EDA notebook (47 cells)
- [x] Get NB1 running on Kaggle (v10 complete)
- [ ] Add NLP label extraction to NB1 (expand 58 → 4,407 labels)
- [ ] Fix EDA issues (charts, Fluid/Fat analysis, labeling bias)
- [ ] Publish NB1 publicly for upvotes
- [ ] Start drafting NB2 (report mining)
- [ ] Post 2-3 discussion insights for bonus medals

### Week 2 (Sep 13-19)
- [ ] Publish NB2
- [ ] Start NB3 (efficient model)
- [ ] Submit competition baseline (target top 40%)

### Week 3 (Sep 20-26)
- [ ] Publish NB3 and NB4
- [ ] Iterate on competition submission

### Week 4 (Sep 27-Oct 4)
- [ ] Publish NB5
- [ ] Monitor upvotes, cross-promote in discussions
- [ ] Final competition submission push

---

## Technical Notes

### Kaggle API Auth
- Token: `KGAT_REDACTED`
- CLI env var: `KAGGLE_API_TOKEN=KGAT_...`
- REST API: `Authorization: Bearer KGAT_...`
- CLI v2.2.4 has double-encoding bug for notebooks — use REST API with `requests`

### NB1 Kernel
- Kernel ID: 133394167
- URL: https://www.kaggle.com/code/nathanjacob/know-your-knee-eda-dicom-deep-dive-and-baseline
- Data path on Kaggle: `/kaggle/input/competitions/rsna-knee-abnormality-detection`
- Push via REST API to `https://www.kaggle.com/api/v1/kernels/push`

### Key Competition Insights
- Only 58/4,407 studies have gold labels — rest have radiology reports
- Top approach: regex NLP to extract labels from reports (~82% agreement)
- DINOv2-small + SlotHead attention is the winning architecture
- Site-grouped CV prevents +0.05 AUC inflation
- NO horizontal flips (laterality matters)
- Percentile normalization (1-99%) > DICOM window metadata

#kaggle #dashboard
