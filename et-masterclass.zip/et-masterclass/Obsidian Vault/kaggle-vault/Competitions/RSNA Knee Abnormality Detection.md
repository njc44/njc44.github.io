# RSNA Knee Abnormality Detection

> RSNA's first **multimodal** Kaggle challenge — images + multilingual radiology reports

---

## Overview

| Field | Value |
|-------|-------|
| Deadline | Oct 22, 2026 |
| Teams | 3,215 |
| Prize | $77,000 |
| Metric | Macro ROC-AUC |
| Tracks | Standard accuracy + Efficiency (novel) |
| Host | Radiological Society of North America |
| Sites | 16 institutions across 5 continents |

---

## Task
Build ML models that detect and classify **12 knee abnormalities** from MRI scans.

### The 12 Targets

| Category | Abnormality | Best Plane |
|----------|------------|------------|
| Ligament | ACL tear | Sagittal |
| Ligament | MCL tear | Coronal |
| Meniscus | Medial Meniscus tear | Sagittal |
| Meniscus | Lateral Meniscus tear | Sagittal |
| Arthritis | Medial OA | Coronal |
| Arthritis | Lateral OA | Coronal |
| Arthritis | PF OA | Axial |
| Other | Effusion | All planes |
| Other | Synovitis | All planes |
| Other | Baker's cyst | Axial/Sagittal |
| Trauma | Contusion | All planes |
| Trauma | Fracture | All planes |

---

## Data

- **~5,000 knee MRI exams**, 819,000+ DICOM files
- **3 anatomical planes**: Sagittal, Coronal, Axial
- **Weak supervision**: Only 58 of 4,407 training studies have gold labels; rest rely on radiology reports (~82% agreement with image labels)
- **Multilingual reports**: 9-12 languages from 16 sites
- **Files**: `train.csv`, `test.csv`, `train_series.csv`, `test_series.csv`, `sample_submission.csv`, DICOM directories

### Key Data Challenges
- Significant class imbalance (Fracture and Contusion are rare)
- Strong co-occurrence patterns (ACL tear + contusion + effusion)
- Variable image dimensions, pixel spacing, slice thickness across scanners
- Multi-institutional scanner variation (domain shift)

---

## Leaderboard (Sep 6, 2026)

| Metric | Value |
|--------|-------|
| Top score | 0.954 |
| Top 20 range | 0.948 – 0.954 |
| Bronze cutoff (~top 40%) | ~rank 1,286 |

---

## Winning Approaches

See [[Modeling Playbook]] for full technical details.

**Dominant stack**: DINOv2 backbone + multi-plane slot attention + weak supervision from reports

---

## My Notebooks for This Competition

- [[NB1 — EDA DICOM Deep Dive]]
- [[NB2 — Multilingual Report Mining]]
- [[NB3 — Lightweight Efficient Model]]
- [[NB4 — Cross-Validation Pitfalls]]
- [[NB5 — 2.5D CNN from Scratch]]

See also: [[Top Notebooks Analysis]]

#kaggle #competition #rsna #medical-imaging
